<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QEDT_Bulk {
    /**
     * Initialize class hooks.
     *
     * @return void
     */
    public static function init() {
        // No hooks needed currently.
    }

    /**
     * Build bulk action preview.
     *
     * @param array  $product_ids Product IDs.
     * @param string $action      Action key.
     * @param array  $payload     Payload.
     * @return array|WP_Error
     */
    public static function preview( $product_ids, $action, $payload ) {
        $product_ids = qedt_sanitize_int_list( $product_ids );
        if ( empty( $product_ids ) ) {
            return new WP_Error( 'empty_products', __( 'No products selected.', 'quick-edit' ) );
        }

        $action  = sanitize_key( $action );
        $payload = is_array( $payload ) ? $payload : array();

        $affected = 0;
        $sample   = array();

        foreach ( $product_ids as $product_id ) {
            $product = wc_get_product( $product_id );
            if ( ! $product ) {
                continue;
            }

            $affected++;
            if ( count( $sample ) < 10 ) {
                $sample[] = self::preview_row( $product, $action, $payload );
            }
        }

        return array(
            'affected' => $affected,
            'sample'   => $sample,
        );
    }

    /**
     * Apply bulk operation to selected products.
     *
     * @param array  $product_ids Product IDs.
     * @param string $action      Action key.
     * @param array  $payload     Payload.
     * @return array|WP_Error
     */
    public static function apply( $product_ids, $action, $payload ) {
        global $wpdb;

        $product_ids = qedt_sanitize_int_list( $product_ids );
        if ( empty( $product_ids ) ) {
            return new WP_Error( 'empty_products', __( 'No products selected.', 'quick-edit' ) );
        }

        $action  = sanitize_key( $action );
        $payload = is_array( $payload ) ? $payload : array();

        $settings = qedt_get_settings();
        if ( ! empty( $settings['auto_backup'] ) ) {
            self::create_backup_snapshot( $product_ids );
        }

        $transaction_started = false;
        $wpdb->query( 'START TRANSACTION' );
        if ( '' === $wpdb->last_error ) {
            $transaction_started = true;
        }

        $success = 0;
        $failed  = array();

        foreach ( array_chunk( $product_ids, 25 ) as $chunk ) {
            foreach ( $chunk as $product_id ) {
                $result = self::apply_to_product( $product_id, $action, $payload );

                if ( is_wp_error( $result ) ) {
                    $failed[] = array(
                        'product_id' => $product_id,
                        'reason'     => $result->get_error_message(),
                    );
                } else {
                    $success++;
                }
            }
        }

        if ( $transaction_started ) {
            if ( empty( $failed ) ) {
                $wpdb->query( 'COMMIT' );
            } else {
                $wpdb->query( 'ROLLBACK' );
            }
        }

        return array(
            'success_count' => $success,
            'failed_rows'   => $failed,
            'rolled_back'   => $transaction_started && ! empty( $failed ),
        );
    }

    /**
     * Build one preview row.
     *
     * @param WC_Product $product Product.
     * @param string     $action  Action key.
     * @param array      $payload Payload.
     * @return array
     */
    protected static function preview_row( $product, $action, $payload ) {
        $row = array(
            'id'   => $product->get_id(),
            'name' => $product->get_name(),
            'from' => '',
            'to'   => '',
        );

        switch ( $action ) {
            case 'regular_price_adjust':
                $row['from'] = $product->get_regular_price();
                $row['to']   = self::calculate_price( $product->get_regular_price(), $payload );
                break;
            case 'sale_price_adjust':
                $row['from'] = $product->get_sale_price();
                $row['to']   = self::calculate_price( $product->get_sale_price(), $payload );
                break;
            case 'set_stock_quantity':
                $row['from'] = $product->get_stock_quantity();
                $row['to']   = isset( $payload['quantity'] ) ? (int) $payload['quantity'] : 0;
                break;
            case 'change_stock_status':
                $row['from'] = $product->get_stock_status();
                $row['to']   = sanitize_key( $payload['stock_status'] ?? '' );
                break;
            case 'change_status':
                $row['from'] = get_post_status( $product->get_id() );
                $row['to']   = sanitize_key( $payload['status'] ?? '' );
                break;
            case 'toggle_featured':
                $row['from'] = $product->is_featured() ? 1 : 0;
                $row['to']   = ! empty( $payload['featured'] ) ? 1 : 0;
                break;
            case 'delete_products':
                $row['from'] = __( 'Existing', 'quick-edit' );
                $row['to']   = __( 'Deleted', 'quick-edit' );
                break;
            case 'duplicate_products':
                $row['from'] = $product->get_name();
                $row['to']   = $product->get_name() . ' (Copy)';
                break;
            default:
                $row['from'] = __( 'Current', 'quick-edit' );
                $row['to']   = __( 'Updated', 'quick-edit' );
                break;
        }

        return $row;
    }

    /**
     * Apply action to one product.
     *
     * @param int    $product_id Product ID.
     * @param string $action     Action key.
     * @param array  $payload    Payload.
     * @return true|WP_Error
     */
    protected static function apply_to_product( $product_id, $action, $payload ) {
        $product = wc_get_product( $product_id );
        if ( ! $product ) {
            return new WP_Error( 'missing_product', __( 'Product not found.', 'quick-edit' ) );
        }

        switch ( $action ) {
            case 'regular_price_adjust':
                $new_price = self::calculate_price( $product->get_regular_price(), $payload );
                $result    = QEDT_Editor::save_rows(
                    array(
                        $product_id => array(
                            'regular_price' => $new_price,
                        ),
                    )
                );
                return empty( $result['failed_rows'] ) ? true : new WP_Error( 'price_update_error', $result['failed_rows'][0]['reason'] );

            case 'sale_price_adjust':
                $new_sale = self::calculate_price( $product->get_sale_price(), $payload );
                $result   = QEDT_Editor::save_rows(
                    array(
                        $product_id => array(
                            'sale_price' => $new_sale,
                        ),
                    )
                );
                return empty( $result['failed_rows'] ) ? true : new WP_Error( 'sale_update_error', $result['failed_rows'][0]['reason'] );

            case 'set_stock_quantity':
                $qty    = isset( $payload['quantity'] ) ? (int) $payload['quantity'] : 0;
                $result = QEDT_Editor::save_rows(
                    array(
                        $product_id => array(
                            'stock_quantity' => $qty,
                        ),
                    )
                );
                return empty( $result['failed_rows'] ) ? true : new WP_Error( 'stock_error', $result['failed_rows'][0]['reason'] );

            case 'change_stock_status':
                $status = sanitize_key( $payload['stock_status'] ?? '' );
                $result = QEDT_Editor::save_rows(
                    array(
                        $product_id => array(
                            'stock_status' => $status,
                        ),
                    )
                );
                return empty( $result['failed_rows'] ) ? true : new WP_Error( 'stock_status_error', $result['failed_rows'][0]['reason'] );

            case 'assign_category':
                $term_ids = qedt_sanitize_int_list( $payload['category_ids'] ?? array() );
                wp_set_object_terms( $product_id, $term_ids, 'product_cat', true );
                return true;

            case 'remove_category':
                $term_ids = qedt_sanitize_int_list( $payload['category_ids'] ?? array() );
                $existing = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
                $new_ids  = array_diff( array_map( 'absint', $existing ), $term_ids );
                wp_set_object_terms( $product_id, $new_ids, 'product_cat', false );
                return true;

            case 'assign_tag':
                $tags = array_filter( array_map( 'sanitize_text_field', (array) ( $payload['tags'] ?? array() ) ) );
                wp_set_object_terms( $product_id, $tags, 'product_tag', true );
                return true;

            case 'remove_tag':
                $remove = array_filter( array_map( 'sanitize_text_field', (array) ( $payload['tags'] ?? array() ) ) );
                $tags   = wp_get_post_terms( $product_id, 'product_tag', array( 'fields' => 'names' ) );
                $tags   = array_diff( $tags, $remove );
                wp_set_object_terms( $product_id, $tags, 'product_tag', false );
                return true;

            case 'change_status':
                $status = sanitize_key( $payload['status'] ?? 'draft' );
                wp_update_post(
                    array(
                        'ID'          => $product_id,
                        'post_status' => $status,
                    )
                );
                return true;

            case 'toggle_featured':
                $featured = ! empty( $payload['featured'] );
                $product->set_featured( $featured );
                $product->save();
                return true;

            case 'delete_products':
                $deleted = wp_delete_post( $product_id, true );
                if ( ! $deleted ) {
                    return new WP_Error( 'delete_failed', __( 'Failed to delete product.', 'quick-edit' ) );
                }
                return true;

            case 'duplicate_products':
                $new_id = self::duplicate_product( $product_id );
                if ( is_wp_error( $new_id ) ) {
                    return $new_id;
                }
                return true;

            default:
                return new WP_Error( 'invalid_action', __( 'Invalid bulk action.', 'quick-edit' ) );
        }
    }

    /**
     * Price adjustment helper.
     *
     * @param string|float $current Current price.
     * @param array        $payload Action payload.
     * @return string
     */
    protected static function calculate_price( $current, $payload ) {
        $current = (float) $current;
        $mode    = sanitize_key( $payload['mode'] ?? 'fixed' );
        $op      = sanitize_key( $payload['operation'] ?? 'increase' );
        $value   = (float) ( $payload['value'] ?? 0 );

        if ( 'percent' === $mode ) {
            $delta = ( $current * $value ) / 100;
        } else {
            $delta = $value;
        }

        $new = 'decrease' === $op ? $current - $delta : $current + $delta;
        if ( $new < 0 ) {
            $new = 0;
        }

        return wc_format_decimal( $new );
    }

    /**
     * Create backup snapshot before bulk edit.
     *
     * @param array $product_ids Product IDs.
     * @return void
     */
    protected static function create_backup_snapshot( $product_ids ) {
        $snapshot = array();
        foreach ( $product_ids as $product_id ) {
            $product = wc_get_product( $product_id );
            if ( ! $product ) {
                continue;
            }
            $snapshot[ $product_id ] = array(
                'name'          => $product->get_name(),
                'regular_price' => $product->get_regular_price(),
                'sale_price'    => $product->get_sale_price(),
                'stock_qty'     => $product->get_stock_quantity(),
                'stock_status'  => $product->get_stock_status(),
                'status'        => get_post_status( $product_id ),
                'featured'      => $product->is_featured(),
                'categories'    => wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) ),
                'tags'          => wp_get_post_terms( $product_id, 'product_tag', array( 'fields' => 'names' ) ),
            );
        }

        set_transient( 'qedt_bulk_backup_' . get_current_user_id(), $snapshot, HOUR_IN_SECONDS );
    }

    /**
     * Duplicate a product.
     *
     * @param int $product_id Product ID.
     * @return int|WP_Error
     */
    protected static function duplicate_product( $product_id ) {
        $post = get_post( $product_id );
        if ( ! $post || 'product' !== $post->post_type ) {
            return new WP_Error( 'invalid_product', __( 'Invalid product for duplication.', 'quick-edit' ) );
        }

        $new_post = array(
            'post_author'    => get_current_user_id(),
            'post_content'   => $post->post_content,
            'post_excerpt'   => $post->post_excerpt,
            'post_title'     => $post->post_title . ' (Copy)',
            'post_status'    => 'draft',
            'post_type'      => 'product',
            'post_parent'    => 0,
            'menu_order'     => $post->menu_order,
            'comment_status' => $post->comment_status,
            'ping_status'    => $post->ping_status,
        );

        $new_id = wp_insert_post( $new_post, true );
        if ( is_wp_error( $new_id ) ) {
            return $new_id;
        }

        $meta = get_post_meta( $product_id );
        foreach ( $meta as $key => $values ) {
            if ( '_sku' === $key ) {
                continue;
            }
            foreach ( $values as $value ) {
                add_post_meta( $new_id, $key, maybe_unserialize( $value ) );
            }
        }

        $taxonomies = array( 'product_cat', 'product_tag', 'product_type', 'product_visibility' );
        foreach ( $taxonomies as $taxonomy ) {
            $terms = wp_get_object_terms( $product_id, $taxonomy, array( 'fields' => 'ids' ) );
            if ( ! is_wp_error( $terms ) ) {
                wp_set_object_terms( $new_id, $terms, $taxonomy, false );
            }
        }

        return $new_id;
    }
}
