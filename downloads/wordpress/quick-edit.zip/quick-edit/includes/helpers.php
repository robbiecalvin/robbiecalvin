<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Check WooCommerce availability.
 *
 * @return bool
 */
function qedt_is_woocommerce_active() {
    if ( class_exists( 'WooCommerce' ) ) {
        return true;
    }

    if ( ! function_exists( 'is_plugin_active' ) ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    return is_plugin_active( 'woocommerce/woocommerce.php' );
}

/**
 * Get plugin settings with defaults.
 *
 * @return array
 */
function qedt_get_settings() {
    $defaults = array(
        'default_rows_per_page' => 50,
        'inline_columns'        => array(
            'name',
            'sku',
            'regular_price',
            'sale_price',
            'stock_quantity',
            'stock_status',
            'product_status',
            'featured',
            'categories',
            'tags',
            'visibility',
            'short_description',
            'weight',
            'dimensions',
        ),
        'advanced_mode'         => 0,
        'custom_meta_keys'      => '',
        'revision_logging'      => 0,
        'auto_backup'           => 0,
    );

    $settings = get_option( 'qedt_settings', array() );
    if ( ! is_array( $settings ) ) {
        $settings = array();
    }

    return wp_parse_args( $settings, $defaults );
}

/**
 * Sanitize int list.
 *
 * @param mixed $value Input.
 * @return array
 */
function qedt_sanitize_int_list( $value ) {
    if ( is_string( $value ) ) {
        $value = explode( ',', $value );
    }

    if ( ! is_array( $value ) ) {
        return array();
    }

    $items = array_map( 'absint', $value );
    $items = array_filter( $items );

    return array_values( array_unique( $items ) );
}

/**
 * Normalize boolish input.
 *
 * @param mixed $value Input.
 * @return bool
 */
function qedt_to_bool( $value ) {
    if ( is_bool( $value ) ) {
        return $value;
    }

    if ( is_numeric( $value ) ) {
        return (int) $value === 1;
    }

    if ( is_string( $value ) ) {
        return in_array( strtolower( $value ), array( '1', 'true', 'yes', 'on' ), true );
    }

    return false;
}

/**
 * Parse numeric value; returns null when empty.
 *
 * @param mixed $value Input.
 * @return float|int|null
 */
function qedt_parse_number( $value ) {
    if ( '' === $value || null === $value ) {
        return null;
    }

    if ( is_string( $value ) ) {
        $value = str_replace( ',', '.', $value );
    }

    if ( ! is_numeric( $value ) ) {
        return null;
    }

    return 0 + $value;
}

/**
 * Get available catalog visibility options.
 *
 * @return array
 */
function qedt_visibility_options() {
    return array(
        'visible' => __( 'Catalog/Search', 'quick-edit' ),
        'catalog' => __( 'Catalog', 'quick-edit' ),
        'search'  => __( 'Search', 'quick-edit' ),
        'hidden'  => __( 'Hidden', 'quick-edit' ),
    );
}

/**
 * Table name for revision log.
 *
 * @return string
 */
function qedt_log_table_name() {
    global $wpdb;

    return $wpdb->prefix . 'quick_edit_log';
}
