<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QEDT_Logger {
    /**
     * Initialize logger hooks.
     *
     * @return void
     */
    public static function init() {
        add_action( 'admin_notices', array( __CLASS__, 'maybe_wc_missing_notice' ) );
    }

    /**
     * Show activation WooCommerce warning.
     *
     * @return void
     */
    public static function maybe_wc_missing_notice() {
        if ( ! get_transient( 'qedt_wc_missing_notice' ) ) {
            return;
        }

        delete_transient( 'qedt_wc_missing_notice' );

        echo '<div class="notice notice-error"><p>' . esc_html__( 'Quick Edit was deactivated because WooCommerce is not active.', 'quick-edit' ) . '</p></div>';
    }

    /**
     * Create log table when needed.
     *
     * @return void
     */
    public static function maybe_create_table() {
        global $wpdb;

        $table_name      = qedt_log_table_name();
        $charset_collate = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $sql = "CREATE TABLE {$table_name} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            product_id BIGINT UNSIGNED NOT NULL,
            field_name VARCHAR(191) NOT NULL,
            old_value LONGTEXT NULL,
            new_value LONGTEXT NULL,
            edited_by BIGINT UNSIGNED NOT NULL,
            edited_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY product_id (product_id),
            KEY edited_at (edited_at)
        ) {$charset_collate};";

        dbDelta( $sql );
    }

    /**
     * Log a change entry.
     *
     * @param int    $product_id Product ID.
     * @param string $field      Field name.
     * @param mixed  $old_value  Old value.
     * @param mixed  $new_value  New value.
     * @return void
     */
    public static function log_change( $product_id, $field, $old_value, $new_value ) {
        $settings = qedt_get_settings();
        if ( empty( $settings['revision_logging'] ) ) {
            return;
        }

        global $wpdb;

        $wpdb->insert(
            qedt_log_table_name(),
            array(
                'product_id' => absint( $product_id ),
                'field_name' => sanitize_key( $field ),
                'old_value'  => maybe_serialize( $old_value ),
                'new_value'  => maybe_serialize( $new_value ),
                'edited_by'  => get_current_user_id(),
                'edited_at'  => current_time( 'mysql' ),
            ),
            array( '%d', '%s', '%s', '%s', '%d', '%s' )
        );
    }

    /**
     * Get product history records.
     *
     * @param int $product_id Product ID.
     * @param int $limit      Row limit.
     * @return array
     */
    public static function get_history( $product_id, $limit = 50 ) {
        global $wpdb;

        $sql = $wpdb->prepare(
            'SELECT id, product_id, field_name, old_value, new_value, edited_by, edited_at FROM ' . qedt_log_table_name() . ' WHERE product_id = %d ORDER BY id DESC LIMIT %d',
            absint( $product_id ),
            absint( $limit )
        );

        $rows = $wpdb->get_results( $sql, ARRAY_A );
        if ( ! is_array( $rows ) ) {
            return array();
        }

        foreach ( $rows as &$row ) {
            $row['old_value'] = maybe_unserialize( $row['old_value'] );
            $row['new_value'] = maybe_unserialize( $row['new_value'] );
        }

        return $rows;
    }

    /**
     * Revert one logged field change.
     *
     * @param int $log_id Log row ID.
     * @return true|WP_Error
     */
    public static function revert_change( $log_id ) {
        global $wpdb;

        $log_id = absint( $log_id );
        if ( ! $log_id ) {
            return new WP_Error( 'invalid_log', __( 'Invalid log entry.', 'quick-edit' ) );
        }

        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . qedt_log_table_name() . ' WHERE id = %d', $log_id ), ARRAY_A );
        if ( ! $row ) {
            return new WP_Error( 'missing_log', __( 'Log entry not found.', 'quick-edit' ) );
        }

        $product = wc_get_product( (int) $row['product_id'] );
        if ( ! $product ) {
            return new WP_Error( 'missing_product', __( 'Product not found.', 'quick-edit' ) );
        }

        $old = maybe_unserialize( $row['old_value'] );

        switch ( $row['field_name'] ) {
            case 'name':
                wp_update_post(
                    array(
                        'ID'         => $product->get_id(),
                        'post_title' => wp_strip_all_tags( (string) $old ),
                    )
                );
                break;
            case 'short_description':
                wp_update_post(
                    array(
                        'ID'           => $product->get_id(),
                        'post_excerpt' => wp_kses_post( (string) $old ),
                    )
                );
                break;
            case 'regular_price':
                $product->set_regular_price( '' === (string) $old ? '' : wc_format_decimal( $old ) );
                $product->save();
                break;
            case 'sale_price':
                $product->set_sale_price( '' === (string) $old ? '' : wc_format_decimal( $old ) );
                $product->save();
                break;
            case 'stock_quantity':
                wc_update_product_stock( $product, null === $old ? null : (int) $old, 'set' );
                break;
            case 'stock_status':
                $product->set_stock_status( sanitize_key( (string) $old ) );
                $product->save();
                break;
            default:
                update_post_meta( $product->get_id(), sanitize_key( $row['field_name'] ), $old );
                break;
        }

        self::log_change( $product->get_id(), 'revert_' . sanitize_key( $row['field_name'] ), $row['new_value'], $row['old_value'] );

        return true;
    }
}
