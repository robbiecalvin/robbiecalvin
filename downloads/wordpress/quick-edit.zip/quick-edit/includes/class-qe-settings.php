<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QEDT_Settings {
    /**
     * Initialize settings hooks.
     *
     * @return void
     */
    public static function init() {
        add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
    }

    /**
     * Register plugin settings.
     *
     * @return void
     */
    public static function register_settings() {
        register_setting( 'qedt_settings_group', 'qedt_settings', array( __CLASS__, 'sanitize' ) );

        add_settings_section(
            'qedt_general_section',
            __( 'General Settings', 'quick-edit' ),
            '__return_false',
            'qe-settings'
        );

        add_settings_field(
            'default_rows_per_page',
            __( 'Default Rows Per Page', 'quick-edit' ),
            array( __CLASS__, 'render_default_rows_field' ),
            'qe-settings',
            'qedt_general_section'
        );

        add_settings_field(
            'inline_columns',
            __( 'Inline Editable Columns', 'quick-edit' ),
            array( __CLASS__, 'render_inline_columns_field' ),
            'qe-settings',
            'qedt_general_section'
        );

        add_settings_field(
            'advanced_mode',
            __( 'Advanced Mode', 'quick-edit' ),
            array( __CLASS__, 'render_advanced_mode_field' ),
            'qe-settings',
            'qedt_general_section'
        );

        add_settings_field(
            'custom_meta_keys',
            __( 'Custom Meta Keys', 'quick-edit' ),
            array( __CLASS__, 'render_custom_meta_keys_field' ),
            'qe-settings',
            'qedt_general_section'
        );

        add_settings_field(
            'revision_logging',
            __( 'Enable Revision Logging', 'quick-edit' ),
            array( __CLASS__, 'render_revision_logging_field' ),
            'qe-settings',
            'qedt_general_section'
        );

        add_settings_field(
            'auto_backup',
            __( 'Auto Backup Before Bulk Edits', 'quick-edit' ),
            array( __CLASS__, 'render_auto_backup_field' ),
            'qe-settings',
            'qedt_general_section'
        );
    }

    /**
     * Sanitize settings input.
     *
     * @param array $input Raw input.
     * @return array
     */
    public static function sanitize( $input ) {
        $settings = qedt_get_settings();

        $rows = isset( $input['default_rows_per_page'] ) ? absint( $input['default_rows_per_page'] ) : $settings['default_rows_per_page'];
        if ( ! in_array( $rows, array( 25, 50, 100 ), true ) ) {
            $rows = 50;
        }

        $allowed_columns = self::editable_columns();
        $inline_columns  = isset( $input['inline_columns'] ) && is_array( $input['inline_columns'] ) ? array_map( 'sanitize_key', $input['inline_columns'] ) : array();
        $inline_columns  = array_values( array_intersect( $inline_columns, array_keys( $allowed_columns ) ) );

        $advanced_mode    = ! empty( $input['advanced_mode'] ) ? 1 : 0;
        $revision_logging = ! empty( $input['revision_logging'] ) ? 1 : 0;
        $auto_backup      = ! empty( $input['auto_backup'] ) ? 1 : 0;
        $custom_meta_keys = isset( $input['custom_meta_keys'] ) ? sanitize_text_field( $input['custom_meta_keys'] ) : '';

        if ( $revision_logging ) {
            QEDT_Logger::maybe_create_table();
        }

        return array(
            'default_rows_per_page' => $rows,
            'inline_columns'        => $inline_columns,
            'advanced_mode'         => $advanced_mode,
            'custom_meta_keys'      => $custom_meta_keys,
            'revision_logging'      => $revision_logging,
            'auto_backup'           => $auto_backup,
        );
    }

    /**
     * Editable columns list.
     *
     * @return array
     */
    public static function editable_columns() {
        return array(
            'name'              => __( 'Product Name', 'quick-edit' ),
            'sku'               => __( 'SKU', 'quick-edit' ),
            'regular_price'     => __( 'Regular Price', 'quick-edit' ),
            'sale_price'        => __( 'Sale Price', 'quick-edit' ),
            'stock_quantity'    => __( 'Stock Quantity', 'quick-edit' ),
            'stock_status'      => __( 'Stock Status', 'quick-edit' ),
            'product_status'    => __( 'Product Status', 'quick-edit' ),
            'featured'          => __( 'Featured', 'quick-edit' ),
            'categories'        => __( 'Category', 'quick-edit' ),
            'tags'              => __( 'Tags', 'quick-edit' ),
            'visibility'        => __( 'Visibility', 'quick-edit' ),
            'short_description' => __( 'Short Description', 'quick-edit' ),
            'weight'            => __( 'Weight', 'quick-edit' ),
            'dimensions'        => __( 'Dimensions', 'quick-edit' ),
        );
    }

    public static function render_default_rows_field() {
        $settings = qedt_get_settings();
        ?>
        <select name="qedt_settings[default_rows_per_page]">
            <option value="25" <?php selected( 25, (int) $settings['default_rows_per_page'] ); ?>>25</option>
            <option value="50" <?php selected( 50, (int) $settings['default_rows_per_page'] ); ?>>50</option>
            <option value="100" <?php selected( 100, (int) $settings['default_rows_per_page'] ); ?>>100</option>
        </select>
        <?php
    }

    public static function render_inline_columns_field() {
        $settings = qedt_get_settings();
        $columns  = self::editable_columns();

        foreach ( $columns as $key => $label ) {
            ?>
            <label style="display:inline-block; min-width:220px; margin:0 0 8px 0;">
                <input type="checkbox" name="qedt_settings[inline_columns][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $settings['inline_columns'], true ) ); ?> />
                <?php echo esc_html( $label ); ?>
            </label>
            <?php
        }
    }

    public static function render_advanced_mode_field() {
        $settings = qedt_get_settings();
        ?>
        <label>
            <input type="checkbox" name="qedt_settings[advanced_mode]" value="1" <?php checked( 1, (int) $settings['advanced_mode'] ); ?> />
            <?php esc_html_e( 'Expose custom meta keys in Product Editor.', 'quick-edit' ); ?>
        </label>
        <?php
    }

    public static function render_custom_meta_keys_field() {
        $settings = qedt_get_settings();
        ?>
        <input type="text" class="regular-text" name="qedt_settings[custom_meta_keys]" value="<?php echo esc_attr( $settings['custom_meta_keys'] ); ?>" />
        <p class="description"><?php esc_html_e( 'Comma-separated list of custom meta keys shown in Advanced Mode.', 'quick-edit' ); ?></p>
        <?php
    }

    public static function render_revision_logging_field() {
        $settings = qedt_get_settings();
        ?>
        <label>
            <input type="checkbox" name="qedt_settings[revision_logging]" value="1" <?php checked( 1, (int) $settings['revision_logging'] ); ?> />
            <?php esc_html_e( 'Store product edit history.', 'quick-edit' ); ?>
        </label>
        <?php
    }

    public static function render_auto_backup_field() {
        $settings = qedt_get_settings();
        ?>
        <label>
            <input type="checkbox" name="qedt_settings[auto_backup]" value="1" <?php checked( 1, (int) $settings['auto_backup'] ); ?> />
            <?php esc_html_e( 'Create a transient snapshot before bulk edits.', 'quick-edit' ); ?>
        </label>
        <?php
    }
}
