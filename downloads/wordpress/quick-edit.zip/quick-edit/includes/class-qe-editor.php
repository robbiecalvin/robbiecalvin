<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QEDT_Editor {
    /**
     * Init class hooks.
     *
     * @return void
     */
    public static function init() {
        // Intentionally empty. Kept for future hooks.
    }

    /**
     * Get filters list with lightweight caching.
     *
     * @return array
     */
    public static function get_filter_data() {
        $cache_key = 'qedt_filter_data_v1';
        $cached    = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $categories = get_terms(
            array(
                'taxonomy'   => 'product_cat',
                'hide_empty' => false,
                'fields'     => 'id=>name',
            )
        );

        $tags = get_terms(
            array(
                'taxonomy'   => 'product_tag',
                'hide_empty' => false,
                'fields'     => 'id=>name',
                'number'     => 500,
            )
        );

        $data = array(
            'categories'    => is_array( $categories ) ? $categories : array(),
            'tags'          => is_array( $tags ) ? $tags : array(),
            'stock_status'  => wc_get_product_stock_status_options(),
            'product_types' => array(
                'simple'   => __( 'Simple', 'quick-edit' ),
                'variable' => __( 'Variable', 'quick-edit' ),
            ),
            'visibility'    => qedt_visibility_options(),
        );

        set_transient( $cache_key, $data, 5 * MINUTE_IN_SECONDS );

        return $data;
    }

    /**
     * Query products with server-side pagination.
     *
     * @param array $args Query args.
     * @return array
     */
    public static function query_products( $args ) {
        $defaults = array(
            'paged'        => 1,
            'per_page'     => 50,
            'category'     => 0,
            'stock_status' => '',
            'product_type' => '',
            'search'       => '',
        );

        $args = wp_parse_args( $args, $defaults );

        $paged    = max( 1, absint( $args['paged'] ) );
        $per_page = absint( $args['per_page'] );
        if ( ! in_array( $per_page, array( 25, 50, 100 ), true ) ) {
            $per_page = 50;
        }

        $query_args = array(
            'limit'   => -1,
            'status'  => array( 'publish', 'draft' ),
            'type'    => array( 'simple', 'variable' ),
            'orderby' => 'ID',
            'order'   => 'DESC',
            'return'  => 'ids',
        );

        if ( ! empty( $args['search'] ) ) {
            $query_args['search'] = '*' . wc_clean( wp_unslash( $args['search'] ) ) . '*';
        }

        if ( ! empty( $args['category'] ) ) {
            $term = get_term( absint( $args['category'] ), 'product_cat' );
            if ( $term && ! is_wp_error( $term ) ) {
                $query_args['category'] = array( (string) $term->slug );
            }
        }

        if ( ! empty( $args['stock_status'] ) ) {
            $query_args['stock_status'] = sanitize_key( $args['stock_status'] );
        }

        if ( ! empty( $args['product_type'] ) && in_array( $args['product_type'], array( 'simple', 'variable' ), true ) ) {
            $query_args['type'] = array( sanitize_key( $args['product_type'] ) );
        }

        $product_ids = array_values( array_map( 'absint', (array) wc_get_products( $query_args ) ) );
        $total       = count( $product_ids );

        if ( empty( $product_ids ) ) {
            return array(
                'rows'        => array(),
                'pagination'  => array(
                    'paged'      => $paged,
                    'per_page'   => $per_page,
                    'total'      => 0,
                    'total_page' => 0,
                ),
                'filters'     => self::get_filter_data(),
                'settings'    => qedt_get_settings(),
                'notice'      => __( 'No products matched the current filters.', 'quick-edit' ),
            );
        }
        $offset    = ( $paged - 1 ) * $per_page;
        $product_ids = array_slice( $product_ids, $offset, $per_page );

        $rows     = array();
        $settings = qedt_get_settings();

        foreach ( $product_ids as $product_id ) {
            $product = wc_get_product( $product_id );
            if ( ! $product ) {
                continue;
            }

            $rows[] = self::format_product_row( $product, $settings );
        }

        return array(
            'rows'        => $rows,
            'pagination'  => array(
                'paged'      => $paged,
                'per_page'   => $per_page,
                'total'      => $total,
                'total_page' => (int) ceil( $total / $per_page ),
            ),
            'filters'     => self::get_filter_data(),
            'settings'    => $settings,
        );
    }

    /**
     * Format product for editor table.
     *
     * @param WC_Product $product Product object.
     * @param array      $settings Plugin settings.
     * @return array
     */
    public static function format_product_row( $product, $settings ) {
        $product_id = $product->get_id();
        $thumb_id   = $product->get_image_id();
        $thumb_url  = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'thumbnail' ) : '';

        $categories = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
        $tag_names  = wp_get_post_terms( $product_id, 'product_tag', array( 'fields' => 'names' ) );

        $custom_meta = array();
        if ( ! empty( $settings['advanced_mode'] ) && ! empty( $settings['custom_meta_keys'] ) ) {
            $keys = array_filter( array_map( 'trim', explode( ',', $settings['custom_meta_keys'] ) ) );
            foreach ( $keys as $meta_key ) {
                $safe_key               = sanitize_key( $meta_key );
                $custom_meta[ $safe_key ] = get_post_meta( $product_id, $safe_key, true );
            }
        }

        return array(
            'id'                => $product_id,
            'thumbnail'         => $thumb_url,
            'name'              => $product->get_name(),
            'sku'               => $product->get_sku(),
            'regular_price'     => $product->get_regular_price(),
            'sale_price'        => $product->get_sale_price(),
            'stock_quantity'    => $product->get_stock_quantity(),
            'stock_status'      => $product->get_stock_status(),
            'product_status'    => get_post_status( $product_id ),
            'featured'          => $product->is_featured() ? 1 : 0,
            'categories'        => array_map( 'absint', (array) $categories ),
            'tags'              => implode( ', ', (array) $tag_names ),
            'visibility'        => $product->get_catalog_visibility(),
            'short_description' => $product->get_short_description(),
            'weight'            => $product->get_weight(),
            'length'            => $product->get_length(),
            'width'             => $product->get_width(),
            'height'            => $product->get_height(),
            'custom_meta'       => $custom_meta,
        );
    }

    /**
     * Save modified rows only.
     *
     * @param array $rows Modified rows.
     * @return array
     */
    public static function save_rows( $rows ) {
        $rows = is_array( $rows ) ? $rows : array();

        if ( ! qedt_is_premium_active() && count( $rows ) > 2 ) {
            return array(
                'success_count' => 0,
                'failed_rows'   => array(
                    array(
                        'product_id' => 0,
                        'reason'     => __( 'Free plan allows editing up to 2 products per save. Upgrade for unlimited edits.', 'quick-edit' ),
                    ),
                ),
            );
        }

        $success_count = 0;
        $failed_rows   = array();

        foreach ( array_chunk( $rows, 25, true ) as $row_chunk ) {
            foreach ( $row_chunk as $product_id => $changes ) {
                $product_id = absint( $product_id );
                if ( ! $product_id ) {
                    $failed_rows[] = array(
                        'product_id' => $product_id,
                        'reason'     => __( 'Invalid product ID.', 'quick-edit' ),
                    );
                    continue;
                }

                $result = self::save_single_product( $product_id, $changes );
                if ( is_wp_error( $result ) ) {
                    $failed_rows[] = array(
                        'product_id' => $product_id,
                        'reason'     => $result->get_error_message(),
                    );
                } else {
                    $success_count++;
                }
            }
        }

        return array(
            'success_count' => $success_count,
            'failed_rows'   => $failed_rows,
        );
    }

    /**
     * Save one product.
     *
     * @param int   $product_id Product ID.
     * @param array $changes    Changed fields.
     * @return true|WP_Error
     */
    protected static function save_single_product( $product_id, $changes ) {
        $product = wc_get_product( $product_id );
        if ( ! $product ) {
            return new WP_Error( 'missing_product', __( 'Product not found.', 'quick-edit' ) );
        }

        $changes = is_array( $changes ) ? $changes : array();

        $post_update = array(
            'ID' => $product_id,
        );

        if ( array_key_exists( 'sku', $changes ) ) {
            $sku = sanitize_text_field( wp_unslash( $changes['sku'] ) );
            if ( '' !== $sku ) {
                $sku_owner = wc_get_product_id_by_sku( $sku );
                if ( $sku_owner && $sku_owner !== $product_id ) {
                    return new WP_Error( 'duplicate_sku', __( 'SKU must be unique.', 'quick-edit' ) );
                }
            }
            QEDT_Logger::log_change( $product_id, 'sku', $product->get_sku(), $sku );
            $product->set_sku( $sku );
        }

        if ( array_key_exists( 'name', $changes ) ) {
            $name                    = sanitize_text_field( wp_unslash( $changes['name'] ) );
            $post_update['post_title'] = $name;
            QEDT_Logger::log_change( $product_id, 'name', $product->get_name(), $name );
        }

        $regular_price = $product->get_regular_price();
        $sale_price    = $product->get_sale_price();

        if ( array_key_exists( 'regular_price', $changes ) ) {
            $reg = qedt_parse_number( $changes['regular_price'] );
            if ( null === $reg && '' !== (string) $changes['regular_price'] ) {
                return new WP_Error( 'invalid_regular_price', __( 'Regular price must be numeric.', 'quick-edit' ) );
            }
            $regular_price = null === $reg ? '' : wc_format_decimal( $reg );
        }

        if ( array_key_exists( 'sale_price', $changes ) ) {
            $sale = qedt_parse_number( $changes['sale_price'] );
            if ( null === $sale && '' !== (string) $changes['sale_price'] ) {
                return new WP_Error( 'invalid_sale_price', __( 'Sale price must be numeric.', 'quick-edit' ) );
            }
            $sale_price = null === $sale ? '' : wc_format_decimal( $sale );
        }

        if ( '' !== (string) $sale_price && '' !== (string) $regular_price && (float) $sale_price > (float) $regular_price ) {
            return new WP_Error( 'invalid_sale_logic', __( 'Sale price must be less than or equal to regular price.', 'quick-edit' ) );
        }

        if ( array_key_exists( 'regular_price', $changes ) ) {
            QEDT_Logger::log_change( $product_id, 'regular_price', $product->get_regular_price(), $regular_price );
            $product->set_regular_price( $regular_price );
            update_post_meta( $product_id, '_regular_price', $regular_price );
        }

        if ( array_key_exists( 'sale_price', $changes ) ) {
            QEDT_Logger::log_change( $product_id, 'sale_price', $product->get_sale_price(), $sale_price );
            $product->set_sale_price( $sale_price );
            update_post_meta( $product_id, '_sale_price', $sale_price );
        }

        if ( array_key_exists( 'stock_quantity', $changes ) ) {
            $qty = qedt_parse_number( $changes['stock_quantity'] );
            if ( null === $qty && '' !== (string) $changes['stock_quantity'] ) {
                return new WP_Error( 'invalid_stock', __( 'Stock quantity must be numeric.', 'quick-edit' ) );
            }
            QEDT_Logger::log_change( $product_id, 'stock_quantity', $product->get_stock_quantity(), $qty );
            wc_update_product_stock( $product, null === $qty ? null : (int) $qty, 'set' );
        }

        if ( array_key_exists( 'stock_status', $changes ) ) {
            $status = sanitize_key( $changes['stock_status'] );
            if ( ! array_key_exists( $status, wc_get_product_stock_status_options() ) ) {
                return new WP_Error( 'invalid_stock_status', __( 'Invalid stock status.', 'quick-edit' ) );
            }
            QEDT_Logger::log_change( $product_id, 'stock_status', $product->get_stock_status(), $status );
            $product->set_stock_status( $status );
            update_post_meta( $product_id, '_stock_status', $status );
        }

        if ( array_key_exists( 'product_status', $changes ) ) {
            $post_status = sanitize_key( $changes['product_status'] );
            if ( ! in_array( $post_status, array( 'draft', 'publish', 'private', 'pending' ), true ) ) {
                return new WP_Error( 'invalid_post_status', __( 'Invalid product status.', 'quick-edit' ) );
            }
            QEDT_Logger::log_change( $product_id, 'product_status', get_post_status( $product_id ), $post_status );
            $post_update['post_status'] = $post_status;
        }

        if ( array_key_exists( 'featured', $changes ) ) {
            $featured = qedt_to_bool( $changes['featured'] );
            QEDT_Logger::log_change( $product_id, 'featured', $product->is_featured() ? 1 : 0, $featured ? 1 : 0 );
            $product->set_featured( $featured );
        }

        if ( array_key_exists( 'categories', $changes ) ) {
            $category_ids = qedt_sanitize_int_list( $changes['categories'] );
            QEDT_Logger::log_change( $product_id, 'categories', wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) ), $category_ids );
            wp_set_object_terms( $product_id, $category_ids, 'product_cat', false );
        }

        if ( array_key_exists( 'tags', $changes ) ) {
            $tags = is_array( $changes['tags'] ) ? $changes['tags'] : explode( ',', (string) $changes['tags'] );
            $tags = array_filter( array_map( 'sanitize_text_field', array_map( 'trim', $tags ) ) );
            QEDT_Logger::log_change( $product_id, 'tags', wp_get_post_terms( $product_id, 'product_tag', array( 'fields' => 'names' ) ), $tags );
            wp_set_object_terms( $product_id, $tags, 'product_tag', false );
        }

        if ( array_key_exists( 'visibility', $changes ) ) {
            $visibility = sanitize_key( $changes['visibility'] );
            if ( ! array_key_exists( $visibility, qedt_visibility_options() ) ) {
                return new WP_Error( 'invalid_visibility', __( 'Invalid visibility.', 'quick-edit' ) );
            }
            QEDT_Logger::log_change( $product_id, 'visibility', $product->get_catalog_visibility(), $visibility );
            $product->set_catalog_visibility( $visibility );
        }

        if ( array_key_exists( 'short_description', $changes ) ) {
            $short_desc = wp_kses_post( wp_unslash( $changes['short_description'] ) );
            QEDT_Logger::log_change( $product_id, 'short_description', $product->get_short_description(), $short_desc );
            $post_update['post_excerpt'] = $short_desc;
        }

        if ( array_key_exists( 'weight', $changes ) ) {
            $weight = '' === (string) $changes['weight'] ? '' : wc_format_decimal( $changes['weight'] );
            if ( '' !== $weight && ! is_numeric( $weight ) ) {
                return new WP_Error( 'invalid_weight', __( 'Weight must be numeric.', 'quick-edit' ) );
            }
            QEDT_Logger::log_change( $product_id, 'weight', $product->get_weight(), $weight );
            $product->set_weight( $weight );
            update_post_meta( $product_id, '_weight', $weight );
        }

        if ( array_key_exists( 'length', $changes ) || array_key_exists( 'width', $changes ) || array_key_exists( 'height', $changes ) ) {
            $length = array_key_exists( 'length', $changes ) ? ( '' === (string) $changes['length'] ? '' : wc_format_decimal( $changes['length'] ) ) : $product->get_length();
            $width  = array_key_exists( 'width', $changes ) ? ( '' === (string) $changes['width'] ? '' : wc_format_decimal( $changes['width'] ) ) : $product->get_width();
            $height = array_key_exists( 'height', $changes ) ? ( '' === (string) $changes['height'] ? '' : wc_format_decimal( $changes['height'] ) ) : $product->get_height();

            foreach ( array( $length, $width, $height ) as $dim ) {
                if ( '' !== $dim && ! is_numeric( $dim ) ) {
                    return new WP_Error( 'invalid_dimension', __( 'Dimensions must be numeric.', 'quick-edit' ) );
                }
            }

            QEDT_Logger::log_change( $product_id, 'length', $product->get_length(), $length );
            QEDT_Logger::log_change( $product_id, 'width', $product->get_width(), $width );
            QEDT_Logger::log_change( $product_id, 'height', $product->get_height(), $height );

            $product->set_length( $length );
            $product->set_width( $width );
            $product->set_height( $height );

            update_post_meta( $product_id, '_length', $length );
            update_post_meta( $product_id, '_width', $width );
            update_post_meta( $product_id, '_height', $height );
        }

        $settings = qedt_get_settings();
        if ( ! empty( $settings['advanced_mode'] ) && ! empty( $changes['custom_meta'] ) && is_array( $changes['custom_meta'] ) ) {
            $allowed = array_filter( array_map( 'trim', explode( ',', $settings['custom_meta_keys'] ) ) );
            $allowed = array_map( 'sanitize_key', $allowed );

            foreach ( $changes['custom_meta'] as $meta_key => $meta_value ) {
                $meta_key = sanitize_key( $meta_key );
                if ( ! in_array( $meta_key, $allowed, true ) ) {
                    continue;
                }
                $new_value = sanitize_textarea_field( wp_unslash( $meta_value ) );
                $old_value = get_post_meta( $product_id, $meta_key, true );
                QEDT_Logger::log_change( $product_id, $meta_key, $old_value, $new_value );
                update_post_meta( $product_id, $meta_key, $new_value );
            }
        }

        if ( count( $post_update ) > 1 ) {
            wp_update_post( $post_update );
        }

        $product->save();

        return true;
    }
}
