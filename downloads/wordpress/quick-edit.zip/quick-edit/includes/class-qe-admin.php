<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QEDT_Admin {
    /**
     * Initialize admin hooks.
     *
     * @return void
     */
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
    }

    /**
     * Register plugin menu pages.
     *
     * @return void
     */
    public static function register_menu() {
        add_menu_page(
            __( 'Quick Edit', 'quick-edit' ),
            __( 'Quick Edit', 'quick-edit' ),
            'manage_woocommerce',
            'qe-product-editor',
            array( __CLASS__, 'render_editor_page' ),
            'dashicons-edit-page',
            56
        );

        add_submenu_page(
            'qe-product-editor',
            __( 'Product Editor', 'quick-edit' ),
            __( 'Product Editor', 'quick-edit' ),
            'manage_woocommerce',
            'qe-product-editor',
            array( __CLASS__, 'render_editor_page' )
        );

        add_submenu_page(
            'qe-product-editor',
            __( 'Bulk Actions', 'quick-edit' ),
            __( 'Bulk Actions', 'quick-edit' ),
            'manage_woocommerce',
            'qe-bulk-actions',
            array( __CLASS__, 'render_bulk_page' )
        );

        add_submenu_page(
            'qe-product-editor',
            __( 'Settings', 'quick-edit' ),
            __( 'Settings', 'quick-edit' ),
            'manage_woocommerce',
            'qe-settings',
            array( __CLASS__, 'render_settings_page' )
        );
    }

    /**
     * Enqueue admin assets.
     *
     * @param string $hook Hook suffix.
     * @return void
     */
    public static function enqueue_assets( $hook ) {
        $allowed = array(
            'toplevel_page_qe-product-editor',
            'qe-product-editor_page_qe-bulk-actions',
            'qe-product-editor_page_qe-settings',
        );

        if ( ! in_array( $hook, $allowed, true ) ) {
            return;
        }

        wp_enqueue_style(
            'qe-admin',
            QEDT_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            QEDT_PLUGIN_VERSION
        );
        wp_enqueue_style(
            'qe-admin-ui',
            QEDT_PLUGIN_URL . 'assets/css/admin-ui.css',
            array( 'qe-admin' ),
            QEDT_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'qe-admin',
            QEDT_PLUGIN_URL . 'assets/js/admin.js',
            array( 'jquery' ),
            QEDT_PLUGIN_VERSION,
            true
        );
        wp_enqueue_script(
            'qe-admin-ui',
            QEDT_PLUGIN_URL . 'assets/js/admin-ui.js',
            array( 'qe-admin' ),
            QEDT_PLUGIN_VERSION,
            true
        );

        $settings = qedt_get_settings();

        wp_localize_script(
            'qe-admin',
            'qeAdmin',
            array(
                'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
                'nonce'        => wp_create_nonce( 'qedt_nonce' ),
                'defaultRows'  => (int) $settings['default_rows_per_page'],
                'inlineCols'   => array_values( (array) $settings['inline_columns'] ),
                'advancedMode' => ! empty( $settings['advanced_mode'] ),
                'strings'      => array(
                    'saving'       => __( 'Saving changes...', 'quick-edit' ),
                    'saved'        => __( 'Changes saved.', 'quick-edit' ),
                    'loadError'    => __( 'Failed to load products.', 'quick-edit' ),
                    'saveError'    => __( 'Failed to save changes.', 'quick-edit' ),
                    'previewError' => __( 'Failed to preview bulk action.', 'quick-edit' ),
                    'applyError'   => __( 'Failed to apply bulk action.', 'quick-edit' ),
                ),
            )
        );
    }

    /**
     * Render product editor page.
     *
     * @return void
     */
    public static function render_editor_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-edit' ) );
        }
        ?>
        <div class="wrap qe-wrap qe-editor-page">
            <h1><?php esc_html_e( 'Quick Edit Product Editor', 'quick-edit' ); ?></h1>
            <div class="qe-toolbar">
                <select id="qe-filter-category"><option value="0"><?php esc_html_e( 'All Categories', 'quick-edit' ); ?></option></select>
                <select id="qe-filter-stock-status"><option value=""><?php esc_html_e( 'All Stock Statuses', 'quick-edit' ); ?></option></select>
                <select id="qe-filter-product-type">
                    <option value=""><?php esc_html_e( 'All Product Types', 'quick-edit' ); ?></option>
                    <option value="simple"><?php esc_html_e( 'Simple', 'quick-edit' ); ?></option>
                    <option value="variable"><?php esc_html_e( 'Variable', 'quick-edit' ); ?></option>
                </select>
                <input type="text" id="qe-filter-search" placeholder="<?php esc_attr_e( 'Search name or SKU', 'quick-edit' ); ?>" />
                <select id="qe-per-page">
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
                <button class="button" id="qe-filter-btn"><?php esc_html_e( 'Filter', 'quick-edit' ); ?></button>
                <button class="button button-primary" id="qe-save-btn"><?php esc_html_e( 'Save Changes', 'quick-edit' ); ?></button>
            </div>

            <div id="qe-message" class="qe-message"></div>

            <div class="qe-table-container">
                <table class="widefat fixed striped qe-table" id="qe-editor-table">
                    <thead>
                    <tr>
                        <th><?php esc_html_e( 'Product ID', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Thumbnail', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Product Name', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'SKU', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Regular Price', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Sale Price', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Stock Quantity', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Stock Status', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Product Status', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Featured', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Category', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Tags', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Visibility', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Short Description', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Weight', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Dimensions (L/W/H)', 'quick-edit' ); ?></th>
                        <th class="qe-advanced-col"><?php esc_html_e( 'Custom Meta', 'quick-edit' ); ?></th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>

            <div class="qe-pagination">
                <button class="button" id="qe-prev-page"><?php esc_html_e( 'Previous', 'quick-edit' ); ?></button>
                <span id="qe-page-info"></span>
                <button class="button" id="qe-next-page"><?php esc_html_e( 'Next', 'quick-edit' ); ?></button>
            </div>
        </div>
        <?php
    }

    /**
     * Render bulk actions page.
     *
     * @return void
     */
    public static function render_bulk_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-edit' ) );
        }
        ?>
        <div class="wrap qe-wrap qe-bulk-page">
            <h1><?php esc_html_e( 'Quick Edit Bulk Actions', 'quick-edit' ); ?></h1>
            <p><?php esc_html_e( 'Select products from the list, configure an action, preview impact, and confirm to apply.', 'quick-edit' ); ?></p>

            <div class="qe-toolbar">
                <select id="qe-bulk-filter-category"><option value="0"><?php esc_html_e( 'All Categories', 'quick-edit' ); ?></option></select>
                <select id="qe-bulk-filter-stock-status"><option value=""><?php esc_html_e( 'All Stock Statuses', 'quick-edit' ); ?></option></select>
                <select id="qe-bulk-filter-product-type">
                    <option value=""><?php esc_html_e( 'All Product Types', 'quick-edit' ); ?></option>
                    <option value="simple"><?php esc_html_e( 'Simple', 'quick-edit' ); ?></option>
                    <option value="variable"><?php esc_html_e( 'Variable', 'quick-edit' ); ?></option>
                </select>
                <input type="text" id="qe-bulk-filter-search" placeholder="<?php esc_attr_e( 'Search name or SKU', 'quick-edit' ); ?>" />
                <button class="button" id="qe-bulk-filter-btn"><?php esc_html_e( 'Filter', 'quick-edit' ); ?></button>
            </div>

            <div class="qe-bulk-controls">
                <select id="qe-bulk-action">
                    <option value="regular_price_adjust"><?php esc_html_e( 'Adjust Regular Price', 'quick-edit' ); ?></option>
                    <option value="sale_price_adjust"><?php esc_html_e( 'Adjust Sale Price', 'quick-edit' ); ?></option>
                    <option value="set_stock_quantity"><?php esc_html_e( 'Set Stock Quantity', 'quick-edit' ); ?></option>
                    <option value="change_stock_status"><?php esc_html_e( 'Change Stock Status', 'quick-edit' ); ?></option>
                    <option value="assign_category"><?php esc_html_e( 'Assign Category', 'quick-edit' ); ?></option>
                    <option value="remove_category"><?php esc_html_e( 'Remove Category', 'quick-edit' ); ?></option>
                    <option value="assign_tag"><?php esc_html_e( 'Assign Tag', 'quick-edit' ); ?></option>
                    <option value="remove_tag"><?php esc_html_e( 'Remove Tag', 'quick-edit' ); ?></option>
                    <option value="change_status"><?php esc_html_e( 'Change Product Status', 'quick-edit' ); ?></option>
                    <option value="toggle_featured"><?php esc_html_e( 'Toggle Featured', 'quick-edit' ); ?></option>
                    <option value="delete_products"><?php esc_html_e( 'Delete Products', 'quick-edit' ); ?></option>
                    <option value="duplicate_products"><?php esc_html_e( 'Duplicate Products', 'quick-edit' ); ?></option>
                </select>
                <input type="text" id="qe-bulk-value" placeholder="<?php esc_attr_e( 'Action value', 'quick-edit' ); ?>" />
                <label>
                    <input type="checkbox" id="qe-bulk-confirm" value="1" />
                    <?php esc_html_e( 'I confirm this operation', 'quick-edit' ); ?>
                </label>
                <button class="button" id="qe-bulk-preview"><?php esc_html_e( 'Preview', 'quick-edit' ); ?></button>
                <button class="button button-primary" id="qe-bulk-apply"><?php esc_html_e( 'Apply', 'quick-edit' ); ?></button>
            </div>

            <div id="qe-bulk-message" class="qe-message"></div>

            <div id="qe-bulk-preview-result" class="qe-preview"></div>

            <div class="qe-table-container">
                <table class="widefat fixed striped qe-table" id="qe-bulk-table">
                    <thead>
                    <tr>
                        <th><input type="checkbox" id="qe-bulk-select-all" /></th>
                        <th><?php esc_html_e( 'Product ID', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Name', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'SKU', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Regular Price', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Sale Price', 'quick-edit' ); ?></th>
                        <th><?php esc_html_e( 'Stock', 'quick-edit' ); ?></th>
                    </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
        <?php
    }

    /**
     * Render settings page.
     *
     * @return void
     */
    public static function render_settings_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-edit' ) );
        }
        ?>
        <div class="wrap qe-wrap qe-settings-page">
            <h1><?php esc_html_e( 'Quick Edit Settings', 'quick-edit' ); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'qedt_settings_group' );
                do_settings_sections( 'qe-settings' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
}
