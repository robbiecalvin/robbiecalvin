<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QEDT_Activator {
    /**
     * Activation handler.
     *
     * @return void
     */
    public static function activate() {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        if ( ! is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
            set_transient( 'qedt_wc_missing_notice', 1, MINUTE_IN_SECONDS * 2 );
            return;
        }

        $settings = qedt_get_settings();
        update_option( 'qedt_settings', $settings );

        QEDT_Logger::maybe_create_table();
    }
}
