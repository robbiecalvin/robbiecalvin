<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QEDT_Ajax {
    /**
     * Initialize AJAX actions.
     *
     * @return void
     */
    public static function init() {
        add_action( 'wp_ajax_qe_load_products', array( __CLASS__, 'load_products' ) );
        add_action( 'wp_ajax_qe_save_products', array( __CLASS__, 'save_products' ) );
        add_action( 'wp_ajax_qe_bulk_preview', array( __CLASS__, 'bulk_preview' ) );
        add_action( 'wp_ajax_qe_bulk_apply', array( __CLASS__, 'bulk_apply' ) );
        add_action( 'wp_ajax_qe_get_history', array( __CLASS__, 'get_history' ) );
        add_action( 'wp_ajax_qe_revert_history', array( __CLASS__, 'revert_history' ) );
    }

    /**
     * Load products endpoint.
     *
     * @return void
     */
    public static function load_products() {
        self::guard();

        $settings = qedt_get_settings();

        $result = QEDT_Editor::query_products(
            array(
                'paged'        => isset( $_POST['paged'] ) ? absint( $_POST['paged'] ) : 1,
                'per_page'     => isset( $_POST['per_page'] ) ? absint( $_POST['per_page'] ) : (int) $settings['default_rows_per_page'],
                'category'     => isset( $_POST['category'] ) ? absint( $_POST['category'] ) : 0,
                'stock_status' => isset( $_POST['stock_status'] ) ? sanitize_key( wp_unslash( $_POST['stock_status'] ) ) : '',
                'product_type' => isset( $_POST['product_type'] ) ? sanitize_key( wp_unslash( $_POST['product_type'] ) ) : '',
                'search'       => isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '',
            )
        );

        wp_send_json_success( $result );
    }

    /**
     * Save changed rows endpoint.
     *
     * @return void
     */
    public static function save_products() {
        self::guard();

        $rows = isset( $_POST['rows'] ) ? json_decode( wp_unslash( $_POST['rows'] ), true ) : array();
        if ( ! is_array( $rows ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid payload.', 'quick-edit' ) ), 400 );
        }

        $result = QEDT_Editor::save_rows( $rows );

        wp_send_json_success( $result );
    }

    /**
     * Bulk preview endpoint.
     *
     * @return void
     */
    public static function bulk_preview() {
        self::guard();

        $ids     = isset( $_POST['product_ids'] ) ? qedt_sanitize_int_list( wp_unslash( $_POST['product_ids'] ) ) : array();
        $action  = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '';
        $payload = isset( $_POST['payload'] ) ? json_decode( wp_unslash( $_POST['payload'] ), true ) : array();

        $result = QEDT_Bulk::preview( $ids, $action, $payload );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
        }

        wp_send_json_success( $result );
    }

    /**
     * Bulk apply endpoint.
     *
     * @return void
     */
    public static function bulk_apply() {
        self::guard();

        $confirmed = isset( $_POST['confirmed'] ) ? qedt_to_bool( wp_unslash( $_POST['confirmed'] ) ) : false;
        if ( ! $confirmed ) {
            wp_send_json_error( array( 'message' => __( 'Bulk action confirmation required.', 'quick-edit' ) ), 400 );
        }

        $ids     = isset( $_POST['product_ids'] ) ? qedt_sanitize_int_list( wp_unslash( $_POST['product_ids'] ) ) : array();
        $action  = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '';
        $payload = isset( $_POST['payload'] ) ? json_decode( wp_unslash( $_POST['payload'] ), true ) : array();

        $result = QEDT_Bulk::apply( $ids, $action, $payload );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
        }

        wp_send_json_success( $result );
    }

    /**
     * History endpoint.
     *
     * @return void
     */
    public static function get_history() {
        self::guard();

        $settings = qedt_get_settings();
        if ( empty( $settings['revision_logging'] ) ) {
            wp_send_json_error( array( 'message' => __( 'Revision logging is disabled.', 'quick-edit' ) ), 400 );
        }

        $product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
        if ( ! $product_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid product ID.', 'quick-edit' ) ), 400 );
        }

        $rows = QEDT_Logger::get_history( $product_id, 100 );
        wp_send_json_success( array( 'history' => $rows ) );
    }

    /**
     * Revert endpoint.
     *
     * @return void
     */
    public static function revert_history() {
        self::guard();

        $settings = qedt_get_settings();
        if ( empty( $settings['revision_logging'] ) ) {
            wp_send_json_error( array( 'message' => __( 'Revision logging is disabled.', 'quick-edit' ) ), 400 );
        }

        $log_id = isset( $_POST['log_id'] ) ? absint( $_POST['log_id'] ) : 0;
        $result = QEDT_Logger::revert_change( $log_id );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
        }

        wp_send_json_success( array( 'message' => __( 'Change reverted successfully.', 'quick-edit' ) ) );
    }

    /**
     * Shared security checks.
     *
     * @return void
     */
    protected static function guard() {
        check_ajax_referer( 'qedt_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'quick-edit' ) ), 403 );
        }
    }
}
