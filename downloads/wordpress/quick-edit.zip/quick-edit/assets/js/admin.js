(function ($) {
    'use strict';

    var state = {
        page: 1,
        perPage: parseInt(qeAdmin.defaultRows, 10) || 50,
        pagination: null,
        filterData: null,
        modifiedRows: {},
        rows: []
    };

    function isEditorPage() {
        return $('.qe-editor-page').length > 0;
    }

    function isBulkPage() {
        return $('.qe-bulk-page').length > 0;
    }

    function ajaxPost(action, data) {
        return $.post(qeAdmin.ajaxUrl, $.extend({}, data, {
            action: action,
            nonce: qeAdmin.nonce
        }));
    }

    function escapeHtml(value) {
        return $('<div/>').text(value == null ? '' : String(value)).html();
    }

    function markModified($cell, productId, field, value) {
        if (!state.modifiedRows[productId]) {
            state.modifiedRows[productId] = {};
        }

        if (field === 'categories') {
            var selected = [];
            var values = $cell.find('select').val() || [];
            values.forEach(function (v) { selected.push(parseInt(v, 10)); });
            state.modifiedRows[productId][field] = selected;
        } else {
            state.modifiedRows[productId][field] = value;
        }

        $cell.addClass('qe-cell-modified');
        $cell.closest('tr').addClass('qe-row-modified');
    }

    function buildFilterOptions(filterData) {
        var $category = $('#qe-filter-category, #qe-bulk-filter-category');
        var $stock = $('#qe-filter-stock-status, #qe-bulk-filter-stock-status');

        $category.find('option:not(:first)').remove();
        $.each(filterData.categories || {}, function (id, label) {
            $category.append('<option value="' + parseInt(id, 10) + '">' + escapeHtml(label) + '</option>');
        });

        $stock.find('option:not(:first)').remove();
        $.each(filterData.stock_status || {}, function (key, label) {
            $stock.append('<option value="' + escapeHtml(key) + '">' + escapeHtml(label) + '</option>');
        });
    }

    function categoryMultiSelect(row, filterData, editable) {
        var html = '<select multiple data-field="categories" ' + (editable ? '' : 'disabled') + '>';
        var selected = row.categories || [];

        $.each(filterData.categories || {}, function (id, label) {
            var sid = parseInt(id, 10);
            var isSelected = selected.indexOf(sid) !== -1 ? ' selected' : '';
            html += '<option value="' + sid + '"' + isSelected + '>' + escapeHtml(label) + '</option>';
        });

        html += '</select>';
        return html;
    }

    function customMetaInput(row) {
        var customMeta = row.custom_meta || {};
        var keys = Object.keys(customMeta);
        if (!keys.length) {
            return '';
        }

        var html = '<div class="qe-custom-meta-wrap">';
        keys.forEach(function (key) {
            html += '<label>' + escapeHtml(key) + '</label>';
            html += '<input type="text" data-meta-key="' + escapeHtml(key) + '" value="' + escapeHtml(customMeta[key]) + '" />';
        });
        html += '</div>';

        return html;
    }

    function renderEditorRows(rows, filterData) {
        var inlineCols = qeAdmin.inlineCols || [];
        var canEdit = function (field) {
            return inlineCols.indexOf(field) !== -1;
        };

        var html = '';
        rows.forEach(function (row) {
            var thumb = row.thumbnail ? '<img src="' + escapeHtml(row.thumbnail) + '" class="qe-thumb" alt="" />' : '';
            var advancedClass = qeAdmin.advancedMode ? '' : ' qe-hidden';

            html += '<tr data-product-id="' + parseInt(row.id, 10) + '">';
            html += '<td>' + parseInt(row.id, 10) + '</td>';
            html += '<td>' + thumb + '</td>';
            html += '<td class="qe-cell" data-field="name"><input type="text" ' + (canEdit('name') ? '' : 'disabled') + ' value="' + escapeHtml(row.name) + '" /></td>';
            html += '<td class="qe-cell" data-field="sku"><input type="text" ' + (canEdit('sku') ? '' : 'disabled') + ' value="' + escapeHtml(row.sku) + '" /></td>';
            html += '<td class="qe-cell" data-field="regular_price"><input type="text" ' + (canEdit('regular_price') ? '' : 'disabled') + ' value="' + escapeHtml(row.regular_price) + '" /></td>';
            html += '<td class="qe-cell" data-field="sale_price"><input type="text" ' + (canEdit('sale_price') ? '' : 'disabled') + ' value="' + escapeHtml(row.sale_price) + '" /></td>';
            html += '<td class="qe-cell" data-field="stock_quantity"><input type="number" ' + (canEdit('stock_quantity') ? '' : 'disabled') + ' value="' + escapeHtml(row.stock_quantity) + '" /></td>';
            html += '<td class="qe-cell" data-field="stock_status"><select ' + (canEdit('stock_status') ? '' : 'disabled') + '>';
            $.each(filterData.stock_status || {}, function (key, label) {
                html += '<option value="' + escapeHtml(key) + '" ' + (row.stock_status === key ? 'selected' : '') + '>' + escapeHtml(label) + '</option>';
            });
            html += '</select></td>';
            html += '<td class="qe-cell" data-field="product_status"><select ' + (canEdit('product_status') ? '' : 'disabled') + '>';
            ['draft', 'publish', 'private', 'pending'].forEach(function (status) {
                html += '<option value="' + status + '" ' + (row.product_status === status ? 'selected' : '') + '>' + status + '</option>';
            });
            html += '</select></td>';
            html += '<td class="qe-cell" data-field="featured"><input type="checkbox" ' + (canEdit('featured') ? '' : 'disabled') + ' ' + (parseInt(row.featured, 10) ? 'checked' : '') + ' /></td>';
            html += '<td class="qe-cell" data-field="categories">' + categoryMultiSelect(row, filterData, canEdit('categories')) + '</td>';
            html += '<td class="qe-cell" data-field="tags"><input type="text" ' + (canEdit('tags') ? '' : 'disabled') + ' value="' + escapeHtml(row.tags) + '" /></td>';
            html += '<td class="qe-cell" data-field="visibility"><select ' + (canEdit('visibility') ? '' : 'disabled') + '>';
            $.each(filterData.visibility || {}, function (key, label) {
                html += '<option value="' + escapeHtml(key) + '" ' + (row.visibility === key ? 'selected' : '') + '>' + escapeHtml(label) + '</option>';
            });
            html += '</select></td>';
            html += '<td class="qe-cell" data-field="short_description"><textarea ' + (canEdit('short_description') ? '' : 'disabled') + '>' + escapeHtml(row.short_description) + '</textarea></td>';
            html += '<td class="qe-cell" data-field="weight"><input type="text" ' + (canEdit('weight') ? '' : 'disabled') + ' value="' + escapeHtml(row.weight) + '" /></td>';
            html += '<td><div class="qe-dim-grid">';
            html += '<input class="qe-cell" data-field="length" type="text" ' + (canEdit('dimensions') ? '' : 'disabled') + ' value="' + escapeHtml(row.length) + '" />';
            html += '<input class="qe-cell" data-field="width" type="text" ' + (canEdit('dimensions') ? '' : 'disabled') + ' value="' + escapeHtml(row.width) + '" />';
            html += '<input class="qe-cell" data-field="height" type="text" ' + (canEdit('dimensions') ? '' : 'disabled') + ' value="' + escapeHtml(row.height) + '" />';
            html += '</div></td>';
            html += '<td class="qe-cell qe-advanced-col' + advancedClass + '" data-field="custom_meta">' + customMetaInput(row) + '</td>';
            html += '</tr>';
        });

        $('#qe-editor-table tbody').html(html || '<tr><td colspan="17">No products found.</td></tr>');
        $('.qe-advanced-col').toggleClass('qe-hidden', !qeAdmin.advancedMode);
    }

    function renderBulkRows(rows) {
        var html = '';
        rows.forEach(function (row) {
            html += '<tr data-product-id="' + parseInt(row.id, 10) + '">';
            html += '<td><input type="checkbox" class="qe-bulk-select" value="' + parseInt(row.id, 10) + '" /></td>';
            html += '<td>' + parseInt(row.id, 10) + '</td>';
            html += '<td>' + escapeHtml(row.name) + '</td>';
            html += '<td>' + escapeHtml(row.sku) + '</td>';
            html += '<td>' + escapeHtml(row.regular_price) + '</td>';
            html += '<td>' + escapeHtml(row.sale_price) + '</td>';
            html += '<td>' + escapeHtml(row.stock_quantity) + '</td>';
            html += '</tr>';
        });
        $('#qe-bulk-table tbody').html(html || '<tr><td colspan="7">No products found.</td></tr>');
    }

    function updatePagination() {
        if (!state.pagination) {
            return;
        }

        $('#qe-page-info').text('Page ' + state.pagination.paged + ' of ' + state.pagination.total_page + ' (' + state.pagination.total + ' products)');
        $('#qe-prev-page').prop('disabled', state.pagination.paged <= 1);
        $('#qe-next-page').prop('disabled', state.pagination.paged >= state.pagination.total_page);
    }

    function loadProducts(forBulk) {
        var data = {
            paged: state.page,
            per_page: forBulk ? 50 : parseInt($('#qe-per-page').val(), 10) || state.perPage,
            category: forBulk ? ($('#qe-bulk-filter-category').val() || 0) : ($('#qe-filter-category').val() || 0),
            stock_status: forBulk ? ($('#qe-bulk-filter-stock-status').val() || '') : ($('#qe-filter-stock-status').val() || ''),
            product_type: forBulk ? ($('#qe-bulk-filter-product-type').val() || '') : ($('#qe-filter-product-type').val() || ''),
            search: forBulk ? ($('#qe-bulk-filter-search').val() || '') : ($('#qe-filter-search').val() || '')
        };

        return ajaxPost('qe_load_products', data).done(function (response) {
            if (!response.success) {
                return;
            }

            state.filterData = response.data.filters || {};
            state.rows = response.data.rows || [];
            state.pagination = response.data.pagination || null;

            buildFilterOptions(state.filterData);
            if (forBulk) {
                renderBulkRows(state.rows);
            } else {
                renderEditorRows(state.rows, state.filterData);
                updatePagination();
                if (response.data.notice) {
                    $('#qe-message').removeClass('qe-success').addClass('qe-error').text(response.data.notice);
                } else {
                    $('#qe-message').removeClass('qe-error').text('');
                }
            }
        }).fail(function () {
            var $msg = forBulk ? $('#qe-bulk-message') : $('#qe-message');
            $msg.removeClass('qe-success').addClass('qe-error').text(qeAdmin.strings.loadError);
        });
    }

    function collectModifiedRows() {
        var payload = {};
        Object.keys(state.modifiedRows).forEach(function (pid) {
            var rowData = state.modifiedRows[pid] || {};
            if (Object.keys(rowData).length) {
                payload[pid] = rowData;
            }
        });
        return payload;
    }

    function saveChanges() {
        var rows = collectModifiedRows();
        if (!Object.keys(rows).length) {
            $('#qe-message').removeClass('qe-error').addClass('qe-success').text('No changes to save.');
            return;
        }

        $('#qe-message').removeClass('qe-error qe-success').text(qeAdmin.strings.saving);

        ajaxPost('qe_save_products', {
            rows: JSON.stringify(rows)
        }).done(function (response) {
            if (!response.success) {
                $('#qe-message').removeClass('qe-success').addClass('qe-error').text(qeAdmin.strings.saveError);
                return;
            }

            var failed = response.data.failed_rows || [];
            if (failed.length) {
                var reasons = failed.map(function (item) {
                    return '#' + item.product_id + ': ' + item.reason;
                }).join('; ');
                $('#qe-message').removeClass('qe-success').addClass('qe-error').text('Saved ' + response.data.success_count + ' rows. Failed: ' + reasons);
            } else {
                $('#qe-message').removeClass('qe-error').addClass('qe-success').text(qeAdmin.strings.saved + ' (' + response.data.success_count + ')');
            }

            state.modifiedRows = {};
            loadProducts(false);
        }).fail(function () {
            $('#qe-message').removeClass('qe-success').addClass('qe-error').text(qeAdmin.strings.saveError);
        });
    }

    function selectedBulkIds() {
        var ids = [];
        $('.qe-bulk-select:checked').each(function () {
            ids.push(parseInt($(this).val(), 10));
        });
        return ids;
    }

    function buildBulkPayload() {
        var action = $('#qe-bulk-action').val();
        var rawValue = $('#qe-bulk-value').val();
        var payload = {};

        if (action === 'regular_price_adjust' || action === 'sale_price_adjust') {
            payload.mode = rawValue.indexOf('%') > -1 ? 'percent' : 'fixed';
            payload.operation = rawValue.indexOf('-') === 0 ? 'decrease' : 'increase';
            payload.value = parseFloat(rawValue.replace('%', '').replace('-', '')) || 0;
        } else if (action === 'set_stock_quantity') {
            payload.quantity = parseInt(rawValue, 10) || 0;
        } else if (action === 'change_stock_status') {
            payload.stock_status = rawValue;
        } else if (action === 'assign_category' || action === 'remove_category') {
            payload.category_ids = rawValue.split(',').map(function (v) { return parseInt(v.trim(), 10); }).filter(Boolean);
        } else if (action === 'assign_tag' || action === 'remove_tag') {
            payload.tags = rawValue.split(',').map(function (v) { return v.trim(); }).filter(Boolean);
        } else if (action === 'change_status') {
            payload.status = rawValue;
        } else if (action === 'toggle_featured') {
            payload.featured = rawValue === '1' || rawValue.toLowerCase() === 'true';
        }

        return payload;
    }

    function renderBulkPreview(preview) {
        var html = '<p><strong>Affected products:</strong> ' + parseInt(preview.affected, 10) + '</p>';
        html += '<table class="widefat striped"><thead><tr><th>ID</th><th>Name</th><th>From</th><th>To</th></tr></thead><tbody>';
        (preview.sample || []).forEach(function (row) {
            html += '<tr><td>' + parseInt(row.id, 10) + '</td><td>' + escapeHtml(row.name) + '</td><td>' + escapeHtml(row.from) + '</td><td>' + escapeHtml(row.to) + '</td></tr>';
        });
        html += '</tbody></table>';
        $('#qe-bulk-preview-result').html(html);
    }

    function runBulkPreview() {
        var ids = selectedBulkIds();
        if (!ids.length) {
            $('#qe-bulk-message').removeClass('qe-success').addClass('qe-error').text('Select at least one product.');
            return;
        }

        ajaxPost('qe_bulk_preview', {
            product_ids: ids,
            bulk_action: $('#qe-bulk-action').val(),
            payload: JSON.stringify(buildBulkPayload())
        }).done(function (response) {
            if (!response.success) {
                $('#qe-bulk-message').removeClass('qe-success').addClass('qe-error').text((response.data && response.data.message) || qeAdmin.strings.previewError);
                return;
            }

            $('#qe-bulk-message').removeClass('qe-error').addClass('qe-success').text('Preview generated.');
            renderBulkPreview(response.data);
        }).fail(function () {
            $('#qe-bulk-message').removeClass('qe-success').addClass('qe-error').text(qeAdmin.strings.previewError);
        });
    }

    function runBulkApply() {
        var ids = selectedBulkIds();
        if (!ids.length) {
            $('#qe-bulk-message').removeClass('qe-success').addClass('qe-error').text('Select at least one product.');
            return;
        }

        if (!$('#qe-bulk-confirm').is(':checked')) {
            $('#qe-bulk-message').removeClass('qe-success').addClass('qe-error').text('You must confirm before apply.');
            return;
        }

        if (!window.confirm('Apply this bulk action to selected products?')) {
            return;
        }

        ajaxPost('qe_bulk_apply', {
            product_ids: ids,
            bulk_action: $('#qe-bulk-action').val(),
            payload: JSON.stringify(buildBulkPayload()),
            confirmed: 1
        }).done(function (response) {
            if (!response.success) {
                $('#qe-bulk-message').removeClass('qe-success').addClass('qe-error').text((response.data && response.data.message) || qeAdmin.strings.applyError);
                return;
            }

            var text = 'Bulk applied. Success: ' + response.data.success_count;
            if (response.data.failed_rows && response.data.failed_rows.length) {
                text += '. Failures: ' + response.data.failed_rows.length;
                if (response.data.rolled_back) {
                    text += ' (transaction rolled back)';
                }
            }
            $('#qe-bulk-message').removeClass('qe-error').addClass('qe-success').text(text);
            loadProducts(true);
        }).fail(function () {
            $('#qe-bulk-message').removeClass('qe-success').addClass('qe-error').text(qeAdmin.strings.applyError);
        });
    }

    $(document).ready(function () {
        if (isEditorPage()) {
            $('#qe-per-page').val(String(state.perPage));
            loadProducts(false);

            $('#qe-filter-btn').on('click', function () {
                state.page = 1;
                loadProducts(false);
            });

            $('#qe-save-btn').on('click', function () {
                saveChanges();
            });

            $('#qe-prev-page').on('click', function () {
                if (state.page > 1) {
                    state.page -= 1;
                    loadProducts(false);
                }
            });

            $('#qe-next-page').on('click', function () {
                if (state.pagination && state.page < state.pagination.total_page) {
                    state.page += 1;
                    loadProducts(false);
                }
            });

            $('#qe-editor-table').on('input change', 'input, textarea, select', function () {
                var $input = $(this);
                var $cell = $input.closest('.qe-cell');
                var $row = $input.closest('tr');
                var productId = parseInt($row.data('product-id'), 10);
                var field = $cell.data('field') || $input.data('field');

                if (field === 'custom_meta') {
                    var meta = {};
                    $cell.find('input[data-meta-key]').each(function () {
                        meta[$(this).data('meta-key')] = $(this).val();
                    });
                    if (!state.modifiedRows[productId]) {
                        state.modifiedRows[productId] = {};
                    }
                    state.modifiedRows[productId].custom_meta = meta;
                    $cell.addClass('qe-cell-modified');
                    $row.addClass('qe-row-modified');
                    return;
                }

                var value;
                if ($input.is(':checkbox')) {
                    value = $input.is(':checked') ? 1 : 0;
                } else {
                    value = $input.val();
                }

                markModified($cell, productId, field, value);
            });
        }

        if (isBulkPage()) {
            loadProducts(true);

            $('#qe-bulk-filter-btn').on('click', function () {
                loadProducts(true);
            });

            $('#qe-bulk-select-all').on('change', function () {
                $('.qe-bulk-select').prop('checked', $(this).is(':checked'));
            });

            $('#qe-bulk-preview').on('click', function () {
                runBulkPreview();
            });

            $('#qe-bulk-apply').on('click', function () {
                runBulkApply();
            });
        }
    });
})(jQuery);
