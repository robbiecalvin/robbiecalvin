# Quick Edit -- Visual To‑Do

## Dashboard

-   Change background to branded sky blue

## Spreadsheet View

-   Align inputs with headers
-   Add spacing between fields
-   Fix checkbox sizing
-   Fix overlapping inputs
-   Mirror Quick SEO spreadsheet structure
-   Add margin between filters and product container
-   Change Filter, Save Changes, Previous, Next to blue with white text

## Bulk Actions

-   Revisit or redesign

## General Settings

-   Add left-side padding to labels
