<?php
/**
 * Admin.
 *
 * @package QuickSchedule
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QSCH_Admin {
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'admin_post_qsch_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_qs_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_qsch_activate_license', array( $this, 'handle_activate_license' ) );
		add_action( 'admin_post_qsch_deactivate_license', array( $this, 'handle_deactivate_license' ) );
		add_action( 'admin_post_qsch_create_schedule_page', array( $this, 'handle_create_schedule_page' ) );
		add_action( 'admin_post_qsch_save_style', array( $this, 'handle_save_style' ) );
		add_action( 'admin_post_qsch_save_template_fields', array( $this, 'handle_save_template_fields' ) );
	}

	public function enqueue_admin_assets( $hook_suffix ) {
		if ( false === strpos( (string) $hook_suffix, 'quick-schedule' ) ) {
			return;
		}

		wp_enqueue_style(
			'qsch-admin-ui',
			QSCH_PLUGIN_URL . 'assets/css/admin-ui.css',
			array(),
			QSCH_PLUGIN_VERSION
		);
		wp_enqueue_script(
			'qsch-admin-ui',
			QSCH_PLUGIN_URL . 'assets/js/admin-ui.js',
			array(),
			QSCH_PLUGIN_VERSION,
			true
		);
	}

	public function register_admin_menu() {
		add_menu_page(
			esc_html__( 'Quick Schedule', 'quick-schedule' ),
			esc_html__( 'Quick Schedule', 'quick-schedule' ),
			'manage_options',
			'quick-schedule',
			array( $this, 'render_appointments_page' ),
			'dashicons-calendar-alt',
			27
		);

		add_submenu_page(
			'quick-schedule',
			esc_html__( 'Appointments', 'quick-schedule' ),
			esc_html__( 'Appointments', 'quick-schedule' ),
			'manage_options',
			'quick-schedule',
			array( $this, 'render_appointments_page' )
		);

		add_submenu_page(
			'quick-schedule',
			esc_html__( 'Settings', 'quick-schedule' ),
			esc_html__( 'Settings', 'quick-schedule' ),
			'manage_options',
			'quick-schedule-settings',
			array( $this, 'render_settings_page' )
		);

		add_submenu_page(
			'quick-schedule',
			esc_html__( 'Page Template', 'quick-schedule' ),
			esc_html__( 'Page Template', 'quick-schedule' ),
			'manage_options',
			'quick-schedule-page-template',
			array( $this, 'render_page_template_page' )
		);

		add_submenu_page(
			'quick-schedule',
			esc_html__( 'Style', 'quick-schedule' ),
			esc_html__( 'Style', 'quick-schedule' ),
			'manage_options',
			'quick-schedule-style',
			array( $this, 'render_style_page' )
		);
	}

	public function render_page_template_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-schedule' ) );
		}

		$created_page_id = isset( $_GET['qsch_created_page'] ) ? absint( $_GET['qsch_created_page'] ) : 0;
		$settings = $this->get_settings();
		$fields = isset( $settings['booking_fields'] ) && is_array( $settings['booking_fields'] ) ? $settings['booking_fields'] : array();
		$defaults = $this->get_default_booking_fields();
		$fields = wp_parse_args( $fields, $defaults );
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Quick Schedule Page Template', 'quick-schedule' ); ?></h1>
			<p><?php echo esc_html__( 'Use this shortcode on any WordPress page to inject the appointment schedule template and booking form.', 'quick-schedule' ); ?></p>
			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th scope="row"><?php echo esc_html__( 'Template Shortcode', 'quick-schedule' ); ?></th>
						<td><code>[quick_schedule_appointment_page]</code></td>
					</tr>
					<tr>
						<th scope="row"><?php echo esc_html__( 'Booking Form Only', 'quick-schedule' ); ?></th>
						<td><code>[quick_schedule_booking]</code></td>
					</tr>
				</tbody>
			</table>
			<?php if ( $created_page_id > 0 ) : ?>
				<div class="notice notice-success inline">
					<p>
						<?php echo esc_html__( 'Appointment page created.', 'quick-schedule' ); ?>
						<a href="<?php echo esc_url( get_permalink( $created_page_id ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html__( 'View Page', 'quick-schedule' ); ?></a>
						|
						<a href="<?php echo esc_url( get_edit_post_link( $created_page_id ) ); ?>"><?php echo esc_html__( 'Edit Page', 'quick-schedule' ); ?></a>
					</p>
				</div>
			<?php endif; ?>
			<h2><?php echo esc_html__( 'Create Schedule Page', 'quick-schedule' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qsch_create_schedule_page" />
				<?php wp_nonce_field( 'qsch_create_schedule_page', 'qsch_create_schedule_page_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row"><label for="qsch-page-title"><?php echo esc_html__( 'Page Title', 'quick-schedule' ); ?></label></th>
							<td><input id="qsch-page-title" name="page_title" type="text" class="regular-text" value="Book Consultation" required /></td>
						</tr>
						<tr>
							<th scope="row"><label for="qsch-page-status"><?php echo esc_html__( 'Status', 'quick-schedule' ); ?></label></th>
							<td>
								<select id="qsch-page-status" name="page_status">
									<option value="publish"><?php echo esc_html__( 'Publish', 'quick-schedule' ); ?></option>
									<option value="draft"><?php echo esc_html__( 'Draft', 'quick-schedule' ); ?></option>
								</select>
							</td>
						</tr>
					</tbody>
				</table>
				<?php submit_button( __( 'Create Appointment Page', 'quick-schedule' ) ); ?>
			</form>
			<hr />
			<h2><?php echo esc_html__( 'Booking Form Fields', 'quick-schedule' ); ?></h2>
			<p><?php echo esc_html__( 'Choose which client fields render on the booking page and customize their labels.', 'quick-schedule' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qsch_save_template_fields" />
				<?php wp_nonce_field( 'qsch_save_template_fields', 'qsch_save_template_fields_nonce' ); ?>
				<table class="form-table" role="presentation">
					<thead>
						<tr>
							<th><?php echo esc_html__( 'Field', 'quick-schedule' ); ?></th>
							<th><?php echo esc_html__( 'Enabled', 'quick-schedule' ); ?></th>
							<th><?php echo esc_html__( 'Required', 'quick-schedule' ); ?></th>
							<th><?php echo esc_html__( 'Label', 'quick-schedule' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $defaults as $field_key => $field_config ) : ?>
							<?php $current = isset( $fields[ $field_key ] ) && is_array( $fields[ $field_key ] ) ? $fields[ $field_key ] : $field_config; ?>
							<tr>
								<td><code><?php echo esc_html( $field_key ); ?></code></td>
								<td><input type="checkbox" name="booking_fields[<?php echo esc_attr( $field_key ); ?>][enabled]" value="1" <?php checked( ! empty( $current['enabled'] ) ); ?> /></td>
								<td><input type="checkbox" name="booking_fields[<?php echo esc_attr( $field_key ); ?>][required]" value="1" <?php checked( ! empty( $current['required'] ) ); ?> /></td>
								<td><input type="text" class="regular-text" name="booking_fields[<?php echo esc_attr( $field_key ); ?>][label]" value="<?php echo esc_attr( (string) $current['label'] ); ?>" /></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<?php submit_button( __( 'Save Form Fields', 'quick-schedule' ) ); ?>
			</form>
		</div>
		<?php
	}

	public function render_appointments_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-schedule' ) );
		}

		global $wpdb;
		$table = $wpdb->prefix . 'quick_schedule_appointments';
		$rows  = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT 500" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$settings = $this->get_settings();
		$license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';
		$license_status = isset( $settings['license_status'] ) ? sanitize_key( (string) $settings['license_status'] ) : 'inactive';
		$license_data = null;
		if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
			$license_data = qlic_get_license_status_for_key_products(
				$license_key,
				array(
					'quick-schedule',
					'quick-schedule-one-site',
					'quick-schedule-five-sites',
					'quick-schedule-unlimited-sites',
					'quick-woo-bundle',
					'quick-woo-suite',
					'quick-bundle',
                    'quick-secretary',
                )
			);
			if ( is_array( $license_data ) ) {
				$license_status = isset( $license_data['status'] ) ? sanitize_key( (string) $license_data['status'] ) : $license_status;
				if ( ! empty( $license_data['valid'] ) && ! empty( $license_data['domain_active'] ) ) {
					$license_status = 'active';
				}
			}
		}
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Quick Schedule Appointments', 'quick-schedule' ); ?></h1>
			<div class="notice notice-info inline">
				<p>
					<strong><?php echo esc_html__( 'License:', 'quick-schedule' ); ?></strong>
					<?php echo esc_html( ucfirst( $license_status ) ); ?>
					<?php if ( is_array( $license_data ) && ! empty( $license_data['product_slug'] ) ) : ?>
						<?php echo esc_html( sprintf( __( ' (%s)', 'quick-schedule' ), (string) $license_data['product_slug'] ) ); ?>
					<?php endif; ?>
					<?php if ( is_array( $license_data ) && isset( $license_data['activations'], $license_data['activation_limit'] ) ) : ?>
						<?php echo esc_html( sprintf( __( ' - Activations: %1$s/%2$s', 'quick-schedule' ), (string) $license_data['activations'], (string) $license_data['activation_limit'] ) ); ?>
					<?php endif; ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=quick-schedule-settings' ) ); ?>"><?php echo esc_html__( 'Manage License', 'quick-schedule' ); ?></a>
				</p>
			</div>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php echo esc_html__( 'ID', 'quick-schedule' ); ?></th>
						<th><?php echo esc_html__( 'Quote ID', 'quick-schedule' ); ?></th>
						<th><?php echo esc_html__( 'Client', 'quick-schedule' ); ?></th>
						<th><?php echo esc_html__( 'Appointment', 'quick-schedule' ); ?></th>
						<th><?php echo esc_html__( 'Base', 'quick-schedule' ); ?></th>
						<th><?php echo esc_html__( 'Fee', 'quick-schedule' ); ?></th>
						<th><?php echo esc_html__( 'Total Due', 'quick-schedule' ); ?></th>
						<th><?php echo esc_html__( 'Status', 'quick-schedule' ); ?></th>
						<th><?php echo esc_html__( 'Created', 'quick-schedule' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $rows ) ) : ?>
						<tr><td colspan="9"><?php echo esc_html__( 'No appointments yet.', 'quick-schedule' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $rows as $row ) : ?>
							<tr>
								<td><?php echo esc_html( (string) $row->id ); ?></td>
								<td><?php echo esc_html( (string) $row->quote_id ); ?></td>
								<td><?php echo esc_html( (string) $row->client_name . ' (' . (string) $row->client_email . ')' ); ?></td>
								<td><?php echo esc_html( (string) $row->appointment_at ); ?></td>
								<td><?php echo esc_html( number_format_i18n( (float) $row->base_amount, 2 ) ); ?></td>
								<td><?php echo esc_html( number_format_i18n( (float) $row->stripe_fee_amount, 2 ) ); ?></td>
								<td><?php echo esc_html( number_format_i18n( (float) $row->total_due, 2 ) ); ?></td>
								<td><?php echo esc_html( (string) $row->status ); ?></td>
								<td><?php echo esc_html( (string) $row->created_at ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-schedule' ) );
		}

		$settings = $this->get_settings();
		$premium_enabled = qsch_is_premium_active();
		$license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';
		$license_status = isset( $settings['license_status'] ) ? sanitize_key( (string) $settings['license_status'] ) : 'inactive';
		$license_message = isset( $settings['license_message'] ) ? sanitize_text_field( (string) $settings['license_message'] ) : '';
		$license_data = null;
		if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
			$license_data = qlic_get_license_status_for_key_products(
				$license_key,
				array(
					'quick-schedule',
					'quick-schedule-one-site',
					'quick-schedule-five-sites',
					'quick-schedule-unlimited-sites',
					'quick-woo-bundle',
					'quick-woo-suite',
					'quick-bundle',
                    'quick-secretary',
                )
			);
			if ( is_array( $license_data ) ) {
				$license_status = isset( $license_data['status'] ) ? sanitize_key( (string) $license_data['status'] ) : $license_status;
				if ( ! empty( $license_data['valid'] ) && ! empty( $license_data['domain_active'] ) ) {
					$license_status = 'active';
				}
			}
		}
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Quick Schedule Settings', 'quick-schedule' ); ?></h1>
			<?php if ( ! $premium_enabled ) : ?>
				<div class="notice notice-warning inline"><p><?php echo esc_html__( 'Stripe fee handling and email integration are premium features.', 'quick-schedule' ); ?></p></div>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qsch_save_settings" />
				<?php wp_nonce_field( 'qsch_save_settings', 'qsch_save_settings_nonce' ); ?>
				<table class="form-table">
					<tr>
						<th><label for="qs-consultation-fee"><?php echo esc_html__( 'Consultation Fee (Due Today)', 'quick-schedule' ); ?></label></th>
						<td>
							<input id="qs-consultation-fee" type="number" min="0" step="0.01" class="small-text" name="consultation_fee" value="<?php echo esc_attr( $settings['consultation_fee'] ); ?>" />
							<p class="description"><?php echo esc_html__( 'This fee is server-enforced and not editable on the client booking form.', 'quick-schedule' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="qs-admin-email"><?php echo esc_html__( 'Admin Email', 'quick-schedule' ); ?></label></th>
						<td><input id="qs-admin-email" type="email" class="regular-text" name="admin_email" value="<?php echo esc_attr( $settings['admin_email'] ); ?>" <?php disabled( ! $premium_enabled ); ?> /></td>
					</tr>
					<tr>
						<th><label for="qs-stripe-fee-percent"><?php echo esc_html__( 'Stripe Fee %', 'quick-schedule' ); ?></label></th>
						<td><input id="qs-stripe-fee-percent" type="number" min="0" step="0.01" class="small-text" name="stripe_fee_percent" value="<?php echo esc_attr( $settings['stripe_fee_percent'] ); ?>" <?php disabled( ! $premium_enabled ); ?> /></td>
					</tr>
					<tr>
						<th><label for="qs-stripe-fee-fixed"><?php echo esc_html__( 'Stripe Fixed Fee', 'quick-schedule' ); ?></label></th>
						<td><input id="qs-stripe-fee-fixed" type="number" min="0" step="0.01" class="small-text" name="stripe_fee_fixed" value="<?php echo esc_attr( $settings['stripe_fee_fixed'] ); ?>" <?php disabled( ! $premium_enabled ); ?> /></td>
					</tr>
					<tr>
						<th><label for="qs-link-template"><?php echo esc_html__( 'Stripe Link Template', 'quick-schedule' ); ?></label></th>
						<td>
							<input id="qs-link-template" type="text" class="regular-text" name="stripe_payment_link_template" value="<?php echo esc_attr( $settings['stripe_payment_link_template'] ); ?>" <?php disabled( ! $premium_enabled ); ?> />
							<p class="description"><?php echo esc_html__( 'Optional. Supports {amount_cents} and {email}.', 'quick-schedule' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><?php echo esc_html__( 'Quick Quotes Integration', 'quick-schedule' ); ?></th>
						<td><label><input type="checkbox" name="quick_quotes_integration_enabled" value="1" <?php checked( '1', $settings['quick_quotes_integration_enabled'] ); ?> <?php disabled( ! $premium_enabled ); ?> /> <?php echo esc_html__( 'Enable Quick Quote to Schedule handoff.', 'quick-schedule' ); ?></label></td>
					</tr>
					<tr>
						<th><?php echo esc_html__( 'Quick Forms Integration', 'quick-schedule' ); ?></th>
						<td><label><input type="checkbox" name="quick_forms_integration_enabled" value="1" <?php checked( '1', $settings['quick_forms_integration_enabled'] ); ?> <?php disabled( ! $premium_enabled ); ?> /> <?php echo esc_html__( 'Enable Quick Forms answer summary in booking view.', 'quick-schedule' ); ?></label></td>
					</tr>
				</table>
				<?php submit_button( __( 'Save Settings', 'quick-schedule' ) ); ?>
			</form>
			<hr />
			<h2><?php echo esc_html__( 'License Activation', 'quick-schedule' ); ?></h2>
			<p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-schedule' ), $license_status ) ); ?></p>
			<?php if ( '' !== $license_message ) : ?>
				<p><?php echo esc_html( $license_message ); ?></p>
			<?php endif; ?>
			<?php if ( is_array( $license_data ) && ! empty( $license_data['product_slug'] ) ) : ?>
				<p><?php echo esc_html( sprintf( __( 'Plan: %s', 'quick-schedule' ), (string) $license_data['product_slug'] ) ); ?></p>
				<p><?php echo esc_html( sprintf( __( 'Activations: %1$s / %2$s', 'quick-schedule' ), (string) $license_data['activations'], (string) $license_data['activation_limit'] ) ); ?></p>
				<p><?php echo esc_html( sprintf( __( 'Expires: %s', 'quick-schedule' ), ! empty( $license_data['expires_at'] ) ? (string) $license_data['expires_at'] : __( 'Never', 'quick-schedule' ) ) ); ?></p>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qsch_activate_license" />
				<?php wp_nonce_field( 'qsch_activate_license', 'qsch_activate_license_nonce' ); ?>
				<input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( $license_key ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
				<?php submit_button( __( 'Activate License', 'quick-schedule' ), 'secondary', '', false ); ?>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:8px;">
				<input type="hidden" name="action" value="qsch_deactivate_license" />
				<?php wp_nonce_field( 'qsch_deactivate_license', 'qsch_deactivate_license_nonce' ); ?>
				<?php submit_button( __( 'Deactivate License', 'quick-schedule' ), 'delete', '', false ); ?>
			</form>
		</div>
		<?php
	}

	public function handle_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-schedule' ) );
		}

		check_admin_referer( 'qsch_save_settings', 'qsch_save_settings_nonce' );
		$premium_enabled = qsch_is_premium_active();
		$current_settings = $this->get_settings();

		$settings = array(
			'consultation_fee'             => isset( $_POST['consultation_fee'] ) ? number_format( max( 0, (float) wp_unslash( $_POST['consultation_fee'] ) ), 2, '.', '' ) : '99.00',
			'admin_email'                  => $premium_enabled && isset( $_POST['admin_email'] ) ? sanitize_email( wp_unslash( $_POST['admin_email'] ) ) : get_option( 'admin_email', '' ),
			'stripe_fee_percent'           => $premium_enabled && isset( $_POST['stripe_fee_percent'] ) ? number_format( max( 0, (float) wp_unslash( $_POST['stripe_fee_percent'] ) ), 2, '.', '' ) : '0.00',
			'stripe_fee_fixed'             => $premium_enabled && isset( $_POST['stripe_fee_fixed'] ) ? number_format( max( 0, (float) wp_unslash( $_POST['stripe_fee_fixed'] ) ), 2, '.', '' ) : '0.00',
			'stripe_payment_link_template' => $premium_enabled && isset( $_POST['stripe_payment_link_template'] ) ? esc_url_raw( wp_unslash( $_POST['stripe_payment_link_template'] ) ) : '',
			'quick_quotes_integration_enabled' => $premium_enabled && isset( $_POST['quick_quotes_integration_enabled'] ) ? '1' : '0',
			'quick_forms_integration_enabled'  => $premium_enabled && isset( $_POST['quick_forms_integration_enabled'] ) ? '1' : '0',
			'custom_booking_css'           => isset( $current_settings['custom_booking_css'] ) ? (string) $current_settings['custom_booking_css'] : '',
			'license_key'                  => isset( $current_settings['license_key'] ) ? (string) $current_settings['license_key'] : '',
			'license_status'               => isset( $current_settings['license_status'] ) ? (string) $current_settings['license_status'] : 'inactive',
			'license_message'              => isset( $current_settings['license_message'] ) ? (string) $current_settings['license_message'] : '',
		);

		update_option( QSCH_OPTION_SETTINGS, $settings );
		wp_safe_redirect( admin_url( 'admin.php?page=quick-schedule-settings' ) );
		exit;
	}

	public function handle_activate_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-schedule' ) );
		}

		check_admin_referer( 'qsch_activate_license', 'qsch_activate_license_nonce' );

		$license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		$settings = $this->get_settings();

		if ( '' === $license_key ) {
			$settings['license_key'] = '';
			$settings['license_status'] = 'inactive';
			$settings['license_message'] = __( 'License key is required.', 'quick-schedule' );
			update_option( QSCH_OPTION_SETTINGS, $settings );
			wp_safe_redirect( admin_url( 'admin.php?page=quick-schedule-settings' ) );
			exit;
		}

		if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
			$settings['license_key'] = $license_key;
			$settings['license_status'] = 'invalid';
			$settings['license_message'] = __( 'Quick Woo License plugin is required for activation.', 'quick-schedule' );
			update_option( QSCH_OPTION_SETTINGS, $settings );
			wp_safe_redirect( admin_url( 'admin.php?page=quick-schedule-settings' ) );
			exit;
		}

		$result = qlic_activate_license_key_for_products(
			$license_key,
			array(
				'quick-schedule',
				'quick-schedule-one-site',
				'quick-schedule-five-sites',
				'quick-schedule-unlimited-sites',
				'quick-woo-bundle',
				'quick-woo-suite',
				'quick-bundle',
                    'quick-secretary',
                )
		);

		$settings['license_key'] = $license_key;
		$settings['license_status'] = isset( $result['status'] ) ? sanitize_key( (string) $result['status'] ) : 'invalid';
		$settings['license_message'] = isset( $result['message'] ) ? sanitize_text_field( (string) $result['message'] ) : __( 'License validation failed.', 'quick-schedule' );
		if ( ! empty( $result['valid'] ) ) {
			$settings['license_status'] = 'active';
		}

		update_option( QSCH_OPTION_SETTINGS, $settings );
		wp_safe_redirect( admin_url( 'admin.php?page=quick-schedule-settings' ) );
		exit;
	}

	public function handle_deactivate_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-schedule' ) );
		}

		check_admin_referer( 'qsch_deactivate_license', 'qsch_deactivate_license_nonce' );

		$settings = $this->get_settings();
		$license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';
		if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
			$result = qlic_deactivate_license_key_for_products(
				$license_key,
				array(
					'quick-schedule',
					'quick-schedule-one-site',
					'quick-schedule-five-sites',
					'quick-schedule-unlimited-sites',
					'quick-woo-bundle',
					'quick-woo-suite',
					'quick-bundle',
                    'quick-secretary',
                )
			);
			$settings['license_status'] = 'inactive';
			$settings['license_message'] = isset( $result['message'] ) ? sanitize_text_field( (string) $result['message'] ) : __( 'License deactivated.', 'quick-schedule' );
		} else {
			$settings['license_status'] = 'inactive';
			$settings['license_message'] = __( 'License deactivated.', 'quick-schedule' );
		}

		update_option( QSCH_OPTION_SETTINGS, $settings );
		wp_safe_redirect( admin_url( 'admin.php?page=quick-schedule-settings' ) );
		exit;
	}

	public function handle_create_schedule_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-schedule' ) );
		}

		check_admin_referer( 'qsch_create_schedule_page', 'qsch_create_schedule_page_nonce' );

		$title = isset( $_POST['page_title'] ) ? sanitize_text_field( wp_unslash( $_POST['page_title'] ) ) : '';
		$status = isset( $_POST['page_status'] ) ? sanitize_key( wp_unslash( $_POST['page_status'] ) ) : 'publish';
		if ( '' === $title ) {
			$title = __( 'Book Consultation', 'quick-schedule' );
		}
		if ( ! in_array( $status, array( 'publish', 'draft' ), true ) ) {
			$status = 'publish';
		}

		$page_id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_title'   => $title,
				'post_status'  => $status,
				'post_content' => '[quick_schedule_appointment_page]',
			),
			true
		);

		$redirect_url = admin_url( 'admin.php?page=quick-schedule-page-template' );
		if ( ! is_wp_error( $page_id ) && $page_id > 0 ) {
			$redirect_url = add_query_arg( 'qsch_created_page', (int) $page_id, $redirect_url );
		}

		wp_safe_redirect( $redirect_url );
		exit;
	}

	public function render_style_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-schedule' ) );
		}

		$settings = $this->get_settings();
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Quick Schedule Style', 'quick-schedule' ); ?></h1>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qsch_save_style" />
				<?php wp_nonce_field( 'qsch_save_style', 'qsch_save_style_nonce' ); ?>
				<textarea name="custom_booking_css" rows="18" class="large-text code"><?php echo esc_textarea( (string) $settings['custom_booking_css'] ); ?></textarea>
				<?php submit_button( __( 'Save Style', 'quick-schedule' ) ); ?>
			</form>
		</div>
		<?php
	}

	public function handle_save_style() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-schedule' ) );
		}

		check_admin_referer( 'qsch_save_style', 'qsch_save_style_nonce' );
		$settings = $this->get_settings();
		$settings['custom_booking_css'] = isset( $_POST['custom_booking_css'] ) ? wp_kses_post( (string) wp_unslash( $_POST['custom_booking_css'] ) ) : '';
		update_option( QSCH_OPTION_SETTINGS, $settings );
		wp_safe_redirect( admin_url( 'admin.php?page=quick-schedule-style' ) );
		exit;
	}

	public function handle_save_template_fields() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-schedule' ) );
		}

		check_admin_referer( 'qsch_save_template_fields', 'qsch_save_template_fields_nonce' );
		$settings = $this->get_settings();
		$defaults = $this->get_default_booking_fields();
		$input_fields = isset( $_POST['booking_fields'] ) && is_array( $_POST['booking_fields'] ) ? wp_unslash( $_POST['booking_fields'] ) : array();
		$saved_fields = array();

		foreach ( $defaults as $field_key => $default_config ) {
			$incoming = isset( $input_fields[ $field_key ] ) && is_array( $input_fields[ $field_key ] ) ? $input_fields[ $field_key ] : array();
			$saved_fields[ $field_key ] = array(
				'enabled'  => ! empty( $incoming['enabled'] ) ? 1 : 0,
				'required' => ! empty( $incoming['required'] ) ? 1 : 0,
				'label'    => isset( $incoming['label'] ) ? sanitize_text_field( (string) $incoming['label'] ) : (string) $default_config['label'],
			);
		}

		$settings['booking_fields'] = $saved_fields;
		update_option( QSCH_OPTION_SETTINGS, $settings );
		wp_safe_redirect( admin_url( 'admin.php?page=quick-schedule-page-template' ) );
		exit;
	}

	private function get_settings() {
		$defaults = array(
			'consultation_fee'             => '99.00',
			'admin_email'                  => get_option( 'admin_email', '' ),
			'stripe_fee_percent'           => '2.90',
			'stripe_fee_fixed'             => '0.30',
			'stripe_payment_link_template' => '',
			'quick_quotes_integration_enabled' => '1',
			'quick_forms_integration_enabled'  => '1',
			'custom_booking_css'           => '',
			'booking_fields'               => $this->get_default_booking_fields(),
			'license_key'                  => '',
			'license_status'               => 'inactive',
			'license_message'              => '',
		);

		return wp_parse_args( get_option( QSCH_OPTION_SETTINGS, array() ), $defaults );
	}

	private function get_default_booking_fields() {
		return array(
			'client_name' => array(
				'enabled'  => 1,
				'required' => 1,
				'label'    => __( 'Name', 'quick-schedule' ),
			),
			'client_email' => array(
				'enabled'  => 1,
				'required' => 1,
				'label'    => __( 'Email', 'quick-schedule' ),
			),
			'client_phone' => array(
				'enabled'  => 1,
				'required' => 0,
				'label'    => __( 'Phone', 'quick-schedule' ),
			),
			'appointment_at' => array(
				'enabled'  => 1,
				'required' => 1,
				'label'    => __( 'Preferred Appointment Time', 'quick-schedule' ),
			),
			'notes' => array(
				'enabled'  => 1,
				'required' => 0,
				'label'    => __( 'Notes', 'quick-schedule' ),
			),
		);
	}
}
