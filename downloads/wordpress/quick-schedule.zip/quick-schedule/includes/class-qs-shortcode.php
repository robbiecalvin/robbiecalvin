<?php
/**
 * Frontend shortcode.
 *
 * @package QuickSchedule
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QSCH_Shortcode {
	private static $template_styles_printed = false;

	public function __construct() {
		add_shortcode( 'quick_schedule_booking', array( $this, 'render_booking_shortcode' ) );
		add_shortcode( 'quick_schedule_appointment_page', array( $this, 'render_appointment_page_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
	}

	public function register_assets() {
		wp_register_script( 'qws-frontend-js', QSCH_PLUGIN_URL . 'assets/js/frontend.js', array( 'jquery' ), QSCH_PLUGIN_VERSION, true );
	}

	public function render_booking_shortcode() {
		$settings = $this->get_settings();
		$premium_enabled = qsch_is_premium_active();
		$quick_quotes_integration_enabled = $premium_enabled && isset( $settings['quick_quotes_integration_enabled'] ) && '1' === (string) $settings['quick_quotes_integration_enabled'];
		$quick_forms_integration_enabled  = $premium_enabled && isset( $settings['quick_forms_integration_enabled'] ) && '1' === (string) $settings['quick_forms_integration_enabled'];

		$name     = isset( $_GET['name'] ) ? sanitize_text_field( wp_unslash( $_GET['name'] ) ) : '';
		$email    = isset( $_GET['email'] ) ? sanitize_email( wp_unslash( $_GET['email'] ) ) : '';
		$quote_id = isset( $_GET['quote_id'] ) ? absint( $_GET['quote_id'] ) : 0;
		$amount   = isset( $_GET['amount'] ) ? max( 0, (float) wp_unslash( $_GET['amount'] ) ) : 0;
		$project_type = '';
		$form_answers = array();
		$prefill_notes = '';
		$quote_due_today = isset( $_GET['due_today'] ) ? max( 0, (float) wp_unslash( $_GET['due_today'] ) ) : 0.0;

		if ( $quote_id > 0 && $quick_quotes_integration_enabled ) {
			$quote_prefill = $this->get_quote_prefill( $quote_id );
			if ( ! empty( $quote_prefill ) ) {
				if ( '' === $name && ! empty( $quote_prefill['client_name'] ) ) {
					$name = (string) $quote_prefill['client_name'];
				}
				if ( '' === $email && ! empty( $quote_prefill['client_email'] ) ) {
					$email = (string) $quote_prefill['client_email'];
				}
				if ( ! empty( $quote_prefill['project_type'] ) ) {
					$project_type = (string) $quote_prefill['project_type'];
				}
				$amount = isset( $quote_prefill['project_estimate'] ) ? max( 0, (float) $quote_prefill['project_estimate'] ) : $amount;
				$quote_due_today = isset( $quote_prefill['due_today'] ) ? max( 0, (float) $quote_prefill['due_today'] ) : $quote_due_today;
				$form_answers = $quick_forms_integration_enabled && isset( $quote_prefill['submitted_answers'] ) && is_array( $quote_prefill['submitted_answers'] ) ? $quote_prefill['submitted_answers'] : array();
				$prefill_notes = isset( $quote_prefill['prefill_notes'] ) ? (string) $quote_prefill['prefill_notes'] : '';
			}
		}

		$consultation_fee = max( 0, (float) $settings['consultation_fee'] );
		$final_due_today  = round( $quote_due_today + $consultation_fee, 2 );
		$booking_fields = isset( $settings['booking_fields'] ) && is_array( $settings['booking_fields'] ) ? $settings['booking_fields'] : $this->get_default_booking_fields();
		$booking_fields = wp_parse_args( $booking_fields, $this->get_default_booking_fields() );

		wp_enqueue_script( 'qws-frontend-js' );
		wp_localize_script(
			'qws-frontend-js',
			'QWSData',
			array(
				'ajax_url'          => admin_url( 'admin-ajax.php' ),
				'nonce'             => wp_create_nonce( 'qsch_book_nonce' ),
				'stripe_fee_percent'=> (float) $settings['stripe_fee_percent'],
				'stripe_fee_fixed'  => (float) $settings['stripe_fee_fixed'],
				'consultation_fee'  => $consultation_fee,
			)
		);

		ob_start();
		?>
		<form id="qs-booking-form" class="qs-booking-form" method="post">
			<?php if ( ! $premium_enabled ) : ?>
				<p><?php echo esc_html__( 'Free mode: appointment requests only. Stripe fee and payment link handling require premium.', 'quick-schedule' ); ?></p>
			<?php endif; ?>
			<input type="hidden" name="quote_id" value="<?php echo esc_attr( (string) $quote_id ); ?>" />
			<input type="hidden" id="qs-base-amount" name="base_amount" value="<?php echo esc_attr( number_format( $consultation_fee, 2, '.', '' ) ); ?>" />
			<input type="hidden" id="qs-quote-due-today" name="quote_due_today" value="<?php echo esc_attr( number_format( $quote_due_today, 2, '.', '' ) ); ?>" />
			<?php if ( '' !== $project_type ) : ?>
				<input type="hidden" name="project_type" value="<?php echo esc_attr( $project_type ); ?>" />
			<?php endif; ?>
			<?php if ( ! empty( $booking_fields['client_name']['enabled'] ) ) : ?>
				<div><label><?php echo esc_html( (string) $booking_fields['client_name']['label'] ); ?></label><input type="text" name="client_name" <?php echo ! empty( $booking_fields['client_name']['required'] ) ? 'required' : ''; ?> value="<?php echo esc_attr( $name ); ?>" /></div>
			<?php endif; ?>
			<?php if ( ! empty( $booking_fields['client_email']['enabled'] ) ) : ?>
				<div><label><?php echo esc_html( (string) $booking_fields['client_email']['label'] ); ?></label><input type="email" name="client_email" <?php echo ! empty( $booking_fields['client_email']['required'] ) ? 'required' : ''; ?> value="<?php echo esc_attr( $email ); ?>" /></div>
			<?php endif; ?>
			<?php if ( ! empty( $booking_fields['client_phone']['enabled'] ) ) : ?>
				<div><label><?php echo esc_html( (string) $booking_fields['client_phone']['label'] ); ?></label><input type="text" name="client_phone" <?php echo ! empty( $booking_fields['client_phone']['required'] ) ? 'required' : ''; ?> /></div>
			<?php endif; ?>
			<?php if ( ! empty( $booking_fields['appointment_at']['enabled'] ) ) : ?>
				<div><label><?php echo esc_html( (string) $booking_fields['appointment_at']['label'] ); ?></label><input type="datetime-local" name="appointment_at" <?php echo ! empty( $booking_fields['appointment_at']['required'] ) ? 'required' : ''; ?> /></div>
			<?php endif; ?>
			<?php if ( '' !== $project_type ) : ?>
				<div><strong><?php echo esc_html__( 'Project Type:', 'quick-schedule' ); ?></strong> <span><?php echo esc_html( $project_type ); ?></span></div>
			<?php endif; ?>
			<?php if ( ! empty( $form_answers ) ) : ?>
				<div>
					<strong><?php echo esc_html__( 'Form Answers Summary:', 'quick-schedule' ); ?></strong>
					<ul>
						<?php foreach ( $form_answers as $answer_line ) : ?>
							<li><?php echo esc_html( $answer_line ); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>
			<?php if ( ! empty( $booking_fields['notes']['enabled'] ) ) : ?>
				<div><label><?php echo esc_html( (string) $booking_fields['notes']['label'] ); ?></label><textarea name="notes" rows="5" <?php echo ! empty( $booking_fields['notes']['required'] ) ? 'required' : ''; ?>><?php echo esc_textarea( $prefill_notes ); ?></textarea></div>
			<?php endif; ?>
			<div><strong><?php echo esc_html__( 'Project Estimate:', 'quick-schedule' ); ?></strong> <span id="qs-project-estimate"><?php echo esc_html( number_format_i18n( $amount, 2 ) ); ?></span></div>
			<div><strong><?php echo esc_html__( 'Quote Due Today:', 'quick-schedule' ); ?></strong> <span id="qs-quote-due-today-display"><?php echo esc_html( number_format_i18n( $quote_due_today, 2 ) ); ?></span></div>
			<div><strong><?php echo esc_html__( 'Consultation Non-refundable Fee:', 'quick-schedule' ); ?></strong> <span id="qs-consultation-fee"><?php echo esc_html( number_format_i18n( $consultation_fee, 2 ) ); ?></span></div>
			<div><strong><?php echo esc_html__( 'Final Total Due Today:', 'quick-schedule' ); ?></strong> <span id="qs-total-amount"><?php echo esc_html( number_format_i18n( $final_due_today, 2 ) ); ?></span></div>
			<button type="submit"><?php echo esc_html__( 'Book Consultation', 'quick-schedule' ); ?></button>
			<div id="qs-message" aria-live="polite"></div>
		</form>
		<?php
		return (string) ob_get_clean();
	}

	public function render_appointment_page_shortcode( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'title'    => __( 'Book Your Consultation', 'quick-schedule' ),
				'subtitle' => __( 'Choose your preferred time and submit your appointment request.', 'quick-schedule' ),
			),
			$atts,
			'quick_schedule_appointment_page'
		);

		$styles = '';
		if ( ! self::$template_styles_printed ) {
			self::$template_styles_printed = true;
			$custom_booking_css = isset( $this->get_settings()['custom_booking_css'] ) ? (string) $this->get_settings()['custom_booking_css'] : '';
			$styles = '<style>
			.qsch-appointment-page{max-width:980px;margin:24px auto;padding:24px;background:#eaf6ff;border:1px solid #9fb8cc;border-radius:10px}
			.qsch-appointment-page h2{margin:0 0 8px 0;color:#0f2a55}
			.qsch-appointment-page p{margin:0 0 16px 0;color:#1f3147}
			.qsch-appointment-page .qsch-card{background:#fff;border:1px solid #000;border-radius:8px;padding:18px}
			.qsch-appointment-page .qs-booking-form{display:grid;grid-template-columns:1fr;gap:12px}
			.qsch-appointment-page .qs-booking-form label{display:block;margin-bottom:4px;font-weight:600;color:#0f2a55}
			.qsch-appointment-page .qs-booking-form input,
			.qsch-appointment-page .qs-booking-form textarea{width:100%;padding:10px;border:1px solid #000;border-radius:6px;box-sizing:border-box}
			.qsch-appointment-page .qs-booking-form button[type=submit]{background:#1f6ef5;color:#fff;border:1px solid #1f6ef5;padding:10px 14px;border-radius:6px;cursor:pointer}
			.qsch-appointment-page #qs-message{font-weight:600}
			' . wp_strip_all_tags( $custom_booking_css ) . '
			</style>';
		}

		$form = $this->render_booking_shortcode();

		ob_start();
		echo $styles; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		?>
		<section class="qsch-appointment-page">
			<h2><?php echo esc_html( $atts['title'] ); ?></h2>
			<p><?php echo esc_html( $atts['subtitle'] ); ?></p>
			<div class="qsch-card">
				<?php echo $form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		</section>
		<?php
		return (string) ob_get_clean();
	}

	private function get_settings() {
		$defaults = array(
			'stripe_fee_percent' => '2.90',
			'stripe_fee_fixed'   => '0.30',
			'consultation_fee'   => '99.00',
			'quick_quotes_integration_enabled' => '1',
			'quick_forms_integration_enabled'  => '1',
			'custom_booking_css'   => '',
			'booking_fields'       => $this->get_default_booking_fields(),
		);
		return wp_parse_args( get_option( QSCH_OPTION_SETTINGS, array() ), $defaults );
	}

	private function get_default_booking_fields() {
		return array(
			'client_name' => array( 'enabled' => 1, 'required' => 1, 'label' => __( 'Name', 'quick-schedule' ) ),
			'client_email' => array( 'enabled' => 1, 'required' => 1, 'label' => __( 'Email', 'quick-schedule' ) ),
			'client_phone' => array( 'enabled' => 1, 'required' => 0, 'label' => __( 'Phone', 'quick-schedule' ) ),
			'appointment_at' => array( 'enabled' => 1, 'required' => 1, 'label' => __( 'Preferred Appointment Time', 'quick-schedule' ) ),
			'notes' => array( 'enabled' => 1, 'required' => 0, 'label' => __( 'Notes', 'quick-schedule' ) ),
		);
	}

	private function get_quote_prefill( $quote_id ) {
		global $wpdb;

		$table = $wpdb->prefix . 'quick_quotes';
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $table !== $exists ) {
			return array();
		}

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, client_name, client_email, project_type, total, due_today, notes FROM {$table} WHERE id = %d LIMIT 1",
				absint( $quote_id )
			),
			ARRAY_A
		);

		if ( ! is_array( $row ) || empty( $row['id'] ) ) {
			return array();
		}

		$submitted_answers = array();
		$prefill_notes = '';
		$notes = isset( $row['notes'] ) ? (string) $row['notes'] : '';
		if ( '' !== $notes ) {
			$decoded = $this->extract_submission_json_from_notes( $notes );
			if ( ! empty( $decoded ) ) {
				foreach ( $decoded as $answer_key => $answer_value ) {
					$answer_key = sanitize_key( (string) $answer_key );
					if ( '' === $answer_key ) {
						continue;
					}

					if ( is_array( $answer_value ) ) {
						$answer_value = implode( ', ', array_map( 'sanitize_text_field', $answer_value ) );
					} else {
						$answer_value = sanitize_text_field( (string) $answer_value );
					}

					if ( '' === $answer_value ) {
						continue;
					}

					$submitted_answers[] = sprintf( '%s: %s', ucwords( str_replace( '_', ' ', $answer_key ) ), $answer_value );
				}
			}

			$prefill_notes = sanitize_textarea_field( $notes );
		}

		return array(
			'client_name'      => isset( $row['client_name'] ) ? sanitize_text_field( (string) $row['client_name'] ) : '',
			'client_email'     => isset( $row['client_email'] ) ? sanitize_email( (string) $row['client_email'] ) : '',
			'project_type'     => isset( $row['project_type'] ) ? sanitize_text_field( (string) $row['project_type'] ) : '',
			'project_estimate' => isset( $row['total'] ) ? (float) $row['total'] : 0.0,
			'due_today'        => isset( $row['due_today'] ) ? (float) $row['due_today'] : 0.0,
			'submitted_answers'=> $submitted_answers,
			'prefill_notes'    => $prefill_notes,
		);
	}

	private function extract_submission_json_from_notes( $notes ) {
		$notes = (string) $notes;
		if ( '' === $notes ) {
			return array();
		}

		$chunks = preg_split( "/\\n\\s*\\n/", $notes );
		if ( ! is_array( $chunks ) ) {
			return array();
		}

		foreach ( array_reverse( $chunks ) as $chunk ) {
			$chunk = trim( (string) $chunk );
			if ( '' === $chunk ) {
				continue;
			}
			$decoded = json_decode( $chunk, true );
			if ( is_array( $decoded ) ) {
				return $decoded;
			}
		}

		return array();
	}
}
