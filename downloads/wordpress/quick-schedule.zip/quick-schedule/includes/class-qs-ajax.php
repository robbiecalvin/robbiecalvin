<?php
/**
 * AJAX handlers.
 *
 * @package QuickSchedule
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QSCH_Ajax {
	public function __construct() {
		add_action( 'wp_ajax_qsch_book_appointment', array( $this, 'handle_book_appointment' ) );
		add_action( 'wp_ajax_nopriv_qsch_book_appointment', array( $this, 'handle_book_appointment' ) );
		add_action( 'wp_ajax_qs_book_appointment', array( $this, 'handle_book_appointment' ) );
		add_action( 'wp_ajax_nopriv_qs_book_appointment', array( $this, 'handle_book_appointment' ) );
	}

	public function handle_book_appointment() {
		check_ajax_referer( 'qsch_book_nonce', 'nonce' );

		$quote_id       = isset( $_POST['quote_id'] ) ? absint( $_POST['quote_id'] ) : 0;
		$client_name    = isset( $_POST['client_name'] ) ? sanitize_text_field( wp_unslash( $_POST['client_name'] ) ) : '';
		$client_email   = isset( $_POST['client_email'] ) ? sanitize_email( wp_unslash( $_POST['client_email'] ) ) : '';
		$client_phone   = isset( $_POST['client_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['client_phone'] ) ) : '';
		$appointment_at = isset( $_POST['appointment_at'] ) ? sanitize_text_field( wp_unslash( $_POST['appointment_at'] ) ) : '';
		$notes          = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '';

		if ( '' === $client_name || ! is_email( $client_email ) || '' === $appointment_at ) {
			wp_send_json_error( array( 'message' => __( 'Please complete all required fields.', 'quick-schedule' ) ), 400 );
		}

		$appointment_mysql = gmdate( 'Y-m-d H:i:s', strtotime( $appointment_at ) );
		if ( false === strtotime( $appointment_mysql ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid appointment time.', 'quick-schedule' ) ), 400 );
		}

		$settings    = $this->get_settings();
		$premium_enabled = qsch_is_premium_active();
		$quick_quotes_integration_enabled = $premium_enabled && isset( $settings['quick_quotes_integration_enabled'] ) && '1' === (string) $settings['quick_quotes_integration_enabled'];
		$base_amount = max( 0, (float) $settings['consultation_fee'] );
		$fee_percent = $premium_enabled ? max( 0, (float) $settings['stripe_fee_percent'] ) : 0.0;
		$fee_fixed   = $premium_enabled ? max( 0, (float) $settings['stripe_fee_fixed'] ) : 0.0;
		$project_estimate = $quick_quotes_integration_enabled ? $this->get_quote_total( $quote_id ) : 0.0;
		$quote_due_today = $quick_quotes_integration_enabled ? $this->get_quote_due_today( $quote_id ) : 0.0;
		$total_due   = round( $base_amount + $quote_due_today, 2 );
		$fee_amount  = round( ( $total_due * ( $fee_percent / 100 ) ) + $fee_fixed, 2 );

		$stripe_url = '';

		global $wpdb;
		$table = $wpdb->prefix . 'quick_schedule_appointments';
		$query = $wpdb->prepare(
			"INSERT INTO {$table}
			(quote_id, client_name, client_email, client_phone, appointment_at, base_amount, stripe_fee_percent, stripe_fee_fixed, stripe_fee_amount, total_due, stripe_payment_url, status, notes, created_at)
			VALUES (%d, %s, %s, %s, %s, %f, %f, %f, %f, %f, %s, %s, %s, %s)",
			$quote_id,
			$client_name,
			$client_email,
			$client_phone,
			$appointment_mysql,
			$base_amount,
			$fee_percent,
			$fee_fixed,
			$fee_amount,
			$total_due,
			$stripe_url,
			'pending',
			$notes,
			current_time( 'mysql' )
		);

		$inserted = $wpdb->query( $query );
		if ( false === $inserted ) {
			wp_send_json_error( array( 'message' => __( 'Could not create appointment.', 'quick-schedule' ) ), 500 );
		}
		$appointment_id = absint( $wpdb->insert_id );

		if ( $premium_enabled ) {
			$checkout = $this->create_woocommerce_checkout_for_consultation( $appointment_id, $quote_id, $client_name, $total_due );
			if ( is_array( $checkout ) && ! empty( $checkout['checkout_url'] ) ) {
				$stripe_url = esc_url_raw( (string) $checkout['checkout_url'] );
				$wpdb->query(
					$wpdb->prepare(
						"UPDATE {$table} SET stripe_payment_url = %s WHERE id = %d",
						$stripe_url,
						$appointment_id
					)
				);
			}
		}

		$admin_email = sanitize_email( $settings['admin_email'] );
		if ( $premium_enabled && is_email( $admin_email ) ) {
			$subject = __( 'New Quick Schedule Appointment', 'quick-schedule' );
				$message = sprintf(
					/* translators: 1: name, 2: email, 3: appointment time, 4: total due */
					__( "Client: %1\$s\nEmail: %2\$s\nAppointment: %3\$s\nTotal Due: %4\$s", 'quick-schedule' ),
				$client_name,
				$client_email,
				$appointment_mysql,
				number_format_i18n( $total_due, 2 )
			);
			wp_mail( $admin_email, $subject, $message );
		}

		if ( $premium_enabled ) {
			$customer_subject = __( 'Your Consultation Request Is Received', 'quick-schedule' );
			$customer_message = sprintf(
				/* translators: 1: client name, 2: appointment datetime, 3: total due */
				__( "Hi %1\$s,\n\nYour consultation request has been received.\nRequested time: %2\$s\nTotal due: %3\$s\n", 'quick-schedule' ),
				$client_name,
				$appointment_mysql,
				number_format_i18n( $total_due, 2 )
			);
			if ( '' !== $stripe_url ) {
				$customer_message .= "\n" . sprintf(
					/* translators: %s: payment URL */
					__( 'Payment link: %s', 'quick-schedule' ),
					$stripe_url
				);
			}
			wp_mail( $client_email, $customer_subject, $customer_message );
		}

		if ( function_exists( 'qwoo_event' ) ) {
			qwoo_event(
				'consultation_booked',
				array(
					'plugin'         => 'quick-schedule',
					'quote_id'       => $quote_id,
					'client_email'   => $client_email,
					'appointment_at' => $appointment_mysql,
					'total_due'      => number_format( $total_due, 2, '.', '' ),
				),
				array(
					'source' => 'quick-schedule',
				)
			);
		}

		wp_send_json_success(
			array(
				'message'             => __( 'Appointment submitted successfully.', 'quick-schedule' ),
				'payment_url'         => $stripe_url,
				'total_due'           => number_format( $total_due, 2, '.', '' ),
				'project_estimate'    => number_format( $project_estimate, 2, '.', '' ),
				'quote_due_today'     => number_format( $quote_due_today, 2, '.', '' ),
				'consultation_fee'    => number_format( $base_amount, 2, '.', '' ),
				'estimated_processor' => number_format( $fee_amount, 2, '.', '' ),
			)
		);
	}

	private function get_settings() {
		$defaults = array(
			'admin_email'                  => get_option( 'admin_email', '' ),
			'stripe_fee_percent'           => '2.90',
			'stripe_fee_fixed'             => '0.30',
			'stripe_payment_link_template' => '',
			'consultation_fee'             => '99.00',
			'quick_quotes_integration_enabled' => '1',
			'quick_forms_integration_enabled'  => '1',
			'custom_booking_css'           => '',
		);
		return wp_parse_args( get_option( QSCH_OPTION_SETTINGS, array() ), $defaults );
	}

	private function get_quote_total( $quote_id ) {
		$quote_id = absint( $quote_id );
		if ( $quote_id < 1 ) {
			return 0.0;
		}

		global $wpdb;
		$table = $wpdb->prefix . 'quick_quotes';
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $table !== $exists ) {
			return 0.0;
		}

		$total = $wpdb->get_var(
			$wpdb->prepare( "SELECT total FROM {$table} WHERE id = %d LIMIT 1", $quote_id )
		);

		return max( 0, (float) $total );
	}

	private function get_quote_due_today( $quote_id ) {
		$quote_id = absint( $quote_id );
		if ( $quote_id < 1 ) {
			return 0.0;
		}

		global $wpdb;
		$table = $wpdb->prefix . 'quick_quotes';
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $table !== $exists ) {
			return 0.0;
		}

		$due_today = $wpdb->get_var(
			$wpdb->prepare( "SELECT due_today FROM {$table} WHERE id = %d LIMIT 1", $quote_id )
		);

		return max( 0, (float) $due_today );
	}

	private function create_woocommerce_checkout_for_consultation( $appointment_id, $quote_id, $client_name, $total_due ) {
		$total_due = max( 0, round( (float) $total_due, 2 ) );
		if ( $total_due <= 0 || ! class_exists( 'WooCommerce' ) ) {
			return array();
		}

		$product_name = sprintf(
			/* translators: 1: appointment id, 2: quote id */
			__( 'Consultation Payment #%1$d (Quote #%2$d)', 'quick-schedule' ),
			absint( $appointment_id ),
			absint( $quote_id )
		);

		$product_id = wp_insert_post(
			array(
				'post_type'    => 'product',
				'post_status'  => 'publish',
				'post_title'   => $product_name,
				'post_content' => '',
			),
			true
		);

		if ( is_wp_error( $product_id ) || $product_id < 1 ) {
			return array();
		}

		$price = number_format( $total_due, 2, '.', '' );
		update_post_meta( $product_id, '_regular_price', $price );
		update_post_meta( $product_id, '_price', $price );
		update_post_meta( $product_id, '_virtual', 'yes' );
		update_post_meta( $product_id, '_sold_individually', 'yes' );
		update_post_meta( $product_id, '_manage_stock', 'no' );
		update_post_meta( $product_id, '_stock_status', 'instock' );
		update_post_meta( $product_id, '_visibility', 'hidden' );
		update_post_meta( $product_id, '_qwoo_quote_id', absint( $quote_id ) );
		update_post_meta( $product_id, '_qwoo_consultation_id', absint( $appointment_id ) );
		update_post_meta( $product_id, '_qwoo_client_name', sanitize_text_field( (string) $client_name ) );

		$checkout_url = '';
		if ( function_exists( 'wc_get_checkout_url' ) ) {
			$checkout_url = add_query_arg(
				array(
					'add-to-cart' => absint( $product_id ),
					'quantity'    => 1,
				),
				wc_get_checkout_url()
			);
		}

		return array(
			'product_id'   => absint( $product_id ),
			'checkout_url' => esc_url_raw( $checkout_url ),
		);
	}
}
