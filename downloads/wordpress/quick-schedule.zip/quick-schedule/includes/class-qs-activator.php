<?php
/**
 * Activator.
 *
 * @package QuickSchedule
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QSCH_Activator {
	public static function activate() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'quick_schedule_appointments';
		$charset_collate = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "CREATE TABLE {$table_name} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			quote_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			client_name VARCHAR(255) NOT NULL,
			client_email VARCHAR(255) NOT NULL,
			client_phone VARCHAR(255) NULL,
			appointment_at DATETIME NULL,
			base_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
			stripe_fee_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
			stripe_fee_fixed DECIMAL(10,2) NOT NULL DEFAULT 0.00,
			stripe_fee_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
			total_due DECIMAL(10,2) NOT NULL DEFAULT 0.00,
			stripe_payment_url TEXT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'pending',
			notes TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id)
		) {$charset_collate};";

		dbDelta( $sql );

		$defaults = array(
			'admin_email'                  => get_option( 'admin_email', '' ),
			'stripe_fee_percent'           => '2.90',
			'stripe_fee_fixed'             => '0.30',
			'stripe_payment_link_template' => '',
		);
		update_option( QSCH_OPTION_SETTINGS, wp_parse_args( get_option( QSCH_OPTION_SETTINGS, array() ), $defaults ) );
	}
}
