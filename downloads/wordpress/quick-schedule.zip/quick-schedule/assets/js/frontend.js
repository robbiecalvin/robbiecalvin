(function ($) {
    'use strict';

    function calculateTotals() {
        var bookingFee = parseFloat($('#qs-base-amount').val() || '0');
        if (isNaN(bookingFee) || bookingFee < 0) {
            bookingFee = 0;
        }

        var quoteDueToday = parseFloat($('#qs-quote-due-today').val() || '0');
        if (isNaN(quoteDueToday) || quoteDueToday < 0) {
            quoteDueToday = 0;
        }

        var feePercent = parseFloat(QWSData.stripe_fee_percent || 0);
        var feeFixed = parseFloat(QWSData.stripe_fee_fixed || 0);
        var processorEstimate = ((quoteDueToday + bookingFee) * (feePercent / 100)) + feeFixed;
        var total = quoteDueToday + bookingFee;

        $('#qs-fee-amount').text(processorEstimate.toFixed(2));
        $('#qs-total-amount').text(total.toFixed(2));
        $('#qs-consultation-fee').text(bookingFee.toFixed(2));
        $('#qs-quote-due-today-display').text(quoteDueToday.toFixed(2));
    }

    $(document).on('input', '#qs-base-amount', calculateTotals);
    calculateTotals();

    $(document).on('submit', '#qs-booking-form', function (e) {
        e.preventDefault();

        var $form = $(this);
        var $msg = $('#qs-message');
        var data = $form.serializeArray();
        data.push({name: 'action', value: 'qsch_book_appointment'});
        data.push({name: 'nonce', value: QWSData.nonce});

        $msg.text('');

        $.post(QWSData.ajax_url, data)
            .done(function (response) {
                if (!response || !response.success) {
                    $msg.text((response && response.data && response.data.message) ? response.data.message : 'Request failed.');
                    return;
                }

                var text = response.data.message || 'Appointment submitted.';
                if (response.data.payment_url) {
                    text += ' ';
                    $msg.html(text + '<a href="' + response.data.payment_url + '" target="_blank" rel="noopener">Pay now</a>');
                } else {
                    $msg.text(text);
                }
                $form.trigger('reset');
                calculateTotals();
            })
            .fail(function (xhr) {
                var response = xhr.responseJSON;
                $msg.text((response && response.data && response.data.message) ? response.data.message : 'Request failed.');
            });
    });
})(jQuery);
