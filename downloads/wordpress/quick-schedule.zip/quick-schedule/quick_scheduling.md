# Quick Scheduling -- Visual To‑Do

## Appointments Page

-   No changes required

## Settings Page

-   Add left-side padding to all form labels

## Page Templates

-   Add left-side padding to labels
