<?php
/**
 * Plugin Name: Quick Audit
 * Description: Fast internal SEO audit for the current WordPress site only.
 * Version: 1.0.0
 * Author: QuickWoo by Robbie Calvin
 * Author URI: https://quickwoo.pro
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/quick-core/bootstrap.php';
}

function qaud_is_premium_active(): bool {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

    if ( function_exists( 'qwoo_has_active_license' ) ) {
        return (bool) qwoo_has_active_license( array( 'quick-audit' ) );
    }

    return false;
}

final class QAUD_Plugin {
    private const NONCE_ACTION = 'qaud_run';
    private const MENU_SLUG = 'quick-audit';
    private const INTEGRATIONS_MENU_SLUG = 'quick-audit-integrations';
    private const INTEGRATIONS_OPTION = 'qaud_integrations';
    private const USER_AGENT = 'QuickAudit/1.0';
    private const MAX_LINKS_PER_PAGE = 120;

    public static function boot(): void {
        $plugin = new self();
        add_action('admin_menu', [$plugin, 'register_menu']);
        add_action('admin_enqueue_scripts', [$plugin, 'enqueue_assets']);
        add_action('wp_ajax_qaud_run', [$plugin, 'ajax_run']);
        add_action('wp_ajax_quick_audit_run', [$plugin, 'ajax_run']);
        add_action('admin_post_qaud_save_integrations', [$plugin, 'handle_save_integrations']);
    }

    public function register_menu(): void {
        add_menu_page(
            'Quick Audit',
            'Quick Audit',
            'manage_options',
            self::MENU_SLUG,
            [$this, 'render_page'],
            'dashicons-search',
            61
        );

        add_submenu_page(
            self::MENU_SLUG,
            'Integrations',
            'Integrations',
            'manage_options',
            self::INTEGRATIONS_MENU_SLUG,
            [$this, 'render_integrations_page']
        );
    }

    public function enqueue_assets(string $hook): void {
        if ($hook !== 'toplevel_page_' . self::MENU_SLUG) {
            return;
        }

        $url = plugin_dir_url(__FILE__);
        wp_enqueue_style('quick-audit-admin-css', $url . 'assets/admin.css', [], '1.0.0');
        wp_enqueue_style('quick-audit-admin-ui-css', $url . 'assets/admin-ui.css', array('quick-audit-admin-css'), '1.0.0');
        wp_enqueue_script('quick-audit-admin-js', $url . 'assets/admin.js', [], '1.0.0', true);
        wp_enqueue_script('quick-audit-admin-ui-js', $url . 'assets/admin-ui.js', array('quick-audit-admin-js'), '1.0.0', true);

        wp_localize_script('quick-audit-admin-js', 'QuickAuditConfig', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce(self::NONCE_ACTION),
            'siteUrl' => home_url('/'),
        ]);
    }

    public function render_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized.', 'quick-audit'));
        }
        $premium_enabled = qaud_is_premium_active();
        ?>
        <div class="wrap quick-audit-wrap qw-ui-shell">
            <div class="quick-audit-card qw-card">
                <h1>Quick Audit</h1>
                <p>Audits only this site: <strong><?php echo esc_html(home_url('/')); ?></strong></p>
                <?php if (!$premium_enabled) : ?>
                    <div class="notice notice-warning inline"><p><?php echo esc_html__('Free tier crawls up to 10 pages. Premium unlocks full crawl depth.', 'quick-audit'); ?></p></div>
                <?php endif; ?>

                <form id="quick-audit-form" novalidate>
                    <label for="quick-audit-max-pages" class="screen-reader-text">Max pages</label>
                    <input id="quick-audit-max-pages" type="number" min="1" max="<?php echo esc_attr($premium_enabled ? '200' : '10'); ?>" value="<?php echo esc_attr($premium_enabled ? '40' : '10'); ?>" required>

                    <label for="quick-audit-max-depth" class="screen-reader-text">Max depth</label>
                    <input id="quick-audit-max-depth" type="number" min="0" max="8" value="3" required>

                    <button type="submit">Run Quick Audit</button>
                </form>

                <section id="quick-audit-loading" class="hidden" aria-live="polite">
                    <p>Running crawl...</p>
                </section>

                <section id="quick-audit-error" class="hidden" aria-live="assertive"></section>

                <section id="quick-audit-results" class="hidden qw-audit-groups">
                    <h2>Summary</h2>
                    <ul id="quick-audit-summary" class="qw-audit-group"></ul>

                    <h2>Top Issues</h2>
                    <div id="quick-audit-issues" class="qw-audit-group"></div>

                    <h2>Pages</h2>
                    <div id="quick-audit-pages" class="qw-audit-groups"></div>
                </section>
            </div>
        </div>
        <?php
    }

    public function render_integrations_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized.', 'quick-audit'));
        }

        $settings = $this->get_integrations_settings();
        $premium_enabled = qaud_is_premium_active();
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Quick Audit Integrations', 'quick-audit'); ?></h1>
            <?php if (!$premium_enabled) : ?>
                <div class="notice notice-warning"><p><?php echo esc_html__('Integrations are a premium feature.', 'quick-audit'); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html__('Enable optional integrations. Quick Audit remains fully standalone when these are off.', 'quick-audit'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="qaud_save_integrations" />
                <?php wp_nonce_field('qaud_save_integrations', 'qaud_integrations_nonce'); ?>
                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row"><?php echo esc_html__('Quick SEO', 'quick-audit'); ?></th>
                            <td><label><input type="checkbox" name="quick_seo" value="1" <?php checked(1, (int) $settings['quick_seo']); ?> <?php disabled(!$premium_enabled); ?> /> <?php echo esc_html__('Share audit completion data with Quick SEO when active.', 'quick-audit'); ?></label></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php echo esc_html__('Quick Code', 'quick-audit'); ?></th>
                            <td><label><input type="checkbox" name="quick_code" value="1" <?php checked(1, (int) $settings['quick_code']); ?> <?php disabled(!$premium_enabled); ?> /> <?php echo esc_html__('Share audit completion data with Quick Code when active.', 'quick-audit'); ?></label></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php echo esc_html__('Quick Traffic', 'quick-audit'); ?></th>
                            <td><label><input type="checkbox" name="quick_traffic" value="1" <?php checked(1, (int) $settings['quick_traffic']); ?> <?php disabled(!$premium_enabled); ?> /> <?php echo esc_html__('Share audit completion data with Quick Traffic when active.', 'quick-audit'); ?></label></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php echo esc_html__('Quick Site', 'quick-audit'); ?></th>
                            <td><label><input type="checkbox" name="quick_site" value="1" <?php checked(1, (int) $settings['quick_site']); ?> <?php disabled(!$premium_enabled); ?> /> <?php echo esc_html__('Share audit completion data with Quick Site when active.', 'quick-audit'); ?></label></td>
                        </tr>
                    </tbody>
                </table>
                <?php submit_button(__('Save Integrations', 'quick-audit')); ?>
            </form>
        </div>
        <?php
    }

    public function handle_save_integrations(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized.', 'quick-audit'));
        }

        check_admin_referer('qaud_save_integrations', 'qaud_integrations_nonce');

        $premium_enabled = qaud_is_premium_active();
        $settings = array(
            'quick_seo' => $premium_enabled && !empty($_POST['quick_seo']) ? 1 : 0,
            'quick_code' => $premium_enabled && !empty($_POST['quick_code']) ? 1 : 0,
            'quick_traffic' => $premium_enabled && !empty($_POST['quick_traffic']) ? 1 : 0,
            'quick_site' => $premium_enabled && !empty($_POST['quick_site']) ? 1 : 0,
        );

        update_option(self::INTEGRATIONS_OPTION, $settings, false);
        wp_safe_redirect(admin_url('admin.php?page=' . self::INTEGRATIONS_MENU_SLUG));
        exit;
    }

    public function ajax_run(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized request.'], 403);
        }

        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, self::NONCE_ACTION)) {
            wp_send_json_error(['message' => 'Invalid token.'], 403);
        }

        $max_pages = isset($_POST['max_pages']) ? (int) $_POST['max_pages'] : 40;
        $max_depth = isset($_POST['max_depth']) ? (int) $_POST['max_depth'] : 3;

        $max_pages = max(1, min(200, $max_pages));
        if (!qaud_is_premium_active()) {
            $max_pages = min(10, $max_pages);
        }
        $max_depth = max(0, min(8, $max_depth));

        $result = $this->run_site_audit($max_pages, $max_depth);
        if (isset($result['error'])) {
            wp_send_json_error(['message' => $result['error']], 400);
        }

        $integrations = $this->get_integrations_settings();
        if (!empty($integrations['quick_seo']) || !empty($integrations['quick_code']) || !empty($integrations['quick_traffic']) || !empty($integrations['quick_site'])) {
            do_action(
                'quickwoo_local/audit_completed',
                $result,
                array(
                    'source' => 'quick-audit',
                    'occurred_at' => current_time('mysql'),
                )
            );
        }

        wp_send_json_success($result);
    }

    private function get_integrations_settings(): array {
        $defaults = array(
            'quick_seo' => 0,
            'quick_code' => 0,
            'quick_traffic' => 0,
            'quick_site' => 0,
        );

        $saved = get_option(self::INTEGRATIONS_OPTION, array());
        if (!is_array($saved)) {
            $saved = array();
        }

        $settings = wp_parse_args($saved, $defaults);
        return array(
            'quick_seo' => !empty($settings['quick_seo']) ? 1 : 0,
            'quick_code' => !empty($settings['quick_code']) ? 1 : 0,
            'quick_traffic' => !empty($settings['quick_traffic']) ? 1 : 0,
            'quick_site' => !empty($settings['quick_site']) ? 1 : 0,
        );
    }

    /**
     * @return array<string, mixed>
     */
    private function run_site_audit(int $max_pages, int $max_depth): array {
        $site_url = home_url('/');
        $parts = wp_parse_url($site_url);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return ['error' => 'Could not resolve current site URL.'];
        }

        $scheme = strtolower((string) $parts['scheme']);
        $host = $this->normalize_host((string) $parts['host']);

        $start = $this->normalize_internal_url($site_url, $scheme, $host);
        if ($start === '') {
            return ['error' => 'Invalid site URL for crawl start.'];
        }

        $queue = [[$start, 0]];
        $visited = [];
        $pages = [];

        while (!empty($queue) && count($visited) < $max_pages) {
            $item = array_shift($queue);
            if (!is_array($item) || count($item) < 2) {
                continue;
            }

            $url = (string) $item[0];
            $depth = (int) $item[1];

            if ($depth > $max_depth || isset($visited[$url])) {
                continue;
            }

            $visited[$url] = true;

            $response = $this->http_get($url);
            if (isset($response['error'])) {
                $pages[] = [
                    'url' => $url,
                    'status' => null,
                    'depth' => $depth,
                    'issues' => ['Fetch failed: ' . $response['error']],
                    'meta' => $this->empty_meta(),
                    'content' => $this->empty_content(),
                ];
                continue;
            }

            $status = (int) $response['status'];
            $body = (string) $response['body'];
            $duration = (float) $response['duration_ms'];

            $page = $this->analyze_page($url, $status, $body, $depth, $duration);
            $pages[] = $page;

            if ($status !== 200 || $body === '') {
                continue;
            }

            $links = $this->extract_internal_links($body, $url, $scheme, $host);
            foreach ($links as $link) {
                if (!isset($visited[$link])) {
                    $queue[] = [$link, $depth + 1];
                }
            }
        }

        $summary = $this->build_summary($pages);
        $issue_rollup = $this->rollup_issues($pages);

        return [
            'site' => $start,
            'summary' => $summary,
            'top_issues' => array_slice($issue_rollup, 0, 8),
            'pages' => $pages,
            'run_at' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function http_get(string $url): array {
        $started = microtime(true);
        $response = wp_remote_get($url, [
            'timeout' => 10,
            'redirection' => 3,
            'user-agent' => self::USER_AGENT,
            'headers' => ['Accept' => 'text/html,application/xhtml+xml'],
        ]);

        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }

        return [
            'status' => (int) wp_remote_retrieve_response_code($response),
            'body' => (string) wp_remote_retrieve_body($response),
            'duration_ms' => round((microtime(true) - $started) * 1000, 1),
        ];
    }

    /**
     * @return array<int, string>
     */
    private function extract_internal_links(string $html, string $base_url, string $scheme, string $host): array {
        $doc = $this->load_dom($html);
        if (!$doc instanceof DOMDocument) {
            return [];
        }

        $xpath = new DOMXPath($doc);
        $nodes = $xpath->query('//a[@href]');
        if (!$nodes instanceof DOMNodeList) {
            return [];
        }

        $links = [];
        $count = 0;

        foreach ($nodes as $node) {
            if (!$node instanceof DOMElement) {
                continue;
            }

            if ($count >= self::MAX_LINKS_PER_PAGE) {
                break;
            }

            $href = trim((string) $node->getAttribute('href'));
            if ($href === '' || $this->starts_with($href, '#')) {
                continue;
            }

            $lower = strtolower($href);
            if (
                $this->starts_with($lower, 'mailto:') ||
                $this->starts_with($lower, 'tel:') ||
                $this->starts_with($lower, 'javascript:') ||
                $this->starts_with($lower, 'data:')
            ) {
                continue;
            }

            $absolute = $this->resolve_url($base_url, $href);
            if ($absolute === null || !$this->is_same_site($absolute, $host)) {
                continue;
            }

            $normalized = $this->normalize_internal_url($absolute, $scheme, $host);
            if ($normalized === '') {
                continue;
            }

            $links[$normalized] = true;
            $count++;
        }

        return array_values(array_keys($links));
    }

    /**
     * @return array<string, mixed>
     */
    private function analyze_page(string $url, int $status, string $html, int $depth, float $duration): array {
        $page = [
            'url' => $url,
            'status' => $status,
            'depth' => $depth,
            'issues' => [],
            'meta' => $this->empty_meta(),
            'content' => $this->empty_content(),
            'performance_ms' => $duration,
        ];

        if ($status !== 200) {
            $page['issues'][] = 'Non-200 status: ' . $status;
            return $page;
        }

        if (trim($html) === '') {
            $page['issues'][] = 'Empty response body';
            return $page;
        }

        if ($duration > 3000) {
            $page['issues'][] = 'Very slow response (>3s)';
        } elseif ($duration > 1500) {
            $page['issues'][] = 'Slow response (>1.5s)';
        }

        $doc = $this->load_dom($html);
        if (!$doc instanceof DOMDocument) {
            $page['issues'][] = 'HTML parse failure';
            return $page;
        }

        $xpath = new DOMXPath($doc);

        $title = trim((string) $this->query_first_node_value($xpath, '//title'));
        $page['meta']['title'] = $title;
        if ($title === '') {
            $page['issues'][] = 'Missing title';
        } elseif (strlen($title) < 30 || strlen($title) > 60) {
            $page['issues'][] = 'Title length outside 30-60 chars';
        }

        $description = trim((string) $this->query_first_attr_value($xpath, '//meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="description"]', 'content'));
        $page['meta']['description'] = $description;
        if ($description === '') {
            $page['issues'][] = 'Missing meta description';
        }

        $canonical = trim((string) $this->query_first_attr_value($xpath, '//link[contains(translate(@rel,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"canonical")]', 'href'));
        $page['meta']['canonical'] = $canonical;
        if ($canonical === '') {
            $page['issues'][] = 'Missing canonical';
        }

        $robots = trim((string) $this->query_first_attr_value($xpath, '//meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="robots"]', 'content'));
        $page['meta']['robots'] = $robots;
        if ($robots !== '' && $this->contains(strtolower($robots), 'noindex')) {
            $page['issues'][] = 'Page marked noindex';
        }

        $h1_nodes = $xpath->query('//h1');
        $h1_count = $h1_nodes instanceof DOMNodeList ? $h1_nodes->length : 0;
        if ($h1_count === 0) {
            $page['issues'][] = 'Missing H1';
        } elseif ($h1_count > 1) {
            $page['issues'][] = 'Multiple H1s';
        }

        $text = $this->extract_text($doc);
        $wc = $this->count_words($text);
        $page['content']['word_count'] = $wc;

        if ($wc > 0 && $wc < 250) {
            $page['issues'][] = 'Thin content (word count < 250)';
        }

        return $page;
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     * @return array<string, int>
     */
    private function build_summary(array $pages): array {
        $with_issues = 0;
        $non_200 = 0;
        $total_words = 0;
        $ok_pages = 0;

        foreach ($pages as $page) {
            if (!empty($page['issues'])) {
                $with_issues++;
            }

            if (($page['status'] ?? 0) !== 200) {
                $non_200++;
            } else {
                $ok_pages++;
                $total_words += (int) ($page['content']['word_count'] ?? 0);
            }
        }

        return [
            'pages_crawled' => count($pages),
            'pages_with_issues' => $with_issues,
            'non_200_pages' => $non_200,
            'avg_word_count' => $ok_pages > 0 ? (int) round($total_words / $ok_pages) : 0,
            'max_depth' => $this->max_depth($pages),
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     * @return array<int, array<string, mixed>>
     */
    private function rollup_issues(array $pages): array {
        $counts = [];

        foreach ($pages as $page) {
            $issues = isset($page['issues']) && is_array($page['issues']) ? $page['issues'] : [];
            foreach ($issues as $issue) {
                $k = (string) $issue;
                if (!isset($counts[$k])) {
                    $counts[$k] = 0;
                }
                $counts[$k]++;
            }
        }

        arsort($counts);

        $out = [];
        foreach ($counts as $issue => $count) {
            $out[] = ['issue' => $issue, 'count' => $count];
        }

        return $out;
    }

    private function max_depth(array $pages): int {
        $depth = 0;
        foreach ($pages as $page) {
            $depth = max($depth, (int) ($page['depth'] ?? 0));
        }

        return $depth;
    }

    private function normalize_host(string $host): string {
        $host = strtolower(trim($host));
        if ($this->starts_with($host, 'www.')) {
            $host = substr($host, 4);
        }
        return $host;
    }

    private function is_same_site(string $url, string $base_host): bool {
        $parts = wp_parse_url($url);
        if (!is_array($parts) || empty($parts['host'])) {
            return false;
        }
        return $this->normalize_host((string) $parts['host']) === $base_host;
    }

    private function normalize_internal_url(string $url, string $scheme, string $host): string {
        $parts = wp_parse_url($url);
        if (!is_array($parts)) {
            return '';
        }

        $path = isset($parts['path']) ? (string) $parts['path'] : '/';
        $path = $path === '' ? '/' : $path;
        $path = rtrim($path, '/');
        if ($path === '') {
            $path = '/';
        }

        return sprintf('%s://%s%s', $scheme, $host, $path);
    }

    private function resolve_url(string $base_url, string $href): ?string {
        if (preg_match('#^https?://#i', $href) === 1) {
            return $href;
        }

        if ($this->starts_with($href, '//')) {
            $base_parts = wp_parse_url($base_url);
            if (!is_array($base_parts) || empty($base_parts['scheme'])) {
                return null;
            }
            return (string) $base_parts['scheme'] . ':' . $href;
        }

        $base_parts = wp_parse_url($base_url);
        if (!is_array($base_parts) || empty($base_parts['scheme']) || empty($base_parts['host'])) {
            return null;
        }

        $scheme = (string) $base_parts['scheme'];
        $host = (string) $base_parts['host'];

        if ($this->starts_with($href, '/')) {
            return sprintf('%s://%s%s', $scheme, $host, $href);
        }

        $path = isset($base_parts['path']) ? (string) $base_parts['path'] : '/';
        $dir = preg_replace('#/[^/]*$#', '/', $path);
        $dir = is_string($dir) && $dir !== '' ? $dir : '/';

        return sprintf('%s://%s%s%s', $scheme, $host, $dir, $href);
    }

    private function load_dom(string $html): ?DOMDocument {
        if (!class_exists('DOMDocument')) {
            return null;
        }

        $doc = new DOMDocument();
        libxml_use_internal_errors(true);
        $loaded = $doc->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();
        return $loaded ? $doc : null;
    }

    private function query_first_node_value(DOMXPath $xpath, string $query): string {
        $nodes = $xpath->query($query);
        if (!$nodes instanceof DOMNodeList || $nodes->length === 0) {
            return '';
        }

        $node = $nodes->item(0);
        return $node instanceof DOMNode ? trim((string) $node->textContent) : '';
    }

    private function query_first_attr_value(DOMXPath $xpath, string $query, string $attr): string {
        $nodes = $xpath->query($query);
        if (!$nodes instanceof DOMNodeList || $nodes->length === 0) {
            return '';
        }

        $node = $nodes->item(0);
        return $node instanceof DOMElement ? trim((string) $node->getAttribute($attr)) : '';
    }

    private function extract_text(DOMDocument $doc): string {
        $xpath = new DOMXPath($doc);
        $body_nodes = $xpath->query('//body');
        $root = $body_nodes instanceof DOMNodeList && $body_nodes->length > 0 ? $body_nodes->item(0) : $doc->documentElement;

        if (!$root instanceof DOMNode) {
            return '';
        }

        $text = preg_replace('/\s+/u', ' ', (string) $root->textContent);
        return trim((string) $text);
    }

    private function count_words(string $text): int {
        if ($text === '') {
            return 0;
        }

        $clean = wp_strip_all_tags($text);
        $clean = preg_replace('/\s+/u', ' ', (string) $clean);
        if (!is_string($clean) || $clean === '') {
            return 0;
        }

        return str_word_count($clean);
    }

    /**
     * @return array<string, string>
     */
    private function empty_meta(): array {
        return [
            'title' => '',
            'description' => '',
            'canonical' => '',
            'robots' => '',
        ];
    }

    /**
     * @return array<string, int>
     */
    private function empty_content(): array {
        return [
            'word_count' => 0,
        ];
    }

    private function starts_with(string $haystack, string $needle): bool {
        if ($needle === '') {
            return true;
        }
        return strpos($haystack, $needle) === 0;
    }

    private function contains(string $haystack, string $needle): bool {
        if ($needle === '') {
            return true;
        }
        return strpos($haystack, $needle) !== false;
    }
}

QAUD_Plugin::boot();

if ( ! function_exists( 'qwoo_quick_audit_license_bootstrap' ) ) {
    function qwoo_quick_audit_license_bootstrap() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu', 'qwoo_quick_audit_license_menu' );
        add_action( 'admin_post_qwoo_quick_audit_activate_license', 'qwoo_quick_audit_license_handle_activate' );
        add_action( 'admin_post_qwoo_quick_audit_deactivate_license', 'qwoo_quick_audit_license_handle_deactivate' );
    }
    add_action( 'plugins_loaded', 'qwoo_quick_audit_license_bootstrap', 30 );

    function qwoo_quick_audit_license_option_key() {
        return 'qwoo_quick_audit_license';
    }

    function qwoo_quick_audit_license_product_scope() {
        return array( 'quick-audit' );
    }

    function qwoo_quick_audit_license_get_data() {
        $defaults = array(
            'license_key' => '',
            'license_status' => 'inactive',
            'license_message' => '',
        );

        $saved = get_option( qwoo_quick_audit_license_option_key(), array() );
        $saved = is_array( $saved ) ? $saved : array();

        return wp_parse_args( $saved, $defaults );
    }

    function qwoo_quick_audit_license_save_data( $data ) {
        $data = is_array( $data ) ? $data : array();

        $clean = array(
            'license_key' => sanitize_text_field( (string) ( $data['license_key'] ?? '' ) ),
            'license_status' => sanitize_key( (string) ( $data['license_status'] ?? 'inactive' ) ),
            'license_message' => sanitize_text_field( (string) ( $data['license_message'] ?? '' ) ),
        );

        update_option( qwoo_quick_audit_license_option_key(), $clean, false );
        return $clean;
    }

    function qwoo_quick_audit_license_menu() {
        add_options_page(
            'Laudit License',
            'Laudit License',
            'manage_options',
            'qwoo-quick-audit-license',
            'qwoo_quick_audit_license_render_page'
        );
    }

    function qwoo_quick_audit_license_render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = qwoo_quick_audit_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );

        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $status = qlic_get_license_status_for_key_products( $license_key, qwoo_quick_audit_license_product_scope() );
            if ( is_array( $status ) ) {
                $data['license_status'] = sanitize_key( (string) ( $status['status'] ?? $data['license_status'] ) );
                $data['license_message'] = sanitize_text_field( (string) ( $status['message'] ?? $data['license_message'] ) );
                if ( ! empty( $status['valid'] ) && ! empty( $status['domain_active'] ) ) {
                    $data['license_status'] = 'active';
                }
                qwoo_quick_audit_license_save_data( $data );
            }
        }

        $notice = isset( $_GET['qwoo_license_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qwoo_license_notice'] ) ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Laudit License', 'quick-audit' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-audit' ), (string) ( $data['license_status'] ?? 'inactive' ) ) ); ?></p>
            <?php if ( ! empty( $data['license_message'] ) ) : ?>
                <p><?php echo esc_html( (string) $data['license_message'] ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_audit_activate_license" />
                <?php wp_nonce_field( 'qwoo_quick_audit_activate_license', 'qwoo_quick_audit_activate_license_nonce' ); ?>
                <p>
                    <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( (string) ( $data['license_key'] ?? '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button type="submit" class="button button-primary"><?php echo esc_html__( 'Activate License', 'quick-audit' ); ?></button>
                </p>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_audit_deactivate_license" />
                <?php wp_nonce_field( 'qwoo_quick_audit_deactivate_license', 'qwoo_quick_audit_deactivate_license_nonce' ); ?>
                <p><button type="submit" class="button"><?php echo esc_html__( 'Deactivate License', 'quick-audit' ); ?></button></p>
            </form>
        </div>
        <?php
    }

    function qwoo_quick_audit_license_redirect( $message ) {
        $url = add_query_arg(
            array(
                'page' => 'qwoo-quick-audit-license',
                'qwoo_license_notice' => rawurlencode( (string) $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    function qwoo_quick_audit_license_handle_activate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-audit' ) );
        }

        check_admin_referer( 'qwoo_quick_audit_activate_license', 'qwoo_quick_audit_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        if ( '' === $license_key ) {
            qwoo_quick_audit_license_save_data(
                array(
                    'license_key' => '',
                    'license_status' => 'inactive',
                    'license_message' => 'License key is required.',
                )
            );
            qwoo_quick_audit_license_redirect( 'License key is required.' );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            qwoo_quick_audit_license_save_data(
                array(
                    'license_key' => $license_key,
                    'license_status' => 'invalid',
                    'license_message' => 'Quick License plugin is required for activation.',
                )
            );
            qwoo_quick_audit_license_redirect( 'Quick License plugin is required for activation.' );
        }

        $result = qlic_activate_license_key_for_products( $license_key, qwoo_quick_audit_license_product_scope() );
        $data = array(
            'license_key' => $license_key,
            'license_status' => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'license_message' => sanitize_text_field( (string) ( $result['message'] ?? 'License validation failed.' ) ),
        );
        if ( ! empty( $result['valid'] ) ) {
            $data['license_status'] = 'active';
        }

        qwoo_quick_audit_license_save_data( $data );
        qwoo_quick_audit_license_redirect( (string) $data['license_message'] );
    }

    function qwoo_quick_audit_license_handle_deactivate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-audit' ) );
        }

        check_admin_referer( 'qwoo_quick_audit_deactivate_license', 'qwoo_quick_audit_deactivate_license_nonce' );

        $data = qwoo_quick_audit_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );
        $message = 'License deactivated.';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products( $license_key, qwoo_quick_audit_license_product_scope() );
            if ( is_array( $result ) && ! empty( $result['message'] ) ) {
                $message = sanitize_text_field( (string) $result['message'] );
            }
        }

        qwoo_quick_audit_license_save_data(
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => $message,
            )
        );

        qwoo_quick_audit_license_redirect( $message );
    }
}
