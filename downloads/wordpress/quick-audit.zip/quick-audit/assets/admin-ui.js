(function () {
  function wrapTables() {
    var tables = document.querySelectorAll('.widefat, .wp-list-table, table');
    tables.forEach(function (table) {
      if (!table || table.closest('.form-table') || table.closest('.qw-table-wrap')) {
        return;
      }
      var wrap = document.createElement('div');
      wrap.className = 'qw-table-wrap';
      table.parentNode.insertBefore(wrap, table);
      wrap.appendChild(table);
    });
  }
  document.addEventListener('DOMContentLoaded', wrapTables);
})();
