(function () {
  const form = document.getElementById('quick-audit-form');
  if (!form || !window.QuickAuditConfig) {
    return;
  }

  const loading = document.getElementById('quick-audit-loading');
  const errorBox = document.getElementById('quick-audit-error');
  const results = document.getElementById('quick-audit-results');
  const summaryList = document.getElementById('quick-audit-summary');
  const issuesBox = document.getElementById('quick-audit-issues');
  const pagesBox = document.getElementById('quick-audit-pages');

  function show(el) { el.classList.remove('hidden'); }
  function hide(el) { el.classList.add('hidden'); }

  function esc(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function resetUI() {
    hide(errorBox);
    hide(results);
    summaryList.innerHTML = '';
    issuesBox.innerHTML = '';
    pagesBox.innerHTML = '';
  }

  function addSummary(label, value) {
    const li = document.createElement('li');
    li.textContent = `${label}: ${value}`;
    li.className = 'qw-audit-item';
    summaryList.appendChild(li);
  }

  function renderSummary(summary) {
    addSummary('Pages Crawled', summary.pages_crawled);
    addSummary('Pages With Issues', summary.pages_with_issues);
    addSummary('Non-200 Pages', summary.non_200_pages);
    addSummary('Average Word Count', summary.avg_word_count);
    addSummary('Max Depth', summary.max_depth);
  }

  function renderIssues(topIssues) {
    if (!Array.isArray(topIssues) || topIssues.length === 0) {
      issuesBox.innerHTML = '<p>No recurring issues detected.</p>';
      return;
    }

    const list = topIssues.map((entry) => {
      const severity = issueSeverity(entry.issue);
      return `<li class="qw-audit-item"><span class="qw-badge qw-badge--${severity}">${severity}</span> <strong>${esc(entry.count)}</strong> - ${esc(entry.issue)}</li>`;
    }).join('');
    issuesBox.innerHTML = `<ul class="qw-audit-list">${list}</ul>`;
  }

  function issueSeverity(issue) {
    const text = String(issue || '').toLowerCase();
    if (text.includes('missing') || text.includes('broken') || text.includes('4xx') || text.includes('5xx')) {
      return 'critical';
    }
    if (text.includes('slow') || text.includes('duplicate') || text.includes('long') || text.includes('short')) {
      return 'warning';
    }
    return 'info';
  }

  function renderPages(pages) {
    if (!Array.isArray(pages) || pages.length === 0) {
      pagesBox.innerHTML = '<p>No pages crawled.</p>';
      return;
    }

    pages.forEach((page) => {
      const issues = Array.isArray(page.issues) && page.issues.length
        ? page.issues.map((i) => `<li>${esc(i)}</li>`).join('')
        : '<li>No issues detected</li>';

      const card = document.createElement('div');
      card.className = 'qa-page qw-audit-group';
      card.innerHTML = `
        <h3>${esc(page.url)} <span class="qw-badge qw-badge--${(page.status >= 400 || page.status === null) ? 'critical' : 'info'}">${esc(page.status === null ? 'N/A' : page.status)}</span></h3>
        <p>Status: ${esc(page.status === null ? 'N/A' : page.status)} | Depth: ${esc(page.depth)} | Words: ${esc(page.content.word_count || 0)} | Time: ${esc(page.performance_ms || 0)}ms</p>
        <ul class="qw-audit-list">${issues}</ul>
      `;
      pagesBox.appendChild(card);
    });
  }

  async function runAudit(maxPages, maxDepth) {
    const body = new URLSearchParams();
    body.set('action', 'qaud_run');
    body.set('nonce', QuickAuditConfig.nonce);
    body.set('max_pages', String(maxPages));
    body.set('max_depth', String(maxDepth));

    const response = await fetch(QuickAuditConfig.ajaxUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString(),
      credentials: 'same-origin',
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    if (!data.success) {
      throw new Error((data.data && data.data.message) ? data.data.message : 'Audit failed.');
    }

    return data.data;
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    resetUI();

    const maxPages = Number(document.getElementById('quick-audit-max-pages').value || 40);
    const maxDepth = Number(document.getElementById('quick-audit-max-depth').value || 3);

    show(loading);

    try {
      const data = await runAudit(maxPages, maxDepth);
      renderSummary(data.summary || {});
      renderIssues(data.top_issues || []);
      renderPages(data.pages || []);
      show(results);
    } catch (err) {
      errorBox.textContent = err.message || 'Audit failed.';
      show(errorBox);
    } finally {
      hide(loading);
    }
  });
})();
