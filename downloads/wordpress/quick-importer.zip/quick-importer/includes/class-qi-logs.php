<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QIIM_Logs {
    const OPTION_KEY = 'qiim_logs';
    const LIMIT      = 20;

    public function add( $type, $content_type, $total_rows, $success_count, $failed_count, $duration, $details = array() ) {
        $logs = $this->all();

        $logs[] = array(
            'date'         => current_time( 'mysql' ),
            'type'         => sanitize_key( $type ),
            'content_type' => sanitize_text_field( $content_type ),
            'total_rows'   => (int) $total_rows,
            'success'      => (int) $success_count,
            'failed'       => (int) $failed_count,
            'duration'     => (float) $duration,
            'details'      => is_array( $details ) ? $details : array(),
        );

        if ( count( $logs ) > self::LIMIT ) {
            $logs = array_slice( $logs, - self::LIMIT );
        }

        update_option( self::OPTION_KEY, $logs, false );
    }

    public function all() {
        $logs = get_option( self::OPTION_KEY, array() );
        return is_array( $logs ) ? $logs : array();
    }
}
