<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QIIM_Settings {
    const OPTION_KEY = 'qiim_settings';

    public function get_all() {
        $saved = get_option( self::OPTION_KEY, array() );
        if ( ! is_array( $saved ) ) {
            $saved = array();
        }

        return wp_parse_args( $saved, qiim_default_settings() );
    }

    public function get( $key, $default = null ) {
        $all = $this->get_all();
        return isset( $all[ $key ] ) ? $all[ $key ] : $default;
    }

    public function save( $input ) {
        $current = $this->get_all();

        $out                           = $current;
        $out['max_upload_mb']          = max( 1, absint( $input['max_upload_mb'] ?? $current['max_upload_mb'] ) );
        $out['batch_size']             = max( 1, absint( $input['batch_size'] ?? $current['batch_size'] ) );
        $out['auto_create_terms']      = empty( $input['auto_create_terms'] ) ? 0 : 1;
        $out['default_import_mode']    = sanitize_key( $input['default_import_mode'] ?? $current['default_import_mode'] );
        $out['default_matching_key']   = sanitize_key( $input['default_matching_key'] ?? $current['default_matching_key'] );
        $out['default_delimiter']      = qiim_sanitize_delimiter( $input['default_delimiter'] ?? $current['default_delimiter'] );
        $out['utf8_bom']               = empty( $input['utf8_bom'] ) ? 0 : 1;
        $out['debug_mode']             = empty( $input['debug_mode'] ) ? 0 : 1;
        $out['scheduled_exports_enabled'] = empty( $input['scheduled_exports_enabled'] ) ? 0 : 1;

        $valid_modes = array( 'update_create', 'update_only', 'create_only' );
        if ( ! in_array( $out['default_import_mode'], $valid_modes, true ) ) {
            $out['default_import_mode'] = 'update_create';
        }

        $valid_keys = array( 'id', 'slug', 'title', 'sku', 'meta' );
        if ( ! in_array( $out['default_matching_key'], $valid_keys, true ) ) {
            $out['default_matching_key'] = 'id';
        }

        update_option( self::OPTION_KEY, $out, false );

        return $out;
    }
}
