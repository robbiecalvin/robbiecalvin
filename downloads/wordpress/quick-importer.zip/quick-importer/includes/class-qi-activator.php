<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QIIM_Activator {
    public static function activate() {
        $defaults = qiim_default_settings();
        $saved    = get_option( 'qiim_settings', array() );

        if ( ! is_array( $saved ) ) {
            $saved = array();
        }

        update_option( 'qiim_settings', wp_parse_args( $saved, $defaults ) );

        if ( false === get_option( 'qiim_logs', false ) ) {
            add_option( 'qiim_logs', array() );
        }

        if ( false === get_option( 'qiim_templates', false ) ) {
            add_option(
                'qiim_templates',
                array(
                    'import' => array(),
                    'export' => array(),
                )
            );
        }

        if ( false === get_option( 'qiim_jobs', false ) ) {
            add_option( 'qiim_jobs', array() );
        }

        qiim_get_upload_dir();
    }
}
