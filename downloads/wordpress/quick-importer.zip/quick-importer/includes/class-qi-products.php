<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QIIM_Products {
    private $settings;
    private $taxonomies;

    public function __construct( $settings, $taxonomies ) {
        $this->settings   = $settings;
        $this->taxonomies = $taxonomies;
    }

    public function is_wc_active() {
        return class_exists( 'WooCommerce' ) && function_exists( 'wc_get_product' );
    }

    public function find_product_by_sku( $sku ) {
        if ( ! $this->is_wc_active() || '' === $sku ) {
            return 0;
        }

        global $wpdb;
        $post_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_sku' AND meta_value = %s LIMIT 1",
                $sku
            )
        );

        return $post_id ? (int) $post_id : 0;
    }

    public function validate_unique_sku( $sku, $current_id = 0 ) {
        $sku = (string) $sku;
        if ( '' === $sku ) {
            return true;
        }

        $existing_id = $this->find_product_by_sku( $sku );
        if ( ! $existing_id ) {
            return true;
        }

        return (int) $existing_id === (int) $current_id;
    }

    public function apply_product_fields( $product_id, $mapped_values ) {
        if ( ! $this->is_wc_active() ) {
            return new WP_Error( 'qiim_wc_missing', 'WooCommerce is not active.' );
        }

        $product_id = (int) $product_id;

        if ( isset( $mapped_values['sku'] ) ) {
            $sku = sanitize_text_field( $mapped_values['sku'] );
            if ( ! $this->validate_unique_sku( $sku, $product_id ) ) {
                return new WP_Error( 'qiim_duplicate_sku', 'SKU already exists for another product.' );
            }
            update_post_meta( $product_id, '_sku', $sku );
        }

        if ( isset( $mapped_values['regular_price'] ) ) {
            update_post_meta( $product_id, '_regular_price', wc_format_decimal( $mapped_values['regular_price'] ) );
        }

        if ( isset( $mapped_values['price'] ) && ! isset( $mapped_values['regular_price'] ) ) {
            update_post_meta( $product_id, '_regular_price', wc_format_decimal( $mapped_values['price'] ) );
        }

        if ( isset( $mapped_values['sale_price'] ) ) {
            update_post_meta( $product_id, '_sale_price', wc_format_decimal( $mapped_values['sale_price'] ) );
        }

        if ( isset( $mapped_values['stock_quantity'] ) ) {
            $qty = is_numeric( $mapped_values['stock_quantity'] ) ? (int) $mapped_values['stock_quantity'] : null;
            if ( null !== $qty ) {
                wc_update_product_stock( $product_id, $qty );
            }
        }

        if ( isset( $mapped_values['stock_status'] ) ) {
            update_post_meta( $product_id, '_stock_status', sanitize_key( $mapped_values['stock_status'] ) );
        }

        if ( isset( $mapped_values['product_type'] ) ) {
            $product_type = sanitize_key( $mapped_values['product_type'] );
            if ( in_array( $product_type, array( 'simple', 'variable' ), true ) ) {
                wp_set_object_terms( $product_id, $product_type, 'product_type', false );
            }
        }

        if ( isset( $mapped_values['weight'] ) ) {
            update_post_meta( $product_id, '_weight', sanitize_text_field( $mapped_values['weight'] ) );
        }

        if ( isset( $mapped_values['dimensions'] ) ) {
            $dims = array_map( 'trim', explode( 'x', (string) $mapped_values['dimensions'] ) );
            if ( isset( $dims[0] ) ) {
                update_post_meta( $product_id, '_length', sanitize_text_field( $dims[0] ) );
            }
            if ( isset( $dims[1] ) ) {
                update_post_meta( $product_id, '_width', sanitize_text_field( $dims[1] ) );
            }
            if ( isset( $dims[2] ) ) {
                update_post_meta( $product_id, '_height', sanitize_text_field( $dims[2] ) );
            }
        }

        if ( isset( $mapped_values['length'] ) ) {
            update_post_meta( $product_id, '_length', sanitize_text_field( $mapped_values['length'] ) );
        }

        if ( isset( $mapped_values['width'] ) ) {
            update_post_meta( $product_id, '_width', sanitize_text_field( $mapped_values['width'] ) );
        }

        if ( isset( $mapped_values['height'] ) ) {
            update_post_meta( $product_id, '_height', sanitize_text_field( $mapped_values['height'] ) );
        }

        if ( isset( $mapped_values['featured'] ) ) {
            $featured = in_array( strtolower( (string) $mapped_values['featured'] ), array( '1', 'yes', 'true' ), true );
            if ( $featured ) {
                wc_get_featured_product_ids();
                wp_set_object_terms( $product_id, 'featured', 'product_visibility', true );
            }
        }

        if ( isset( $mapped_values['virtual'] ) ) {
            update_post_meta( $product_id, '_virtual', in_array( strtolower( (string) $mapped_values['virtual'] ), array( '1', 'yes', 'true' ), true ) ? 'yes' : 'no' );
        }

        if ( isset( $mapped_values['downloadable'] ) ) {
            update_post_meta( $product_id, '_downloadable', in_array( strtolower( (string) $mapped_values['downloadable'] ), array( '1', 'yes', 'true' ), true ) ? 'yes' : 'no' );
        }

        if ( isset( $mapped_values['product_visibility'] ) ) {
            $visibility = sanitize_key( $mapped_values['product_visibility'] );
            if ( '' !== $visibility ) {
                wp_set_object_terms( $product_id, $visibility, 'product_visibility', false );
            }
        }

        if ( isset( $mapped_values['attributes'] ) ) {
            $this->apply_attributes( $product_id, $mapped_values['attributes'] );
        }

        if ( isset( $mapped_values['variations'] ) ) {
            $this->apply_variations( $product_id, $mapped_values );
        }

        if ( isset( $mapped_values['categories'] ) ) {
            $this->taxonomies->assign_to_object( $product_id, 'product_cat', $mapped_values['categories'] );
        }

        if ( isset( $mapped_values['tags'] ) ) {
            $this->taxonomies->assign_to_object( $product_id, 'product_tag', $mapped_values['tags'] );
        }

        return true;
    }

    private function apply_attributes( $product_id, $raw_attributes ) {
        $raw_attributes = (string) $raw_attributes;
        if ( '' === $raw_attributes ) {
            return;
        }

        $attribute_pairs = explode( ';', $raw_attributes );
        $out             = array();

        foreach ( $attribute_pairs as $pair ) {
            $pair = trim( $pair );
            if ( '' === $pair || false === strpos( $pair, ':' ) ) {
                continue;
            }

            list( $name, $value_string ) = array_map( 'trim', explode( ':', $pair, 2 ) );
            if ( '' === $name || '' === $value_string ) {
                continue;
            }

            $slug = wc_sanitize_taxonomy_name( $name );
            $out[ $slug ] = array(
                'name'         => $name,
                'value'        => implode( ' | ', qiim_parse_list_string( $value_string ) ),
                'is_visible'   => 1,
                'is_variation' => 1,
                'is_taxonomy'  => 0,
            );
        }

        if ( ! empty( $out ) ) {
            update_post_meta( $product_id, '_product_attributes', $out );
        }
    }

    private function apply_variations( $product_id, $mapped_values ) {
        $raw = (string) ( $mapped_values['variations'] ?? '' );
        if ( '' === trim( $raw ) ) {
            return;
        }

        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) {
            return;
        }

        wp_set_object_terms( $product_id, 'variable', 'product_type', false );

        foreach ( $decoded as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }

            $sku = sanitize_text_field( (string) ( $item['sku'] ?? '' ) );
            $variation_id = 0;

            if ( '' !== $sku ) {
                $existing_id = $this->find_product_by_sku( $sku );
                if ( $existing_id ) {
                    $parent_id = (int) wp_get_post_parent_id( $existing_id );
                    if ( $parent_id === (int) $product_id ) {
                        $variation_id = (int) $existing_id;
                    }
                }
            }

            $post_data = array(
                'post_type'   => 'product_variation',
                'post_parent' => $product_id,
                'post_status' => 'publish',
                'post_title'  => 'Variation #' . $product_id,
            );

            if ( $variation_id ) {
                $post_data['ID'] = $variation_id;
                $res = wp_update_post( $post_data, true );
            } else {
                $res = wp_insert_post( $post_data, true );
                $variation_id = (int) $res;
            }

            if ( is_wp_error( $res ) || ! $variation_id ) {
                continue;
            }

            if ( '' !== $sku && $this->validate_unique_sku( $sku, $variation_id ) ) {
                update_post_meta( $variation_id, '_sku', $sku );
            }

            if ( isset( $item['regular_price'] ) ) {
                update_post_meta( $variation_id, '_regular_price', wc_format_decimal( $item['regular_price'] ) );
                update_post_meta( $variation_id, '_price', wc_format_decimal( $item['regular_price'] ) );
            }

            if ( isset( $item['sale_price'] ) ) {
                update_post_meta( $variation_id, '_sale_price', wc_format_decimal( $item['sale_price'] ) );
            }

            if ( isset( $item['stock_quantity'] ) && is_numeric( $item['stock_quantity'] ) ) {
                wc_update_product_stock( $variation_id, (int) $item['stock_quantity'] );
            }

            if ( isset( $item['attributes'] ) && is_array( $item['attributes'] ) ) {
                foreach ( $item['attributes'] as $attr_name => $attr_val ) {
                    $meta_key = 'attribute_' . sanitize_title( (string) $attr_name );
                    update_post_meta( $variation_id, $meta_key, sanitize_text_field( (string) $attr_val ) );
                }
            }
        }
    }
}
