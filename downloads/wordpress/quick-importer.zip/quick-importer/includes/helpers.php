<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function qiim_default_settings() {
    return array(
        'max_upload_mb'              => 20,
        'batch_size'                 => 50,
        'auto_create_terms'          => 1,
        'default_import_mode'        => 'update_create',
        'default_matching_key'       => 'id',
        'default_delimiter'          => ',',
        'utf8_bom'                   => 1,
        'debug_mode'                 => 0,
        'scheduled_exports_enabled'  => 0,
    );
}

function qiim_get_upload_dir() {
    $upload = wp_upload_dir();
    $path   = trailingslashit( $upload['basedir'] ) . 'quick-importer';
    if ( ! file_exists( $path ) ) {
        wp_mkdir_p( $path );
    }

    $index = trailingslashit( $path ) . 'index.php';
    if ( ! file_exists( $index ) ) {
        file_put_contents( $index, "<?php\n// Silence is golden.\n" );
    }

    $ht = trailingslashit( $path ) . '.htaccess';
    if ( ! file_exists( $ht ) ) {
        file_put_contents( $ht, "Deny from all\n" );
    }

    return $path;
}

function qiim_can_manage( $is_product_action = false ) {
    if ( current_user_can( 'manage_options' ) ) {
        return true;
    }

    if ( $is_product_action && current_user_can( 'manage_woocommerce' ) ) {
        return true;
    }

    return false;
}

function qiim_is_premium() {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

    return (bool) apply_filters( 'quick_importer_is_premium', false );
}

function qiim_sanitize_delimiter( $delimiter ) {
    $delimiter = is_string( $delimiter ) ? $delimiter : ',';
    $delimiter = trim( $delimiter );
    if ( '' === $delimiter ) {
        return ',';
    }

    $allowed = array( ',', ';', "\t", '|' );
    if ( ! in_array( $delimiter, $allowed, true ) ) {
        return ',';
    }

    return $delimiter;
}

function qiim_escape_csv_formula( $value ) {
    $value = (string) $value;
    if ( '' === $value ) {
        return $value;
    }

    $first = substr( $value, 0, 1 );
    if ( in_array( $first, array( '=', '+', '-', '@' ), true ) ) {
        return "'" . $value;
    }

    return $value;
}

function qiim_prepare_csv_row( $row ) {
    $prepared = array();
    foreach ( (array) $row as $val ) {
        $prepared[] = qiim_escape_csv_formula( $val );
    }

    return $prepared;
}

function qiim_parse_list_string( $value ) {
    if ( ! is_string( $value ) ) {
        return array();
    }

    $parts = preg_split( '/[|,;]+/', $value );
    $out   = array();

    foreach ( $parts as $part ) {
        $part = trim( wp_strip_all_tags( $part ) );
        if ( '' !== $part ) {
            $out[] = $part;
        }
    }

    return array_values( array_unique( $out ) );
}

function qiim_get_memory_snapshot() {
    return array(
        'usage' => size_format( memory_get_usage( true ) ),
        'peak'  => size_format( memory_get_peak_usage( true ) ),
        'limit' => ini_get( 'memory_limit' ),
    );
}

function qiim_safe_unlink( $file ) {
    if ( ! is_string( $file ) || '' === $file ) {
        return;
    }

    $base = qiim_get_upload_dir();
    $real = realpath( $file );

    if ( false === $real ) {
        return;
    }

    if ( 0 !== strpos( $real, realpath( $base ) ) ) {
        return;
    }

    if ( file_exists( $real ) && is_file( $real ) ) {
        wp_delete_file( $real );
    }
}
