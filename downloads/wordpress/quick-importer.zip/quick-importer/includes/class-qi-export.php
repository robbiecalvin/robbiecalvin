<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QIIM_Export {
    private $settings;
    private $logs;

    public function __construct( $settings, $logs ) {
        $this->settings = $settings;
        $this->logs     = $logs;
    }

    public function hooks() {
        add_action( 'admin_post_qiim_export_csv', array( $this, 'handle_export' ) );
    }

    public function get_exportable_types() {
        $types = array(
            'post'        => 'Posts',
            'page'        => 'Pages',
            'category'    => 'Categories',
            'post_tag'    => 'Tags',
            'custom_post' => 'Custom Post Type',
            'custom_tax'  => 'Custom Taxonomy',
        );

        if ( qiim_is_premium() ) {
            $types['product'] = 'WooCommerce Products';
        }

        return $types;
    }

    public function default_fields_for_type( $type ) {
        $base = array(
            'id',
            'title',
            'slug',
            'content',
            'excerpt',
            'status',
            'author',
            'date',
            'meta_json',
            'taxonomies',
        );

        if ( 'product' === $type ) {
            $premium = array(
                'sku',
                'regular_price',
                'sale_price',
                'stock_quantity',
                'stock_status',
                'attributes',
                'categories',
                'meta_json',
                'product_type',
                'weight',
                'length',
                'width',
                'height',
                'variations',
            );

            return array_merge( $base, $premium );
        }

        return $base;
    }

    public function handle_export() {
        if ( ! qiim_can_manage( true ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        check_admin_referer( 'qiim_export_action', 'qiim_export_nonce' );

        $start = microtime( true );

        $type            = sanitize_key( wp_unslash( $_POST['content_type'] ?? 'post' ) );
        $post_type       = sanitize_key( wp_unslash( $_POST['custom_post_type'] ?? '' ) );
        $taxonomy        = sanitize_key( wp_unslash( $_POST['custom_taxonomy'] ?? '' ) );
        $fields          = array_map( 'sanitize_text_field', (array) ( $_POST['fields'] ?? array() ) );
        $delimiter       = qiim_sanitize_delimiter( wp_unslash( $_POST['delimiter'] ?? $this->settings->get( 'default_delimiter', ',' ) ) );
        $include_bom     = ! empty( $_POST['utf8_bom'] );

        if ( empty( $fields ) ) {
            $fields = $this->default_fields_for_type( $type );
        }

        if ( 'product' === $type && ! qiim_is_premium() ) {
            wp_safe_redirect(
                add_query_arg(
                    array(
                        'page'        => 'quick-importer-export',
                        'qiim_notice' => rawurlencode( 'Product export is available in QuickWoo Pro.' ),
                    ),
                    admin_url( 'admin.php' )
                )
            );
            exit;
        }

        $filename = 'quick-importer-' . $type . '-' . gmdate( 'Ymd-His' ) . '.csv';

        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=' . $filename );

        $out = fopen( 'php://output', 'w' );
        if ( ! $out ) {
            wp_die( esc_html__( 'Could not stream CSV output.', 'quick-importer' ) );
        }

        if ( $include_bom ) {
            echo "\xEF\xBB\xBF";
        }

        fputcsv( $out, $fields, $delimiter );

        $filters = $this->get_filters();
        $rows    = 0;

        if ( in_array( $type, array( 'post', 'page', 'product' ), true ) ) {
            $target_post_type = $type;
            if ( 'custom_post' === $type && '' !== $post_type ) {
                $target_post_type = $post_type;
            }
            $rows = $this->stream_posts( $out, $target_post_type, $fields, $filters, $delimiter );
        } elseif ( in_array( $type, array( 'category', 'post_tag' ), true ) ) {
            $rows = $this->stream_terms( $out, $type, $fields, $delimiter );
        } elseif ( 'custom_tax' === $type && '' !== $taxonomy ) {
            $rows = $this->stream_terms( $out, $taxonomy, $fields, $delimiter );
        } elseif ( 'custom_post' === $type && '' !== $post_type ) {
            $rows = $this->stream_posts( $out, $post_type, $fields, $filters, $delimiter );
        }

        fclose( $out );

        $this->logs->add(
            'export',
            $type,
            $rows,
            $rows,
            0,
            microtime( true ) - $start,
            array(
                'fields' => $fields,
            )
        );

        exit;
    }

    private function get_filters() {
        $include_ids = array_filter( array_map( 'absint', explode( ',', (string) ( $_POST['include_ids'] ?? '' ) ) ) );
        $exclude_ids = array_filter( array_map( 'absint', explode( ',', (string) ( $_POST['exclude_ids'] ?? '' ) ) ) );

        return array(
            'status'      => sanitize_key( wp_unslash( $_POST['status'] ?? '' ) ),
            'date_from'   => sanitize_text_field( wp_unslash( $_POST['date_from'] ?? '' ) ),
            'date_to'     => sanitize_text_field( wp_unslash( $_POST['date_to'] ?? '' ) ),
            'category_id' => absint( $_POST['category_id'] ?? 0 ),
            'include_ids' => $include_ids,
            'exclude_ids' => $exclude_ids,
        );
    }

    private function stream_posts( $handle, $post_type, $fields, $filters, $delimiter ) {
        $batch = 200;
        $paged = 1;
        $total = 0;

        do {
            $args = array(
                'post_type'      => $post_type,
                'post_status'    => $filters['status'] ? $filters['status'] : array( 'publish', 'draft', 'pending', 'private', 'future' ),
                'posts_per_page' => $batch,
                'paged'          => $paged,
                'orderby'        => 'ID',
                'order'          => 'ASC',
            );

            if ( ! empty( $filters['include_ids'] ) ) {
                $args['post__in'] = $filters['include_ids'];
            }

            if ( ! empty( $filters['exclude_ids'] ) ) {
                $args['post__not_in'] = $filters['exclude_ids'];
            }

            if ( $filters['date_from'] || $filters['date_to'] ) {
                $args['date_query'] = array(
                    array_filter(
                        array(
                            'after'     => $filters['date_from'] ?: null,
                            'before'    => $filters['date_to'] ?: null,
                            'inclusive' => true,
                        )
                    ),
                );
            }

            if ( $filters['category_id'] && 'post' === $post_type ) {
                $args['cat'] = $filters['category_id'];
            }

            $q = new WP_Query( $args );

            if ( ! $q->have_posts() ) {
                break;
            }

            foreach ( $q->posts as $post ) {
                $row = $this->build_post_row( $post, $fields );
                fputcsv( $handle, qiim_prepare_csv_row( $row ), $delimiter );
                $total++;
            }

            wp_reset_postdata();
            $paged++;
        } while ( true );

        return $total;
    }

    private function stream_terms( $handle, $taxonomy, $fields, $delimiter ) {
        if ( ! taxonomy_exists( $taxonomy ) ) {
            return 0;
        }

        $offset = 0;
        $number = 200;
        $total  = 0;

        while ( true ) {
            $terms = get_terms(
                array(
                    'taxonomy'   => $taxonomy,
                    'hide_empty' => false,
                    'number'     => $number,
                    'offset'     => $offset,
                )
            );

            if ( is_wp_error( $terms ) || empty( $terms ) ) {
                break;
            }

            foreach ( $terms as $term ) {
                $row = $this->build_term_row( $term, $fields, $taxonomy );
                fputcsv( $handle, qiim_prepare_csv_row( $row ), $delimiter );
                $total++;
            }

            $offset += $number;
        }

        return $total;
    }

    private function build_post_row( $post, $fields ) {
        $row = array();

        foreach ( $fields as $field ) {
            switch ( $field ) {
                case 'id':
                    $row[] = $post->ID;
                    break;
                case 'title':
                    $row[] = $post->post_title;
                    break;
                case 'slug':
                    $row[] = $post->post_name;
                    break;
                case 'status':
                    $row[] = $post->post_status;
                    break;
                case 'author':
                    $row[] = get_the_author_meta( 'user_login', $post->post_author );
                    break;
                case 'date':
                    $row[] = $post->post_date;
                    break;
                case 'content':
                    $row[] = $post->post_content;
                    break;
                case 'excerpt':
                    $row[] = $post->post_excerpt;
                    break;
                case 'featured_image_url':
                    $row[] = get_the_post_thumbnail_url( $post->ID, 'full' );
                    break;
                case 'categories':
                    $row[] = implode( ',', wp_get_post_categories( $post->ID, array( 'fields' => 'names' ) ) );
                    break;
                case 'tags':
                    $tags  = wp_get_post_tags( $post->ID, array( 'fields' => 'names' ) );
                    $row[] = implode( ',', $tags );
                    break;
                case 'meta_json':
                    $meta = get_post_meta( $post->ID );
                    $safe_meta = array();
                    foreach ( (array) $meta as $k => $v ) {
                        if ( is_array( $v ) && isset( $v[0] ) ) {
                            $safe_meta[ $k ] = maybe_unserialize( $v[0] );
                        }
                    }
                    $row[] = wp_json_encode( $safe_meta );
                    break;
                case 'taxonomies':
                    $tax_names = get_object_taxonomies( $post->post_type );
                    $all_terms = array();
                    foreach ( $tax_names as $tax_name ) {
                        $terms = wp_get_post_terms( $post->ID, $tax_name, array( 'fields' => 'names' ) );
                        if ( is_array( $terms ) && ! empty( $terms ) ) {
                            $all_terms = array_merge( $all_terms, $terms );
                        }
                    }
                    $row[] = implode( ',', array_values( array_unique( $all_terms ) ) );
                    break;
                default:
                    $row[] = $this->build_product_or_meta_field( $post->ID, $field );
                    break;
            }
        }

        return $row;
    }

    private function build_term_row( $term, $fields, $taxonomy ) {
        $row = array();

        foreach ( $fields as $field ) {
            switch ( $field ) {
                case 'id':
                    $row[] = $term->term_id;
                    break;
                case 'title':
                    $row[] = $term->name;
                    break;
                case 'slug':
                    $row[] = $term->slug;
                    break;
                case 'status':
                    $row[] = 'n/a';
                    break;
                case 'author':
                    $row[] = 'n/a';
                    break;
                case 'date':
                    $row[] = 'n/a';
                    break;
                case 'content':
                    $row[] = $term->description;
                    break;
                case 'excerpt':
                    $row[] = $term->description;
                    break;
                case 'categories':
                    $row[] = 'category' === $taxonomy ? $term->name : '';
                    break;
                case 'tags':
                    $row[] = 'post_tag' === $taxonomy ? $term->name : '';
                    break;
                case 'custom_fields':
                    $meta = get_term_meta( $term->term_id );
                    $pairs = array();
                    foreach ( $meta as $k => $v ) {
                        if ( is_array( $v ) && isset( $v[0] ) ) {
                            $pairs[] = $k . ':' . maybe_serialize( $v[0] );
                        }
                    }
                    $row[] = implode( ';', $pairs );
                    break;
                case 'seo_meta':
                    $seo_keys = array(
                        '_quickseo_seo_title',
                        '_quickseo_meta_description',
                        '_quickseo_focus_keyword',
                    );
                    $pairs = array();
                    foreach ( $seo_keys as $key ) {
                        $pairs[] = $key . ':' . get_term_meta( $term->term_id, $key, true );
                    }
                    $row[] = implode( ';', $pairs );
                    break;
                default:
                    $row[] = '';
                    break;
            }
        }

        return $row;
    }

    private function build_product_or_meta_field( $post_id, $field ) {
        switch ( $field ) {
            case 'sku':
                return get_post_meta( $post_id, '_sku', true );
            case 'regular_price':
                return get_post_meta( $post_id, '_regular_price', true );
            case 'sale_price':
                return get_post_meta( $post_id, '_sale_price', true );
            case 'stock_quantity':
                return get_post_meta( $post_id, '_stock', true );
            case 'stock_status':
                return get_post_meta( $post_id, '_stock_status', true );
            case 'product_type':
                $terms = wp_get_object_terms( $post_id, 'product_type', array( 'fields' => 'names' ) );
                return is_array( $terms ) ? implode( ',', $terms ) : '';
            case 'weight':
                return get_post_meta( $post_id, '_weight', true );
            case 'length':
                return get_post_meta( $post_id, '_length', true );
            case 'width':
                return get_post_meta( $post_id, '_width', true );
            case 'height':
                return get_post_meta( $post_id, '_height', true );
            case 'attributes':
                return maybe_serialize( get_post_meta( $post_id, '_product_attributes', true ) );
            case 'variations':
                $children = get_children(
                    array(
                        'post_parent' => $post_id,
                        'post_type'   => 'product_variation',
                        'fields'      => 'ids',
                    )
                );
                return implode( ',', array_map( 'absint', $children ) );
            case 'categories':
                $cats = wp_get_post_terms( $post_id, 'product_cat', array( 'fields' => 'names' ) );
                return is_array( $cats ) ? implode( ',', $cats ) : '';
            case 'meta_json':
                $meta = get_post_meta( $post_id );
                $safe_meta = array();
                foreach ( (array) $meta as $k => $v ) {
                    if ( is_array( $v ) && isset( $v[0] ) ) {
                        $safe_meta[ $k ] = maybe_unserialize( $v[0] );
                    }
                }
                return wp_json_encode( $safe_meta );
            default:
                return get_post_meta( $post_id, $field, true );
        }
    }
}
