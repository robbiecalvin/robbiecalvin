<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QIIM_Admin {
    private $settings;
    private $logs;
    private $templates;
    private $importer;
    private $exporter;

    public function __construct( $settings, $logs, $templates, $importer, $exporter ) {
        $this->settings  = $settings;
        $this->logs      = $logs;
        $this->templates = $templates;
        $this->importer  = $importer;
        $this->exporter  = $exporter;
    }

    public function hooks() {
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
        add_action( 'admin_post_qiim_save_settings', array( $this, 'handle_save_settings' ) );
        add_action( 'admin_post_qiim_save_export_template', array( $this, 'handle_save_export_template' ) );
        add_action( 'admin_post_qiim_delete_template', array( $this, 'handle_delete_template' ) );
    }

    public function register_menu() {
        add_submenu_page(
            'quickwoo',
            __( 'Quick Importer', 'quick-importer' ),
            __( 'Quick Importer', 'quick-importer' ),
            'manage_options',
            'quick-importer',
            array( $this, 'render_import_page' )
        );

        add_menu_page(
            __( 'Quick Importer', 'quick-importer' ),
            __( 'Quick Importer', 'quick-importer' ),
            'manage_options',
            'quick-importer',
            array( $this, 'render_import_page' ),
            'dashicons-database-import',
            63
        );

        add_submenu_page( 'quick-importer', __( 'Import', 'quick-importer' ), __( 'Import', 'quick-importer' ), 'manage_options', 'quick-importer', array( $this, 'render_import_page' ) );
        add_submenu_page( 'quick-importer', __( 'Export', 'quick-importer' ), __( 'Export', 'quick-importer' ), 'manage_options', 'quick-importer-export', array( $this, 'render_export_page' ) );
        add_submenu_page( 'quick-importer', __( 'Templates', 'quick-importer' ), __( 'Templates', 'quick-importer' ), 'manage_options', 'quick-importer-templates', array( $this, 'render_templates_page' ) );
        add_submenu_page( 'quick-importer', __( 'Logs', 'quick-importer' ), __( 'Logs', 'quick-importer' ), 'manage_options', 'quick-importer-logs', array( $this, 'render_logs_page' ) );
        add_submenu_page( 'quick-importer', __( 'Settings', 'quick-importer' ), __( 'Settings', 'quick-importer' ), 'manage_options', 'quick-importer-settings', array( $this, 'render_settings_page' ) );
    }

    public function enqueue_admin_assets( $hook ) {
        if ( false === strpos( $hook, 'quick-importer' ) ) {
            return;
        }

        wp_enqueue_style( 'qiim-admin', QIIM_URL . 'assets/css/admin.css', array(), QIIM_VERSION );
        wp_enqueue_script( 'qiim-admin', QIIM_URL . 'assets/js/admin.js', array( 'jquery' ), QIIM_VERSION, true );
        wp_enqueue_script( 'qiim-import', QIIM_URL . 'assets/js/import.js', array( 'jquery' ), QIIM_VERSION, true );

        wp_localize_script(
            'qiim-import',
            'qiimImport',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'qiim_import_ajax' ),
            )
        );
    }

    public function handle_save_settings() {
        if ( ! qiim_can_manage( false ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        check_admin_referer( 'qiim_save_settings_action', 'qiim_save_settings_nonce' );

        $this->settings->save( wp_unslash( $_POST ) );

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer-settings', 'updated' => 1 ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_save_export_template() {
        if ( ! qiim_can_manage( true ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        check_admin_referer( 'qiim_export_template_action', 'qiim_export_template_nonce' );

        $name = sanitize_text_field( wp_unslash( $_POST['template_name'] ?? '' ) );
        if ( '' !== $name ) {
            $payload = array(
                'content_type'     => sanitize_key( wp_unslash( $_POST['content_type'] ?? 'post' ) ),
                'custom_post_type' => sanitize_key( wp_unslash( $_POST['custom_post_type'] ?? '' ) ),
                'custom_taxonomy'  => sanitize_key( wp_unslash( $_POST['custom_taxonomy'] ?? '' ) ),
                'fields'           => array_map( 'sanitize_text_field', (array) ( $_POST['fields'] ?? array() ) ),
                'delimiter'        => qiim_sanitize_delimiter( wp_unslash( $_POST['delimiter'] ?? ',' ) ),
                'utf8_bom'         => ! empty( $_POST['utf8_bom'] ) ? 1 : 0,
            );
            $this->templates->save_export( $name, $payload );
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer-templates' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_delete_template() {
        if ( ! qiim_can_manage( false ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        check_admin_referer( 'qiim_delete_template_action', 'qiim_delete_template_nonce' );

        $group = sanitize_key( wp_unslash( $_GET['group'] ?? '' ) );
        $name  = sanitize_text_field( wp_unslash( $_GET['name'] ?? '' ) );

        if ( in_array( $group, array( 'import', 'export' ), true ) && '' !== $name ) {
            $this->templates->remove( $group, $name );
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer-templates' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function render_import_page() {
        if ( ! qiim_can_manage( true ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        $settings   = $this->settings->get_all();
        $upload_id  = sanitize_text_field( wp_unslash( $_GET['upload_id'] ?? '' ) );
        $job_id     = sanitize_text_field( wp_unslash( $_GET['job_id'] ?? '' ) );
        $upload     = $upload_id ? $this->importer->get_upload( $upload_id ) : null;
        $job        = $job_id ? $this->importer->get_job( $job_id ) : null;

        $post_types = get_post_types( array( 'public' => true ), 'objects' );
        $taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );
        $notice     = isset( $_GET['qiim_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qiim_notice'] ) ) : '';
        ?>
        <div class="wrap qiim-wrap">
            <h1><?php esc_html_e( 'Quick Importer - Import', 'quick-importer' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( urldecode( $notice ) ); ?></p></div>
            <?php endif; ?>

            <div class="qiim-card">
                <h2><?php esc_html_e( 'Step 1: Upload CSV', 'quick-importer' ); ?></h2>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
                    <?php wp_nonce_field( 'qiim_import_upload_action', 'qiim_import_upload_nonce' ); ?>
                    <input type="hidden" name="action" value="qiim_import_upload" />
                    <table class="form-table">
                        <tr>
                            <th><label for="qiim_csv_file"><?php esc_html_e( 'CSV File', 'quick-importer' ); ?></label></th>
                            <td><input type="file" name="qiim_csv_file" id="qiim_csv_file" accept=".csv,text/csv" required /></td>
                        </tr>
                        <tr>
                            <th><label for="qiim_content_type"><?php esc_html_e( 'Content Type', 'quick-importer' ); ?></label></th>
                            <td>
                                <select name="content_type" id="qiim_content_type">
                                    <option value="post">Posts</option>
                                    <option value="page">Pages</option>
                                    <option value="product">Products</option>
                                    <option value="category">Categories</option>
                                    <option value="post_tag">Tags</option>
                                    <option value="custom_post">Custom Post Type</option>
                                    <option value="custom_tax">Custom Taxonomy</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="qiim_custom_post_type"><?php esc_html_e( 'Custom Post Type', 'quick-importer' ); ?></label></th>
                            <td>
                                <select name="custom_post_type" id="qiim_custom_post_type">
                                    <option value="">--</option>
                                    <?php foreach ( $post_types as $pt ) : ?>
                                        <option value="<?php echo esc_attr( $pt->name ); ?>"><?php echo esc_html( $pt->labels->name ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="qiim_custom_taxonomy"><?php esc_html_e( 'Custom Taxonomy', 'quick-importer' ); ?></label></th>
                            <td>
                                <select name="custom_taxonomy" id="qiim_custom_taxonomy">
                                    <option value="">--</option>
                                    <?php foreach ( $taxonomies as $tx ) : ?>
                                        <option value="<?php echo esc_attr( $tx->name ); ?>"><?php echo esc_html( $tx->labels->name ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="qiim_delimiter"><?php esc_html_e( 'Delimiter', 'quick-importer' ); ?></label></th>
                            <td><input type="text" maxlength="1" name="delimiter" id="qiim_delimiter" value="<?php echo esc_attr( $settings['default_delimiter'] ); ?>" /></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Header Row', 'quick-importer' ); ?></th>
                            <td><label><input type="checkbox" name="has_header" value="1" checked /> <?php esc_html_e( 'First row contains column names', 'quick-importer' ); ?></label></td>
                        </tr>
                    </table>
                    <p><button class="button button-primary" type="submit"><?php esc_html_e( 'Upload CSV', 'quick-importer' ); ?></button></p>
                </form>
            </div>

            <?php if ( $upload ) : ?>
                <?php $this->render_mapping_step( $upload, $settings ); ?>
            <?php endif; ?>

            <?php if ( $job ) : ?>
                <?php $this->render_job_step( $job ); ?>
            <?php endif; ?>
        </div>
        <?php
    }

    private function render_mapping_step( $upload, $settings ) {
        $headers = (array) $upload['headers'];
        ?>
        <div class="qiim-card">
            <h2><?php esc_html_e( 'Step 2: Column Mapping', 'quick-importer' ); ?></h2>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'qiim_import_start_action', 'qiim_import_start_nonce' ); ?>
                <input type="hidden" name="action" value="qiim_import_start" />
                <input type="hidden" name="upload_id" value="<?php echo esc_attr( $upload['id'] ); ?>" />

                <table class="widefat striped qiim-map-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'CSV Column', 'quick-importer' ); ?></th>
                            <th><?php esc_html_e( 'Map To', 'quick-importer' ); ?></th>
                            <th><?php esc_html_e( 'Custom Meta Key', 'quick-importer' ); ?></th>
                            <th><?php esc_html_e( 'Custom Taxonomy', 'quick-importer' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $headers as $header ) : ?>
                        <tr>
                            <td><?php echo esc_html( $header ); ?></td>
                            <td>
                                <select name="mapping[<?php echo esc_attr( $header ); ?>]">
                                    <option value="__skip__">-- Skip --</option>
                                    <option value="id">ID</option>
                                    <option value="title">Title</option>
                                    <option value="slug">Slug</option>
                                    <option value="status">Status</option>
                                    <option value="author">Author</option>
                                    <option value="date">Date</option>
                                    <option value="content">Content</option>
                                    <option value="excerpt">Excerpt</option>
                                    <option value="meta_json">Meta (JSON)</option>
                                    <option value="taxonomies">Taxonomies (comma-separated)</option>
                                    <option value="featured_image_url">Featured Image URL</option>
                                    <option value="categories">Categories</option>
                                    <option value="tags">Tags</option>
                                    <option value="focus_keyword">Focus Keyword</option>
                                    <option value="secondary_keyword">Secondary Keyword</option>
                                    <option value="seo_title">SEO Title</option>
                                    <option value="meta_description">Meta Description</option>
                                    <option value="longtail_keyword">Longtail Keyword</option>
                                    <option value="sku">SKU</option>
                                    <option value="price">Price</option>
                                    <option value="regular_price">Regular Price</option>
                                    <option value="sale_price">Sale Price</option>
                                    <option value="stock_quantity">Stock Quantity</option>
                                    <option value="stock_status">Stock Status</option>
                                    <option value="product_type">Product Type</option>
                                    <option value="weight">Weight</option>
                                    <option value="length">Length</option>
                                    <option value="width">Width</option>
                                    <option value="height">Height</option>
                                    <option value="attributes">Attributes</option>
                                    <option value="variations">Variations (JSON)</option>
                                    <option value="product_visibility">Product Visibility</option>
                                    <option value="featured">Featured</option>
                                    <option value="downloadable">Downloadable</option>
                                    <option value="virtual">Virtual</option>
                                    <option value="custom_meta">Custom Meta Field</option>
                                    <option value="custom_tax">Custom Taxonomy</option>
                                </select>
                            </td>
                            <td><input type="text" name="mapping_custom_meta[<?php echo esc_attr( $header ); ?>]" placeholder="meta_key" /></td>
                            <td><input type="text" name="mapping_custom_tax[<?php echo esc_attr( $header ); ?>]" placeholder="taxonomy_slug" /></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <h3><?php esc_html_e( 'Step 3: Import Mode + Matching', 'quick-importer' ); ?></h3>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e( 'Import Mode', 'quick-importer' ); ?></th>
                        <td>
                            <select name="import_mode">
                                <option value="update_create" <?php selected( $settings['default_import_mode'], 'update_create' ); ?>>Update existing + Create new</option>
                                <option value="update_only" <?php selected( $settings['default_import_mode'], 'update_only' ); ?>>Update existing only</option>
                                <option value="create_only" <?php selected( $settings['default_import_mode'], 'create_only' ); ?>>Create new only</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Matching Key', 'quick-importer' ); ?></th>
                        <td>
                            <select name="matching_key">
                                <option value="id" <?php selected( $settings['default_matching_key'], 'id' ); ?>>ID</option>
                                <option value="slug" <?php selected( $settings['default_matching_key'], 'slug' ); ?>>Slug</option>
                                <option value="title" <?php selected( $settings['default_matching_key'], 'title' ); ?>>Title</option>
                                <option value="sku" <?php selected( $settings['default_matching_key'], 'sku' ); ?>>SKU (products)</option>
                                <option value="meta" <?php selected( $settings['default_matching_key'], 'meta' ); ?>>Custom Meta Key</option>
                            </select>
                            <input type="text" name="matching_meta_key" placeholder="meta_key_if_selected" />
                        </td>
                    </tr>
                </table>

                <p>
                    <button type="submit" class="button button-primary"><?php esc_html_e( 'Start Import', 'quick-importer' ); ?></button>
                </p>
            </form>
        </div>
        <?php
    }

    private function render_job_step( $job ) {
        ?>
        <div class="qiim-card" id="qiim-import-progress" data-job-id="<?php echo esc_attr( $job['id'] ); ?>">
            <h2><?php esc_html_e( 'Import Progress', 'quick-importer' ); ?></h2>
            <p><strong>Status:</strong> <span class="qiim-status-text"><?php echo esc_html( $job['status'] ); ?></span></p>
            <div class="qiim-progress"><div class="qiim-progress-bar" style="width:0%"></div></div>
            <p>
                <span class="qiim-progress-label">0%</span> |
                <span class="qiim-progress-counts">Processed 0 / <?php echo esc_html( (int) $job['row_count'] ); ?></span>
            </p>
            <div class="qiim-failed-rows"></div>
            <p><button class="button button-primary qiim-start-import"><?php esc_html_e( 'Run Import', 'quick-importer' ); ?></button></p>
        </div>
        <?php
    }

    public function render_export_page() {
        if ( ! qiim_can_manage( true ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        $settings    = $this->settings->get_all();
        $is_premium  = qiim_is_premium();
        $post_types  = get_post_types( array( 'public' => true ), 'objects' );
        $taxonomies  = get_taxonomies( array( 'public' => true ), 'objects' );
        $cat_terms   = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => false ) );
        $content_type = 'post';
        $fields      = $this->exporter->default_fields_for_type( $content_type );
        $notice      = isset( $_GET['qiim_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qiim_notice'] ) ) : '';
        ?>
        <div class="wrap qiim-wrap">
            <h1><?php esc_html_e( 'Quick Importer - Export', 'quick-importer' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-warning"><p><?php echo esc_html( urldecode( $notice ) ); ?></p></div>
            <?php endif; ?>

            <?php if ( ! $is_premium ) : ?>
                <div class="notice notice-warning"><p><?php esc_html_e( 'Product export is available in QuickWoo Pro.', 'quick-importer' ); ?></p></div>
            <?php endif; ?>

            <div class="qiim-card">
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'qiim_export_action', 'qiim_export_nonce' ); ?>
                    <input type="hidden" name="action" value="qiim_export_csv" />

                    <table class="form-table">
                        <tr>
                            <th><label for="qiim_export_type"><?php esc_html_e( 'Content Type', 'quick-importer' ); ?></label></th>
                            <td>
                                <select id="qiim_export_type" name="content_type">
                                    <?php foreach ( $this->exporter->get_exportable_types() as $key => $label ) : ?>
                                        <option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Date Range', 'quick-importer' ); ?></th>
                            <td>
                                <input type="date" name="date_from" />
                                <input type="date" name="date_to" />
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Category Filter', 'quick-importer' ); ?></th>
                            <td>
                                <select name="category_id">
                                    <option value="0">All</option>
                                    <?php if ( ! is_wp_error( $cat_terms ) ) : ?>
                                        <?php foreach ( $cat_terms as $term ) : ?>
                                            <option value="<?php echo esc_attr( $term->term_id ); ?>"><?php echo esc_html( $term->name ); ?></option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Status', 'quick-importer' ); ?></th>
                            <td>
                                <select name="status">
                                    <option value="">All</option>
                                    <option value="publish">publish</option>
                                    <option value="draft">draft</option>
                                    <option value="private">private</option>
                                    <option value="pending">pending</option>
                                    <option value="future">future</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Include IDs', 'quick-importer' ); ?></th>
                            <td><input type="text" name="include_ids" placeholder="1,2,3" /></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Exclude IDs', 'quick-importer' ); ?></th>
                            <td><input type="text" name="exclude_ids" placeholder="4,5,6" /></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Custom Post Type', 'quick-importer' ); ?></th>
                            <td>
                                <select name="custom_post_type">
                                    <option value="">--</option>
                                    <?php foreach ( $post_types as $pt ) : ?>
                                        <option value="<?php echo esc_attr( $pt->name ); ?>"><?php echo esc_html( $pt->labels->name ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Custom Taxonomy', 'quick-importer' ); ?></th>
                            <td>
                                <select name="custom_taxonomy">
                                    <option value="">--</option>
                                    <?php foreach ( $taxonomies as $tx ) : ?>
                                        <option value="<?php echo esc_attr( $tx->name ); ?>"><?php echo esc_html( $tx->labels->name ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Delimiter', 'quick-importer' ); ?></th>
                            <td><input type="text" maxlength="1" name="delimiter" value="<?php echo esc_attr( $settings['default_delimiter'] ); ?>" /></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'UTF-8 BOM', 'quick-importer' ); ?></th>
                            <td><label><input type="checkbox" name="utf8_bom" value="1" <?php checked( ! empty( $settings['utf8_bom'] ) ); ?> /> Include BOM</label></td>
                        </tr>
                    </table>

                    <h2><?php esc_html_e( 'Field Selection', 'quick-importer' ); ?></h2>
                    <div class="qiim-field-grid">
                        <?php foreach ( $fields as $field ) : ?>
                            <label><input type="checkbox" name="fields[]" value="<?php echo esc_attr( $field ); ?>" checked /> <?php echo esc_html( $field ); ?></label>
                        <?php endforeach; ?>
                    </div>

                    <p><button type="submit" class="button button-primary"><?php esc_html_e( 'Download CSV', 'quick-importer' ); ?></button></p>
                </form>

                <hr />

                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'qiim_export_template_action', 'qiim_export_template_nonce' ); ?>
                    <input type="hidden" name="action" value="qiim_save_export_template" />
                    <input type="hidden" name="content_type" value="post" />
                    <input type="hidden" name="delimiter" value="<?php echo esc_attr( $settings['default_delimiter'] ); ?>" />
                    <?php foreach ( $fields as $field ) : ?>
                        <input type="hidden" name="fields[]" value="<?php echo esc_attr( $field ); ?>" />
                    <?php endforeach; ?>
                    <label><?php esc_html_e( 'Save current field preset as template:', 'quick-importer' ); ?> <input type="text" name="template_name" /></label>
                    <button type="submit" class="button"><?php esc_html_e( 'Save Template', 'quick-importer' ); ?></button>
                </form>
            </div>
        </div>
        <?php
    }

    public function render_templates_page() {
        if ( ! qiim_can_manage( false ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        $templates = $this->templates->all();
        ?>
        <div class="wrap qiim-wrap">
            <h1><?php esc_html_e( 'Quick Importer - Templates', 'quick-importer' ); ?></h1>
            <div class="qiim-card">
                <h2><?php esc_html_e( 'Import Templates', 'quick-importer' ); ?></h2>
                <?php $this->render_template_list( 'import', $templates['import'] ); ?>

                <h2><?php esc_html_e( 'Export Templates', 'quick-importer' ); ?></h2>
                <?php $this->render_template_list( 'export', $templates['export'] ); ?>
            </div>
        </div>
        <?php
    }

    private function render_template_list( $group, $items ) {
        if ( empty( $items ) ) {
            echo '<p>No templates saved.</p>';
            return;
        }

        echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Payload</th><th>Actions</th></tr></thead><tbody>';
        foreach ( $items as $name => $payload ) {
            $delete_url = wp_nonce_url(
                add_query_arg(
                    array(
                        'action' => 'qiim_delete_template',
                        'group'  => $group,
                        'name'   => rawurlencode( $name ),
                    ),
                    admin_url( 'admin-post.php' )
                ),
                'qiim_delete_template_action',
                'qiim_delete_template_nonce'
            );

            echo '<tr>';
            echo '<td>' . esc_html( $name ) . '</td>';
            echo '<td><code>' . esc_html( wp_json_encode( $payload ) ) . '</code></td>';
            echo '<td><a href="' . esc_url( $delete_url ) . '" class="button button-small">Delete</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    public function render_logs_page() {
        if ( ! qiim_can_manage( false ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        $logs = $this->logs->all();
        ?>
        <div class="wrap qiim-wrap">
            <h1><?php esc_html_e( 'Quick Importer - Logs', 'quick-importer' ); ?></h1>
            <div class="qiim-card">
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Date', 'quick-importer' ); ?></th>
                            <th><?php esc_html_e( 'Type', 'quick-importer' ); ?></th>
                            <th><?php esc_html_e( 'Content Type', 'quick-importer' ); ?></th>
                            <th><?php esc_html_e( 'Total Rows', 'quick-importer' ); ?></th>
                            <th><?php esc_html_e( 'Success', 'quick-importer' ); ?></th>
                            <th><?php esc_html_e( 'Failed', 'quick-importer' ); ?></th>
                            <th><?php esc_html_e( 'Duration (s)', 'quick-importer' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ( empty( $logs ) ) : ?>
                            <tr><td colspan="7"><?php esc_html_e( 'No logs yet.', 'quick-importer' ); ?></td></tr>
                        <?php else : ?>
                            <?php foreach ( array_reverse( $logs ) as $log ) : ?>
                                <tr>
                                    <td><?php echo esc_html( $log['date'] ?? '' ); ?></td>
                                    <td><?php echo esc_html( $log['type'] ?? '' ); ?></td>
                                    <td><?php echo esc_html( $log['content_type'] ?? '' ); ?></td>
                                    <td><?php echo esc_html( (int) ( $log['total_rows'] ?? 0 ) ); ?></td>
                                    <td><?php echo esc_html( (int) ( $log['success'] ?? 0 ) ); ?></td>
                                    <td><?php echo esc_html( (int) ( $log['failed'] ?? 0 ) ); ?></td>
                                    <td><?php echo esc_html( number_format_i18n( (float) ( $log['duration'] ?? 0 ), 2 ) ); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    public function render_settings_page() {
        if ( ! qiim_can_manage( false ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        $settings = $this->settings->get_all();
        $memory   = qiim_get_memory_snapshot();
        ?>
        <div class="wrap qiim-wrap">
            <h1><?php esc_html_e( 'Quick Importer - Settings', 'quick-importer' ); ?></h1>
            <div class="qiim-card">
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'qiim_save_settings_action', 'qiim_save_settings_nonce' ); ?>
                    <input type="hidden" name="action" value="qiim_save_settings" />

                    <table class="form-table">
                        <tr>
                            <th><?php esc_html_e( 'Max Upload Size (MB)', 'quick-importer' ); ?></th>
                            <td><input type="number" min="1" name="max_upload_mb" value="<?php echo esc_attr( $settings['max_upload_mb'] ); ?>" /></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Batch Size', 'quick-importer' ); ?></th>
                            <td><input type="number" min="1" name="batch_size" value="<?php echo esc_attr( $settings['batch_size'] ); ?>" /></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Auto-create Taxonomy Terms', 'quick-importer' ); ?></th>
                            <td><label><input type="checkbox" name="auto_create_terms" value="1" <?php checked( ! empty( $settings['auto_create_terms'] ) ); ?> /></label></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Default Import Mode', 'quick-importer' ); ?></th>
                            <td>
                                <select name="default_import_mode">
                                    <option value="update_create" <?php selected( $settings['default_import_mode'], 'update_create' ); ?>>Update existing + Create new</option>
                                    <option value="update_only" <?php selected( $settings['default_import_mode'], 'update_only' ); ?>>Update existing only</option>
                                    <option value="create_only" <?php selected( $settings['default_import_mode'], 'create_only' ); ?>>Create new only</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Default Matching Key', 'quick-importer' ); ?></th>
                            <td>
                                <select name="default_matching_key">
                                    <option value="id" <?php selected( $settings['default_matching_key'], 'id' ); ?>>ID</option>
                                    <option value="slug" <?php selected( $settings['default_matching_key'], 'slug' ); ?>>Slug</option>
                                    <option value="title" <?php selected( $settings['default_matching_key'], 'title' ); ?>>Title</option>
                                    <option value="sku" <?php selected( $settings['default_matching_key'], 'sku' ); ?>>SKU</option>
                                    <option value="meta" <?php selected( $settings['default_matching_key'], 'meta' ); ?>>Custom Meta Key</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Default CSV Delimiter', 'quick-importer' ); ?></th>
                            <td><input type="text" name="default_delimiter" maxlength="1" value="<?php echo esc_attr( $settings['default_delimiter'] ); ?>" /></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'UTF-8 BOM', 'quick-importer' ); ?></th>
                            <td><label><input type="checkbox" name="utf8_bom" value="1" <?php checked( ! empty( $settings['utf8_bom'] ) ); ?> /></label></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Scheduled Exports (Premium Stub)', 'quick-importer' ); ?></th>
                            <td><label><input type="checkbox" name="scheduled_exports_enabled" value="1" <?php checked( ! empty( $settings['scheduled_exports_enabled'] ) ); ?> /></label></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Debug Mode', 'quick-importer' ); ?></th>
                            <td><label><input type="checkbox" name="debug_mode" value="1" <?php checked( ! empty( $settings['debug_mode'] ) ); ?> /></label></td>
                        </tr>
                    </table>

                    <p><button type="submit" class="button button-primary"><?php esc_html_e( 'Save Settings', 'quick-importer' ); ?></button></p>
                </form>

                <h2><?php esc_html_e( 'Memory Monitor', 'quick-importer' ); ?></h2>
                <p>
                    <?php echo esc_html( sprintf( 'Usage: %s | Peak: %s | Limit: %s', $memory['usage'], $memory['peak'], $memory['limit'] ) ); ?>
                </p>
            </div>
        </div>
        <?php
    }
}
