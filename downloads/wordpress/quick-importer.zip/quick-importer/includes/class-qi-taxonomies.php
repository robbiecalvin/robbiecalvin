<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QIIM_Taxonomies {
    private $settings;

    public function __construct( $settings ) {
        $this->settings = $settings;
    }

    public function resolve_terms( $taxonomy, $raw_value ) {
        $term_ids = array();

        if ( ! taxonomy_exists( $taxonomy ) ) {
            return $term_ids;
        }

        $parts = qiim_parse_list_string( $raw_value );
        if ( empty( $parts ) ) {
            return $term_ids;
        }

        foreach ( $parts as $item ) {
            $parent_id = 0;
            $name      = $item;

            if ( false !== strpos( $item, '>' ) ) {
                $chain = array_map( 'trim', explode( '>', $item ) );
                foreach ( $chain as $index => $seg ) {
                    if ( '' === $seg ) {
                        continue;
                    }

                    $term = term_exists( $seg, $taxonomy, $parent_id );
                    if ( ! $term && $this->can_auto_create_terms() ) {
                        $insert = wp_insert_term(
                            $seg,
                            $taxonomy,
                            array(
                                'parent' => $parent_id,
                            )
                        );
                        if ( ! is_wp_error( $insert ) ) {
                            $term = $insert;
                        }
                    }

                    if ( is_array( $term ) && ! empty( $term['term_id'] ) ) {
                        $parent_id = (int) $term['term_id'];
                        if ( count( $chain ) - 1 === $index ) {
                            $term_ids[] = $parent_id;
                        }
                    }
                }
                continue;
            }

            $term = term_exists( $name, $taxonomy );
            if ( ! $term && $this->can_auto_create_terms() ) {
                $insert = wp_insert_term( $name, $taxonomy );
                if ( ! is_wp_error( $insert ) ) {
                    $term = $insert;
                }
            }

            if ( is_array( $term ) && ! empty( $term['term_id'] ) ) {
                $term_ids[] = (int) $term['term_id'];
            }
        }

        return array_values( array_unique( array_filter( $term_ids ) ) );
    }

    public function assign_to_object( $object_id, $taxonomy, $raw_value ) {
        $term_ids = $this->resolve_terms( $taxonomy, $raw_value );
        if ( empty( $term_ids ) ) {
            return;
        }

        wp_set_object_terms( (int) $object_id, $term_ids, $taxonomy, false );
    }

    private function can_auto_create_terms() {
        return (bool) $this->settings->get( 'auto_create_terms', 1 );
    }
}
