<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QIIM_Import {
    const JOBS_OPTION    = 'qiim_jobs';
    const UPLOADS_OPTION = 'qiim_uploads';

    private $settings;
    private $logs;
    private $templates;
    private $taxonomies;
    private $products;

    public function __construct( $settings, $logs, $templates, $taxonomies, $products ) {
        $this->settings   = $settings;
        $this->logs       = $logs;
        $this->templates  = $templates;
        $this->taxonomies = $taxonomies;
        $this->products   = $products;
    }

    public function hooks() {
        add_action( 'admin_post_qiim_import_upload', array( $this, 'handle_upload' ) );
        add_action( 'admin_post_qiim_import_start', array( $this, 'handle_start_import' ) );
        add_action( 'admin_post_qiim_save_import_template', array( $this, 'handle_save_template' ) );

        add_action( 'wp_ajax_qiim_process_import', array( $this, 'ajax_process_import' ) );
        add_action( 'wp_ajax_qiim_import_status', array( $this, 'ajax_import_status' ) );
    }

    public function get_upload( $upload_id ) {
        $uploads = get_option( self::UPLOADS_OPTION, array() );
        if ( ! is_array( $uploads ) ) {
            $uploads = array();
        }

        return $uploads[ $upload_id ] ?? null;
    }

    public function get_job( $job_id ) {
        $jobs = get_option( self::JOBS_OPTION, array() );
        if ( ! is_array( $jobs ) ) {
            $jobs = array();
        }

        return $jobs[ $job_id ] ?? null;
    }

    public function handle_upload() {
        if ( ! qiim_can_manage( true ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        check_admin_referer( 'qiim_import_upload_action', 'qiim_import_upload_nonce' );

        if ( empty( $_FILES['qiim_csv_file'] ) ) {
            wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer', 'qiim_notice' => 'upload_missing' ), admin_url( 'admin.php' ) ) );
            exit;
        }

        $file = $_FILES['qiim_csv_file'];

        $max_bytes = (int) $this->settings->get( 'max_upload_mb', 20 ) * 1024 * 1024;
        if ( (int) $file['size'] > $max_bytes ) {
            wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer', 'qiim_notice' => 'upload_too_large' ), admin_url( 'admin.php' ) ) );
            exit;
        }

        $allowed_mimes = array(
            'text/csv',
            'text/plain',
            'application/csv',
            'application/vnd.ms-excel',
        );

        $ft = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
        if ( empty( $ft['ext'] ) || ! in_array( $ft['type'], $allowed_mimes, true ) ) {
            wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer', 'qiim_notice' => 'upload_invalid_type' ), admin_url( 'admin.php' ) ) );
            exit;
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';

        $overrides = array(
            'test_form' => false,
            'mimes'     => array(
                'csv' => 'text/csv',
                'txt' => 'text/plain',
            ),
        );

        $moved = wp_handle_upload( $file, $overrides );
        if ( ! empty( $moved['error'] ) ) {
            wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer', 'qiim_notice' => 'upload_failed' ), admin_url( 'admin.php' ) ) );
            exit;
        }

        $target_dir = qiim_get_upload_dir();
        $source     = $moved['file'];
        $dest       = trailingslashit( $target_dir ) . wp_unique_filename( $target_dir, basename( $source ) );

        if ( ! @rename( $source, $dest ) ) {
            if ( ! @copy( $source, $dest ) ) {
                qiim_safe_unlink( $source );
                wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer', 'qiim_notice' => 'upload_failed' ), admin_url( 'admin.php' ) ) );
                exit;
            }
            qiim_safe_unlink( $source );
        }

        $delimiter  = qiim_sanitize_delimiter( wp_unslash( $_POST['delimiter'] ?? $this->settings->get( 'default_delimiter', ',' ) ) );
        $has_header = ! empty( $_POST['has_header'] );

        $parsed = $this->read_csv_preview( $dest, $delimiter, $has_header );
        if ( is_wp_error( $parsed ) ) {
            qiim_safe_unlink( $dest );
            wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer', 'qiim_notice' => 'upload_parse_failed' ), admin_url( 'admin.php' ) ) );
            exit;
        }

        $upload_id          = wp_generate_uuid4();
        $uploads            = get_option( self::UPLOADS_OPTION, array() );
        $uploads[ $upload_id ] = array(
            'id'           => $upload_id,
            'created_at'   => time(),
            'file'         => $dest,
            'delimiter'    => $delimiter,
            'has_header'   => $has_header ? 1 : 0,
            'headers'      => $parsed['headers'],
            'sample_rows'  => $parsed['sample_rows'],
            'row_count'    => $parsed['row_count'],
            'content_type' => sanitize_key( wp_unslash( $_POST['content_type'] ?? 'post' ) ),
            'custom_post_type' => sanitize_key( wp_unslash( $_POST['custom_post_type'] ?? '' ) ),
            'custom_taxonomy'  => sanitize_key( wp_unslash( $_POST['custom_taxonomy'] ?? '' ) ),
        );
        update_option( self::UPLOADS_OPTION, $uploads, false );

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer', 'upload_id' => $upload_id ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_start_import() {
        if ( ! qiim_can_manage( true ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        check_admin_referer( 'qiim_import_start_action', 'qiim_import_start_nonce' );

        $upload_id = sanitize_text_field( wp_unslash( $_POST['upload_id'] ?? '' ) );
        $upload    = $this->get_upload( $upload_id );

        if ( ! $upload || empty( $upload['file'] ) || ! file_exists( $upload['file'] ) ) {
            wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer', 'qiim_notice' => 'missing_upload' ), admin_url( 'admin.php' ) ) );
            exit;
        }

        if ( 'product' === $upload['content_type'] && ! qiim_is_premium() ) {
            wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer', 'qiim_notice' => 'premium_required' ), admin_url( 'admin.php' ) ) );
            exit;
        }

        $mode       = sanitize_key( wp_unslash( $_POST['import_mode'] ?? $this->settings->get( 'default_import_mode', 'update_create' ) ) );
        $match_key  = sanitize_key( wp_unslash( $_POST['matching_key'] ?? $this->settings->get( 'default_matching_key', 'id' ) ) );
        $match_meta = sanitize_key( wp_unslash( $_POST['matching_meta_key'] ?? '' ) );

        $mapping_raw = (array) ( $_POST['mapping'] ?? array() );
        $custom_meta = (array) ( $_POST['mapping_custom_meta'] ?? array() );
        $custom_tax  = (array) ( $_POST['mapping_custom_tax'] ?? array() );

        $mapping = array();
        foreach ( $mapping_raw as $csv_col => $target ) {
            $csv_col = sanitize_text_field( wp_unslash( $csv_col ) );
            $target  = sanitize_text_field( wp_unslash( $target ) );
            if ( '' === $target || '__skip__' === $target ) {
                continue;
            }

            if ( 'custom_meta' === $target ) {
                $meta_key = sanitize_key( wp_unslash( $custom_meta[ $csv_col ] ?? '' ) );
                if ( '' !== $meta_key ) {
                    $target = 'meta:' . $meta_key;
                }
            }

            if ( 'custom_tax' === $target ) {
                $tax_key = sanitize_key( wp_unslash( $custom_tax[ $csv_col ] ?? '' ) );
                if ( '' !== $tax_key ) {
                    $target = 'tax:' . $tax_key;
                }
            }

            if ( '' !== $target && '__skip__' !== $target ) {
                $mapping[ $csv_col ] = $target;
            }
        }

        $job_id = wp_generate_uuid4();
        $jobs   = get_option( self::JOBS_OPTION, array() );
        if ( ! is_array( $jobs ) ) {
            $jobs = array();
        }

        $jobs[ $job_id ] = array(
            'id'               => $job_id,
            'created_at'       => time(),
            'status'           => 'pending',
            'upload_id'        => $upload_id,
            'file'             => $upload['file'],
            'delimiter'        => $upload['delimiter'],
            'has_header'       => ! empty( $upload['has_header'] ),
            'headers'          => $upload['headers'],
            'content_type'     => $upload['content_type'],
            'custom_post_type' => $upload['custom_post_type'],
            'custom_taxonomy'  => $upload['custom_taxonomy'],
            'import_mode'      => $mode,
            'matching_key'     => $match_key,
            'matching_meta_key'=> $match_meta,
            'mapping'          => $mapping,
            'row_count'        => (int) $upload['row_count'],
            'offset'           => 0,
            'success'          => 0,
            'created'          => 0,
            'updated'          => 0,
            'skipped'          => 0,
            'failed'           => 0,
            'failed_rows'      => array(),
            'started_at'       => null,
            'ended_at'         => null,
        );

        update_option( self::JOBS_OPTION, $jobs, false );

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer', 'job_id' => $job_id ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_save_template() {
        if ( ! qiim_can_manage( true ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-importer' ) );
        }

        check_admin_referer( 'qiim_import_template_action', 'qiim_import_template_nonce' );

        $name    = sanitize_text_field( wp_unslash( $_POST['template_name'] ?? '' ) );
        $mapping = (array) ( $_POST['template_mapping'] ?? array() );
        if ( '' !== $name && ! empty( $mapping ) ) {
            $this->templates->save_import( $name, $mapping );
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-importer-templates' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function ajax_import_status() {
        if ( ! qiim_can_manage( true ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ), 403 );
        }

        check_ajax_referer( 'qiim_import_ajax', 'nonce' );

        $job_id = sanitize_text_field( wp_unslash( $_POST['job_id'] ?? '' ) );
        $job    = $this->get_job( $job_id );

        if ( ! $job ) {
            wp_send_json_error( array( 'message' => 'Job not found.' ), 404 );
        }

        wp_send_json_success( $this->job_response( $job ) );
    }

    public function ajax_process_import() {
        if ( ! qiim_can_manage( true ) ) {
            wp_send_json_error( array( 'message' => 'Permission denied.' ), 403 );
        }

        check_ajax_referer( 'qiim_import_ajax', 'nonce' );

        $job_id = sanitize_text_field( wp_unslash( $_POST['job_id'] ?? '' ) );
        $job    = $this->get_job( $job_id );

        if ( ! $job ) {
            wp_send_json_error( array( 'message' => 'Job not found.' ), 404 );
        }

        if ( ! file_exists( $job['file'] ) ) {
            wp_send_json_error( array( 'message' => 'Import file missing.' ), 400 );
        }

        $jobs = get_option( self::JOBS_OPTION, array() );
        if ( ! isset( $jobs[ $job_id ] ) ) {
            wp_send_json_error( array( 'message' => 'Job not found.' ), 404 );
        }

        if ( 'done' === $job['status'] ) {
            wp_send_json_success( $this->job_response( $job ) );
        }

        if ( empty( $job['started_at'] ) ) {
            $job['started_at'] = microtime( true );
            $job['status']     = 'running';
        }

        $batch_size = (int) $this->settings->get( 'batch_size', 50 );
        $processed  = 0;

        $csv = new SplFileObject( $job['file'], 'r' );
        $csv->setFlags( SplFileObject::READ_CSV | SplFileObject::SKIP_EMPTY );
        $csv->setCsvControl( $job['delimiter'] );

        $header_offset = ! empty( $job['has_header'] ) ? 1 : 0;
        $start_line    = (int) $job['offset'] + $header_offset;
        $csv->seek( $start_line );

        while ( ! $csv->eof() && $processed < $batch_size ) {
            $row = $csv->current();
            $csv->next();

            if ( ! is_array( $row ) || ( 1 === count( $row ) && null === $row[0] ) ) {
                continue;
            }

            $result = $this->process_row( $job, $row, $start_line + $processed + 1 );
            if ( is_wp_error( $result ) ) {
                $job['failed']++;
                $job['failed_rows'][] = array(
                    'line'   => $start_line + $processed + 1,
                    'reason' => $result->get_error_message(),
                );
                if ( count( $job['failed_rows'] ) > 200 ) {
                    $job['failed_rows'] = array_slice( $job['failed_rows'], -200 );
                }
            } else {
                $status = is_array( $result ) && isset( $result['status'] ) ? sanitize_key( (string) $result['status'] ) : 'success';
                if ( 'skipped' === $status ) {
                    $job['skipped']++;
                } else {
                    $job['success']++;
                    if ( 'created' === $status ) {
                        $job['created']++;
                    } elseif ( 'updated' === $status ) {
                        $job['updated']++;
                    }
                }
            }

            $job['offset']++;
            $processed++;
        }

        if ( $job['offset'] >= (int) $job['row_count'] ) {
            $job['status']   = 'done';
            $job['ended_at'] = microtime( true );

            $duration = max( 0, (float) $job['ended_at'] - (float) $job['started_at'] );
            $this->logs->add(
                'import',
                $job['content_type'],
                (int) $job['row_count'],
                (int) $job['success'],
                (int) $job['failed'],
                $duration,
                array(
                    'failed_rows' => $job['failed_rows'],
                )
            );

            $this->cleanup_upload( $job['upload_id'] );
        }

        $jobs[ $job_id ] = $job;
        update_option( self::JOBS_OPTION, $jobs, false );

        wp_send_json_success( $this->job_response( $job ) );
    }

    private function process_row( $job, $row, $line_number ) {
        $headers = (array) $job['headers'];
        $mapping = (array) $job['mapping'];

        $assoc = array();
        foreach ( $headers as $idx => $header ) {
            $assoc[ $header ] = isset( $row[ $idx ] ) ? wp_unslash( (string) $row[ $idx ] ) : '';
        }

        $mapped = array();
        foreach ( $mapping as $csv_col => $target ) {
            $mapped[ $target ] = $assoc[ $csv_col ] ?? '';
        }

        $context = $this->resolve_target( $job, $mapped );
        if ( is_wp_error( $context ) ) {
            return $context;
        }

        if ( ! empty( $context['skip'] ) ) {
            return array( 'status' => 'skipped' );
        }

        if ( in_array( $job['content_type'], array( 'category', 'post_tag', 'custom_tax' ), true ) ) {
            return $this->upsert_term( $job, $mapped, $context );
        }

        return $this->upsert_post_like( $job, $mapped, $context );
    }

    private function resolve_target( $job, $mapped ) {
        $mode      = $job['import_mode'];
        $match_key = $job['matching_key'];
        $existing  = 0;

        if ( 'product' === $this->target_post_type( $job ) ) {
            $match_key = 'sku';
        } elseif ( in_array( $this->target_post_type( $job ), array( 'post', 'page' ), true ) && ! in_array( $match_key, array( 'id', 'slug' ), true ) ) {
            $match_key = 'slug';
        }

        if ( 'id' === $match_key && ! empty( $mapped['id'] ) ) {
            $existing = absint( $mapped['id'] );
            if ( $existing && ! get_post( $existing ) ) {
                $existing = 0;
            }
        }

        if ( 'slug' === $match_key && ! empty( $mapped['slug'] ) ) {
            $slug = sanitize_title( $mapped['slug'] );
            $pt   = $this->target_post_type( $job );
            $obj  = get_page_by_path( $slug, OBJECT, $pt );
            $existing = $obj ? (int) $obj->ID : 0;
        }

        if ( 'title' === $match_key && ! empty( $mapped['title'] ) ) {
            $pt = $this->target_post_type( $job );
            $q  = get_posts(
                array(
                    'post_type'      => $pt,
                    'title'          => sanitize_text_field( $mapped['title'] ),
                    'posts_per_page' => 1,
                    'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
                    'fields'         => 'ids',
                )
            );
            $existing = ! empty( $q ) ? (int) $q[0] : 0;
        }

        if ( 'sku' === $match_key && ! empty( $mapped['sku'] ) ) {
            $existing = $this->products->find_product_by_sku( sanitize_text_field( $mapped['sku'] ) );
        }

        if ( 'meta' === $match_key && ! empty( $job['matching_meta_key'] ) ) {
            $meta_key = sanitize_key( $job['matching_meta_key'] );
            $meta_val = (string) ( $mapped[ 'meta:' . $meta_key ] ?? '' );
            if ( '' !== $meta_val ) {
                $q = get_posts(
                    array(
                        'post_type'      => $this->target_post_type( $job ),
                        'posts_per_page' => 1,
                        'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
                        'fields'         => 'ids',
                        'meta_query'     => array(
                            array(
                                'key'   => $meta_key,
                                'value' => sanitize_text_field( $meta_val ),
                            ),
                        ),
                    )
                );
                $existing = ! empty( $q ) ? (int) $q[0] : 0;
            }
        }

        if ( 'update_only' === $mode && ! $existing ) {
            return array( 'skip' => true );
        }

        if ( 'create_only' === $mode && $existing ) {
            return array( 'skip' => true );
        }

        return array(
            'post_id'  => $existing,
            'existing' => ! empty( $existing ),
        );
    }

    private function target_post_type( $job ) {
        if ( 'custom_post' === $job['content_type'] && ! empty( $job['custom_post_type'] ) ) {
            return sanitize_key( $job['custom_post_type'] );
        }

        return sanitize_key( $job['content_type'] );
    }

    private function upsert_post_like( $job, $mapped, $context ) {
        $post_id    = (int) ( $context['post_id'] ?? 0 );
        $post_type  = $this->target_post_type( $job );
        $is_product = 'product' === $post_type;

        $post_data = array();
        if ( $post_id ) {
            $post_data['ID'] = $post_id;
        } else {
            $post_data['post_type'] = $post_type;
            $post_data['post_status'] = 'draft';
        }

        $core_map = array(
            'title'   => 'post_title',
            'slug'    => 'post_name',
            'status'  => 'post_status',
            'date'    => 'post_date',
            'content' => 'post_content',
            'excerpt' => 'post_excerpt',
        );

        foreach ( $core_map as $source => $target ) {
            if ( isset( $mapped[ $source ] ) ) {
                $val = (string) $mapped[ $source ];
                if ( 'post_name' === $target ) {
                    $val = sanitize_title( $val );
                }
                if ( 'post_status' === $target ) {
                    $val = sanitize_key( $val );
                }
                $post_data[ $target ] = $val;
            }
        }

        if ( isset( $mapped['author'] ) ) {
            $author = get_user_by( 'login', sanitize_user( $mapped['author'] ) );
            if ( $author ) {
                $post_data['post_author'] = (int) $author->ID;
            }
        }

        $result = $post_id ? wp_update_post( $post_data, true ) : wp_insert_post( $post_data, true );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $post_id = (int) $result;

        if ( isset( $mapped['featured_image_url'] ) && '' !== trim( (string) $mapped['featured_image_url'] ) ) {
            $this->assign_featured_image_from_url( $post_id, $mapped['featured_image_url'] );
        }

        if ( isset( $mapped['categories'] ) ) {
            if ( $is_product ) {
                $this->taxonomies->assign_to_object( $post_id, 'product_cat', $mapped['categories'] );
            } else {
                $this->taxonomies->assign_to_object( $post_id, 'category', $mapped['categories'] );
            }
        }

        if ( isset( $mapped['tags'] ) ) {
            if ( $is_product ) {
                $this->taxonomies->assign_to_object( $post_id, 'product_tag', $mapped['tags'] );
            } else {
                $this->taxonomies->assign_to_object( $post_id, 'post_tag', $mapped['tags'] );
            }
        }

        if ( isset( $mapped['taxonomies'] ) ) {
            $list = qiim_parse_list_string( (string) $mapped['taxonomies'] );
            if ( ! empty( $list ) ) {
                if ( $is_product ) {
                    $this->taxonomies->assign_to_object( $post_id, 'product_cat', implode( ',', $list ) );
                } else {
                    $this->taxonomies->assign_to_object( $post_id, 'category', implode( ',', $list ) );
                }
            }
        }

        if ( isset( $mapped['meta_json'] ) ) {
            $meta_payload = json_decode( (string) $mapped['meta_json'], true );
            if ( is_array( $meta_payload ) ) {
                foreach ( $meta_payload as $meta_key => $meta_value ) {
                    $meta_key = sanitize_key( (string) $meta_key );
                    if ( '' === $meta_key ) {
                        continue;
                    }
                    update_post_meta( $post_id, $meta_key, maybe_serialize( $meta_value ) );
                }
            }
        }

        foreach ( $mapped as $target => $value ) {
            if ( 0 === strpos( $target, 'meta:' ) ) {
                $meta_key = sanitize_key( substr( $target, 5 ) );
                if ( '' !== $meta_key ) {
                    update_post_meta( $post_id, $meta_key, sanitize_text_field( $value ) );
                }
                continue;
            }

            if ( 0 === strpos( $target, 'tax:' ) ) {
                $taxonomy = sanitize_key( substr( $target, 4 ) );
                if ( taxonomy_exists( $taxonomy ) ) {
                    $this->taxonomies->assign_to_object( $post_id, $taxonomy, $value );
                }
                continue;
            }

            if ( in_array( $target, array( 'focus_keyword', 'secondary_keyword', 'longtail_keyword', 'seo_title', 'meta_description', 'og_title', 'og_description', 'twitter_title', 'twitter_description', 'robots', 'sitemap' ), true ) ) {
                update_post_meta( $post_id, '_quickseo_' . sanitize_key( $target ), sanitize_text_field( $value ) );
            }
        }

        if ( $is_product ) {
            $product_apply = $this->products->apply_product_fields( $post_id, $mapped );
            if ( is_wp_error( $product_apply ) ) {
                return $product_apply;
            }
        }

        return array( 'status' => ! empty( $context['existing'] ) ? 'updated' : 'created' );
    }

    private function upsert_term( $job, $mapped, $context ) {
        $taxonomy = 'custom_tax' === $job['content_type'] ? sanitize_key( $job['custom_taxonomy'] ) : sanitize_key( $job['content_type'] );
        if ( ! taxonomy_exists( $taxonomy ) ) {
            return new WP_Error( 'qiim_bad_tax', 'Taxonomy does not exist.' );
        }

        $term_id = 0;
        if ( ! empty( $mapped['id'] ) ) {
            $term = get_term( absint( $mapped['id'] ), $taxonomy );
            if ( $term && ! is_wp_error( $term ) ) {
                $term_id = (int) $term->term_id;
            }
        }

        if ( 0 === $term_id && ! empty( $mapped['slug'] ) ) {
            $term = get_term_by( 'slug', sanitize_title( $mapped['slug'] ), $taxonomy );
            if ( $term && ! is_wp_error( $term ) ) {
                $term_id = (int) $term->term_id;
            }
        }

        if ( 0 === $term_id && ! empty( $mapped['title'] ) ) {
            $term = get_term_by( 'name', sanitize_text_field( $mapped['title'] ), $taxonomy );
            if ( $term && ! is_wp_error( $term ) ) {
                $term_id = (int) $term->term_id;
            }
        }

        if ( 'update_only' === $job['import_mode'] && 0 === $term_id ) {
            return array( 'status' => 'skipped' );
        }

        if ( 'create_only' === $job['import_mode'] && $term_id > 0 ) {
            return array( 'status' => 'skipped' );
        }

        $args = array();
        if ( isset( $mapped['slug'] ) ) {
            $args['slug'] = sanitize_title( $mapped['slug'] );
        }
        if ( isset( $mapped['content'] ) ) {
            $args['description'] = wp_kses_post( $mapped['content'] );
        }

        $existing_term = $term_id > 0;

        if ( $existing_term ) {
            $result = wp_update_term( $term_id, $taxonomy, $args );
        } else {
            $name = sanitize_text_field( $mapped['title'] ?? '' );
            if ( '' === $name ) {
                return new WP_Error( 'qiim_term_name', 'Term name is required.' );
            }
            $result = wp_insert_term( $name, $taxonomy, $args );
        }

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $term_id = $term_id > 0 ? $term_id : (int) $result['term_id'];

        foreach ( $mapped as $target => $value ) {
            if ( 0 === strpos( $target, 'meta:' ) ) {
                $meta_key = sanitize_key( substr( $target, 5 ) );
                if ( '' !== $meta_key ) {
                    update_term_meta( $term_id, $meta_key, sanitize_text_field( $value ) );
                }
                continue;
            }

            if ( in_array( $target, array( 'focus_keyword', 'secondary_keyword', 'longtail_keyword', 'seo_title', 'meta_description', 'og_title', 'og_description', 'twitter_title', 'twitter_description', 'robots', 'sitemap' ), true ) ) {
                update_term_meta( $term_id, '_quickseo_' . sanitize_key( $target ), sanitize_text_field( $value ) );
            }
        }

        return array( 'status' => $existing_term ? 'updated' : 'created' );
    }

    private function assign_featured_image_from_url( $post_id, $url ) {
        $url = esc_url_raw( $url );
        if ( '' === $url ) {
            return;
        }

        $attachment_id = attachment_url_to_postid( $url );
        if ( $attachment_id > 0 ) {
            set_post_thumbnail( $post_id, $attachment_id );
        }
    }

    private function read_csv_preview( $file, $delimiter, $has_header ) {
        if ( ! file_exists( $file ) ) {
            return new WP_Error( 'qiim_file_missing', 'CSV file not found.' );
        }

        $csv = new SplFileObject( $file, 'r' );
        $csv->setFlags( SplFileObject::READ_CSV | SplFileObject::SKIP_EMPTY );
        $csv->setCsvControl( $delimiter );

        $row_count  = 0;
        $headers    = array();
        $sample     = array();

        foreach ( $csv as $row ) {
            if ( ! is_array( $row ) || ( 1 === count( $row ) && null === $row[0] ) ) {
                continue;
            }

            if ( 0 === $row_count ) {
                if ( $has_header ) {
                    $headers = array_map(
                        static function( $val ) {
                            return sanitize_text_field( trim( (string) $val ) );
                        },
                        $row
                    );
                } else {
                    $headers = array();
                    foreach ( $row as $idx => $unused ) {
                        $headers[] = 'column_' . ( $idx + 1 );
                    }
                    $sample[] = $row;
                }
            } else {
                if ( count( $sample ) < 5 ) {
                    $sample[] = $row;
                }
            }

            $row_count++;
        }

        if ( empty( $headers ) ) {
            return new WP_Error( 'qiim_empty_csv', 'CSV header row is empty.' );
        }

        $data_rows = $has_header ? max( 0, $row_count - 1 ) : $row_count;

        return array(
            'headers'     => $headers,
            'sample_rows' => $sample,
            'row_count'   => $data_rows,
        );
    }

    private function cleanup_upload( $upload_id ) {
        if ( '' === $upload_id ) {
            return;
        }

        $uploads = get_option( self::UPLOADS_OPTION, array() );
        if ( ! isset( $uploads[ $upload_id ] ) ) {
            return;
        }

        $file = $uploads[ $upload_id ]['file'] ?? '';
        qiim_safe_unlink( $file );

        unset( $uploads[ $upload_id ] );
        update_option( self::UPLOADS_OPTION, $uploads, false );
    }

    private function job_response( $job ) {
        $total      = max( 1, (int) $job['row_count'] );
        $processed  = (int) $job['offset'];
        $percentage = min( 100, (int) floor( ( $processed / $total ) * 100 ) );

        return array(
            'id'         => $job['id'],
            'status'     => $job['status'],
            'row_count'  => (int) $job['row_count'],
            'processed'  => $processed,
            'success'    => (int) $job['success'],
            'created'    => (int) ( $job['created'] ?? 0 ),
            'updated'    => (int) ( $job['updated'] ?? 0 ),
            'skipped'    => (int) ( $job['skipped'] ?? 0 ),
            'failed'     => (int) $job['failed'],
            'percentage' => $percentage,
            'failed_rows'=> array_slice( (array) $job['failed_rows'], -20 ),
            'memory'     => qiim_get_memory_snapshot(),
        );
    }
}
