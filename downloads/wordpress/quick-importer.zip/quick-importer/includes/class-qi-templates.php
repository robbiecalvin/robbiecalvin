<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QIIM_Templates {
    const OPTION_KEY = 'qiim_templates';

    public function all() {
        $templates = get_option( self::OPTION_KEY, array( 'import' => array(), 'export' => array() ) );
        if ( ! is_array( $templates ) ) {
            $templates = array( 'import' => array(), 'export' => array() );
        }

        if ( empty( $templates['import'] ) || ! is_array( $templates['import'] ) ) {
            $templates['import'] = array();
        }

        if ( empty( $templates['export'] ) || ! is_array( $templates['export'] ) ) {
            $templates['export'] = array();
        }

        return $templates;
    }

    public function save_import( $name, $payload ) {
        $templates                     = $this->all();
        $templates['import'][ $name ]  = $payload;
        update_option( self::OPTION_KEY, $templates, false );
    }

    public function save_export( $name, $payload ) {
        $templates                     = $this->all();
        $templates['export'][ $name ]  = $payload;
        update_option( self::OPTION_KEY, $templates, false );
    }

    public function remove( $group, $name ) {
        $templates = $this->all();
        if ( isset( $templates[ $group ][ $name ] ) ) {
            unset( $templates[ $group ][ $name ] );
            update_option( self::OPTION_KEY, $templates, false );
        }
    }
}
