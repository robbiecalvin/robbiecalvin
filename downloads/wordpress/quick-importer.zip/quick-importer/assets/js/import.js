(function ($) {
  'use strict';

  function renderStatus(container, data) {
    container.find('.qiim-status-text').text(data.status || 'running');
    container.find('.qiim-progress-bar').css('width', (data.percentage || 0) + '%');
    container.find('.qiim-progress-label').text((data.percentage || 0) + '%');
    container.find('.qiim-progress-counts').text(
      'Processed ' + (data.processed || 0) + ' / ' + (data.row_count || 0) +
      ' | Created: ' + (data.created || 0) +
      ' | Updated: ' + (data.updated || 0) +
      ' | Skipped: ' + (data.skipped || 0) +
      ' | Failed: ' + (data.failed || 0)
    );

    var failed = container.find('.qiim-failed-rows');
    if (Array.isArray(data.failed_rows) && data.failed_rows.length > 0) {
      var html = '<strong>Failed Rows</strong><ul>';
      data.failed_rows.forEach(function (row) {
        html += '<li>Line ' + row.line + ': ' + row.reason + '</li>';
      });
      html += '</ul>';
      failed.html(html).show();
    }
  }

  function processJob(container, jobId) {
    $.post(qiimImport.ajaxUrl, {
      action: 'qiim_process_import',
      nonce: qiimImport.nonce,
      job_id: jobId
    }).done(function (res) {
      if (!res || !res.success) {
        return;
      }

      var data = res.data || {};
      renderStatus(container, data);

      if (data.status !== 'done') {
        window.setTimeout(function () {
          processJob(container, jobId);
        }, 250);
      }
    });
  }

  $(document).on('click', '.qiim-start-import', function (event) {
    event.preventDefault();
    var container = $('#qiim-import-progress');
    var jobId = container.data('job-id');
    if (!jobId) {
      return;
    }

    $(this).prop('disabled', true).text('Running...');
    processJob(container, jobId);
  });
})(jQuery);
