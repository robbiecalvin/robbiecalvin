(function () {
  'use strict';

  document.addEventListener('change', function (event) {
    if (!event.target || event.target.id !== 'qiim_export_type') {
      return;
    }

    var value = event.target.value;
    var fieldGrid = document.querySelector('.qiim-field-grid');
    if (!fieldGrid) {
      return;
    }

    var labels = fieldGrid.querySelectorAll('label');
    labels.forEach(function (label) {
      var input = label.querySelector('input[type="checkbox"]');
      if (!input) {
        return;
      }

      var isProductOnly = [
        'sku',
        'regular_price',
        'sale_price',
        'stock_quantity',
        'stock_status',
        'product_type',
        'weight',
        'dimensions',
        'attributes',
        'variations',
        'product_visibility',
        'featured',
        'downloadable_virtual'
      ].indexOf(input.value) !== -1;

      if (isProductOnly) {
        label.style.display = value === 'product' ? '' : 'none';
      }
    });
  });
})();
