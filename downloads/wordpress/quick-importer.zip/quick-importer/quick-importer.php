<?php
/**
 * Plugin Name: Quick Importer
 * Plugin URI: https://quickwoo.pro
 * Description: High-performance CSV importer/exporter for posts, pages, WooCommerce products, taxonomies, and custom fields.
 * Version: 1.0.0
 * Author: QuickWoo by Robbie Calvin
 * Author URI: https://quickwoo.pro
 * License: GPL-2.0-or-later
 * Text Domain: quick-importer
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/quick-core/bootstrap.php';
}

define( 'QIIM_VERSION', '1.0.0' );
define( 'QIIM_FILE', __FILE__ );
define( 'QIIM_DIR', plugin_dir_path( __FILE__ ) );
define( 'QIIM_URL', plugin_dir_url( __FILE__ ) );
define( 'QIIM_SLUG', 'quick-importer' );

require_once QIIM_DIR . 'includes/helpers.php';
require_once QIIM_DIR . 'includes/class-qi-activator.php';
require_once QIIM_DIR . 'includes/class-qi-logs.php';
require_once QIIM_DIR . 'includes/class-qi-settings.php';
require_once QIIM_DIR . 'includes/class-qi-templates.php';
require_once QIIM_DIR . 'includes/class-qi-taxonomies.php';
require_once QIIM_DIR . 'includes/class-qi-products.php';
require_once QIIM_DIR . 'includes/class-qi-export.php';
require_once QIIM_DIR . 'includes/class-qi-import.php';
require_once QIIM_DIR . 'includes/class-qi-admin.php';

register_activation_hook( QIIM_FILE, array( 'QIIM_Activator', 'activate' ) );

function qiim_bootstrap() {
    $logs      = new QIIM_Logs();
    $settings  = new QIIM_Settings();
    $templates = new QIIM_Templates();
    $taxes     = new QIIM_Taxonomies( $settings );
    $products  = new QIIM_Products( $settings, $taxes );
    $exporter  = new QIIM_Export( $settings, $logs );
    $importer  = new QIIM_Import( $settings, $logs, $templates, $taxes, $products );

    $admin = new QIIM_Admin( $settings, $logs, $templates, $importer, $exporter );
    $admin->hooks();

    $importer->hooks();
    $exporter->hooks();
}
add_action( 'plugins_loaded', 'qiim_bootstrap' );

if ( ! function_exists( 'qwoo_quick_importer_license_bootstrap' ) ) {
    function qwoo_quick_importer_license_bootstrap() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu', 'qwoo_quick_importer_license_menu' );
        add_action( 'admin_post_qwoo_quick_importer_activate_license', 'qwoo_quick_importer_license_handle_activate' );
        add_action( 'admin_post_qwoo_quick_importer_deactivate_license', 'qwoo_quick_importer_license_handle_deactivate' );
    }
    add_action( 'plugins_loaded', 'qwoo_quick_importer_license_bootstrap', 30 );

    function qwoo_quick_importer_license_option_key() {
        return 'qwoo_quick_importer_license';
    }

    function qwoo_quick_importer_license_product_scope() {
        return array( 'quick-importer' );
    }

    function qwoo_quick_importer_license_get_data() {
        $defaults = array(
            'license_key' => '',
            'license_status' => 'inactive',
            'license_message' => '',
        );

        $saved = get_option( qwoo_quick_importer_license_option_key(), array() );
        $saved = is_array( $saved ) ? $saved : array();

        return wp_parse_args( $saved, $defaults );
    }

    function qwoo_quick_importer_license_save_data( $data ) {
        $data = is_array( $data ) ? $data : array();

        $clean = array(
            'license_key' => sanitize_text_field( (string) ( $data['license_key'] ?? '' ) ),
            'license_status' => sanitize_key( (string) ( $data['license_status'] ?? 'inactive' ) ),
            'license_message' => sanitize_text_field( (string) ( $data['license_message'] ?? '' ) ),
        );

        update_option( qwoo_quick_importer_license_option_key(), $clean, false );
        return $clean;
    }

    function qwoo_quick_importer_license_menu() {
        add_options_page(
            'Limporter License',
            'Limporter License',
            'manage_options',
            'qwoo-quick-importer-license',
            'qwoo_quick_importer_license_render_page'
        );
    }

    function qwoo_quick_importer_license_render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = qwoo_quick_importer_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );

        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $status = qlic_get_license_status_for_key_products( $license_key, qwoo_quick_importer_license_product_scope() );
            if ( is_array( $status ) ) {
                $data['license_status'] = sanitize_key( (string) ( $status['status'] ?? $data['license_status'] ) );
                $data['license_message'] = sanitize_text_field( (string) ( $status['message'] ?? $data['license_message'] ) );
                if ( ! empty( $status['valid'] ) && ! empty( $status['domain_active'] ) ) {
                    $data['license_status'] = 'active';
                }
                qwoo_quick_importer_license_save_data( $data );
            }
        }

        $notice = isset( $_GET['qwoo_license_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qwoo_license_notice'] ) ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Limporter License', 'quick-importer' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-importer' ), (string) ( $data['license_status'] ?? 'inactive' ) ) ); ?></p>
            <?php if ( ! empty( $data['license_message'] ) ) : ?>
                <p><?php echo esc_html( (string) $data['license_message'] ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_importer_activate_license" />
                <?php wp_nonce_field( 'qwoo_quick_importer_activate_license', 'qwoo_quick_importer_activate_license_nonce' ); ?>
                <p>
                    <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( (string) ( $data['license_key'] ?? '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button type="submit" class="button button-primary"><?php echo esc_html__( 'Activate License', 'quick-importer' ); ?></button>
                </p>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_importer_deactivate_license" />
                <?php wp_nonce_field( 'qwoo_quick_importer_deactivate_license', 'qwoo_quick_importer_deactivate_license_nonce' ); ?>
                <p><button type="submit" class="button"><?php echo esc_html__( 'Deactivate License', 'quick-importer' ); ?></button></p>
            </form>
        </div>
        <?php
    }

    function qwoo_quick_importer_license_redirect( $message ) {
        $url = add_query_arg(
            array(
                'page' => 'qwoo-quick-importer-license',
                'qwoo_license_notice' => rawurlencode( (string) $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    function qwoo_quick_importer_license_handle_activate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-importer' ) );
        }

        check_admin_referer( 'qwoo_quick_importer_activate_license', 'qwoo_quick_importer_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        if ( '' === $license_key ) {
            qwoo_quick_importer_license_save_data(
                array(
                    'license_key' => '',
                    'license_status' => 'inactive',
                    'license_message' => 'License key is required.',
                )
            );
            qwoo_quick_importer_license_redirect( 'License key is required.' );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            qwoo_quick_importer_license_save_data(
                array(
                    'license_key' => $license_key,
                    'license_status' => 'invalid',
                    'license_message' => 'Quick License plugin is required for activation.',
                )
            );
            qwoo_quick_importer_license_redirect( 'Quick License plugin is required for activation.' );
        }

        $result = qlic_activate_license_key_for_products( $license_key, qwoo_quick_importer_license_product_scope() );
        $data = array(
            'license_key' => $license_key,
            'license_status' => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'license_message' => sanitize_text_field( (string) ( $result['message'] ?? 'License validation failed.' ) ),
        );
        if ( ! empty( $result['valid'] ) ) {
            $data['license_status'] = 'active';
        }

        qwoo_quick_importer_license_save_data( $data );
        qwoo_quick_importer_license_redirect( (string) $data['license_message'] );
    }

    function qwoo_quick_importer_license_handle_deactivate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-importer' ) );
        }

        check_admin_referer( 'qwoo_quick_importer_deactivate_license', 'qwoo_quick_importer_deactivate_license_nonce' );

        $data = qwoo_quick_importer_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );
        $message = 'License deactivated.';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products( $license_key, qwoo_quick_importer_license_product_scope() );
            if ( is_array( $result ) && ! empty( $result['message'] ) ) {
                $message = sanitize_text_field( (string) $result['message'] );
            }
        }

        qwoo_quick_importer_license_save_data(
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => $message,
            )
        );

        qwoo_quick_importer_license_redirect( $message );
    }
}
