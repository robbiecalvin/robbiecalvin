<?php

if (!defined('ABSPATH')) {
    exit;
}

class QSIT_Optimizer
{
    public static function init(): void
    {
        add_action('init', [self::class, 'apply_core_toggles'], 20);
        add_filter('heartbeat_settings', [self::class, 'filter_heartbeat_settings']);
        add_filter('script_loader_src', [self::class, 'remove_query_strings'], 20, 1);
        add_filter('style_loader_src', [self::class, 'remove_query_strings'], 20, 1);
        add_filter('script_loader_tag', [self::class, 'maybe_defer_script'], 20, 3);
        add_filter('script_loader_tag', [self::class, 'maybe_minify_script_tag'], 25, 3);
        add_filter('style_loader_tag', [self::class, 'maybe_minify_style_tag'], 25, 4);
        add_filter('the_content', [self::class, 'maybe_lazyload_images'], 20);
        add_action('wp_head', [self::class, 'print_preload_assets'], 1);
    }

    public static function apply_core_toggles(): void
    {
        if (qsit_is_safe_mode_enabled()) {
            return;
        }

        $settings = qsit_get_settings();

        if (!empty($settings['disable_emojis'])) {
            remove_action('wp_head', 'print_emoji_detection_script', 7);
            remove_action('admin_print_scripts', 'print_emoji_detection_script');
            remove_action('wp_print_styles', 'print_emoji_styles');
            remove_action('admin_print_styles', 'print_emoji_styles');
            remove_filter('the_content_feed', 'wp_staticize_emoji');
            remove_filter('comment_text_rss', 'wp_staticize_emoji');
            remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
            add_filter('emoji_svg_url', '__return_false');
        }

        if (!empty($settings['disable_embeds'])) {
            remove_action('wp_head', 'wp_oembed_add_discovery_links');
            remove_action('wp_head', 'wp_oembed_add_host_js');
            remove_filter('oembed_dataparse', 'wp_filter_oembed_result', 10);
            add_filter('embed_oembed_discover', '__return_false');
            remove_action('rest_api_init', 'wp_oembed_register_route');
            add_filter('rewrite_rules_array', static function ($rules) {
                foreach ($rules as $rule => $rewrite) {
                    if (strpos($rule, 'embed=true') !== false) {
                        unset($rules[$rule]);
                    }
                }
                return $rules;
            });
        }
    }

    public static function filter_heartbeat_settings(array $settings): array
    {
        if (qsit_is_safe_mode_enabled()) {
            return $settings;
        }

        $opts = qsit_get_settings();

        if (is_admin()) {
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if ($screen && $screen->base === 'post') {
                $settings['interval'] = max(15, (int) $opts['heartbeat_editor']);
            } else {
                $settings['interval'] = max(15, (int) $opts['heartbeat_admin']);
            }
        } else {
            $settings['interval'] = max(15, (int) $opts['heartbeat_front']);
        }

        return $settings;
    }

    public static function remove_query_strings(string $src): string
    {
        if (qsit_is_safe_mode_enabled()) {
            return $src;
        }

        $opts = qsit_get_settings();
        if (empty($opts['remove_asset_query_strings'])) {
            return $src;
        }

        $parts = wp_parse_url($src);
        if (!is_array($parts) || empty($parts['path'])) {
            return $src;
        }

        return (string) preg_replace('/\?.*/', '', $src);
    }

    public static function maybe_defer_script(string $tag, string $handle, string $src): string
    {
        if (is_admin() || qsit_is_safe_mode_enabled()) {
            return $tag;
        }

        $opts = qsit_get_settings();
        if (empty($opts['defer_js'])) {
            return $tag;
        }

        $exclude = qsit_normalize_lines((string) $opts['defer_excludes']);
        foreach ($exclude as $item) {
            if ($item === '') {
                continue;
            }

            if (stripos($handle, $item) !== false || stripos($src, $item) !== false) {
                return $tag;
            }
        }

        if (strpos($tag, ' defer') !== false || strpos($tag, ' type="module"') !== false) {
            return $tag;
        }

        return str_replace('<script ', '<script defer ', $tag);
    }

    public static function maybe_minify_script_tag(string $tag, string $handle, string $src): string
    {
        if (qsit_is_safe_mode_enabled()) {
            return $tag;
        }

        $opts = qsit_get_settings();
        if (empty($opts['minify_assets'])) {
            return $tag;
        }

        $exclude = qsit_normalize_lines((string) $opts['minify_excludes']);
        foreach ($exclude as $item) {
            if ($item !== '' && (stripos($handle, $item) !== false || stripos($src, $item) !== false)) {
                return $tag;
            }
        }

        if (stripos($tag, '<script') === false || stripos($tag, 'src=') !== false) {
            return $tag;
        }

        if (!preg_match('#<script[^>]*>(.*?)</script>#is', $tag, $matches)) {
            return $tag;
        }

        $inline = $matches[1];
        $minified = self::minify_js_inline($inline);
        return str_replace($inline, $minified, $tag);
    }

    public static function maybe_minify_style_tag(string $tag, string $handle, string $href, string $media): string
    {
        if (qsit_is_safe_mode_enabled()) {
            return $tag;
        }

        $opts = qsit_get_settings();
        if (empty($opts['minify_assets'])) {
            return $tag;
        }

        $exclude = qsit_normalize_lines((string) $opts['minify_excludes']);
        foreach ($exclude as $item) {
            if ($item !== '' && (stripos($handle, $item) !== false || stripos($href, $item) !== false)) {
                return $tag;
            }
        }

        if (stripos($tag, '<style') === false || stripos($tag, 'href=') !== false) {
            return $tag;
        }

        if (!preg_match('#<style[^>]*>(.*?)</style>#is', $tag, $matches)) {
            return $tag;
        }

        $inline = $matches[1];
        $minified = self::minify_css_inline($inline);
        return str_replace($inline, $minified, $tag);
    }

    private static function minify_js_inline(string $js): string
    {
        if (strpos($js, '/*!') !== false) {
            return $js;
        }

        $js = preg_replace('#^\s*//.*$#m', '', $js);
        $js = preg_replace('#/\*[^!][\s\S]*?\*/#', '', $js);
        if (!is_string($js)) {
            return '';
        }

        $js = preg_replace('/\s+/', ' ', $js);
        if (!is_string($js)) {
            return '';
        }

        return trim($js);
    }

    private static function minify_css_inline(string $css): string
    {
        if (strpos($css, '/*!') !== false) {
            return $css;
        }

        $css = preg_replace('#/\*[^!][\s\S]*?\*/#', '', $css);
        if (!is_string($css)) {
            return '';
        }

        $css = preg_replace('/\s+/', ' ', $css);
        if (!is_string($css)) {
            return '';
        }

        $css = str_replace(['; ', ': ', ' {', '{ ', ', ', '} '], [';', ':', '{', '{', ',', '}'], $css);
        return trim($css);
    }

    public static function maybe_lazyload_images(string $content): string
    {
        if (is_admin() || qsit_is_safe_mode_enabled()) {
            return $content;
        }

        $opts = qsit_get_settings();
        if (empty($opts['lazyload_images'])) {
            return $content;
        }

        return preg_replace('/<img(?![^>]*loading=)([^>]+?)>/i', '<img loading="lazy"$1>', $content) ?: $content;
    }

    public static function print_preload_assets(): void
    {
        if (is_admin() || qsit_is_safe_mode_enabled()) {
            return;
        }

        $opts = qsit_get_settings();
        $assets = qsit_normalize_lines((string) $opts['preload_assets']);
        if (empty($assets)) {
            return;
        }

        foreach ($assets as $url) {
            $url = esc_url($url);
            if ($url === '') {
                continue;
            }

            $as = 'fetch';
            if (preg_match('/\.css($|\?)/i', $url)) {
                $as = 'style';
            } elseif (preg_match('/\.js($|\?)/i', $url)) {
                $as = 'script';
            } elseif (preg_match('/\.(woff2?|ttf|otf)($|\?)/i', $url)) {
                $as = 'font';
            } elseif (preg_match('/\.(png|jpe?g|webp|avif|gif|svg)($|\?)/i', $url)) {
                $as = 'image';
            }

            echo '<link rel="preload" href="' . esc_attr($url) . '" as="' . esc_attr($as) . '" crossorigin />' . "\n";
        }
    }
}
