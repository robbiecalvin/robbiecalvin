<?php

if (!defined('ABSPATH')) {
    exit;
}

class QSIT_Dropin
{
    public static function init(): void
    {
        add_action('admin_notices', [self::class, 'wp_cache_notice']);
    }

    public static function install_dropin(): bool
    {
        $source = QUICK_SITE_DIR . 'dropins/advanced-cache.php';
        $target = trailingslashit(WP_CONTENT_DIR) . 'advanced-cache.php';

        if (!file_exists($source)) {
            return false;
        }

        $content = @file_get_contents($source);
        if ($content === false) {
            return false;
        }

        return qsit_atomic_write_file($target, $content);
    }

    public static function is_dropin_installed(): bool
    {
        $target = trailingslashit(WP_CONTENT_DIR) . 'advanced-cache.php';
        if (!file_exists($target)) {
            return false;
        }

        $content = @file_get_contents($target);
        if ($content === false) {
            return false;
        }

        return strpos($content, 'Quick Site advanced-cache drop-in') !== false;
    }

    public static function wp_cache_notice(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $screen = get_current_screen();
        if (!$screen || strpos($screen->id, 'quick-site') === false) {
            return;
        }

        if (defined('WP_CACHE') && WP_CACHE) {
            return;
        }

        echo '<div class="notice notice-warning"><p><strong>Quick Site:</strong> Define <code>WP_CACHE</code> as <code>true</code> in <code>wp-config.php</code> to enable earliest cache serving via drop-in. Fallback output-buffer caching still works without it.</p></div>';
    }
}
