<?php

if (!defined('ABSPATH')) {
    exit;
}

class QSIT_Cache
{
    private static string $cacheFile = '';
    private static bool $buffering = false;

    public static function init(): void
    {
        add_action('template_redirect', [self::class, 'maybe_serve_or_start_buffer'], 0);
        add_action('shutdown', [self::class, 'maybe_store_buffer'], 0);

        add_action('save_post', [self::class, 'purge_related_on_post_save'], 20, 3);
        add_action('delete_post', [self::class, 'purge_related_on_post_delete'], 20, 1);
        add_action('transition_comment_status', [self::class, 'purge_on_comment_transition'], 20, 3);
    }

    public static function maybe_serve_or_start_buffer(): void
    {
        if (!self::is_cacheable_request()) {
            return;
        }

        qsit_ensure_cache_dirs();

        $cacheFile = self::get_cache_file_for_current_request();
        self::$cacheFile = $cacheFile;
        $settings = qsit_get_settings();

        if (self::serve_if_fresh($cacheFile, (int) $settings['cache_ttl'])) {
            return;
        }

        qsit_increment_stat('misses');
        self::$buffering = true;
        ob_start();
    }

    public static function maybe_store_buffer(): void
    {
        if (!self::$buffering || self::$cacheFile === '') {
            return;
        }

        if (!ob_get_level()) {
            return;
        }

        $output = ob_get_contents();
        if ($output === false) {
            ob_end_flush();
            return;
        }

        if (!self::should_cache_current_response($output)) {
            ob_end_flush();
            return;
        }

        self::store_cache_file(self::$cacheFile, $output);
        ob_end_flush();
    }

    private static function should_cache_current_response(string $output): bool
    {
        if (is_admin() || is_404()) {
            return false;
        }

        if (http_response_code() !== 200) {
            return false;
        }

        if ($output === '') {
            return false;
        }

        $headers = headers_list();
        foreach ($headers as $header) {
            if (stripos($header, 'content-type:') === 0 && stripos($header, 'text/html') === false) {
                return false;
            }
        }

        return true;
    }

    private static function serve_if_fresh(string $cacheFile, int $ttl): bool
    {
        if (!file_exists($cacheFile)) {
            return false;
        }

        $mtime = @filemtime($cacheFile);
        if ($mtime === false || (time() - $mtime) > $ttl) {
            @unlink($cacheFile);
            return false;
        }

        $contents = @file_get_contents($cacheFile);
        if ($contents === false) {
            return false;
        }

        self::send_cache_headers($mtime, true);
        qsit_increment_stat('hits');
        echo $contents;
        exit;
    }

    private static function store_cache_file(string $cacheFile, string $output): void
    {
        $lockFile = $cacheFile . '.lock';
        $lock = @fopen($lockFile, 'c+');

        if (!$lock) {
            return;
        }

        try {
            if (!flock($lock, LOCK_EX)) {
                fclose($lock);
                return;
            }

            if (qsit_atomic_write_file($cacheFile, $output)) {
                self::send_cache_headers(time(), false);
            }

            flock($lock, LOCK_UN);
        } finally {
            fclose($lock);
        }
    }

    private static function send_cache_headers(int $timestamp, bool $hit): void
    {
        $settings = qsit_get_settings();
        if (empty($settings['add_cache_headers'])) {
            return;
        }

        if (headers_sent()) {
            return;
        }

        $ttl = (int) $settings['cache_ttl'];
        header('X-Quick-Site-Cache: ' . ($hit ? 'HIT' : 'MISS'));
        header('Cache-Control: public, max-age=' . $ttl);
        header('Expires: ' . gmdate('D, d M Y H:i:s', $timestamp + $ttl) . ' GMT');

        if (!empty($settings['disable_etag_header'])) {
            header_remove('ETag');
        }
    }

    public static function is_cacheable_request(): bool
    {
        $settings = qsit_get_settings();

        if (qsit_is_safe_mode_enabled()) {
            return false;
        }

        if (empty($settings['page_cache_enabled'])) {
            return false;
        }

        if (is_admin() || is_user_logged_in()) {
            return false;
        }

        if (defined('REST_REQUEST') && REST_REQUEST) {
            return false;
        }

        if (is_preview() || is_feed()) {
            return false;
        }

        if (!empty($_POST) || strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET') {
            return false;
        }

        if (is_search() && empty($settings['cache_search'])) {
            return false;
        }

        if (function_exists('is_cart') && is_cart()) {
            return false;
        }

        if (function_exists('is_checkout') && is_checkout()) {
            return false;
        }

        if (function_exists('is_account_page') && is_account_page()) {
            return false;
        }

        $uri = self::current_request_uri_path();

        foreach (qsit_normalize_lines((string) $settings['exclude_urls']) as $pattern) {
            if ($pattern !== '' && strpos($uri, $pattern) !== false) {
                return false;
            }
        }

        $cookies = array_keys($_COOKIE);
        foreach (qsit_normalize_lines((string) $settings['exclude_cookies']) as $cookiePattern) {
            foreach ($cookies as $cookieName) {
                if ($cookiePattern !== '' && strpos($cookieName, $cookiePattern) !== false) {
                    return false;
                }
            }
        }

        $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
        foreach (qsit_normalize_lines((string) $settings['exclude_user_agents']) as $uaPattern) {
            if ($uaPattern !== '' && stripos($ua, $uaPattern) !== false) {
                return false;
            }
        }

        return true;
    }

    private static function current_request_uri_path(): string
    {
        $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
        $parts = wp_parse_url($uri);
        return isset($parts['path']) ? (string) $parts['path'] : '/';
    }

    public static function get_cache_file_for_current_request(): string
    {
        $normalized = self::build_normalized_request_cache_url();
        [$device, $lang] = self::get_variants();

        $hash = md5($normalized);
        $fileName = sprintf('%s--%s--%s.html', $hash, $device, $lang);

        return qsit_get_cache_pages_dir() . $fileName;
    }

    public static function build_normalized_request_cache_url(): string
    {
        $settings = qsit_get_settings();
        $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
        $parts = wp_parse_url($uri);
        $path = isset($parts['path']) ? (string) $parts['path'] : '/';

        $queryParams = [];
        if (!empty($parts['query'])) {
            parse_str((string) $parts['query'], $queryParams);
        }

        $whitelist = qsit_normalize_lines((string) $settings['query_whitelist']);
        $ignorePrefixes = qsit_normalize_lines((string) $settings['ignore_query_prefixes']);
        $kept = [];

        foreach ($queryParams as $key => $value) {
            $isAllowed = in_array($key, $whitelist, true);

            if (!$isAllowed) {
                foreach ($ignorePrefixes as $prefix) {
                    if ($prefix !== '' && strpos($key, $prefix) === 0) {
                        $isAllowed = false;
                        break;
                    }
                }
            }

            if ($isAllowed) {
                $kept[$key] = $value;
            }
        }

        ksort($kept);

        $base = home_url($path);
        if (!empty($kept)) {
            $base .= '?' . http_build_query($kept);
        }

        return $base;
    }

    private static function get_variants(): array
    {
        $settings = qsit_get_settings();

        $device = 'all';
        if (!empty($settings['split_device'])) {
            $ua = strtolower((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
            $device = preg_match('/mobile|iphone|android|ipad|tablet/', $ua) ? 'mobile' : 'desktop';
        }

        $lang = 'all';
        if (!empty($settings['split_language'])) {
            $lang = self::detect_language_variant();
        }

        return [$device, $lang];
    }

    private static function detect_language_variant(): string
    {
        $lang = '';

        if (function_exists('pll_current_language')) {
            $lang = (string) pll_current_language('slug');
        } elseif (defined('ICL_LANGUAGE_CODE')) {
            $lang = (string) ICL_LANGUAGE_CODE;
        }

        if ($lang === '') {
            $lang = apply_filters('qsit_current_language_variant', 'all');
        }

        $lang = sanitize_key($lang);
        return $lang !== '' ? $lang : 'all';
    }

    public static function purge_all(): bool
    {
        $dir = qsit_get_cache_pages_dir();
        if (!file_exists($dir)) {
            return true;
        }

        $ok = true;
        foreach (glob($dir . '*.html') ?: [] as $file) {
            if (!@unlink($file)) {
                $ok = false;
            }
        }

        qsit_debug_log('Cache purge: all');
        return $ok;
    }

    public static function purge_url(string $url): int
    {
        $url = trim($url);
        if ($url === '') {
            return 0;
        }

        $hash = md5($url);
        $pattern = qsit_get_cache_pages_dir() . $hash . '--*.html';

        $deleted = 0;
        foreach (glob($pattern) ?: [] as $file) {
            if (@unlink($file)) {
                $deleted++;
            }
        }

        if ($deleted > 0) {
            qsit_debug_log('Cache purge URL: ' . $url . ' deleted=' . $deleted);
        }

        return $deleted;
    }

    public static function purge_related_on_post_save(int $postId, WP_Post $post, bool $update): void
    {
        if (wp_is_post_autosave($postId) || wp_is_post_revision($postId)) {
            return;
        }

        if ($post->post_status !== 'publish' && $post->post_status !== 'private') {
            return;
        }

        self::purge_related_urls_for_post($postId);
    }

    public static function purge_related_on_post_delete(int $postId): void
    {
        self::purge_related_urls_for_post($postId);
    }

    private static function purge_related_urls_for_post(int $postId): void
    {
        $urls = [];

        $permalink = get_permalink($postId);
        if ($permalink) {
            $urls[] = $permalink;
        }

        $urls[] = home_url('/');

        if (get_option('show_on_front') === 'page') {
            $postsPage = (int) get_option('page_for_posts');
            if ($postsPage > 0) {
                $blogUrl = get_permalink($postsPage);
                if ($blogUrl) {
                    $urls[] = $blogUrl;
                }
            }
        }

        $postType = get_post_type($postId);

        $taxonomies = get_object_taxonomies((string) $postType, 'names');
        foreach ($taxonomies as $taxonomy) {
            $terms = get_the_terms($postId, $taxonomy);
            if (!is_array($terms)) {
                continue;
            }

            foreach ($terms as $term) {
                $termLink = get_term_link($term);
                if (!is_wp_error($termLink)) {
                    $urls[] = $termLink;
                }
            }
        }

        if ($postType === 'product') {
            $shopId = function_exists('wc_get_page_id') ? (int) wc_get_page_id('shop') : 0;
            if ($shopId > 0) {
                $shopUrl = get_permalink($shopId);
                if ($shopUrl) {
                    $urls[] = $shopUrl;
                }
            }

            $productCats = wp_get_post_terms($postId, 'product_cat');
            if (is_array($productCats)) {
                foreach ($productCats as $cat) {
                    $catLink = get_term_link($cat);
                    if (!is_wp_error($catLink)) {
                        $urls[] = $catLink;
                    }
                }
            }
        }

        $urls = array_unique(array_filter($urls));
        foreach ($urls as $url) {
            self::purge_url((string) $url);
        }
    }

    public static function purge_on_comment_transition(string $newStatus, string $oldStatus, WP_Comment $comment): void
    {
        if ($newStatus === $oldStatus) {
            return;
        }

        $settings = qsit_get_settings();
        if (empty($settings['purge_on_comment_change'])) {
            return;
        }

        $postId = (int) $comment->comment_post_ID;
        if ($postId > 0) {
            self::purge_related_urls_for_post($postId);
        }
    }

    public static function get_cache_size_bytes(): int
    {
        $total = 0;
        foreach (glob(qsit_get_cache_pages_dir() . '*.html') ?: [] as $file) {
            $size = @filesize($file);
            if ($size !== false) {
                $total += (int) $size;
            }
        }
        return $total;
    }
}
