<?php

if (!defined('ABSPATH')) {
    exit;
}

class QSIT_Admin
{
    private const MENU_SLUG = 'quick-site-dashboard';

    public static function init(): void
    {
        add_action('admin_menu', [self::class, 'register_menu']);
        add_action('admin_enqueue_scripts', [self::class, 'enqueue_assets']);

        add_action('admin_post_qs_purge_all', [self::class, 'handle_purge_all']);
        add_action('admin_post_qsit_purge_all', [self::class, 'handle_purge_all']);
        add_action('admin_post_qs_purge_url', [self::class, 'handle_purge_url']);
        add_action('admin_post_qsit_purge_url', [self::class, 'handle_purge_url']);
        add_action('admin_post_qs_install_dropin', [self::class, 'handle_install_dropin']);
        add_action('admin_post_qsit_install_dropin', [self::class, 'handle_install_dropin']);
        add_action('admin_post_qs_db_preview', [self::class, 'handle_db_preview']);
        add_action('admin_post_qsit_db_preview', [self::class, 'handle_db_preview']);
        add_action('admin_post_qs_db_cleanup', [self::class, 'handle_db_cleanup']);
        add_action('admin_post_qsit_db_cleanup', [self::class, 'handle_db_cleanup']);
        add_action('admin_post_qs_export_settings', [self::class, 'handle_export_settings']);
        add_action('admin_post_qsit_export_settings', [self::class, 'handle_export_settings']);
        add_action('admin_post_qs_import_settings', [self::class, 'handle_import_settings']);
        add_action('admin_post_qsit_import_settings', [self::class, 'handle_import_settings']);
    }

    public static function register_menu(): void
    {
        add_menu_page(
            'Quick Site',
            'Quick Site',
            'manage_options',
            self::MENU_SLUG,
            [self::class, 'render_dashboard_page'],
            'dashicons-performance',
            58
        );

        add_submenu_page(self::MENU_SLUG, 'Dashboard', 'Dashboard', 'manage_options', self::MENU_SLUG, [self::class, 'render_dashboard_page']);
        add_submenu_page(self::MENU_SLUG, 'Cache', 'Cache', 'manage_options', 'quick-site-cache', [self::class, 'render_cache_page']);
        add_submenu_page(self::MENU_SLUG, 'Optimization', 'Optimization', 'manage_options', 'quick-site-optimization', [self::class, 'render_optimization_page']);
        add_submenu_page(self::MENU_SLUG, 'Database', 'Database', 'manage_options', 'quick-site-database', [self::class, 'render_database_page']);
        add_submenu_page(self::MENU_SLUG, 'Settings', 'Settings', 'manage_options', 'quick-site-settings', [self::class, 'render_settings_page']);
        add_submenu_page(self::MENU_SLUG, 'Integrations', 'Integrations', 'manage_options', 'quick-site-integrations', ['QSIT_Integrations', 'render_page']);
    }

    public static function enqueue_assets(string $hook): void
    {
        if (strpos($hook, 'quick-site') === false) {
            return;
        }

        wp_enqueue_style('quick-site-admin', QUICK_SITE_URL . 'assets/css/admin.css', [], QUICK_SITE_VERSION);
        wp_enqueue_script('quick-site-admin', QUICK_SITE_URL . 'assets/js/admin.js', ['jquery'], QUICK_SITE_VERSION, true);
    }

    private static function ensure_capability(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions.');
        }
    }

    private static function render_header(string $title): void
    {
        settings_errors('quick_site_messages');
        echo '<div class="wrap quick-site-wrap">';
        echo '<h1>' . esc_html($title) . '</h1>';
    }

    private static function render_footer(): void
    {
        echo '</div>';
    }

    public static function render_dashboard_page(): void
    {
        self::ensure_capability();
        $settings = qsit_get_settings();
        $premium_enabled = qsit_is_premium_active();

        self::render_header('Quick Site Dashboard');

        $hitCount = qsit_get_stat('hits');
        $missCount = qsit_get_stat('misses');
        $cacheSize = size_format(QSIT_Cache::get_cache_size_bytes(), 2);

        echo '<div class="qs-grid">';
        echo '<div class="qs-card">';
        echo '<h2>Status</h2>';
        echo '<p><strong>Safe mode:</strong> ' . (qsit_is_safe_mode_enabled() ? 'Enabled' : 'Disabled') . '</p>';
        echo '<p><strong>Page cache:</strong> ' . (!empty($settings['page_cache_enabled']) ? 'Enabled' : 'Disabled') . '</p>';
        echo '<p><strong>Drop-in installed:</strong> ' . (QSIT_Dropin::is_dropin_installed() ? 'Yes' : 'No') . '</p>';
        echo '<p><strong>Cache TTL:</strong> ' . (int) $settings['cache_ttl'] . 's</p>';
        echo '<p><strong>Cache size:</strong> ' . esc_html($cacheSize) . '</p>';
        echo '<p><strong>Hits / Misses:</strong> ' . (int) $hitCount . ' / ' . (int) $missCount . '</p>';
        echo '</div>';

        echo '<div class="qs-card">';
        echo '<h2>Quick Actions</h2>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('qsit_purge_all');
        echo '<input type="hidden" name="action" value="qsit_purge_all" />';
        echo '<button class="button button-primary" type="submit">Purge All Cache</button>';
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('qsit_purge_url');
        echo '<input type="hidden" name="action" value="qsit_purge_url" />';
        echo '<p><label for="qs-purge-url">Purge single URL</label></p>';
        echo '<input type="url" class="regular-text" id="qs-purge-url" name="url" value="' . esc_attr(home_url('/')) . '" required />';
        echo '<p><button class="button" type="submit">Purge URL</button></p>';
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('qsit_install_dropin');
        echo '<input type="hidden" name="action" value="qsit_install_dropin" />';
        echo '<button class="button" type="submit">Install/Reinstall Drop-in</button>';
        echo '</form>';

        echo '</div>';

        echo '<div class="qs-card">';
        echo '<h2>Recommendations</h2>';
        if (! $premium_enabled) {
            echo '<p>This panel is available on premium.</p>';
        } else {
            echo '<ul class="qs-list">';
            echo '<li>Enable server-level gzip or Brotli in Nginx/Apache for transfer compression.</li>';
            echo '<li>Set <code>WP_CACHE</code> to <code>true</code> in <code>wp-config.php</code> for earliest cache serving.</li>';
            echo '<li>Use persistent object cache (Redis/Memcached) for dynamic workloads.</li>';
            echo '<li>Validate defer/minify on staging before enabling in production.</li>';
            echo '</ul>';
        }
        echo '</div>';

        echo '<div class="qs-card">';
        echo '<h2>Diagnostics</h2>';
        $diag = self::get_diagnostics();
        echo '<ul class="qs-list">';
        echo '<li><strong>Cache directory writable:</strong> ' . ($diag['cache_writable'] ? 'Yes' : 'No') . '</li>';
        echo '<li><strong>Caching conflicts:</strong> ' . esc_html($diag['conflicts']) . '</li>';
        echo '<li><strong>WooCommerce sensitive pages excluded:</strong> ' . ($diag['woo_excluded'] ? 'Yes' : 'No') . '</li>';
        echo '</ul>';
        echo '</div>';
        echo '</div>';

        self::render_footer();
    }

    public static function render_cache_page(): void
    {
        self::ensure_capability();
        $settings = qsit_get_settings();

        self::render_header('Quick Site Cache');
        echo '<form method="post" action="options.php">';
        settings_fields('qsit_settings_group');

        echo '<table class="form-table">';
        self::checkbox_row('Enable Page Cache', 'page_cache_enabled', $settings);
        self::number_row('Cache TTL (seconds)', 'cache_ttl', $settings, 60, 86400);
        self::checkbox_row('Cache Search Results', 'cache_search', $settings);
        self::checkbox_row('Split Cache by Device', 'split_device', $settings);
        self::checkbox_row('Split Cache by Language', 'split_language', $settings);
        self::textarea_row('Query String Whitelist (one per line)', 'query_whitelist', $settings);
        self::textarea_row('Ignore Query Prefixes (one per line)', 'ignore_query_prefixes', $settings);
        self::textarea_row('Exclude URL patterns (one per line)', 'exclude_urls', $settings);
        self::textarea_row('Exclude cookies (one per line)', 'exclude_cookies', $settings);
        self::textarea_row('Exclude user agents (one per line)', 'exclude_user_agents', $settings);
        self::checkbox_row('Add Cache Headers', 'add_cache_headers', $settings);
        self::checkbox_row('Disable ETag Header', 'disable_etag_header', $settings);
        self::checkbox_row('Purge On Comment Status Changes', 'purge_on_comment_change', $settings);
        echo '</table>';

        submit_button('Save Cache Settings');
        echo '</form>';
        self::render_footer();
    }

    public static function render_optimization_page(): void
    {
        self::ensure_capability();
        $settings = qsit_get_settings();
        $premium_enabled = qsit_is_premium_active();

        self::render_header('Quick Site Optimization');
        if (! $premium_enabled) {
            echo '<div class="notice notice-warning"><p>Optimization controls are available on premium.</p></div>';
        }
        echo '<form method="post" action="options.php">';
        settings_fields('qsit_settings_group');

        echo '<table class="form-table">';
        if (! $premium_enabled) {
            echo '<tr><td colspan="2">Upgrade to premium to configure optimization.</td></tr>';
        } else {
            self::checkbox_row('Disable Emojis', 'disable_emojis', $settings);
            self::checkbox_row('Disable Embeds', 'disable_embeds', $settings);
            self::number_row('Heartbeat Interval: Admin (seconds)', 'heartbeat_admin', $settings, 15, 300);
            self::number_row('Heartbeat Interval: Editor (seconds)', 'heartbeat_editor', $settings, 15, 300);
            self::number_row('Heartbeat Interval: Frontend (seconds)', 'heartbeat_front', $settings, 15, 300);
            self::checkbox_row('Remove Query Strings from Static Assets', 'remove_asset_query_strings', $settings);
            self::textarea_row('Preload Assets URLs (one per line)', 'preload_assets', $settings);
            self::checkbox_row('Lazy-load Images', 'lazyload_images', $settings);
            self::checkbox_row('Defer JavaScript', 'defer_js', $settings);
            self::textarea_row('Defer Excludes (handle/src fragment per line)', 'defer_excludes', $settings);
            self::checkbox_row('Minify Inline CSS/JS (conservative)', 'minify_assets', $settings);
            self::textarea_row('Minify Excludes (handle/src fragment per line)', 'minify_excludes', $settings);
        }
        echo '</table>';

        submit_button('Save Optimization Settings');
        echo '</form>';
        self::render_footer();
    }

    public static function render_database_page(): void
    {
        self::ensure_capability();
        $settings = qsit_get_settings();
        $preview = get_transient('qsit_db_preview_' . get_current_user_id());

        self::render_header('Quick Site Database');

        echo '<form method="post" action="options.php">';
        settings_fields('qsit_settings_group');
        echo '<table class="form-table">';
        self::checkbox_row('Enable Database Cleanup Tools', 'db_cleanup_enabled', $settings);
        self::number_row('Delete Revisions Older Than (days)', 'db_delete_revisions_days', $settings, 1, 3650);
        self::number_row('Delete Auto-Drafts Older Than (days)', 'db_delete_autodraft_days', $settings, 1, 3650);
        self::number_row('Delete Trash Posts Older Than (days)', 'db_delete_trash_days', $settings, 1, 3650);
        self::checkbox_row('Optimize Tables During Cleanup', 'db_optimize_tables', $settings);
        echo '</table>';
        submit_button('Save Database Settings');
        echo '</form>';

        echo '<h2>Cleanup Tools</h2>';
        echo '<p><strong>Last cleanup run:</strong> ' . esc_html(QSIT_DBTools::get_last_run_time() ?: 'Never') . '</p>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('qsit_db_preview');
        echo '<input type="hidden" name="action" value="qsit_db_preview" />';
        echo '<button class="button" type="submit">Preview Cleanup</button>';
        echo '</form>';

        if (is_array($preview)) {
            echo '<div class="qs-card">';
            echo '<h3>Preview Results</h3>';
            echo '<ul class="qs-list">';
            echo '<li>Expired transients: ' . (int) $preview['expired_transients'] . '</li>';
            echo '<li>Old revisions: ' . (int) $preview['old_revisions'] . '</li>';
            echo '<li>Old auto-drafts: ' . (int) $preview['old_autodrafts'] . '</li>';
            echo '<li>Old trash posts: ' . (int) $preview['old_trash_posts'] . '</li>';
            echo '<li>Tables eligible for optimization: ' . count($preview['tables']) . '</li>';
            echo '</ul>';
            echo '</div>';

            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'Run cleanup now? This action is irreversible.\');">';
            wp_nonce_field('qsit_db_cleanup');
            echo '<input type="hidden" name="action" value="qsit_db_cleanup" />';
            echo '<button class="button button-primary" type="submit">Run Cleanup</button>';
            echo '</form>';
        }

        self::render_footer();
    }

    public static function render_settings_page(): void
    {
        self::ensure_capability();
        $settings = qsit_get_settings();

        self::render_header('Quick Site Settings');

        echo '<form method="post" action="options.php">';
        settings_fields('qsit_settings_group');
        echo '<table class="form-table">';
        self::checkbox_row('Safe Mode (disable caching and optimizations)', 'safe_mode', $settings);
        self::checkbox_row('Enable Debug Log (when WP_DEBUG is true)', 'debug_log', $settings);
        self::checkbox_row('Enable Drop-in Management', 'dropin_enabled', $settings);
        echo '</table>';
        submit_button('Save General Settings');
        echo '</form>';

        echo '<h2>Export / Import</h2>';
        echo '<p>Export and import plugin settings as JSON.</p>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('qsit_export_settings');
        echo '<input type="hidden" name="action" value="qsit_export_settings" />';
        echo '<button class="button" type="submit">Export Settings JSON</button>';
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" enctype="multipart/form-data">';
        wp_nonce_field('qsit_import_settings');
        echo '<input type="hidden" name="action" value="qsit_import_settings" />';
        echo '<p><input type="file" name="qsit_import_file" accept="application/json" required /></p>';
        echo '<p><button class="button" type="submit">Import Settings JSON</button></p>';
        echo '</form>';

        self::render_footer();
    }

    private static function checkbox_row(string $label, string $key, array $settings): void
    {
        echo '<tr>';
        echo '<th scope="row">' . esc_html($label) . '</th>';
        echo '<td>';
        echo '<label><input type="checkbox" name="' . esc_attr(QUICK_SITE_OPTION_KEY . '[' . $key . ']') . '" value="1" ' . checked(!empty($settings[$key]), true, false) . ' /> Enabled</label>';
        echo '</td>';
        echo '</tr>';
    }

    private static function number_row(string $label, string $key, array $settings, int $min, int $max): void
    {
        echo '<tr>';
        echo '<th scope="row">' . esc_html($label) . '</th>';
        echo '<td>';
        echo '<input type="number" name="' . esc_attr(QUICK_SITE_OPTION_KEY . '[' . $key . ']') . '" value="' . esc_attr((string) $settings[$key]) . '" min="' . (int) $min . '" max="' . (int) $max . '" class="small-text" />';
        echo '</td>';
        echo '</tr>';
    }

    private static function textarea_row(string $label, string $key, array $settings): void
    {
        echo '<tr>';
        echo '<th scope="row">' . esc_html($label) . '</th>';
        echo '<td>';
        echo '<textarea name="' . esc_attr(QUICK_SITE_OPTION_KEY . '[' . $key . ']') . '" rows="5" cols="60" class="large-text code">' . esc_textarea((string) $settings[$key]) . '</textarea>';
        echo '</td>';
        echo '</tr>';
    }

    public static function handle_purge_all(): void
    {
        self::ensure_capability();
        check_admin_referer('qsit_purge_all');

        $ok = QSIT_Cache::purge_all();
        if (class_exists('QSIT_Integrations')) {
            QSIT_Integrations::emit_cache_event('purge_all');
        }
        self::add_notice($ok ? 'Cache purged successfully.' : 'Cache purge completed with errors.', $ok ? 'updated' : 'error');
        wp_safe_redirect(self::admin_page_url(self::MENU_SLUG));
        exit;
    }

    public static function handle_purge_url(): void
    {
        self::ensure_capability();
        check_admin_referer('qsit_purge_url');

        $url = isset($_POST['url']) ? esc_url_raw(wp_unslash($_POST['url'])) : '';
        $count = QSIT_Cache::purge_url($url);
        if (class_exists('QSIT_Integrations')) {
            QSIT_Integrations::emit_cache_event('purge_url', ['url' => $url, 'count' => (int) $count]);
        }
        self::add_notice('Purged variants: ' . $count, 'updated');
        wp_safe_redirect(self::admin_page_url(self::MENU_SLUG));
        exit;
    }

    public static function handle_install_dropin(): void
    {
        self::ensure_capability();
        check_admin_referer('qsit_install_dropin');

        $ok = QSIT_Dropin::install_dropin();
        self::add_notice($ok ? 'Drop-in installed successfully.' : 'Drop-in installation failed.', $ok ? 'updated' : 'error');
        wp_safe_redirect(self::admin_page_url(self::MENU_SLUG));
        exit;
    }

    public static function handle_db_preview(): void
    {
        self::ensure_capability();
        check_admin_referer('qsit_db_preview');

        $settings = qsit_get_settings();
        if (empty($settings['db_cleanup_enabled'])) {
            self::add_notice('Enable database cleanup tools first.', 'error');
            wp_safe_redirect(self::admin_page_url('quick-site-database'));
            exit;
        }

        $preview = QSIT_DBTools::preview_cleanup($settings);
        set_transient('qsit_db_preview_' . get_current_user_id(), $preview, MINUTE_IN_SECONDS * 10);
        self::add_notice('Database cleanup preview generated.', 'updated');
        wp_safe_redirect(self::admin_page_url('quick-site-database'));
        exit;
    }

    public static function handle_db_cleanup(): void
    {
        self::ensure_capability();
        check_admin_referer('qsit_db_cleanup');

        $settings = qsit_get_settings();
        if (empty($settings['db_cleanup_enabled'])) {
            self::add_notice('Enable database cleanup tools first.', 'error');
            wp_safe_redirect(self::admin_page_url('quick-site-database'));
            exit;
        }

        $report = QSIT_DBTools::run_cleanup($settings);
        delete_transient('qsit_db_preview_' . get_current_user_id());

        $msg = sprintf(
            'Cleanup done. Expired transients: %d, revisions: %d, auto-drafts: %d, trash posts: %d, optimized tables: %d.',
            (int) $report['expired_transients'],
            (int) $report['old_revisions'],
            (int) $report['old_autodrafts'],
            (int) $report['old_trash_posts'],
            (int) $report['optimized_tables']
        );

        if (!empty($report['errors'])) {
            $msg .= ' Errors: ' . implode(' | ', array_map('sanitize_text_field', $report['errors']));
        }

        self::add_notice($msg, empty($report['errors']) ? 'updated' : 'error');
        wp_safe_redirect(self::admin_page_url('quick-site-database'));
        exit;
    }

    public static function handle_export_settings(): void
    {
        self::ensure_capability();
        check_admin_referer('qsit_export_settings');

        $settings = qsit_get_settings();
        $json = wp_json_encode($settings, JSON_PRETTY_PRINT);
        if ($json === false) {
            self::add_notice('Failed to export settings.', 'error');
            wp_safe_redirect(self::admin_page_url('quick-site-settings'));
            exit;
        }

        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename=quick-site-settings-' . gmdate('Ymd-His') . '.json');
        echo $json;
        exit;
    }

    public static function handle_import_settings(): void
    {
        self::ensure_capability();
        check_admin_referer('qsit_import_settings');

        if (empty($_FILES['qsit_import_file']['tmp_name'])) {
            self::add_notice('No import file uploaded.', 'error');
            wp_safe_redirect(self::admin_page_url('quick-site-settings'));
            exit;
        }

        $tmp = isset($_FILES['qsit_import_file']['tmp_name']) ? (string) wp_unslash($_FILES['qsit_import_file']['tmp_name']) : '';
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            self::add_notice('Invalid uploaded file.', 'error');
            wp_safe_redirect(self::admin_page_url('quick-site-settings'));
            exit;
        }

        $raw = @file_get_contents($tmp);
        if ($raw === false) {
            self::add_notice('Could not read import file.', 'error');
            wp_safe_redirect(self::admin_page_url('quick-site-settings'));
            exit;
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            self::add_notice('Invalid JSON settings file.', 'error');
            wp_safe_redirect(self::admin_page_url('quick-site-settings'));
            exit;
        }

        $sanitized = QSIT_Settings::sanitize_settings($decoded);
        update_option(QUICK_SITE_OPTION_KEY, $sanitized, false);
        qsit_write_dropin_config();

        self::add_notice('Settings imported successfully.', 'updated');
        wp_safe_redirect(self::admin_page_url('quick-site-settings'));
        exit;
    }

    private static function add_notice(string $message, string $type = 'updated'): void
    {
        set_transient('qsit_admin_notice_' . get_current_user_id(), [
            'message' => $message,
            'type'    => $type,
        ], 60);
    }

    private static function admin_page_url(string $slug): string
    {
        return admin_url('admin.php?page=' . $slug);
    }

    private static function get_diagnostics(): array
    {
        $cacheWritable = qsit_ensure_cache_dirs() && is_writable(qsit_get_cache_base_dir());

        $conflicts = [];
        $activePlugins = (array) get_option('active_plugins', []);

        $needles = [
            'wp-super-cache',
            'w3-total-cache',
            'litespeed-cache',
            'wp-rocket',
            'autoptimize',
        ];

        foreach ($activePlugins as $pluginPath) {
            $pluginPath = strtolower((string) $pluginPath);
            foreach ($needles as $needle) {
                if (strpos($pluginPath, $needle) !== false) {
                    $conflicts[] = $pluginPath;
                    break;
                }
            }
        }

        $settings = qsit_get_settings();
        $exclude = strtolower((string) $settings['exclude_urls']);
        $wooExcluded = true;

        if (class_exists('WooCommerce')) {
            $required = ['/cart', '/checkout', '/my-account'];
            foreach ($required as $slug) {
                if (strpos($exclude, $slug) === false) {
                    $wooExcluded = false;
                    break;
                }
            }
        }

        return [
            'cache_writable' => $cacheWritable,
            'conflicts'      => empty($conflicts) ? 'None detected' : implode(', ', $conflicts),
            'woo_excluded'   => $wooExcluded,
        ];
    }
}

add_action('admin_notices', static function () {
    if (!current_user_can('manage_options')) {
        return;
    }

    $key = 'qsit_admin_notice_' . get_current_user_id();
    $notice = get_transient($key);
    if (!is_array($notice)) {
        return;
    }

    delete_transient($key);
    $type = $notice['type'] === 'error' ? 'notice notice-error' : 'notice notice-success';
    echo '<div class="' . esc_attr($type) . '"><p>' . esc_html((string) $notice['message']) . '</p></div>';
});
