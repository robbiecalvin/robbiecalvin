<?php

if (!defined('ABSPATH')) {
    exit;
}

class QSIT_Settings
{
    public static function init(): void
    {
        add_action('admin_init', [self::class, 'register_settings']);
    }

    public static function register_settings(): void
    {
        register_setting(
            'qsit_settings_group',
            QUICK_SITE_OPTION_KEY,
            [
                'type'              => 'array',
                'sanitize_callback' => [self::class, 'sanitize_settings'],
                'default'           => qsit_get_default_settings(),
            ]
        );
    }

    public static function sanitize_settings($input): array
    {
        $defaults = qsit_get_default_settings();
        $existing = qsit_get_settings();
        $premium_enabled = qsit_is_premium_active();
        $output = $existing;

        if (!is_array($input)) {
            $input = [];
        }

        $boolKeys = [
            'page_cache_enabled',
            'cache_search',
            'split_device',
            'split_language',
            'safe_mode',
            'debug_log',
            'disable_emojis',
            'disable_embeds',
            'remove_asset_query_strings',
            'lazyload_images',
            'defer_js',
            'minify_assets',
            'db_cleanup_enabled',
            'db_optimize_tables',
            'purge_on_comment_change',
            'add_cache_headers',
            'disable_etag_header',
            'dropin_enabled',
        ];

        foreach ($boolKeys as $key) {
            $output[$key] = !empty($input[$key]) ? 1 : 0;
        }

        $intKeys = [
            'cache_ttl',
            'heartbeat_admin',
            'heartbeat_editor',
            'heartbeat_front',
            'db_delete_revisions_days',
            'db_delete_autodraft_days',
            'db_delete_trash_days',
        ];

        foreach ($intKeys as $key) {
            if (isset($input[$key])) {
                $output[$key] = max(1, (int) $input[$key]);
            }
        }

        $textAreaKeys = [
            'query_whitelist',
            'ignore_query_prefixes',
            'exclude_urls',
            'exclude_cookies',
            'exclude_user_agents',
            'preload_assets',
            'defer_excludes',
            'minify_excludes',
        ];

        foreach ($textAreaKeys as $key) {
            $raw = isset($input[$key]) ? (string) $input[$key] : '';
            $lines = preg_split('/\r\n|\r|\n/', $raw);
            if (!is_array($lines)) {
                $lines = [];
            }

            $clean = [];
            foreach ($lines as $line) {
                $line = trim(wp_strip_all_tags($line));
                if ($line === '') {
                    continue;
                }
                $clean[] = $line;
            }

            $output[$key] = implode("\n", $clean);
        }

        if (! $premium_enabled) {
            $premium_bool_keys = [
                'disable_emojis',
                'disable_embeds',
                'remove_asset_query_strings',
                'lazyload_images',
                'defer_js',
                'minify_assets',
            ];
            $premium_text_keys = [
                'preload_assets',
                'defer_excludes',
                'minify_excludes',
            ];
            $premium_int_keys = [
                'heartbeat_admin',
                'heartbeat_editor',
                'heartbeat_front',
            ];

            foreach ($premium_bool_keys as $key) {
                $output[$key] = isset($existing[$key]) ? (int) $existing[$key] : 0;
            }
            foreach ($premium_text_keys as $key) {
                $output[$key] = isset($existing[$key]) ? (string) $existing[$key] : '';
            }
            foreach ($premium_int_keys as $key) {
                $output[$key] = isset($existing[$key]) ? (int) $existing[$key] : (int) $defaults[$key];
            }
        }

        $output = wp_parse_args($output, $defaults);

        $output['cache_ttl'] = max(60, (int) $output['cache_ttl']);
        $output['heartbeat_admin'] = max(15, (int) $output['heartbeat_admin']);
        $output['heartbeat_editor'] = max(15, (int) $output['heartbeat_editor']);
        $output['heartbeat_front'] = max(15, (int) $output['heartbeat_front']);
        $output['db_delete_revisions_days'] = max(1, (int) $output['db_delete_revisions_days']);
        $output['db_delete_autodraft_days'] = max(1, (int) $output['db_delete_autodraft_days']);
        $output['db_delete_trash_days'] = max(1, (int) $output['db_delete_trash_days']);

        qsit_write_dropin_config_from_settings($output);

        if (!empty($output['dropin_enabled'])) {
            QSIT_Dropin::install_dropin();
        }

        return $output;
    }
}
