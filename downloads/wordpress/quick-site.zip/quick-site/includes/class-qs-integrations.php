<?php

if (!defined('ABSPATH')) {
    exit;
}

class QSIT_Integrations
{
    private const OPTION_KEY = 'qsit_integrations';

    public static function init(): void
    {
        add_action('admin_post_qsit_save_integrations', [self::class, 'handle_save']);

        if (self::is_enabled('quick_audit')) {
            add_action('quickwoo_local/audit_completed', [self::class, 'handle_audit_completed'], 10, 2);
        }
    }

    public static function render_page(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions.');
        }

        $settings = self::get_settings();
        $premium_enabled = qsit_is_premium_active();
        echo '<div class="wrap quick-site-wrap">';
        echo '<h1>Quick Site Integrations</h1>';
        if (! $premium_enabled) {
            echo '<div class="notice notice-warning"><p>Integrations are available on premium.</p></div>';
        }
        echo '<p>Optional integrations only. Quick Site remains fully standalone.</p>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="qsit_save_integrations" />';
        wp_nonce_field('qsit_save_integrations', 'qsit_integrations_nonce');

        echo '<table class="form-table" role="presentation"><tbody>';
        self::checkbox_row('quick_seo', 'Quick SEO', 'Share optimization and cache events with Quick SEO when active.', $settings, $premium_enabled);
        self::checkbox_row('quick_audit', 'Quick Audit', 'Share optimization and cache events with Quick Audit when active.', $settings, $premium_enabled);
        self::checkbox_row('quick_code', 'Quick Code', 'Share optimization and cache events with Quick Code when active.', $settings, $premium_enabled);
        self::checkbox_row('quick_traffic', 'Quick Traffic', 'Share optimization and cache events with Quick Traffic when active.', $settings, $premium_enabled);
        echo '</tbody></table>';

        submit_button('Save Integrations');
        echo '</form>';
        echo '</div>';
    }

    public static function handle_save(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions.');
        }

        check_admin_referer('qsit_save_integrations', 'qsit_integrations_nonce');

        $premium_enabled = qsit_is_premium_active();
        $settings = [
            'quick_seo' => $premium_enabled && !empty($_POST['quick_seo']) ? 1 : 0,
            'quick_audit' => $premium_enabled && !empty($_POST['quick_audit']) ? 1 : 0,
            'quick_code' => $premium_enabled && !empty($_POST['quick_code']) ? 1 : 0,
            'quick_traffic' => $premium_enabled && !empty($_POST['quick_traffic']) ? 1 : 0,
        ];

        update_option(self::OPTION_KEY, $settings, false);
        wp_safe_redirect(admin_url('admin.php?page=quick-site-integrations'));
        exit;
    }

    public static function emit_cache_event(string $operation, array $payload = []): void
    {
        do_action(
            'quickwoo_local/site_cache_event',
            [
                'operation' => sanitize_key($operation),
                'payload' => $payload,
            ],
            [
                'source' => 'quick-site',
                'occurred_at' => current_time('mysql'),
            ]
        );
    }

    public static function handle_audit_completed($payload, $context): void
    {
        if (!self::is_enabled('quick_audit')) {
            return;
        }

        update_option('qsit_last_audit_event', [
            'payload' => is_array($payload) ? $payload : [],
            'context' => is_array($context) ? $context : [],
            'stored_at' => current_time('mysql'),
        ], false);
    }

    private static function checkbox_row(string $key, string $label, string $description, array $settings, bool $premium_enabled = true): void
    {
        echo '<tr>';
        echo '<th scope="row">' . esc_html($label) . '</th>';
        echo '<td><label><input type="checkbox" name="' . esc_attr($key) . '" value="1" ' . checked(!empty($settings[$key]), true, false) . ' ' . disabled(! $premium_enabled, true, false) . ' /> ' . esc_html($description) . '</label></td>';
        echo '</tr>';
    }

    private static function get_settings(): array
    {
        $defaults = [
            'quick_seo' => 0,
            'quick_audit' => 0,
            'quick_code' => 0,
            'quick_traffic' => 0,
        ];

        $saved = get_option(self::OPTION_KEY, []);
        if (!is_array($saved)) {
            $saved = [];
        }

        $settings = wp_parse_args($saved, $defaults);

        return [
            'quick_seo' => !empty($settings['quick_seo']) ? 1 : 0,
            'quick_audit' => !empty($settings['quick_audit']) ? 1 : 0,
            'quick_code' => !empty($settings['quick_code']) ? 1 : 0,
            'quick_traffic' => !empty($settings['quick_traffic']) ? 1 : 0,
        ];
    }

    private static function is_enabled(string $key): bool
    {
        $settings = self::get_settings();
        return !empty($settings[$key]);
    }
}
