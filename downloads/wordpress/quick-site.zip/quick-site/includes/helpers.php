<?php

if (!defined('ABSPATH')) {
    exit;
}

function qsit_get_default_settings(): array
{
    return [
        'page_cache_enabled'           => 1,
        'cache_ttl'                    => QUICK_SITE_DEFAULT_TTL,
        'cache_search'                 => 0,
        'query_whitelist'              => "gclid\nfbclid",
        'ignore_query_prefixes'        => "utm_",
        'split_device'                 => 0,
        'split_language'               => 0,
        'exclude_urls'                 => "/cart\n/checkout\n/my-account\n/wp-json/",
        'exclude_cookies'              => "woocommerce_items_in_cart\nwoocommerce_cart_hash\nwp_woocommerce_session_\nwordpress_logged_in_\ncomment_author_",
        'exclude_user_agents'          => '',
        'safe_mode'                    => 0,
        'debug_log'                    => 0,
        'disable_emojis'               => 1,
        'disable_embeds'               => 1,
        'heartbeat_admin'              => 60,
        'heartbeat_editor'             => 60,
        'heartbeat_front'              => 120,
        'remove_asset_query_strings'   => 0,
        'preload_assets'               => '',
        'lazyload_images'              => 0,
        'defer_js'                     => 0,
        'defer_excludes'               => "jquery\njquery-core\njquery-migrate",
        'minify_assets'                => 0,
        'minify_excludes'              => '',
        'db_cleanup_enabled'           => 0,
        'db_delete_revisions_days'     => 30,
        'db_delete_autodraft_days'     => 14,
        'db_delete_trash_days'         => 14,
        'db_optimize_tables'           => 0,
        'purge_on_comment_change'      => 0,
        'add_cache_headers'            => 0,
        'disable_etag_header'          => 0,
        'dropin_enabled'               => 1,
    ];
}

function qsit_get_settings(): array
{
    $defaults = qsit_get_default_settings();
    $saved = get_option(QUICK_SITE_OPTION_KEY, []);
    if (!is_array($saved)) {
        $saved = [];
    }

    $settings = wp_parse_args($saved, $defaults);

    $settings['cache_ttl'] = max(60, (int) $settings['cache_ttl']);
    $settings['heartbeat_admin'] = max(15, (int) $settings['heartbeat_admin']);
    $settings['heartbeat_editor'] = max(15, (int) $settings['heartbeat_editor']);
    $settings['heartbeat_front'] = max(15, (int) $settings['heartbeat_front']);
    $settings['db_delete_revisions_days'] = max(1, (int) $settings['db_delete_revisions_days']);
    $settings['db_delete_autodraft_days'] = max(1, (int) $settings['db_delete_autodraft_days']);
    $settings['db_delete_trash_days'] = max(1, (int) $settings['db_delete_trash_days']);

    return $settings;
}

function qsit_is_safe_mode_enabled(): bool
{
    if (defined('QUICK_SITE_SAFE_MODE') && QUICK_SITE_SAFE_MODE) {
        return true;
    }

    $settings = qsit_get_settings();
    return !empty($settings['safe_mode']);
}

function qsit_get_cache_base_dir(): string
{
    return trailingslashit(WP_CONTENT_DIR) . 'cache/quick-site/';
}

function qsit_get_cache_pages_dir(): string
{
    return qsit_get_cache_base_dir() . 'pages/';
}

function qsit_get_cache_logs_dir(): string
{
    return qsit_get_cache_base_dir() . 'logs/';
}

function qsit_get_cache_stats_dir(): string
{
    return qsit_get_cache_base_dir() . 'stats/';
}

function qsit_ensure_cache_dirs(): bool
{
    $dirs = [
        qsit_get_cache_base_dir(),
        qsit_get_cache_pages_dir(),
        qsit_get_cache_logs_dir(),
        qsit_get_cache_stats_dir(),
    ];

    foreach ($dirs as $dir) {
        if (!file_exists($dir) && !wp_mkdir_p($dir)) {
            return false;
        }
    }

    return true;
}

function qsit_get_dropin_config_path(): string
{
    return qsit_get_cache_base_dir() . 'config.php';
}

function qsit_normalize_lines(string $text): array
{
    $lines = preg_split('/\r\n|\r|\n/', $text);
    if (!is_array($lines)) {
        return [];
    }

    $clean = [];
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $clean[] = $line;
    }

    return $clean;
}

function qsit_atomic_write_file(string $path, string $content): bool
{
    $dir = dirname($path);
    if (!file_exists($dir) && !wp_mkdir_p($dir)) {
        return false;
    }

    $tmp = $path . '.tmp-' . wp_generate_password(8, false, false);

    if (file_put_contents($tmp, $content, LOCK_EX) === false) {
        @unlink($tmp);
        return false;
    }

    if (!@rename($tmp, $path)) {
        @unlink($tmp);
        return false;
    }

    @chmod($path, 0644);
    return true;
}

function qsit_write_dropin_config(): bool
{
    return qsit_write_dropin_config_from_settings(qsit_get_settings());
}

function qsit_write_dropin_config_from_settings(array $settings): bool
{
    $safeMode = (defined('QUICK_SITE_SAFE_MODE') && QUICK_SITE_SAFE_MODE) || !empty($settings['safe_mode']);

    $config = [
        'enabled'               => !empty($settings['page_cache_enabled']) && !$safeMode,
        'ttl'                   => (int) $settings['cache_ttl'],
        'cache_search'          => !empty($settings['cache_search']),
        'split_device'          => !empty($settings['split_device']),
        'split_language'        => !empty($settings['split_language']),
        'exclude_urls'          => qsit_normalize_lines((string) $settings['exclude_urls']),
        'exclude_cookies'       => qsit_normalize_lines((string) $settings['exclude_cookies']),
        'exclude_user_agents'   => qsit_normalize_lines((string) $settings['exclude_user_agents']),
        'query_whitelist'       => qsit_normalize_lines((string) $settings['query_whitelist']),
        'ignore_query_prefixes' => qsit_normalize_lines((string) $settings['ignore_query_prefixes']),
        'cache_dir'             => qsit_get_cache_pages_dir(),
        'stats_dir'             => qsit_get_cache_stats_dir(),
        'site_url'              => home_url('/'),
    ];

    $export = "<?php\nreturn " . var_export($config, true) . ";\n";
    return qsit_atomic_write_file(qsit_get_dropin_config_path(), $export);
}

function qsit_debug_log(string $message): void
{
    if (!defined('WP_DEBUG') || !WP_DEBUG) {
        return;
    }

    $settings = qsit_get_settings();
    if (empty($settings['debug_log'])) {
        return;
    }

    $logDir = qsit_get_cache_logs_dir();
    if (!file_exists($logDir) && !wp_mkdir_p($logDir)) {
        return;
    }

    $line = sprintf("[%s] %s\n", gmdate('Y-m-d H:i:s'), $message);
    @file_put_contents($logDir . 'debug.log', $line, FILE_APPEND | LOCK_EX);
}

function qsit_increment_stat(string $name): void
{
    $statsDir = qsit_get_cache_stats_dir();
    if (!file_exists($statsDir) && !wp_mkdir_p($statsDir)) {
        return;
    }

    $path = $statsDir . sanitize_key($name) . '.count';
    $fp = @fopen($path, 'c+');
    if (!$fp) {
        return;
    }

    try {
        if (!flock($fp, LOCK_EX)) {
            fclose($fp);
            return;
        }

        $raw = stream_get_contents($fp);
        $count = is_numeric(trim((string) $raw)) ? (int) trim((string) $raw) : 0;
        $count++;

        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, (string) $count);
        fflush($fp);
        flock($fp, LOCK_UN);
    } finally {
        fclose($fp);
    }
}

function qsit_get_stat(string $name): int
{
    $path = qsit_get_cache_stats_dir() . sanitize_key($name) . '.count';
    if (!file_exists($path)) {
        return 0;
    }

    $raw = @file_get_contents($path);
    if ($raw === false) {
        return 0;
    }

    return is_numeric(trim($raw)) ? (int) trim($raw) : 0;
}
