<?php

if (!defined('ABSPATH')) {
    exit;
}

class QSIT_DBTools
{
    private const LAST_RUN_OPTION = 'quick_site_db_last_run';

    public static function init(): void
    {
        // Intentionally no background jobs. Tools run only by admin actions.
    }

    public static function get_last_run_time(): string
    {
        $value = get_option(self::LAST_RUN_OPTION, '');
        return is_string($value) ? $value : '';
    }

    public static function preview_cleanup(array $settings): array
    {
        global $wpdb;

        $results = [
            'expired_transients' => 0,
            'old_revisions'      => 0,
            'old_autodrafts'     => 0,
            'old_trash_posts'    => 0,
            'tables'             => [],
        ];

        $results['expired_transients'] = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_%' AND option_value < UNIX_TIMESTAMP()"
        );

        $results['old_revisions'] = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                max(1, (int) $settings['db_delete_revisions_days'])
            )
        );

        $results['old_autodrafts'] = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'auto-draft' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                max(1, (int) $settings['db_delete_autodraft_days'])
            )
        );

        $results['old_trash_posts'] = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'trash' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                max(1, (int) $settings['db_delete_trash_days'])
            )
        );

        $tableNames = $wpdb->get_col('SHOW TABLES');
        if (is_array($tableNames)) {
            $results['tables'] = $tableNames;
        }

        return $results;
    }

    public static function run_cleanup(array $settings): array
    {
        global $wpdb;

        $report = [
            'expired_transients' => 0,
            'old_revisions'      => 0,
            'old_autodrafts'     => 0,
            'old_trash_posts'    => 0,
            'optimized_tables'   => 0,
            'errors'             => [],
        ];

        $expiredTimeoutRows = $wpdb->get_results(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_%' AND option_value < UNIX_TIMESTAMP()"
        );

        if (is_array($expiredTimeoutRows)) {
            foreach ($expiredTimeoutRows as $row) {
                $timeoutName = (string) $row->option_name;
                $transientName = str_replace('_transient_timeout_', '_transient_', $timeoutName);

                delete_option($timeoutName);
                delete_option($transientName);
                $report['expired_transients']++;
            }
        }

        $revIds = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                max(1, (int) $settings['db_delete_revisions_days'])
            )
        );

        if (is_array($revIds)) {
            foreach ($revIds as $id) {
                if (wp_delete_post((int) $id, true)) {
                    $report['old_revisions']++;
                }
            }
        }

        $autoIds = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'auto-draft' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                max(1, (int) $settings['db_delete_autodraft_days'])
            )
        );

        if (is_array($autoIds)) {
            foreach ($autoIds as $id) {
                if (wp_delete_post((int) $id, true)) {
                    $report['old_autodrafts']++;
                }
            }
        }

        $trashIds = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'trash' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                max(1, (int) $settings['db_delete_trash_days'])
            )
        );

        if (is_array($trashIds)) {
            foreach ($trashIds as $id) {
                if (wp_delete_post((int) $id, true)) {
                    $report['old_trash_posts']++;
                }
            }
        }

        if (!empty($settings['db_optimize_tables'])) {
            $tables = $wpdb->get_col('SHOW TABLES');
            if (is_array($tables)) {
                foreach ($tables as $table) {
                    $table = preg_replace('/[^a-zA-Z0-9_]/', '', (string) $table);
                    if ($table === '') {
                        continue;
                    }
                    $ok = $wpdb->query("OPTIMIZE TABLE `{$table}`");
                    if ($ok === false) {
                        $report['errors'][] = 'Failed optimizing table: ' . $table;
                    } else {
                        $report['optimized_tables']++;
                    }
                }
            }
        }

        update_option(self::LAST_RUN_OPTION, current_time('mysql'));

        return $report;
    }
}
