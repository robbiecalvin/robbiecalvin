<?php

if (!defined('ABSPATH')) {
    exit;
}

class QSIT_Activator
{
    public static function activate(): void
    {
        $defaults = qsit_get_default_settings();
        $existing = get_option(QUICK_SITE_OPTION_KEY, []);
        if (!is_array($existing)) {
            $existing = [];
        }

        update_option(QUICK_SITE_OPTION_KEY, wp_parse_args($existing, $defaults), false);
        qsit_ensure_cache_dirs();
        qsit_write_dropin_config();

        $settings = qsit_get_settings();
        if (!empty($settings['dropin_enabled'])) {
            QSIT_Dropin::install_dropin();
        }
    }

    public static function deactivate(): void
    {
        qsit_write_dropin_config();
    }
}
