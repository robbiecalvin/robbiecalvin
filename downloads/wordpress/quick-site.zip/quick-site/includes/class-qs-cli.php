<?php

if (!defined('ABSPATH')) {
    exit;
}

class QSIT_CLI
{
    public static function register(): void
    {
        WP_CLI::add_command('quick-site', [self::class, 'handle_command']);
    }

    /**
     * WP-CLI command handler.
     *
     * ## OPTIONS
     *
     * <action>
     * : purge
     *
     * <scope>
     * : all|url
     *
     * [<url>]
     * : URL for purge url command.
     */
    public static function handle_command(array $args): void
    {
        $action = $args[0] ?? '';
        $scope = $args[1] ?? '';

        if ($action !== 'purge') {
            WP_CLI::error('Unknown action. Use: wp quick-site purge all|url <url>');
        }

        if ($scope === 'all') {
            $ok = QSIT_Cache::purge_all();
            if ($ok) {
                WP_CLI::success('Quick Site cache purged.');
                return;
            }

            WP_CLI::warning('Quick Site cache purge completed with errors.');
            return;
        }

        if ($scope === 'url') {
            $url = $args[2] ?? '';
            if ($url === '') {
                WP_CLI::error('Provide a URL. Example: wp quick-site purge url https://example.com/path/');
            }

            $count = QSIT_Cache::purge_url($url);
            WP_CLI::success('Purged cache variants: ' . $count);
            return;
        }

        WP_CLI::error('Unknown scope. Use all or url.');
    }
}
