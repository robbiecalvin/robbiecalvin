<?php
/**
 * Quick Site advanced-cache drop-in.
 *
 * This file is copied to wp-content/advanced-cache.php by the plugin.
 */

if (!defined('ABSPATH')) {
    return;
}

$qsConfigFile = WP_CONTENT_DIR . '/cache/quick-site/config.php';
if (!file_exists($qsConfigFile)) {
    return;
}

$qsConfig = include $qsConfigFile;
if (!is_array($qsConfig) || empty($qsConfig['enabled'])) {
    return;
}

$qsMethod = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
if ($qsMethod !== 'GET') {
    return;
}

if (!empty($_POST)) {
    return;
}

$qsUri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
$qsPath = (string) (parse_url($qsUri, PHP_URL_PATH) ?: '/');
$qsQuery = (string) (parse_url($qsUri, PHP_URL_QUERY) ?: '');

if ($qsPath === '') {
    $qsPath = '/';
}

$qsExcludePaths = isset($qsConfig['exclude_urls']) && is_array($qsConfig['exclude_urls']) ? $qsConfig['exclude_urls'] : [];
foreach ($qsExcludePaths as $qsPattern) {
    $qsPattern = trim((string) $qsPattern);
    if ($qsPattern !== '' && strpos($qsPath, $qsPattern) !== false) {
        return;
    }
}

if (strpos($qsPath, '/wp-json/') !== false || strpos($qsPath, '/feed') !== false) {
    return;
}

if (strpos($qsQuery, 'preview=true') !== false) {
    return;
}

$qsCookieNames = array_keys($_COOKIE ?? []);
$qsExcludeCookies = isset($qsConfig['exclude_cookies']) && is_array($qsConfig['exclude_cookies']) ? $qsConfig['exclude_cookies'] : [];
foreach ($qsExcludeCookies as $qsCookiePattern) {
    $qsCookiePattern = trim((string) $qsCookiePattern);
    if ($qsCookiePattern === '') {
        continue;
    }

    foreach ($qsCookieNames as $qsCookieName) {
        if (strpos((string) $qsCookieName, $qsCookiePattern) !== false) {
            return;
        }
    }
}

if (!empty($_COOKIE['wordpress_logged_in_']) || !empty($_COOKIE['comment_author_'])) {
    return;
}

$qsUA = strtolower((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
$qsExcludeUAs = isset($qsConfig['exclude_user_agents']) && is_array($qsConfig['exclude_user_agents']) ? $qsConfig['exclude_user_agents'] : [];
foreach ($qsExcludeUAs as $qsUaPattern) {
    $qsUaPattern = trim((string) $qsUaPattern);
    if ($qsUaPattern !== '' && strpos($qsUA, strtolower($qsUaPattern)) !== false) {
        return;
    }
}

$qsWhitelist = isset($qsConfig['query_whitelist']) && is_array($qsConfig['query_whitelist']) ? $qsConfig['query_whitelist'] : [];
$qsIgnorePrefixes = isset($qsConfig['ignore_query_prefixes']) && is_array($qsConfig['ignore_query_prefixes']) ? $qsConfig['ignore_query_prefixes'] : [];
$qsParams = [];
if ($qsQuery !== '') {
    parse_str($qsQuery, $qsParams);
}

if (empty($qsConfig['cache_search']) && array_key_exists('s', $qsParams)) {
    return;
}

$qsKept = [];
foreach ($qsParams as $qsKey => $qsValue) {
    $qsAllowed = in_array($qsKey, $qsWhitelist, true);

    if (!$qsAllowed) {
        foreach ($qsIgnorePrefixes as $qsPrefix) {
            $qsPrefix = trim((string) $qsPrefix);
            if ($qsPrefix !== '' && strpos($qsKey, $qsPrefix) === 0) {
                $qsAllowed = false;
                break;
            }
        }
    }

    if ($qsAllowed) {
        $qsKept[$qsKey] = $qsValue;
    }
}

ksort($qsKept);

$qsSiteUrl = isset($qsConfig['site_url']) ? rtrim((string) $qsConfig['site_url'], '/') : '';
$qsNormalized = $qsSiteUrl . $qsPath;
if (!empty($qsKept)) {
    $qsNormalized .= '?' . http_build_query($qsKept);
}

$qsDevice = 'all';
if (!empty($qsConfig['split_device'])) {
    $qsDevice = preg_match('/mobile|iphone|android|ipad|tablet/', $qsUA) ? 'mobile' : 'desktop';
}

$qsLanguage = 'all';
if (!empty($qsConfig['split_language'])) {
    if (!empty($_COOKIE['pll_language'])) {
        $qsLanguage = preg_replace('/[^a-z0-9_-]/i', '', (string) $_COOKIE['pll_language']);
    } elseif (!empty($_COOKIE['wp-wpml_current_language'])) {
        $qsLanguage = preg_replace('/[^a-z0-9_-]/i', '', (string) $_COOKIE['wp-wpml_current_language']);
    } elseif (!empty($_GET['lang'])) {
        $qsLanguage = preg_replace('/[^a-z0-9_-]/i', '', (string) $_GET['lang']);
    }

    if ($qsLanguage === '') {
        $qsLanguage = 'all';
    }
}

$qsHash = md5($qsNormalized);
$qsCacheDir = isset($qsConfig['cache_dir']) ? (string) $qsConfig['cache_dir'] : WP_CONTENT_DIR . '/cache/quick-site/pages/';
$qsFile = rtrim($qsCacheDir, '/\\') . '/' . $qsHash . '--' . $qsDevice . '--' . $qsLanguage . '.html';

if (!file_exists($qsFile)) {
    return;
}

$qsTTL = isset($qsConfig['ttl']) ? max(60, (int) $qsConfig['ttl']) : 600;
$qsMtime = (int) @filemtime($qsFile);
if ($qsMtime <= 0 || (time() - $qsMtime) > $qsTTL) {
    @unlink($qsFile);
    return;
}

$qsContent = @file_get_contents($qsFile);
if ($qsContent === false || $qsContent === '') {
    return;
}

if (!headers_sent()) {
    header('Content-Type: text/html; charset=UTF-8');
    header('X-Quick-Site-Cache: HIT');
    header('Cache-Control: public, max-age=' . $qsTTL);
    header('Expires: ' . gmdate('D, d M Y H:i:s', time() + $qsTTL) . ' GMT');
}

$qsStatsDir = isset($qsConfig['stats_dir']) ? (string) $qsConfig['stats_dir'] : '';
if ($qsStatsDir !== '') {
    $qsHitFile = rtrim($qsStatsDir, '/\\') . '/hits.count';
    $qsFp = @fopen($qsHitFile, 'c+');
    if ($qsFp) {
        if (flock($qsFp, LOCK_EX)) {
            $qsRaw = stream_get_contents($qsFp);
            $qsCount = is_numeric(trim((string) $qsRaw)) ? (int) trim((string) $qsRaw) : 0;
            $qsCount++;
            ftruncate($qsFp, 0);
            rewind($qsFp);
            fwrite($qsFp, (string) $qsCount);
            fflush($qsFp);
            flock($qsFp, LOCK_UN);
        }
        fclose($qsFp);
    }
}

echo $qsContent;
exit;
