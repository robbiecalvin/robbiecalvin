(function ($) {
  'use strict';

  $(document).on('submit', 'form', function () {
    var actionField = $(this).find('input[name="action"]').val();
    if (actionField === 'qsit_purge_all') {
      return window.confirm('Purge all Quick Site cache files?');
    }
    return true;
  });
})(jQuery);
