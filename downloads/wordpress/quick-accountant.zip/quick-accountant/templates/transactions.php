<?php
if (!defined('ABSPATH')) {
    exit;
}

$edit = $data['edit_transaction'];
$settings = qacc_get_settings();
$premium_enabled = qacc_is_premium_active();
?>
<div class="wrap qa-wrap">
    <h1><?php esc_html_e('Transactions', 'quick-accountant'); ?></h1>
    <?php
    if (isset($_GET['qacc_notice'])) {
        echo '<div class="notice notice-success"><p>' . esc_html(sanitize_text_field(wp_unslash($_GET['qacc_notice']))) . '</p></div>';
    }
    ?>

    <div class="qa-grid-2">
        <div class="qa-card">
            <h2><?php echo $edit ? esc_html__('Edit Transaction', 'quick-accountant') : esc_html__('Add Transaction', 'quick-accountant'); ?></h2>
            <form method="post" enctype="multipart/form-data" class="qa-form-stack">
                <?php wp_nonce_field('qacc_transactions_action', 'qacc_nonce'); ?>
                <input type="hidden" name="qacc_action" value="save_transaction" />
                <input type="hidden" name="id" value="<?php echo esc_attr($edit['id'] ?? 0); ?>" />
                <input type="hidden" name="existing_receipt_url" value="<?php echo esc_attr($edit['receipt_url'] ?? ''); ?>" />
                <input type="hidden" name="existing_receipt_attachment_id" value="<?php echo esc_attr((string) absint($edit['receipt_attachment_id'] ?? 0)); ?>" />

                <label>
                    <?php esc_html_e('Date', 'quick-accountant'); ?>
                    <input type="date" name="txn_date" required value="<?php echo esc_attr($edit['txn_date'] ?? gmdate('Y-m-d')); ?>" />
                </label>

                <label>
                    <?php esc_html_e('Amount', 'quick-accountant'); ?>
                    <input type="number" step="0.01" min="0" name="amount" required value="<?php echo esc_attr($edit['amount'] ?? ''); ?>" />
                </label>

                <label>
                    <?php esc_html_e('Type', 'quick-accountant'); ?>
                    <select name="txn_type" required>
                        <option value="income" <?php selected(($edit['txn_type'] ?? ''), 'income'); ?>><?php esc_html_e('Income', 'quick-accountant'); ?></option>
                        <option value="expense" <?php selected(($edit['txn_type'] ?? 'expense'), 'expense'); ?>><?php esc_html_e('Expense', 'quick-accountant'); ?></option>
                    </select>
                </label>

                <label>
                    <?php esc_html_e('Category', 'quick-accountant'); ?>
                    <select name="category_id" required>
                        <option value=""><?php esc_html_e('Select category', 'quick-accountant'); ?></option>
                        <?php foreach ($data['categories'] as $category) : ?>
                            <option value="<?php echo esc_attr($category['id']); ?>" <?php selected((int) ($edit['category_id'] ?? 0), (int) $category['id']); ?>>
                                <?php echo esc_html($category['name'] . ' (' . $category['kind'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>
                    <?php esc_html_e('Vendor/Client', 'quick-accountant'); ?>
                    <input type="text" name="party_name" value="<?php echo esc_attr($edit['party_name'] ?? ''); ?>" />
                </label>

                <label>
                    <?php esc_html_e('Payment Method', 'quick-accountant'); ?>
                    <input type="text" name="payment_method" value="<?php echo esc_attr($edit['payment_method'] ?? ''); ?>" />
                </label>

                <label>
                    <input type="checkbox" name="tax_included" value="1" <?php checked((int) ($edit['tax_included'] ?? 0), 1); ?> />
                    <?php esc_html_e('Tax Included', 'quick-accountant'); ?>
                </label>

                <label>
                    <?php esc_html_e('Tax Amount', 'quick-accountant'); ?>
                    <input type="number" step="0.01" min="0" name="tax_amount" value="<?php echo esc_attr($edit['tax_amount'] ?? '0.00'); ?>" />
                </label>

                <?php if (!empty($settings['enable_project_labels'])) : ?>
                    <label>
                        <?php esc_html_e('Project/Client Label', 'quick-accountant'); ?>
                        <input type="text" name="project_label" value="<?php echo esc_attr($edit['project_label'] ?? ''); ?>" />
                    </label>
                <?php endif; ?>

                <label>
                    <?php esc_html_e('Status', 'quick-accountant'); ?>
                    <select name="status">
                        <option value="cleared" <?php selected(($edit['status'] ?? 'cleared'), 'cleared'); ?>><?php esc_html_e('Cleared', 'quick-accountant'); ?></option>
                        <option value="pending" <?php selected(($edit['status'] ?? ''), 'pending'); ?>><?php esc_html_e('Pending', 'quick-accountant'); ?></option>
                    </select>
                </label>

                <label>
                    <?php esc_html_e('Notes', 'quick-accountant'); ?>
                    <textarea name="notes" rows="3"><?php echo esc_textarea($edit['notes'] ?? ''); ?></textarea>
                </label>

                <?php if ($premium_enabled && !empty($settings['receipt_uploads_enabled'])) : ?>
                    <label>
                        <?php esc_html_e('Receipt (pdf/jpg/png)', 'quick-accountant'); ?> <span class="qa-badge qa-badge-pro">PRO</span>
                        <input type="file" name="receipt_file" accept=".pdf,.jpg,.jpeg,.png" />
                    </label>
                    <?php if (!empty($edit['receipt_url'])) : ?>
                        <p>
                            <a href="<?php echo esc_url($edit['receipt_url']); ?>" target="_blank" rel="noopener noreferrer">
                                <?php esc_html_e('Current receipt', 'quick-accountant'); ?>
                            </a>
                        </p>
                    <?php endif; ?>
                <?php else : ?>
                    <p class="description"><?php esc_html_e('Receipt uploads are available in QuickWoo Pro.', 'quick-accountant'); ?></p>
                <?php endif; ?>

                <p>
                    <button type="submit" class="button button-primary"><?php esc_html_e('Save Transaction', 'quick-accountant'); ?></button>
                    <?php if ($edit) : ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=quick-accountant-transactions')); ?>" class="button"><?php esc_html_e('Cancel', 'quick-accountant'); ?></a>
                    <?php endif; ?>
                </p>
            </form>
        </div>

        <div class="qa-card">
            <h2><?php esc_html_e('Filters', 'quick-accountant'); ?></h2>
            <form method="get" class="qa-form-stack">
                <input type="hidden" name="page" value="quick-accountant-transactions" />

                <label><?php esc_html_e('Start Date', 'quick-accountant'); ?><input type="date" name="filter_start" value="<?php echo esc_attr(isset($_GET['filter_start']) ? sanitize_text_field(wp_unslash($_GET['filter_start'])) : ''); ?>" /></label>
                <label><?php esc_html_e('End Date', 'quick-accountant'); ?><input type="date" name="filter_end" value="<?php echo esc_attr(isset($_GET['filter_end']) ? sanitize_text_field(wp_unslash($_GET['filter_end'])) : ''); ?>" /></label>

                <label>
                    <?php esc_html_e('Type', 'quick-accountant'); ?>
                    <select name="filter_type">
                        <option value=""><?php esc_html_e('All', 'quick-accountant'); ?></option>
                        <option value="income" <?php selected(isset($_GET['filter_type']) ? sanitize_text_field(wp_unslash($_GET['filter_type'])) : '', 'income'); ?>><?php esc_html_e('Income', 'quick-accountant'); ?></option>
                        <option value="expense" <?php selected(isset($_GET['filter_type']) ? sanitize_text_field(wp_unslash($_GET['filter_type'])) : '', 'expense'); ?>><?php esc_html_e('Expense', 'quick-accountant'); ?></option>
                    </select>
                </label>

                <label>
                    <?php esc_html_e('Category', 'quick-accountant'); ?>
                    <select name="filter_category">
                        <option value=""><?php esc_html_e('All', 'quick-accountant'); ?></option>
                        <?php foreach ($data['categories'] as $category) : ?>
                            <option value="<?php echo esc_attr($category['id']); ?>" <?php selected(isset($_GET['filter_category']) ? absint($_GET['filter_category']) : 0, (int) $category['id']); ?>>
                                <?php echo esc_html($category['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label>
                    <?php esc_html_e('Status', 'quick-accountant'); ?>
                    <select name="filter_status">
                        <option value=""><?php esc_html_e('All', 'quick-accountant'); ?></option>
                        <option value="cleared" <?php selected(isset($_GET['filter_status']) ? sanitize_text_field(wp_unslash($_GET['filter_status'])) : '', 'cleared'); ?>><?php esc_html_e('Cleared', 'quick-accountant'); ?></option>
                        <option value="pending" <?php selected(isset($_GET['filter_status']) ? sanitize_text_field(wp_unslash($_GET['filter_status'])) : '', 'pending'); ?>><?php esc_html_e('Pending', 'quick-accountant'); ?></option>
                    </select>
                </label>

                <label><?php esc_html_e('Search Notes/Party', 'quick-accountant'); ?><input type="search" name="s" value="<?php echo esc_attr(isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : ''); ?>" /></label>
                <button class="button" type="submit"><?php esc_html_e('Filter', 'quick-accountant'); ?></button>
            </form>
        </div>
    </div>

    <div class="qa-card">
        <h2><?php esc_html_e('Transactions List', 'quick-accountant'); ?></h2>
        <form method="post">
            <?php wp_nonce_field('qacc_transactions_action', 'qacc_nonce'); ?>
            <input type="hidden" name="qacc_action" value="bulk_action" />

            <div class="qa-inline-form qa-bulk-bar">
                <select name="bulk_action">
                    <option value=""><?php esc_html_e('Bulk Actions', 'quick-accountant'); ?></option>
                    <option value="delete"><?php esc_html_e('Delete', 'quick-accountant'); ?></option>
                    <option value="mark_cleared"><?php esc_html_e('Mark Cleared', 'quick-accountant'); ?></option>
                    <option value="mark_pending"><?php esc_html_e('Mark Pending', 'quick-accountant'); ?></option>
                    <option value="reassign_category"><?php esc_html_e('Reassign Category', 'quick-accountant'); ?></option>
                </select>
                <select name="reassign_category_id">
                    <option value=""><?php esc_html_e('Select Category', 'quick-accountant'); ?></option>
                    <?php foreach ($data['categories'] as $category) : ?>
                        <option value="<?php echo esc_attr($category['id']); ?>"><?php echo esc_html($category['name']); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="button"><?php esc_html_e('Apply', 'quick-accountant'); ?></button>
            </div>

            <table class="widefat striped qa-table">
                <thead>
                    <tr>
                        <th><input type="checkbox" class="qa-check-all" /></th>
                        <th><?php esc_html_e('Date', 'quick-accountant'); ?></th>
                        <th><?php esc_html_e('Amount', 'quick-accountant'); ?></th>
                        <th><?php esc_html_e('Type', 'quick-accountant'); ?></th>
                        <th><?php esc_html_e('Category', 'quick-accountant'); ?></th>
                        <th><?php esc_html_e('Vendor/Client', 'quick-accountant'); ?></th>
                        <th><?php esc_html_e('Status', 'quick-accountant'); ?></th>
                        <th><?php esc_html_e('Actions', 'quick-accountant'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($data['transactions'])) : ?>
                        <?php foreach ($data['transactions'] as $txn) : ?>
                            <tr>
                                <td><input type="checkbox" name="txn_ids[]" value="<?php echo esc_attr($txn['id']); ?>" /></td>
                                <td><?php echo esc_html($txn['txn_date']); ?></td>
                                <td><?php echo esc_html(qacc_format_currency($txn['amount'])); ?></td>
                                <td><?php echo esc_html(ucfirst($txn['txn_type'])); ?></td>
                                <td><?php echo esc_html($txn['category_name'] ?: '—'); ?></td>
                                <td><?php echo esc_html($txn['party_name']); ?></td>
                                <td><?php echo esc_html(ucfirst($txn['status'])); ?></td>
                                <td>
                                    <a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=quick-accountant-transactions&edit=' . absint($txn['id']))); ?>"><?php esc_html_e('Edit', 'quick-accountant'); ?></a>
                                    <button type="submit" class="button button-small qa-delete-btn" name="qacc_action" value="delete_transaction" formaction="<?php echo esc_url(admin_url('admin.php?page=quick-accountant-transactions')); ?>" onclick="document.getElementById('qa-delete-id').value='<?php echo esc_js($txn['id']); ?>'; return confirm('Delete this transaction?');"><?php esc_html_e('Delete', 'quick-accountant'); ?></button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr><td colspan="8"><?php esc_html_e('No transactions found.', 'quick-accountant'); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <input type="hidden" id="qa-delete-id" name="id" value="0" />
        </form>

        <?php
        $pagination = $data['pagination'];
        if ($pagination['total_pages'] > 1) :
            $current_url = admin_url('admin.php?page=quick-accountant-transactions');
            $query = $_GET;
            unset($query['paged']);
        ?>
            <div class="tablenav">
                <div class="tablenav-pages">
                    <?php for ($i = 1; $i <= $pagination['total_pages']; $i++) :
                        $link = add_query_arg(array_merge($query, array('paged' => $i)), $current_url);
                    ?>
                        <a class="button <?php echo $i === $pagination['current_page'] ? 'button-primary' : ''; ?>" href="<?php echo esc_url($link); ?>"><?php echo esc_html($i); ?></a>
                    <?php endfor; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
