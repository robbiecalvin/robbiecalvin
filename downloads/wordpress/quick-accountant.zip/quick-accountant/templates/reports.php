<?php
if (!defined('ABSPATH')) {
    exit;
}

$export_nonce = wp_create_nonce('qacc_export');
?>
<div class="wrap qa-wrap">
    <h1><?php esc_html_e('Reports', 'quick-accountant'); ?></h1>

    <form method="get" class="qa-inline-form">
        <input type="hidden" name="page" value="quick-accountant-reports" />
        <label>
            <?php esc_html_e('Start Date', 'quick-accountant'); ?>
            <input type="date" name="start_date" value="<?php echo esc_attr($data['start_date']); ?>" />
        </label>
        <label>
            <?php esc_html_e('End Date', 'quick-accountant'); ?>
            <input type="date" name="end_date" value="<?php echo esc_attr($data['end_date']); ?>" />
        </label>
        <button type="submit" class="button button-primary"><?php esc_html_e('Generate', 'quick-accountant'); ?></button>
    </form>

    <div class="qa-card">
        <h2><?php esc_html_e('Export CSV', 'quick-accountant'); ?></h2>
        <p class="qa-inline-form">
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=quick-accountant-reports&qacc_export=all&_wpnonce=' . $export_nonce)); ?>"><?php esc_html_e('All Transactions', 'quick-accountant'); ?></a>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=quick-accountant-reports&qacc_export=month&month=' . rawurlencode(gmdate('Y-m')) . '&_wpnonce=' . $export_nonce)); ?>"><?php esc_html_e('Current Month', 'quick-accountant'); ?></a>
        </p>
        <form method="get" class="qa-inline-form">
            <input type="hidden" name="page" value="quick-accountant-reports" />
            <input type="hidden" name="qacc_export" value="category" />
            <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($export_nonce); ?>" />
            <select name="category_id" required>
                <option value=""><?php esc_html_e('Select category', 'quick-accountant'); ?></option>
                <?php foreach ($data['categories'] as $cat) : ?>
                    <option value="<?php echo esc_attr($cat['id']); ?>"><?php echo esc_html($cat['name']); ?></option>
                <?php endforeach; ?>
            </select>
            <button class="button" type="submit"><?php esc_html_e('Export by Category', 'quick-accountant'); ?></button>
        </form>
    </div>

    <div class="qa-grid-2">
        <div class="qa-card">
            <h2><?php esc_html_e('Monthly Summary', 'quick-accountant'); ?></h2>
            <table class="widefat striped qa-table">
                <thead><tr><th><?php esc_html_e('Month', 'quick-accountant'); ?></th><th><?php esc_html_e('Income', 'quick-accountant'); ?></th><th><?php esc_html_e('Expenses', 'quick-accountant'); ?></th><th><?php esc_html_e('Profit', 'quick-accountant'); ?></th></tr></thead>
                <tbody>
                    <?php foreach ($data['monthly_summary'] as $row) :
                        $profit = (float) $row['income'] - (float) $row['expenses'];
                    ?>
                        <tr>
                            <td><?php echo esc_html($row['month']); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($row['income'])); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($row['expenses'])); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($profit)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="qa-card">
            <h2><?php esc_html_e('Category Breakdown', 'quick-accountant'); ?></h2>
            <canvas id="qa-category-chart" width="600" height="300"></canvas>
            <table class="widefat striped qa-table">
                <thead><tr><th><?php esc_html_e('Category', 'quick-accountant'); ?></th><th><?php esc_html_e('Group', 'quick-accountant'); ?></th><th><?php esc_html_e('Type', 'quick-accountant'); ?></th><th><?php esc_html_e('Total', 'quick-accountant'); ?></th></tr></thead>
                <tbody>
                    <?php foreach ($data['category_breakdown'] as $row) : ?>
                        <tr>
                            <td><?php echo esc_html($row['name']); ?></td>
                            <td><?php echo esc_html($row['group_name']); ?></td>
                            <td><?php echo esc_html($row['txn_type']); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($row['total'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="qa-grid-2">
        <div class="qa-card">
            <h2><?php esc_html_e('Vendor/Client Breakdown', 'quick-accountant'); ?></h2>
            <table class="widefat striped qa-table">
                <thead><tr><th><?php esc_html_e('Party', 'quick-accountant'); ?></th><th><?php esc_html_e('Type', 'quick-accountant'); ?></th><th><?php esc_html_e('Total', 'quick-accountant'); ?></th></tr></thead>
                <tbody>
                    <?php foreach ($data['party_breakdown'] as $row) : ?>
                        <tr>
                            <td><?php echo esc_html($row['party_name']); ?></td>
                            <td><?php echo esc_html($row['txn_type']); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($row['total'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="qa-card">
            <h2><?php esc_html_e('Tax Summary', 'quick-accountant'); ?></h2>
            <table class="widefat striped qa-table">
                <thead><tr><th><?php esc_html_e('Type', 'quick-accountant'); ?></th><th><?php esc_html_e('Tax Total', 'quick-accountant'); ?></th><th><?php esc_html_e('Tax Included Txns', 'quick-accountant'); ?></th><th><?php esc_html_e('Txn Count', 'quick-accountant'); ?></th></tr></thead>
                <tbody>
                    <?php foreach ($data['tax_summary'] as $row) : ?>
                        <tr>
                            <td><?php echo esc_html($row['txn_type']); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($row['total_tax'])); ?></td>
                            <td><?php echo esc_html($row['tax_included_count']); ?></td>
                            <td><?php echo esc_html($row['txn_count']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="qa-card">
        <h2><?php esc_html_e('Profit by Project Label', 'quick-accountant'); ?></h2>
        <table class="widefat striped qa-table">
            <thead><tr><th><?php esc_html_e('Project', 'quick-accountant'); ?></th><th><?php esc_html_e('Income', 'quick-accountant'); ?></th><th><?php esc_html_e('Expenses', 'quick-accountant'); ?></th><th><?php esc_html_e('Profit', 'quick-accountant'); ?></th></tr></thead>
            <tbody>
                <?php if (!empty($data['project_profit'])) : ?>
                    <?php foreach ($data['project_profit'] as $row) :
                        $profit = (float) $row['income'] - (float) $row['expenses'];
                    ?>
                        <tr>
                            <td><?php echo esc_html($row['project_label']); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($row['income'])); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($row['expenses'])); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($profit)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr><td colspan="4"><?php esc_html_e('No project labels in selected range.', 'quick-accountant'); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
window.qaCategoryData = <?php echo wp_json_encode($data['category_breakdown']); ?>;
</script>
