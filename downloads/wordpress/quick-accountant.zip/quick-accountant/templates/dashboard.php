<?php
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap qa-wrap qw-ui-shell qa-dashboard">
    <h1><?php esc_html_e('Quick Accountant Dashboard', 'quick-accountant'); ?></h1>

    <div class="qw-ui-grid qw-ui-grid--2">
        <div class="qw-card">
            <h2><?php esc_html_e('Operational Snapshot', 'quick-accountant'); ?></h2>
            <div class="qw-kpi-grid">
                <div class="qw-kpi">
                    <p class="qw-kpi__label"><?php esc_html_e('Revenue', 'quick-accountant'); ?></p>
                    <p class="qw-kpi__value"><?php echo esc_html(qacc_format_currency($data['income'])); ?></p>
                </div>
                <div class="qw-kpi">
                    <p class="qw-kpi__label"><?php esc_html_e('Expenses', 'quick-accountant'); ?></p>
                    <p class="qw-kpi__value"><?php echo esc_html(qacc_format_currency($data['expenses'])); ?></p>
                </div>
                <div class="qw-kpi">
                    <p class="qw-kpi__label"><?php esc_html_e('Profit', 'quick-accountant'); ?></p>
                    <p class="qw-kpi__value"><?php echo esc_html(qacc_format_currency($data['profit'])); ?></p>
                </div>
            </div>
        </div>

        <div class="qw-card">
            <h2><?php esc_html_e('Filters & Summary', 'quick-accountant'); ?></h2>
            <form method="get" class="qa-filters qa-inline-form">
                <input type="hidden" name="page" value="quick-accountant" />
                <label>
                    <?php esc_html_e('Range', 'quick-accountant'); ?>
                    <select name="range">
                        <option value="7d" <?php selected($data['range'], '7d'); ?>><?php esc_html_e('Last 7 days', 'quick-accountant'); ?></option>
                        <option value="30d" <?php selected($data['range'], '30d'); ?>><?php esc_html_e('Last 30 days', 'quick-accountant'); ?></option>
                        <option value="month" <?php selected($data['range'], 'month'); ?>><?php esc_html_e('This month', 'quick-accountant'); ?></option>
                        <option value="custom" <?php selected($data['range'], 'custom'); ?>><?php esc_html_e('Custom', 'quick-accountant'); ?></option>
                    </select>
                </label>
                <label>
                    <?php esc_html_e('Start', 'quick-accountant'); ?>
                    <input type="date" name="start_date" value="<?php echo esc_attr($data['start_date']); ?>" />
                </label>
                <label>
                    <?php esc_html_e('End', 'quick-accountant'); ?>
                    <input type="date" name="end_date" value="<?php echo esc_attr($data['end_date']); ?>" />
                </label>
                <button class="button button-primary" type="submit"><?php esc_html_e('Apply', 'quick-accountant'); ?></button>
            </form>
            <p><strong><?php esc_html_e('Net Margin %', 'quick-accountant'); ?>:</strong>
                <?php
                if ($data['margin'] === null) {
                    esc_html_e('N/A', 'quick-accountant');
                } else {
                    echo esc_html(number_format((float) $data['margin'], 2) . '%');
                }
                ?>
            </p>
        </div>
    </div>

    <div class="qw-ui-grid qw-ui-grid--2">
        <div class="qw-card">
            <h2><?php esc_html_e('Budget vs Actual (Month)', 'quick-accountant'); ?></h2>
            <form method="get" class="qa-inline-form">
                <input type="hidden" name="page" value="quick-accountant" />
                <label>
                    <?php esc_html_e('Month', 'quick-accountant'); ?>
                    <input type="month" name="budget_month" value="<?php echo esc_attr($data['month']); ?>" />
                </label>
                <button type="submit" class="button"><?php esc_html_e('Load', 'quick-accountant'); ?></button>
            </form>
            <div class="qw-table-wrap">
            <table class="widefat striped qa-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Category', 'quick-accountant'); ?></th>
                        <th><?php esc_html_e('Budget', 'quick-accountant'); ?></th>
                        <th><?php esc_html_e('Actual', 'quick-accountant'); ?></th>
                        <th><?php esc_html_e('Variance', 'quick-accountant'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data['budget_rows'] as $row) :
                        $actual = (float) $row['actual_amount'];
                        $budget = (float) $row['budget_amount'];
                        $variance = $budget - $actual;
                    ?>
                        <tr>
                            <td><?php echo esc_html($row['name']); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($budget)); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($actual)); ?></td>
                            <td><?php echo esc_html(qacc_format_currency($variance)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>

        <div class="qw-card">
            <h2><?php esc_html_e('Transaction Insights', 'quick-accountant'); ?></h2>
            <p><?php esc_html_e('Top spend categories for the selected range.', 'quick-accountant'); ?></p>
            <div class="qw-table-wrap">
            <table class="widefat striped qa-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Category', 'quick-accountant'); ?></th>
                        <th><?php esc_html_e('Spend', 'quick-accountant'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($data['top_categories'])) : ?>
                        <?php foreach ($data['top_categories'] as $row) : ?>
                            <tr>
                                <td><?php echo esc_html($row['name']); ?></td>
                                <td><?php echo esc_html(qacc_format_currency($row['total_spend'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr><td colspan="2"><?php esc_html_e('No expense data for this range.', 'quick-accountant'); ?></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>

    <div class="qw-card">
        <h2><?php esc_html_e('Cashflow', 'quick-accountant'); ?></h2>
        <canvas id="qa-cashflow-chart" width="1200" height="320"></canvas>
    </div>
</div>
<script>
window.qaCashflowData = <?php echo wp_json_encode($data['cashflow']); ?>;
</script>
