<?php
if (!defined('ABSPATH')) {
    exit;
}

$settings = $data['settings'];
?>
<div class="wrap qa-wrap">
    <h1><?php esc_html_e('Quick Accountant Settings', 'quick-accountant'); ?></h1>
    <?php
    if (isset($_GET['qacc_notice'])) {
        echo '<div class="notice notice-success"><p>' . esc_html(sanitize_text_field(wp_unslash($_GET['qacc_notice']))) . '</p></div>';
    }
    ?>

    <div class="qa-card">
        <h2><?php esc_html_e('General Settings', 'quick-accountant'); ?></h2>
        <form method="post" class="qa-form-stack">
            <?php wp_nonce_field('qacc_settings_action', 'qacc_nonce'); ?>
            <input type="hidden" name="qacc_action" value="save_settings" />

            <label>
                <?php esc_html_e('Currency Symbol', 'quick-accountant'); ?>
                <input type="text" name="currency_symbol" value="<?php echo esc_attr($settings['currency_symbol']); ?>" maxlength="8" />
            </label>

            <label>
                <?php esc_html_e('Default Dashboard Range', 'quick-accountant'); ?>
                <select name="default_date_range">
                    <option value="7d" <?php selected($settings['default_date_range'], '7d'); ?>><?php esc_html_e('Last 7 days', 'quick-accountant'); ?></option>
                    <option value="30d" <?php selected($settings['default_date_range'], '30d'); ?>><?php esc_html_e('Last 30 days', 'quick-accountant'); ?></option>
                    <option value="month" <?php selected($settings['default_date_range'], 'month'); ?>><?php esc_html_e('This month', 'quick-accountant'); ?></option>
                </select>
            </label>

            <label>
                <input type="checkbox" name="enable_woo_auto_sync" value="1" <?php checked((int) ($settings['enable_woo_auto_sync'] ?? 0), 1); ?> />
                <?php esc_html_e('Enable WooCommerce Auto Sync', 'quick-accountant'); ?> <span class="qa-badge qa-badge-pro">PRO</span>
            </label>

            <label>
                <input type="checkbox" name="receipt_uploads_enabled" value="1" <?php checked((int) $settings['receipt_uploads_enabled'], 1); ?> />
                <?php esc_html_e('Enable Receipt Uploads', 'quick-accountant'); ?> <span class="qa-badge qa-badge-pro">PRO</span>
            </label>

            <label>
                <?php esc_html_e('Receipt Max Size (MB)', 'quick-accountant'); ?>
                <input type="number" min="1" max="100" name="receipt_max_size_mb" value="<?php echo esc_attr($settings['receipt_max_size_mb']); ?>" />
            </label>

            <label>
                <?php esc_html_e('Allowed Receipt MIME Types (comma-separated)', 'quick-accountant'); ?>
                <input type="text" name="allowed_mime_types" value="<?php echo esc_attr($settings['allowed_mime_types']); ?>" />
            </label>

            <label>
                <input type="checkbox" name="enable_project_labels" value="1" <?php checked((int) $settings['enable_project_labels'], 1); ?> />
                <?php esc_html_e('Enable Project Labels', 'quick-accountant'); ?>
            </label>

            <label>
                <?php esc_html_e('Data Retention for Receipts (days, 0 = off)', 'quick-accountant'); ?>
                <input type="number" min="0" max="3650" name="data_retention_days" value="<?php echo esc_attr($settings['data_retention_days']); ?>" />
            </label>

            <label>
                <?php esc_html_e('Access Capability', 'quick-accountant'); ?>
                <select name="access_capability">
                    <option value="manage_options" <?php selected($settings['access_capability'], 'manage_options'); ?>><?php esc_html_e('manage_options (admins)', 'quick-accountant'); ?></option>
                    <option value="manage_quick_accountant" <?php selected($settings['access_capability'], 'manage_quick_accountant'); ?>><?php esc_html_e('manage_quick_accountant (custom)', 'quick-accountant'); ?></option>
                </select>
            </label>

            <p><button type="submit" class="button button-primary"><?php esc_html_e('Save Settings', 'quick-accountant'); ?></button></p>
        </form>
    </div>

    <div class="qa-grid-2">
        <div class="qa-card">
            <h2><?php esc_html_e('Export/Import Data', 'quick-accountant'); ?></h2>
            <form method="post" class="qa-form-stack">
                <?php wp_nonce_field('qacc_settings_action', 'qacc_nonce'); ?>
                <input type="hidden" name="qacc_action" value="export_data_json" />
                <button type="submit" class="button"><?php esc_html_e('Export Data as JSON', 'quick-accountant'); ?></button>
            </form>

            <form method="post" enctype="multipart/form-data" class="qa-form-stack" style="margin-top:1rem;">
                <?php wp_nonce_field('qacc_settings_action', 'qacc_nonce'); ?>
                <input type="hidden" name="qacc_action" value="import_data_json" />
                <label>
                    <?php esc_html_e('Import JSON File', 'quick-accountant'); ?>
                    <input type="file" name="import_json" accept="application/json" required />
                </label>
                <button type="submit" class="button"><?php esc_html_e('Import Data', 'quick-accountant'); ?></button>
            </form>
        </div>

        <div class="qa-card qa-danger-zone">
            <h2><?php esc_html_e('Danger Zone', 'quick-accountant'); ?></h2>
            <p><?php esc_html_e('This deletes all Quick Accountant data from custom tables and resets settings.', 'quick-accountant'); ?></p>
            <form method="post" class="qa-form-stack">
                <?php wp_nonce_field('qacc_settings_action', 'qacc_nonce'); ?>
                <input type="hidden" name="qacc_action" value="wipe_all_data" />
                <label>
                    <?php esc_html_e('Type WIPE to confirm', 'quick-accountant'); ?>
                    <input type="text" name="wipe_confirmation" required pattern="WIPE" />
                </label>
                <button type="submit" class="button button-secondary" onclick="return confirm('This will permanently wipe all Quick Accountant data. Continue?');"><?php esc_html_e('Wipe All Data', 'quick-accountant'); ?></button>
            </form>
        </div>
    </div>
</div>
