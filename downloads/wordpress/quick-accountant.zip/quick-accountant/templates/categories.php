<?php
if (!defined('ABSPATH')) {
    exit;
}

$edit_category = null;
if (isset($_GET['edit_category'])) {
    $edit_id = absint($_GET['edit_category']);
    foreach ($data['categories'] as $row) {
        if ((int) $row['id'] === $edit_id) {
            $edit_category = $row;
            break;
        }
    }
}
?>
<div class="wrap qa-wrap">
    <h1><?php esc_html_e('Categories & Budgets', 'quick-accountant'); ?></h1>
    <?php
    if (isset($_GET['qacc_notice'])) {
        echo '<div class="notice notice-success"><p>' . esc_html(sanitize_text_field(wp_unslash($_GET['qacc_notice']))) . '</p></div>';
    }
    ?>

    <div class="qa-grid-2">
        <div class="qa-card">
            <h2><?php echo $edit_category ? esc_html__('Edit Category', 'quick-accountant') : esc_html__('Add Category', 'quick-accountant'); ?></h2>
            <form method="post" class="qa-form-stack">
                <?php wp_nonce_field('qacc_categories_action', 'qacc_nonce'); ?>
                <input type="hidden" name="qacc_action" value="save_category" />
                <input type="hidden" name="id" value="<?php echo esc_attr($edit_category['id'] ?? 0); ?>" />

                <label>
                    <?php esc_html_e('Name', 'quick-accountant'); ?>
                    <input type="text" required name="name" value="<?php echo esc_attr($edit_category['name'] ?? ''); ?>" />
                </label>

                <label>
                    <?php esc_html_e('Kind', 'quick-accountant'); ?>
                    <select name="kind">
                        <option value="both" <?php selected(($edit_category['kind'] ?? 'both'), 'both'); ?>><?php esc_html_e('Both', 'quick-accountant'); ?></option>
                        <option value="income" <?php selected(($edit_category['kind'] ?? ''), 'income'); ?>><?php esc_html_e('Income', 'quick-accountant'); ?></option>
                        <option value="expense" <?php selected(($edit_category['kind'] ?? ''), 'expense'); ?>><?php esc_html_e('Expense', 'quick-accountant'); ?></option>
                    </select>
                </label>

                <label>
                    <?php esc_html_e('Group Name', 'quick-accountant'); ?>
                    <input type="text" name="group_name" value="<?php echo esc_attr($edit_category['group_name'] ?? ''); ?>" />
                </label>

                <p>
                    <button type="submit" class="button button-primary"><?php esc_html_e('Save Category', 'quick-accountant'); ?></button>
                    <?php if ($edit_category) : ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=quick-accountant-categories')); ?>" class="button"><?php esc_html_e('Cancel', 'quick-accountant'); ?></a>
                    <?php endif; ?>
                </p>
            </form>
        </div>

        <div class="qa-card">
            <h2><?php esc_html_e('Budget Editor', 'quick-accountant'); ?></h2>
            <form method="get" class="qa-inline-form">
                <input type="hidden" name="page" value="quick-accountant-categories" />
                <label>
                    <?php esc_html_e('Month', 'quick-accountant'); ?>
                    <input type="month" name="budget_month" value="<?php echo esc_attr($data['month']); ?>" />
                </label>
                <button type="submit" class="button"><?php esc_html_e('Load', 'quick-accountant'); ?></button>
            </form>

            <form method="post">
                <?php wp_nonce_field('qacc_budgets_action', 'qacc_nonce'); ?>
                <input type="hidden" name="qacc_action" value="save_budgets" />
                <input type="hidden" name="month" value="<?php echo esc_attr($data['month']); ?>" />

                <table class="widefat striped qa-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Category', 'quick-accountant'); ?></th>
                            <th><?php esc_html_e('Budget', 'quick-accountant'); ?></th>
                            <th><?php esc_html_e('Actual (Expense)', 'quick-accountant'); ?></th>
                            <th><?php esc_html_e('Actual (Income)', 'quick-accountant'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data['budgets'] as $row) : ?>
                            <tr>
                                <td><?php echo esc_html($row['name']); ?></td>
                                <td><input type="number" step="0.01" min="0" name="budgets[<?php echo esc_attr($row['category_id']); ?>]" value="<?php echo esc_attr($row['budget_amount']); ?>" /></td>
                                <td><?php echo esc_html(qacc_format_currency($row['actual_expense'])); ?></td>
                                <td><?php echo esc_html(qacc_format_currency($row['actual_income'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <p><button type="submit" class="button button-primary"><?php esc_html_e('Save Budgets', 'quick-accountant'); ?></button></p>
            </form>
        </div>
    </div>

    <div class="qa-card">
        <h2><?php esc_html_e('Category List', 'quick-accountant'); ?></h2>
        <table class="widefat striped qa-table">
            <thead>
                <tr>
                    <th><?php esc_html_e('Name', 'quick-accountant'); ?></th>
                    <th><?php esc_html_e('Kind', 'quick-accountant'); ?></th>
                    <th><?php esc_html_e('Group', 'quick-accountant'); ?></th>
                    <th><?php esc_html_e('Transactions', 'quick-accountant'); ?></th>
                    <th><?php esc_html_e('Actions', 'quick-accountant'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data['categories'] as $category) : ?>
                    <tr>
                        <td><?php echo esc_html($category['name']); ?></td>
                        <td><?php echo esc_html(ucfirst($category['kind'])); ?></td>
                        <td><?php echo esc_html($category['group_name']); ?></td>
                        <td><?php echo esc_html($category['txn_count']); ?></td>
                        <td>
                            <a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=quick-accountant-categories&edit_category=' . absint($category['id']))); ?>"><?php esc_html_e('Edit', 'quick-accountant'); ?></a>
                            <form method="post" class="qa-inline-form" style="display:inline-flex;">
                                <?php wp_nonce_field('qacc_categories_action', 'qacc_nonce'); ?>
                                <input type="hidden" name="qacc_action" value="delete_category" />
                                <input type="hidden" name="id" value="<?php echo esc_attr($category['id']); ?>" />
                                <button type="submit" class="button button-small" onclick="return confirm('Delete this category?');"><?php esc_html_e('Delete', 'quick-accountant'); ?></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
