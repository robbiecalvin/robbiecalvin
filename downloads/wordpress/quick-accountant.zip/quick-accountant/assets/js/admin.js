(function () {
    'use strict';

    function drawLineChart(canvasId, rows) {
        var canvas = document.getElementById(canvasId);
        if (!canvas || !rows || !rows.length) {
            return;
        }

        var ctx = canvas.getContext('2d');
        var w = canvas.width;
        var h = canvas.height;
        var padding = 30;

        ctx.clearRect(0, 0, w, h);

        var maxValue = 0;
        rows.forEach(function (row) {
            var income = parseFloat(row.income || 0);
            var expenses = parseFloat(row.expenses || 0);
            if (income > maxValue) maxValue = income;
            if (expenses > maxValue) maxValue = expenses;
        });
        if (maxValue <= 0) maxValue = 1;

        function y(v) {
            return h - padding - (v / maxValue) * (h - padding * 2);
        }

        function x(i) {
            if (rows.length === 1) return padding;
            return padding + (i / (rows.length - 1)) * (w - padding * 2);
        }

        ctx.strokeStyle = '#ddd';
        ctx.beginPath();
        ctx.moveTo(padding, padding);
        ctx.lineTo(padding, h - padding);
        ctx.lineTo(w - padding, h - padding);
        ctx.stroke();

        ctx.strokeStyle = '#1d4ed8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        rows.forEach(function (row, i) {
            var px = x(i);
            var py = y(parseFloat(row.income || 0));
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        });
        ctx.stroke();

        ctx.strokeStyle = '#dc2626';
        ctx.beginPath();
        rows.forEach(function (row, i) {
            var px = x(i);
            var py = y(parseFloat(row.expenses || 0));
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        });
        ctx.stroke();

        ctx.fillStyle = '#111';
        ctx.font = '12px sans-serif';
        ctx.fillText('Income', padding, 14);
        ctx.fillText('Expenses', padding + 60, 14);
    }

    function drawBarChart(canvasId, rows) {
        var canvas = document.getElementById(canvasId);
        if (!canvas || !rows || !rows.length) {
            return;
        }

        var ctx = canvas.getContext('2d');
        var w = canvas.width;
        var h = canvas.height;
        var padding = 30;
        var chartHeight = h - padding * 2;
        var usableRows = rows.slice(0, 10);

        var maxValue = 0;
        usableRows.forEach(function (row) {
            var v = parseFloat(row.total || 0);
            if (v > maxValue) maxValue = v;
        });
        if (maxValue <= 0) maxValue = 1;

        ctx.clearRect(0, 0, w, h);
        ctx.strokeStyle = '#ddd';
        ctx.strokeRect(padding, padding, w - padding * 2, chartHeight);

        var barSpace = (w - padding * 2) / usableRows.length;
        var barWidth = Math.max(16, barSpace - 8);

        usableRows.forEach(function (row, i) {
            var value = parseFloat(row.total || 0);
            var barHeight = (value / maxValue) * (chartHeight - 20);
            var x = padding + i * barSpace + 4;
            var y = h - padding - barHeight;
            ctx.fillStyle = row.txn_type === 'income' ? '#16a34a' : '#f97316';
            ctx.fillRect(x, y, barWidth, barHeight);
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        var checkAll = document.querySelector('.qa-check-all');
        if (checkAll) {
            checkAll.addEventListener('change', function () {
                var checks = document.querySelectorAll('input[name="txn_ids[]"]');
                checks.forEach(function (box) {
                    box.checked = checkAll.checked;
                });
            });
        }

        if (window.qaCashflowData) {
            drawLineChart('qa-cashflow-chart', window.qaCashflowData);
        }

        if (window.qaCategoryData) {
            drawBarChart('qa-category-chart', window.qaCategoryData);
        }
    });
})();
