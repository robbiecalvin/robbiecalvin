<?php

if (!defined('ABSPATH')) {
    exit;
}

class QACC_Reports
{
    public function get_dashboard_data()
    {
        global $wpdb;

        $settings = qacc_get_settings();
        list($start_date, $end_date, $range) = qacc_get_date_range_from_request($settings['default_date_range']);

        $totals_sql = "SELECT
                COALESCE(SUM(CASE WHEN txn_type = 'income' THEN amount ELSE 0 END), 0) AS income,
                COALESCE(SUM(CASE WHEN txn_type = 'expense' THEN amount ELSE 0 END), 0) AS expenses
            FROM " . qacc_table_transactions() . "
            WHERE txn_date BETWEEN %s AND %s";
        $totals = $wpdb->get_row($wpdb->prepare($totals_sql, $start_date, $end_date), ARRAY_A);

        $income = isset($totals['income']) ? (float) $totals['income'] : 0.0;
        $expenses = isset($totals['expenses']) ? (float) $totals['expenses'] : 0.0;
        $profit = $income - $expenses;
        $margin = $income > 0 ? ($profit / $income) * 100 : null;

        $month = isset($_GET['budget_month']) ? sanitize_text_field(wp_unslash($_GET['budget_month'])) : gmdate('Y-m');
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
            $month = gmdate('Y-m');
        }

        $budget_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT c.name,
                    COALESCE(b.budget_amount, 0) AS budget_amount,
                    COALESCE(SUM(CASE WHEN t.txn_type = 'expense' THEN t.amount ELSE 0 END), 0) AS actual_amount
             FROM " . qacc_table_categories() . " c
             LEFT JOIN " . qacc_table_budgets() . " b ON b.category_id = c.id AND b.month = %s
             LEFT JOIN " . qacc_table_transactions() . " t ON t.category_id = c.id AND DATE_FORMAT(t.txn_date, '%%Y-%%m') = %s
             GROUP BY c.id, c.name, b.budget_amount
             ORDER BY c.name ASC",
            $month,
            $month
        ), ARRAY_A);

        $top_categories = $wpdb->get_results($wpdb->prepare(
            "SELECT c.name, SUM(t.amount) AS total_spend
             FROM " . qacc_table_transactions() . " t
             INNER JOIN " . qacc_table_categories() . " c ON c.id = t.category_id
             WHERE t.txn_type = 'expense' AND t.txn_date BETWEEN %s AND %s
             GROUP BY t.category_id, c.name
             ORDER BY total_spend DESC
             LIMIT 5",
            $start_date,
            $end_date
        ), ARRAY_A);

        $cashflow = $wpdb->get_results($wpdb->prepare(
            "SELECT txn_date,
                    SUM(CASE WHEN txn_type = 'income' THEN amount ELSE 0 END) AS income,
                    SUM(CASE WHEN txn_type = 'expense' THEN amount ELSE 0 END) AS expenses
             FROM " . qacc_table_transactions() . "
             WHERE txn_date BETWEEN %s AND %s
             GROUP BY txn_date
             ORDER BY txn_date ASC",
            $start_date,
            $end_date
        ), ARRAY_A);

        return array(
            'start_date' => $start_date,
            'end_date' => $end_date,
            'range' => $range,
            'income' => $income,
            'expenses' => $expenses,
            'profit' => $profit,
            'margin' => $margin,
            'budget_rows' => $budget_rows,
            'top_categories' => $top_categories,
            'cashflow' => $cashflow,
            'month' => $month,
        );
    }

    public function get_reports_data()
    {
        global $wpdb;

        $start_date = isset($_GET['start_date']) ? sanitize_text_field(wp_unslash($_GET['start_date'])) : gmdate('Y-m-01');
        $end_date = isset($_GET['end_date']) ? sanitize_text_field(wp_unslash($_GET['end_date'])) : gmdate('Y-m-d');

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) {
            $start_date = gmdate('Y-m-01');
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) {
            $end_date = gmdate('Y-m-d');
        }

        $monthly_summary = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE_FORMAT(txn_date, '%%Y-%%m') AS month,
                    SUM(CASE WHEN txn_type = 'income' THEN amount ELSE 0 END) AS income,
                    SUM(CASE WHEN txn_type = 'expense' THEN amount ELSE 0 END) AS expenses
             FROM " . qacc_table_transactions() . "
             WHERE txn_date BETWEEN %s AND %s
             GROUP BY DATE_FORMAT(txn_date, '%%Y-%%m')
             ORDER BY month ASC",
            $start_date,
            $end_date
        ), ARRAY_A);

        $category_breakdown = $wpdb->get_results($wpdb->prepare(
            "SELECT c.name,
                    c.group_name,
                    t.txn_type,
                    SUM(t.amount) AS total
             FROM " . qacc_table_transactions() . " t
             INNER JOIN " . qacc_table_categories() . " c ON c.id = t.category_id
             WHERE t.txn_date BETWEEN %s AND %s
             GROUP BY t.category_id, c.name, c.group_name, t.txn_type
             ORDER BY total DESC",
            $start_date,
            $end_date
        ), ARRAY_A);

        $party_breakdown = $wpdb->get_results($wpdb->prepare(
            "SELECT party_name, txn_type, SUM(amount) AS total
             FROM " . qacc_table_transactions() . "
             WHERE txn_date BETWEEN %s AND %s
               AND party_name IS NOT NULL
               AND party_name <> ''
             GROUP BY party_name, txn_type
             ORDER BY total DESC
             LIMIT 100",
            $start_date,
            $end_date
        ), ARRAY_A);

        $tax_summary = $wpdb->get_results($wpdb->prepare(
            "SELECT txn_type,
                    SUM(tax_amount) AS total_tax,
                    SUM(CASE WHEN tax_included = 1 THEN 1 ELSE 0 END) AS tax_included_count,
                    COUNT(*) AS txn_count
             FROM " . qacc_table_transactions() . "
             WHERE txn_date BETWEEN %s AND %s
             GROUP BY txn_type",
            $start_date,
            $end_date
        ), ARRAY_A);

        $project_profit = $wpdb->get_results($wpdb->prepare(
            "SELECT project_label,
                    SUM(CASE WHEN txn_type = 'income' THEN amount ELSE 0 END) AS income,
                    SUM(CASE WHEN txn_type = 'expense' THEN amount ELSE 0 END) AS expenses
             FROM " . qacc_table_transactions() . "
             WHERE txn_date BETWEEN %s AND %s
               AND project_label IS NOT NULL
               AND project_label <> ''
             GROUP BY project_label
             ORDER BY project_label ASC",
            $start_date,
            $end_date
        ), ARRAY_A);

        return array(
            'start_date' => $start_date,
            'end_date' => $end_date,
            'monthly_summary' => $monthly_summary,
            'category_breakdown' => $category_breakdown,
            'party_breakdown' => $party_breakdown,
            'tax_summary' => $tax_summary,
            'project_profit' => $project_profit,
            'categories' => $this->get_categories(),
        );
    }

    private function get_categories()
    {
        global $wpdb;
        return $wpdb->get_results("SELECT id, name FROM " . qacc_table_categories() . " ORDER BY name ASC", ARRAY_A);
    }
}
