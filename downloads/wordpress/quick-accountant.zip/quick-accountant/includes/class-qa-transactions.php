<?php

if (!defined('ABSPATH')) {
    exit;
}

class QACC_Transactions
{
    public function handle_actions()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        if (!isset($_POST['qacc_action'])) {
            return;
        }

        check_admin_referer('qacc_transactions_action', 'qacc_nonce');

        $action = sanitize_text_field(wp_unslash($_POST['qacc_action']));

        switch ($action) {
            case 'save_transaction':
                $this->save_transaction();
                break;
            case 'delete_transaction':
                $this->delete_transaction();
                break;
            case 'bulk_action':
                $this->handle_bulk_action();
                break;
        }
    }

    public function get_page_data()
    {
        global $wpdb;

        $table = qacc_table_transactions();
        $cat_table = qacc_table_categories();

        $paged = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
        $per_page = 20;
        $offset = ($paged - 1) * $per_page;

        $where = array('1=1');
        $params = array();

        if (!empty($_GET['filter_start']) && !empty($_GET['filter_end'])) {
            $start = sanitize_text_field(wp_unslash($_GET['filter_start']));
            $end = sanitize_text_field(wp_unslash($_GET['filter_end']));
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $start) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
                $where[] = 't.txn_date BETWEEN %s AND %s';
                $params[] = $start;
                $params[] = $end;
            }
        }

        if (!empty($_GET['filter_type'])) {
            $type = sanitize_text_field(wp_unslash($_GET['filter_type']));
            if (in_array($type, array('income', 'expense'), true)) {
                $where[] = 't.txn_type = %s';
                $params[] = $type;
            }
        }

        if (!empty($_GET['filter_category'])) {
            $cat_id = absint($_GET['filter_category']);
            if ($cat_id > 0) {
                $where[] = 't.category_id = %d';
                $params[] = $cat_id;
            }
        }

        if (!empty($_GET['filter_status'])) {
            $status = sanitize_text_field(wp_unslash($_GET['filter_status']));
            if (in_array($status, array('cleared', 'pending'), true)) {
                $where[] = 't.status = %s';
                $params[] = $status;
            }
        }

        if (!empty($_GET['s'])) {
            $s = '%' . $wpdb->esc_like(sanitize_text_field(wp_unslash($_GET['s']))) . '%';
            $where[] = '(t.notes LIKE %s OR t.party_name LIKE %s)';
            $params[] = $s;
            $params[] = $s;
        }

        $where_sql = implode(' AND ', $where);

        $count_sql = "SELECT COUNT(*) FROM {$table} t WHERE {$where_sql}";
        if (!empty($params)) {
            $total_items = (int) $wpdb->get_var($wpdb->prepare($count_sql, $params));
        } else {
            $total_items = (int) $wpdb->get_var($count_sql);
        }

        $sql = "SELECT t.*, c.name AS category_name
                FROM {$table} t
                LEFT JOIN {$cat_table} c ON c.id = t.category_id
                WHERE {$where_sql}
                ORDER BY t.txn_date DESC, t.id DESC
                LIMIT %d OFFSET %d";
        $query_params = array_merge($params, array($per_page, $offset));
        $transactions = $wpdb->get_results($wpdb->prepare($sql, $query_params), ARRAY_A);

        $edit_transaction = null;
        if (!empty($_GET['edit'])) {
            $edit_id = absint($_GET['edit']);
            if ($edit_id > 0) {
                $edit_transaction = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $edit_id), ARRAY_A);
            }
        }

        return array(
            'transactions' => $transactions,
            'categories' => $this->get_categories(),
            'edit_transaction' => $edit_transaction,
            'pagination' => array(
                'total_items' => $total_items,
                'per_page' => $per_page,
                'current_page' => $paged,
                'total_pages' => (int) ceil($total_items / $per_page),
            ),
        );
    }

    private function save_transaction()
    {
        global $wpdb;

        $table = qacc_table_transactions();
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;

        $txn_date = isset($_POST['txn_date']) ? sanitize_text_field(wp_unslash($_POST['txn_date'])) : '';
        $amount = isset($_POST['amount']) ? qacc_sanitize_decimal(wp_unslash($_POST['amount'])) : '0.00';
        $txn_type = isset($_POST['txn_type']) ? sanitize_text_field(wp_unslash($_POST['txn_type'])) : '';
        $category_id = isset($_POST['category_id']) ? absint($_POST['category_id']) : 0;
        $party_name = isset($_POST['party_name']) ? sanitize_text_field(wp_unslash($_POST['party_name'])) : '';
        $payment_method = isset($_POST['payment_method']) ? sanitize_text_field(wp_unslash($_POST['payment_method'])) : '';
        $tax_included = isset($_POST['tax_included']) ? 1 : 0;
        $tax_amount = isset($_POST['tax_amount']) ? qacc_sanitize_decimal(wp_unslash($_POST['tax_amount'])) : '0.00';
        $notes = isset($_POST['notes']) ? sanitize_textarea_field(wp_unslash($_POST['notes'])) : '';
        $status = isset($_POST['status']) ? sanitize_text_field(wp_unslash($_POST['status'])) : 'cleared';
        $project_label = isset($_POST['project_label']) ? sanitize_text_field(wp_unslash($_POST['project_label'])) : '';

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $txn_date)) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Invalid transaction date.');
        }
        if (!in_array($txn_type, array('income', 'expense'), true)) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Invalid transaction type.');
        }
        if ($category_id <= 0) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Category is required.');
        }
        if (!in_array($status, array('cleared', 'pending'), true)) {
            $status = 'cleared';
        }

        $receipt_url = isset($_POST['existing_receipt_url']) ? esc_url_raw(wp_unslash($_POST['existing_receipt_url'])) : '';
        $receipt_attachment_id = isset($_POST['existing_receipt_attachment_id']) ? absint($_POST['existing_receipt_attachment_id']) : 0;
        $settings = qacc_get_settings();

        if (!empty($_FILES['receipt_file']['name'])) {
            if (!qacc_is_premium_active() || empty($settings['receipt_uploads_enabled'])) {
                qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'WooCommerce auto-sync and receipt uploads are available in QuickWoo Pro.');
            }

            $upload_result = $this->handle_receipt_upload();
            if (is_wp_error($upload_result)) {
                qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), $upload_result->get_error_message());
            }
            $receipt_url = $upload_result['url'];
            $receipt_attachment_id = $upload_result['attachment_id'];
        }

        if (empty($settings['enable_project_labels'])) {
            $project_label = '';
        }

        $data = array(
            'txn_date' => $txn_date,
            'amount' => $amount,
            'txn_type' => $txn_type,
            'category_id' => $category_id,
            'party_name' => $party_name,
            'payment_method' => $payment_method,
            'tax_included' => $tax_included,
            'tax_amount' => $tax_amount,
            'notes' => $notes,
            'receipt_url' => $receipt_url,
            'receipt_attachment_id' => $receipt_attachment_id,
            'status' => $status,
            'project_label' => $project_label,
            'updated_at' => current_time('mysql'),
        );
        $formats = array('%s', '%f', '%s', '%d', '%s', '%s', '%d', '%f', '%s', '%s', '%d', '%s', '%s', '%s');

        if ($id > 0) {
            $wpdb->update($table, $data, array('id' => $id), $formats, array('%d'));
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Transaction updated.');
        }

        $data['created_at'] = current_time('mysql');
        $formats[] = '%s';
        $wpdb->insert($table, $data, $formats);
        qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Transaction added.');
    }

    private function delete_transaction()
    {
        global $wpdb;

        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        if ($id <= 0) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Invalid transaction.');
        }

        $wpdb->delete(qacc_table_transactions(), array('id' => $id), array('%d'));
        qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Transaction deleted.');
    }

    private function handle_bulk_action()
    {
        global $wpdb;

        $ids = isset($_POST['txn_ids']) && is_array($_POST['txn_ids']) ? array_map('absint', $_POST['txn_ids']) : array();
        $ids = array_values(array_filter($ids));

        if (empty($ids)) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'No transactions selected.');
        }

        $action = isset($_POST['bulk_action']) ? sanitize_text_field(wp_unslash($_POST['bulk_action'])) : '';
        $table = qacc_table_transactions();
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        if ($action === 'delete') {
            $sql = "DELETE FROM {$table} WHERE id IN ({$placeholders})";
            $wpdb->query($wpdb->prepare($sql, $ids));
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Transactions deleted.');
        }

        if ($action === 'mark_cleared' || $action === 'mark_pending') {
            $status = $action === 'mark_cleared' ? 'cleared' : 'pending';
            $sql = "UPDATE {$table} SET status = %s, updated_at = %s WHERE id IN ({$placeholders})";
            $params = array_merge(array($status, current_time('mysql')), $ids);
            $wpdb->query($wpdb->prepare($sql, $params));
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Transactions updated.');
        }

        if ($action === 'reassign_category') {
            $new_category_id = isset($_POST['reassign_category_id']) ? absint($_POST['reassign_category_id']) : 0;
            if ($new_category_id <= 0) {
                qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Please select a category for reassignment.');
            }
            $sql = "UPDATE {$table} SET category_id = %d, updated_at = %s WHERE id IN ({$placeholders})";
            $params = array_merge(array($new_category_id, current_time('mysql')), $ids);
            $wpdb->query($wpdb->prepare($sql, $params));
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'Category reassigned.');
        }

        qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-transactions'), 'No bulk action performed.');
    }

    private function handle_receipt_upload()
    {
        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
            return new WP_Error('qacc_perm', 'Insufficient permission to upload receipts.');
        }

        if (!function_exists('media_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $file = $_FILES['receipt_file'];
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return new WP_Error('qacc_upload', 'Receipt upload failed.');
        }

        $max_size = qacc_receipt_size_limit_bytes();
        if ((int) $file['size'] > $max_size) {
            return new WP_Error('qacc_upload_size', 'Receipt file exceeds max configured size.');
        }

        $allowed_mimes = qacc_allowed_receipt_mimes();
        $ft = wp_check_filetype_and_ext($file['tmp_name'], $file['name']);
        if (empty($ft['type']) || !in_array($ft['type'], $allowed_mimes, true)) {
            return new WP_Error('qacc_upload_mime', 'Receipt file type is not allowed.');
        }

        add_filter('upload_mimes', array($this, 'filter_receipt_mimes'));
        $attachment_id = media_handle_upload('receipt_file', 0);
        remove_filter('upload_mimes', array($this, 'filter_receipt_mimes'));

        if (is_wp_error($attachment_id)) {
            return new WP_Error('qacc_upload_error', $attachment_id->get_error_message());
        }

        $url = wp_get_attachment_url($attachment_id);
        if (!$url) {
            return new WP_Error('qacc_upload_url', 'Could not get receipt URL.');
        }

        return array(
            'url' => esc_url_raw($url),
            'attachment_id' => absint($attachment_id),
        );
    }

    public function filter_receipt_mimes($mimes)
    {
        $allowed = qacc_allowed_receipt_mimes();
        $map = qacc_mime_to_ext_map();
        $filtered = array();

        foreach ($allowed as $mime) {
            if (isset($map[$mime])) {
                $filtered[$map[$mime]] = $mime;
            }
        }

        return !empty($filtered) ? $filtered : $mimes;
    }

    private function get_categories()
    {
        global $wpdb;

        return $wpdb->get_results(
            "SELECT id, name, kind FROM " . qacc_table_categories() . " ORDER BY name ASC",
            ARRAY_A
        );
    }
}
