<?php

if (!defined('ABSPATH')) {
    exit;
}

class QACC_Admin
{
    private static $instance = null;
    private $transactions;
    private $categories;
    private $budgets;
    private $reports;
    private $settings;
    private $export;

    public static function instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->transactions = new QACC_Transactions();
        $this->categories = new QACC_Categories();
        $this->budgets = new QACC_Budgets();
        $this->reports = new QACC_Reports();
        $this->settings = new QACC_Settings();
        $this->export = new QACC_Export();

        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_init', array($this, 'route_actions'));
    }

    public function register_menu()
    {
        if (!qacc_user_can_access()) {
            return;
        }

        $cap = qacc_current_capability();

        add_menu_page(
            __('Quick Accountant', 'quick-accountant'),
            __('Quick Accountant', 'quick-accountant'),
            $cap,
            'quick-accountant',
            array($this, 'render_dashboard_page'),
            'dashicons-chart-bar',
            58
        );

        add_submenu_page('quick-accountant', __('Dashboard', 'quick-accountant'), __('Dashboard', 'quick-accountant'), $cap, 'quick-accountant', array($this, 'render_dashboard_page'));
        add_submenu_page('quick-accountant', __('Transactions', 'quick-accountant'), __('Transactions', 'quick-accountant'), $cap, 'quick-accountant-transactions', array($this, 'render_transactions_page'));
        add_submenu_page('quick-accountant', __('Categories & Budgets', 'quick-accountant'), __('Categories & Budgets', 'quick-accountant'), $cap, 'quick-accountant-categories', array($this, 'render_categories_page'));
        add_submenu_page('quick-accountant', __('Reports', 'quick-accountant'), __('Reports', 'quick-accountant'), $cap, 'quick-accountant-reports', array($this, 'render_reports_page'));
        add_submenu_page('quick-accountant', __('Settings', 'quick-accountant'), __('Settings', 'quick-accountant'), $cap, 'quick-accountant-settings', array($this, 'render_settings_page'));
    }

    public function enqueue_assets($hook)
    {
        if (strpos((string) $hook, 'quick-accountant') === false) {
            return;
        }

        wp_enqueue_style('qa-admin', QACC_PLUGIN_URL . 'assets/css/admin.css', array(), QACC_PLUGIN_VERSION);
        wp_enqueue_style('qa-admin-ui', QACC_PLUGIN_URL . 'assets/css/admin-ui.css', array('qa-admin'), QACC_PLUGIN_VERSION);
        wp_enqueue_script('qa-admin', QACC_PLUGIN_URL . 'assets/js/admin.js', array(), QACC_PLUGIN_VERSION, true);
        wp_enqueue_script('qa-admin-ui', QACC_PLUGIN_URL . 'assets/js/admin-ui.js', array('qa-admin'), QACC_PLUGIN_VERSION, true);

        wp_localize_script('qa-admin', 'qaAdmin', array(
            'currencySymbol' => qacc_get_settings()['currency_symbol'],
        ));
    }

    public function route_actions()
    {
        if (!is_admin() || !qacc_user_can_access()) {
            return;
        }

        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        if ($page === 'quick-accountant-transactions') {
            $this->transactions->handle_actions();
        }

        if ($page === 'quick-accountant-categories') {
            $this->categories->handle_actions();
            $this->budgets->handle_actions();
        }

        if ($page === 'quick-accountant-settings') {
            $this->settings->handle_actions();
        }

        if ($page === 'quick-accountant-reports') {
            $this->export->handle_actions();
        }
    }

    public function render_dashboard_page()
    {
        if (!qacc_user_can_access()) {
            wp_die(esc_html__('You are not allowed to access this page.', 'quick-accountant'));
        }

        $data = $this->reports->get_dashboard_data();
        include QACC_PLUGIN_DIR . 'templates/dashboard.php';
    }

    public function render_transactions_page()
    {
        if (!qacc_user_can_access()) {
            wp_die(esc_html__('You are not allowed to access this page.', 'quick-accountant'));
        }

        $data = $this->transactions->get_page_data();
        include QACC_PLUGIN_DIR . 'templates/transactions.php';
    }

    public function render_categories_page()
    {
        if (!qacc_user_can_access()) {
            wp_die(esc_html__('You are not allowed to access this page.', 'quick-accountant'));
        }

        $data = array(
            'categories' => $this->categories->get_categories(),
            'month' => $this->budgets->get_selected_month(),
            'budgets' => $this->budgets->get_budgets_with_actuals($this->budgets->get_selected_month()),
        );

        include QACC_PLUGIN_DIR . 'templates/categories.php';
    }

    public function render_reports_page()
    {
        if (!qacc_user_can_access()) {
            wp_die(esc_html__('You are not allowed to access this page.', 'quick-accountant'));
        }

        $data = $this->reports->get_reports_data();
        include QACC_PLUGIN_DIR . 'templates/reports.php';
    }

    public function render_settings_page()
    {
        if (!qacc_user_can_access()) {
            wp_die(esc_html__('You are not allowed to access this page.', 'quick-accountant'));
        }

        $data = array(
            'settings' => qacc_get_settings(),
        );
        include QACC_PLUGIN_DIR . 'templates/settings.php';
    }
}
