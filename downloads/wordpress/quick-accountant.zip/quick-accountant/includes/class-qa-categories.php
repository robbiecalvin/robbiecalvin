<?php

if (!defined('ABSPATH')) {
    exit;
}

class QACC_Categories
{
    public function handle_actions()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        if (empty($_POST['qacc_action'])) {
            return;
        }

        $action = sanitize_text_field(wp_unslash($_POST['qacc_action']));
        if (!in_array($action, array('save_category', 'delete_category'), true)) {
            return;
        }

        check_admin_referer('qacc_categories_action', 'qacc_nonce');

        if ($action === 'save_category') {
            $this->save_category();
        }

        if ($action === 'delete_category') {
            $this->delete_category();
        }
    }

    public function get_categories()
    {
        global $wpdb;

        return $wpdb->get_results(
            "SELECT c.*,
                (SELECT COUNT(*) FROM " . qacc_table_transactions() . " t WHERE t.category_id = c.id) AS txn_count
             FROM " . qacc_table_categories() . " c
             ORDER BY c.name ASC",
            ARRAY_A
        );
    }

    private function save_category()
    {
        global $wpdb;

        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $kind = isset($_POST['kind']) ? sanitize_text_field(wp_unslash($_POST['kind'])) : 'both';
        $group_name = isset($_POST['group_name']) ? sanitize_text_field(wp_unslash($_POST['group_name'])) : '';

        if ($name === '') {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-categories'), 'Category name is required.');
        }

        if (!in_array($kind, array('income', 'expense', 'both'), true)) {
            $kind = 'both';
        }

        $table = qacc_table_categories();

        if ($id > 0) {
            $wpdb->update(
                $table,
                array(
                    'name' => $name,
                    'kind' => $kind,
                    'group_name' => $group_name,
                ),
                array('id' => $id),
                array('%s', '%s', '%s'),
                array('%d')
            );
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-categories'), 'Category updated.');
        }

        $wpdb->insert(
            $table,
            array(
                'name' => $name,
                'kind' => $kind,
                'group_name' => $group_name,
                'created_at' => current_time('mysql'),
            ),
            array('%s', '%s', '%s', '%s')
        );

        qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-categories'), 'Category created.');
    }

    private function delete_category()
    {
        global $wpdb;

        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        if ($id <= 0) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-categories'), 'Invalid category.');
        }

        $txn_count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . qacc_table_transactions() . " WHERE category_id = %d",
            $id
        ));

        if ($txn_count > 0) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-categories'), 'Cannot delete category with transactions attached.');
        }

        $wpdb->delete(qacc_table_categories(), array('id' => $id), array('%d'));
        $wpdb->delete(qacc_table_budgets(), array('category_id' => $id), array('%d'));

        qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-categories'), 'Category deleted.');
    }
}
