<?php

if (!defined('ABSPATH')) {
    exit;
}

class QACC_Budgets
{
    public function handle_actions()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        if (empty($_POST['qacc_action']) || sanitize_text_field(wp_unslash($_POST['qacc_action'])) !== 'save_budgets') {
            return;
        }

        check_admin_referer('qacc_budgets_action', 'qacc_nonce');
        $this->save_budgets();
    }

    public function get_selected_month()
    {
        if (!empty($_GET['budget_month'])) {
            $month = sanitize_text_field(wp_unslash($_GET['budget_month']));
            if (preg_match('/^\d{4}-\d{2}$/', $month)) {
                return $month;
            }
        }
        return gmdate('Y-m');
    }

    public function get_budgets_with_actuals($month)
    {
        global $wpdb;

        $start = $month . '-01';
        $end = gmdate('Y-m-t', strtotime($start));

        $sql = "SELECT c.id AS category_id,
                    c.name,
                    c.kind,
                    c.group_name,
                    COALESCE(b.budget_amount, 0) AS budget_amount,
                    COALESCE(SUM(CASE WHEN t.txn_type = 'expense' THEN t.amount ELSE 0 END), 0) AS actual_expense,
                    COALESCE(SUM(CASE WHEN t.txn_type = 'income' THEN t.amount ELSE 0 END), 0) AS actual_income
                FROM " . qacc_table_categories() . " c
                LEFT JOIN " . qacc_table_budgets() . " b ON b.category_id = c.id AND b.month = %s
                LEFT JOIN " . qacc_table_transactions() . " t ON t.category_id = c.id AND t.txn_date BETWEEN %s AND %s
                GROUP BY c.id, c.name, c.kind, c.group_name, b.budget_amount
                ORDER BY c.name ASC";

        return $wpdb->get_results($wpdb->prepare($sql, $month, $start, $end), ARRAY_A);
    }

    private function save_budgets()
    {
        global $wpdb;

        $month = isset($_POST['month']) ? sanitize_text_field(wp_unslash($_POST['month'])) : '';
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-categories'), 'Invalid budget month.');
        }

        $budgets = isset($_POST['budgets']) && is_array($_POST['budgets']) ? $_POST['budgets'] : array();
        $table = qacc_table_budgets();

        foreach ($budgets as $category_id => $amount) {
            $cat_id = absint($category_id);
            if ($cat_id <= 0) {
                continue;
            }

            $decimal = qacc_sanitize_decimal(wp_unslash($amount));

            $exists = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$table} WHERE category_id = %d AND month = %s",
                $cat_id,
                $month
            ));

            if ($exists > 0) {
                $wpdb->update(
                    $table,
                    array('budget_amount' => $decimal),
                    array('id' => $exists),
                    array('%f'),
                    array('%d')
                );
            } else {
                $wpdb->insert(
                    $table,
                    array(
                        'category_id' => $cat_id,
                        'month' => $month,
                        'budget_amount' => $decimal,
                    ),
                    array('%d', '%s', '%f')
                );
            }
        }

        qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-categories&budget_month=' . rawurlencode($month)), 'Budgets saved.');
    }
}
