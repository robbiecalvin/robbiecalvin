<?php

if (!defined('ABSPATH')) {
    exit;
}

class QACC_Export
{
    public function handle_actions()
    {
        if (empty($_GET['qacc_export'])) {
            return;
        }

        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'qacc_export')) {
            wp_die(esc_html__('Invalid export nonce.', 'quick-accountant'));
        }

        $type = sanitize_text_field(wp_unslash($_GET['qacc_export']));

        switch ($type) {
            case 'all':
                $this->export_transactions_csv();
                break;
            case 'category':
                $this->export_transactions_csv(absint($_GET['category_id'] ?? 0));
                break;
            case 'month':
                $month = sanitize_text_field(wp_unslash($_GET['month'] ?? ''));
                $this->export_transactions_csv(0, $month);
                break;
        }
    }

    public function export_data_json()
    {
        global $wpdb;

        $data = array(
            'settings' => qacc_get_settings(),
            'categories' => $wpdb->get_results("SELECT * FROM " . qacc_table_categories() . " ORDER BY id ASC", ARRAY_A),
            'budgets' => $wpdb->get_results("SELECT * FROM " . qacc_table_budgets() . " ORDER BY id ASC", ARRAY_A),
            'transactions' => $wpdb->get_results("SELECT * FROM " . qacc_table_transactions() . " ORDER BY id ASC", ARRAY_A),
        );

        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="quick-accountant-export-' . gmdate('Ymd-His') . '.json"');
        echo wp_json_encode($data, JSON_PRETTY_PRINT);
        exit;
    }

    private function export_transactions_csv($category_id = 0, $month = '')
    {
        global $wpdb;

        $where = array('1=1');
        $params = array();

        if ($category_id > 0) {
            $where[] = 't.category_id = %d';
            $params[] = $category_id;
        }

        if ($month !== '' && preg_match('/^\d{4}-\d{2}$/', $month)) {
            $where[] = "DATE_FORMAT(t.txn_date, '%%Y-%%m') = %s";
            $params[] = $month;
        }

        $sql = "SELECT t.id, t.txn_date, t.amount, t.txn_type, c.name AS category_name,
                    t.party_name, t.payment_method, t.tax_included, t.tax_amount,
                    t.notes, t.receipt_url, t.status, t.project_label, t.created_at, t.updated_at
                FROM " . qacc_table_transactions() . " t
                LEFT JOIN " . qacc_table_categories() . " c ON c.id = t.category_id
                WHERE " . implode(' AND ', $where) . "
                ORDER BY t.txn_date DESC, t.id DESC";

        $rows = empty($params)
            ? $wpdb->get_results($sql, ARRAY_A)
            : $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);

        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="quick-accountant-transactions-' . gmdate('Ymd-His') . '.csv"');

        $out = fopen('php://output', 'w');
        fputcsv($out, array(
            'ID', 'Date', 'Amount', 'Type', 'Category', 'Vendor/Client', 'Payment Method',
            'Tax Included', 'Tax Amount', 'Notes', 'Receipt URL', 'Status', 'Project Label', 'Created At', 'Updated At',
        ));

        foreach ($rows as $row) {
            fputcsv($out, array(
                $row['id'],
                $row['txn_date'],
                $row['amount'],
                $row['txn_type'],
                $row['category_name'],
                $row['party_name'],
                $row['payment_method'],
                $row['tax_included'],
                $row['tax_amount'],
                $row['notes'],
                $row['receipt_url'],
                $row['status'],
                $row['project_label'],
                $row['created_at'],
                $row['updated_at'],
            ));
        }

        fclose($out);
        exit;
    }
}
