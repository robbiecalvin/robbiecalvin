<?php

if (!defined('ABSPATH')) {
    exit;
}

class QACC_Settings
{
    public function handle_actions()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['qacc_action'])) {
            return;
        }

        $action = sanitize_text_field(wp_unslash($_POST['qacc_action']));

        if ($action === 'save_settings') {
            check_admin_referer('qacc_settings_action', 'qacc_nonce');
            $this->save_settings();
        }

        if ($action === 'import_data_json') {
            check_admin_referer('qacc_settings_action', 'qacc_nonce');
            $this->import_data_json();
        }

        if ($action === 'export_data_json') {
            check_admin_referer('qacc_settings_action', 'qacc_nonce');
            $exporter = new QACC_Export();
            $exporter->export_data_json();
        }

        if ($action === 'wipe_all_data') {
            check_admin_referer('qacc_settings_action', 'qacc_nonce');
            $this->wipe_all_data();
        }
    }

    private function save_settings()
    {
        $settings = qacc_get_settings();
        $premium_enabled = qacc_is_premium_active();

        $settings['currency_symbol'] = isset($_POST['currency_symbol']) ? sanitize_text_field(wp_unslash($_POST['currency_symbol'])) : '$';
        $settings['default_date_range'] = isset($_POST['default_date_range']) ? sanitize_text_field(wp_unslash($_POST['default_date_range'])) : '30d';
        if (!in_array($settings['default_date_range'], array('7d', '30d', 'month'), true)) {
            $settings['default_date_range'] = '30d';
        }

        $settings['receipt_uploads_enabled'] = $premium_enabled && isset($_POST['receipt_uploads_enabled']) ? 1 : 0;
        $settings['receipt_max_size_mb'] = isset($_POST['receipt_max_size_mb']) ? max(1, absint($_POST['receipt_max_size_mb'])) : 5;
        $settings['enable_woo_auto_sync'] = $premium_enabled && isset($_POST['enable_woo_auto_sync']) ? 1 : 0;

        $mimes = isset($_POST['allowed_mime_types']) ? sanitize_text_field(wp_unslash($_POST['allowed_mime_types'])) : '';
        $settings['allowed_mime_types'] = $mimes;

        $settings['enable_project_labels'] = isset($_POST['enable_project_labels']) ? 1 : 0;
        $settings['data_retention_days'] = isset($_POST['data_retention_days']) ? max(0, absint($_POST['data_retention_days'])) : 0;

        $access_capability = isset($_POST['access_capability']) ? sanitize_key(wp_unslash($_POST['access_capability'])) : 'manage_options';
        if (!in_array($access_capability, array('manage_options', 'manage_quick_accountant'), true)) {
            $access_capability = 'manage_options';
        }
        $settings['access_capability'] = $access_capability;

        update_option(QACC_SETTINGS_OPTION, $settings);

        $this->cleanup_old_receipts_if_needed($settings['data_retention_days']);

        qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-settings'), 'Settings saved.');
    }

    private function import_data_json()
    {
        if (empty($_FILES['import_json']['name'])) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-settings'), 'Please select a JSON file to import.');
        }

        $file = $_FILES['import_json'];
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-settings'), 'Invalid import file upload.');
        }

        $contents = file_get_contents($file['tmp_name']);
        if ($contents === false) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-settings'), 'Could not read import file.');
        }

        $data = json_decode($contents, true);
        if (!is_array($data) || !isset($data['transactions'], $data['categories'], $data['budgets'], $data['settings'])) {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-settings'), 'Invalid JSON format.');
        }

        global $wpdb;
        $wpdb->query('START TRANSACTION');
        try {
            $wpdb->query('DELETE FROM ' . qacc_table_transactions());
            $wpdb->query('DELETE FROM ' . qacc_table_budgets());
            $wpdb->query('DELETE FROM ' . qacc_table_categories());

            foreach ($data['categories'] as $row) {
                $wpdb->insert(
                    qacc_table_categories(),
                    array(
                        'id' => isset($row['id']) ? absint($row['id']) : null,
                        'name' => isset($row['name']) ? sanitize_text_field($row['name']) : '',
                        'kind' => isset($row['kind']) ? sanitize_text_field($row['kind']) : 'both',
                        'group_name' => isset($row['group_name']) ? sanitize_text_field($row['group_name']) : '',
                        'created_at' => isset($row['created_at']) ? sanitize_text_field($row['created_at']) : current_time('mysql'),
                    ),
                    array('%d', '%s', '%s', '%s', '%s')
                );
            }

            foreach ($data['transactions'] as $row) {
                $wpdb->insert(
                    qacc_table_transactions(),
                    array(
                        'id' => isset($row['id']) ? absint($row['id']) : null,
                        'txn_date' => isset($row['txn_date']) ? sanitize_text_field($row['txn_date']) : gmdate('Y-m-d'),
                        'amount' => isset($row['amount']) ? qacc_sanitize_decimal($row['amount']) : '0.00',
                        'txn_type' => isset($row['txn_type']) ? sanitize_text_field($row['txn_type']) : 'expense',
                        'category_id' => isset($row['category_id']) ? absint($row['category_id']) : 0,
                        'party_name' => isset($row['party_name']) ? sanitize_text_field($row['party_name']) : '',
                        'payment_method' => isset($row['payment_method']) ? sanitize_text_field($row['payment_method']) : '',
                        'tax_included' => !empty($row['tax_included']) ? 1 : 0,
                        'tax_amount' => isset($row['tax_amount']) ? qacc_sanitize_decimal($row['tax_amount']) : '0.00',
                        'notes' => isset($row['notes']) ? sanitize_textarea_field($row['notes']) : '',
                        'receipt_url' => isset($row['receipt_url']) ? esc_url_raw($row['receipt_url']) : '',
                        'receipt_attachment_id' => isset($row['receipt_attachment_id']) ? absint($row['receipt_attachment_id']) : 0,
                        'status' => isset($row['status']) ? sanitize_text_field($row['status']) : 'cleared',
                        'project_label' => isset($row['project_label']) ? sanitize_text_field($row['project_label']) : '',
                        'created_at' => isset($row['created_at']) ? sanitize_text_field($row['created_at']) : current_time('mysql'),
                        'updated_at' => isset($row['updated_at']) ? sanitize_text_field($row['updated_at']) : current_time('mysql'),
                    ),
                    array('%d', '%s', '%f', '%s', '%d', '%s', '%s', '%d', '%f', '%s', '%d', '%s', '%s', '%s', '%s')
                );
            }

            foreach ($data['budgets'] as $row) {
                $wpdb->insert(
                    qacc_table_budgets(),
                    array(
                        'id' => isset($row['id']) ? absint($row['id']) : null,
                        'category_id' => isset($row['category_id']) ? absint($row['category_id']) : 0,
                        'month' => isset($row['month']) ? sanitize_text_field($row['month']) : gmdate('Y-m'),
                        'budget_amount' => isset($row['budget_amount']) ? qacc_sanitize_decimal($row['budget_amount']) : '0.00',
                    ),
                    array('%d', '%d', '%s', '%f')
                );
            }

            update_option(QACC_SETTINGS_OPTION, wp_parse_args($data['settings'], qacc_default_settings()));
            $wpdb->query('COMMIT');
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-settings'), 'Import failed.');
        }

        qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-settings'), 'Data import completed.');
    }

    private function wipe_all_data()
    {
        $confirm = isset($_POST['wipe_confirmation']) ? sanitize_text_field(wp_unslash($_POST['wipe_confirmation'])) : '';
        if ($confirm !== 'WIPE') {
            qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-settings'), 'Type WIPE to confirm data deletion.');
        }

        global $wpdb;
        $wpdb->query('DELETE FROM ' . qacc_table_transactions());
        $wpdb->query('DELETE FROM ' . qacc_table_budgets());
        $wpdb->query('DELETE FROM ' . qacc_table_categories());

        delete_option(QACC_SETTINGS_OPTION);
        add_option(QACC_SETTINGS_OPTION, qacc_default_settings());

        qacc_redirect_with_notice(admin_url('admin.php?page=quick-accountant-settings'), 'All Quick Accountant data wiped.');
    }

    private function cleanup_old_receipts_if_needed($days)
    {
        if ($days <= 0) {
            return;
        }

        global $wpdb;
        $cutoff = gmdate('Y-m-d', strtotime('-' . absint($days) . ' days'));

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, receipt_url, receipt_attachment_id
             FROM " . qacc_table_transactions() . "
             WHERE receipt_url IS NOT NULL
               AND receipt_url <> ''
               AND txn_date < %s",
            $cutoff
        ), ARRAY_A);

        foreach ($rows as $row) {
            $attachment_id = isset($row['receipt_attachment_id']) ? absint($row['receipt_attachment_id']) : 0;
            if ($attachment_id > 0) {
                wp_delete_attachment($attachment_id, true);
            } else {
                $url = isset($row['receipt_url']) ? esc_url_raw($row['receipt_url']) : '';
                if ($url !== '') {
                    $fallback_id = attachment_url_to_postid($url);
                    if ($fallback_id > 0) {
                        wp_delete_attachment($fallback_id, true);
                    }
                }
            }

            $wpdb->update(
                qacc_table_transactions(),
                array('receipt_url' => '', 'receipt_attachment_id' => 0),
                array('id' => absint($row['id'])),
                array('%s', '%d'),
                array('%d')
            );
        }
    }
}
