<?php

if (!defined('ABSPATH')) {
    exit;
}

function qacc_table_transactions()
{
    global $wpdb;
    return $wpdb->prefix . 'quick_accountant_transactions';
}

function qacc_table_categories()
{
    global $wpdb;
    return $wpdb->prefix . 'quick_accountant_categories';
}

function qacc_table_budgets()
{
    global $wpdb;
    return $wpdb->prefix . 'quick_accountant_budgets';
}

function qacc_table_ledger()
{
    global $wpdb;
    return $wpdb->prefix . 'quickwoo_ledger';
}

function qacc_default_settings()
{
    return array(
        'currency_symbol' => '$',
        'default_date_range' => '30d',
        'receipt_uploads_enabled' => 1,
        'receipt_max_size_mb' => 5,
        'allowed_mime_types' => 'image/jpeg,image/png,application/pdf',
        'enable_project_labels' => 1,
        'enable_woo_auto_sync' => 1,
        'data_retention_days' => 0,
        'access_capability' => 'manage_options',
    );
}

function qacc_get_settings()
{
    $settings = get_option(QACC_SETTINGS_OPTION, array());
    return wp_parse_args(is_array($settings) ? $settings : array(), qacc_default_settings());
}

function qacc_current_capability()
{
    $settings = qacc_get_settings();
    $cap = !empty($settings['access_capability']) ? sanitize_key($settings['access_capability']) : 'manage_options';
    if ($cap !== 'manage_options' && $cap !== 'manage_quick_accountant') {
        $cap = 'manage_options';
    }
    return $cap;
}

function qacc_user_can_access()
{
    return current_user_can(qacc_current_capability()) || current_user_can('manage_options');
}

function qacc_sanitize_decimal($value)
{
    $normalized = preg_replace('/[^0-9.\-]/', '', (string) $value);
    if ($normalized === '' || !is_numeric($normalized)) {
        return '0.00';
    }
    return number_format((float) $normalized, 2, '.', '');
}

function qacc_get_date_range_from_request($default = '30d')
{
    $range = isset($_GET['range']) ? sanitize_text_field(wp_unslash($_GET['range'])) : $default;
    $today = gmdate('Y-m-d');

    if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
        $start = sanitize_text_field(wp_unslash($_GET['start_date']));
        $end = sanitize_text_field(wp_unslash($_GET['end_date']));
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $start) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
            return array($start, $end, 'custom');
        }
    }

    switch ($range) {
        case '7d':
            return array(gmdate('Y-m-d', strtotime('-6 days')), $today, '7d');
        case 'month':
            return array(gmdate('Y-m-01'), $today, 'month');
        case '30d':
        default:
            return array(gmdate('Y-m-d', strtotime('-29 days')), $today, '30d');
    }
}

function qacc_format_currency($amount)
{
    $settings = qacc_get_settings();
    $symbol = isset($settings['currency_symbol']) ? $settings['currency_symbol'] : '$';
    return esc_html($symbol) . number_format((float) $amount, 2);
}

function qacc_allowed_receipt_mimes()
{
    $settings = qacc_get_settings();
    $raw = isset($settings['allowed_mime_types']) ? (string) $settings['allowed_mime_types'] : '';
    $parts = array_filter(array_map('trim', explode(',', $raw)));
    $allowed = array();
    foreach ($parts as $mime) {
        if (preg_match('/^[a-z0-9\-\.]+\/[a-z0-9\-\.\+]+$/i', $mime)) {
            $allowed[] = strtolower($mime);
        }
    }
    if (empty($allowed)) {
        $allowed = array('image/jpeg', 'image/png', 'application/pdf');
    }
    return $allowed;
}

function qacc_mime_to_ext_map()
{
    return array(
        'image/jpeg' => 'jpg|jpeg',
        'image/png' => 'png',
        'application/pdf' => 'pdf',
    );
}

function qacc_receipt_size_limit_bytes()
{
    $settings = qacc_get_settings();
    $mb = isset($settings['receipt_max_size_mb']) ? absint($settings['receipt_max_size_mb']) : 5;
    if ($mb < 1) {
        $mb = 1;
    }
    return $mb * 1024 * 1024;
}

function qacc_admin_notice($message, $type = 'success')
{
    if (!isset($_GET['qacc_notice'])) {
        return;
    }

    $notice = sanitize_text_field(wp_unslash($_GET['qacc_notice']));
    if ($notice !== $message) {
        return;
    }

    $class = $type === 'error' ? 'notice notice-error' : 'notice notice-success';
    echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($notice) . '</p></div>';
}

function qacc_redirect_with_notice($url, $message)
{
    $location = add_query_arg('qacc_notice', rawurlencode($message), $url);
    wp_safe_redirect($location);
    exit;
}
