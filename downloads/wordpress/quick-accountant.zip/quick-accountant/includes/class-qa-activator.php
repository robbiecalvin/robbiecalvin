<?php

if (!defined('ABSPATH')) {
    exit;
}

class QACC_Activator
{
    public static function activate()
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $transactions = qacc_table_transactions();
        $categories = qacc_table_categories();
        $budgets = qacc_table_budgets();
        $ledger = qacc_table_ledger();

        $sql_transactions = "CREATE TABLE {$transactions} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            txn_date DATE NOT NULL,
            amount DECIMAL(12,2) NOT NULL,
            txn_type VARCHAR(10) NOT NULL,
            category_id BIGINT UNSIGNED NOT NULL,
            party_name VARCHAR(255) NULL,
            payment_method VARCHAR(100) NULL,
            tax_included TINYINT(1) NOT NULL DEFAULT 0,
            tax_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            notes TEXT NULL,
            receipt_url TEXT NULL,
            receipt_attachment_id BIGINT UNSIGNED NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'cleared',
            project_label VARCHAR(191) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY txn_date (txn_date),
            KEY category_id (category_id),
            KEY txn_type (txn_type),
            KEY status (status)
        ) {$charset_collate};";

        $sql_categories = "CREATE TABLE {$categories} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(191) NOT NULL,
            kind VARCHAR(20) NOT NULL DEFAULT 'both',
            group_name VARCHAR(191) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY uq_name (name)
        ) {$charset_collate};";

        $sql_budgets = "CREATE TABLE {$budgets} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            category_id BIGINT UNSIGNED NOT NULL,
            month VARCHAR(7) NOT NULL,
            budget_amount DECIMAL(12,2) NOT NULL,
            PRIMARY KEY  (id),
            KEY category_id (category_id),
            KEY month (month),
            UNIQUE KEY uq_category_month (category_id, month)
        ) {$charset_collate};";

        $sql_ledger = "CREATE TABLE {$ledger} (
            entry_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            type VARCHAR(20) NOT NULL,
            source VARCHAR(50) NOT NULL,
            order_id BIGINT UNSIGNED NULL,
            gross_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            tax_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            net_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            customer_name VARCHAR(255) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (entry_id),
            UNIQUE KEY uq_source_order (source, order_id),
            KEY source (source),
            KEY order_id (order_id),
            KEY created_at (created_at)
        ) {$charset_collate};";

        dbDelta($sql_transactions);
        dbDelta($sql_categories);
        dbDelta($sql_budgets);
        dbDelta($sql_ledger);

        $role = get_role('administrator');
        if ($role && !$role->has_cap('manage_quick_accountant')) {
            $role->add_cap('manage_quick_accountant');
        }

        if (!get_option(QACC_SETTINGS_OPTION)) {
            add_option(QACC_SETTINGS_OPTION, qacc_default_settings());
        }

        self::seed_default_categories();
    }

    private static function seed_default_categories()
    {
        global $wpdb;

        $table = qacc_table_categories();
        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        if ($count > 0) {
            return;
        }

        $now = current_time('mysql');
        $defaults = array(
            array('Office Supplies', 'expense', 'Ops'),
            array('Software', 'expense', 'Ops'),
            array('Advertising', 'expense', 'Marketing'),
            array('Contractor Payments', 'expense', 'Ops'),
            array('Client Revenue', 'income', 'Revenue'),
            array('Affiliate Revenue', 'income', 'Revenue'),
        );

        foreach ($defaults as $row) {
            $wpdb->insert(
                $table,
                array(
                    'name' => $row[0],
                    'kind' => $row[1],
                    'group_name' => $row[2],
                    'created_at' => $now,
                ),
                array('%s', '%s', '%s', '%s')
            );
        }
    }
}
