<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QPNT_Activator {
    public static function activate() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        $balances = qpnt_table( 'quick_points_balances' );
        $tx       = qpnt_table( 'quick_points_transactions' );
        $tiers    = qpnt_table( 'quick_points_tiers' );
        $exp      = qpnt_table( 'quick_points_expirations' );

        $sql_balances = "CREATE TABLE {$balances} (
            user_id BIGINT(20) UNSIGNED NOT NULL,
            total_points BIGINT(20) NOT NULL DEFAULT 0,
            lifetime_points BIGINT(20) NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (user_id),
            KEY updated_at (updated_at)
        ) {$charset};";

        $sql_tx = "CREATE TABLE {$tx} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            points_change INT(11) NOT NULL,
            type VARCHAR(50) NOT NULL,
            reference_id BIGINT(20) UNSIGNED NULL DEFAULT NULL,
            description TEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY type (type),
            KEY created_at (created_at),
            KEY reference_id (reference_id)
        ) {$charset};";

        $sql_tiers = "CREATE TABLE {$tiers} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(100) NOT NULL,
            threshold INT(11) NOT NULL DEFAULT 0,
            multiplier DECIMAL(4,2) NOT NULL DEFAULT 1.00,
            PRIMARY KEY (id),
            KEY threshold (threshold)
        ) {$charset};";

        $sql_exp = "CREATE TABLE {$exp} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            points INT(11) NOT NULL,
            earned_at DATETIME NOT NULL,
            expires_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY expires_at (expires_at)
        ) {$charset};";

        dbDelta( $sql_balances );
        dbDelta( $sql_tx );
        dbDelta( $sql_tiers );
        dbDelta( $sql_exp );

        if ( false === get_option( 'qpnt_settings', false ) ) {
            add_option( 'qpnt_settings', qpnt_default_settings() );
        }

        if ( false === get_option( 'qpnt_activity_log', false ) ) {
            add_option( 'qpnt_activity_log', array() );
        }

        self::seed_tiers_if_missing();

        if ( ! wp_next_scheduled( 'qpnt_daily_expiry_event' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'qpnt_daily_expiry_event' );
        }
    }

    public static function deactivate() {
        wp_clear_scheduled_hook( 'qpnt_daily_expiry_event' );
    }

    private static function seed_tiers_if_missing() {
        global $wpdb;
        $table = qpnt_table( 'quick_points_tiers' );

        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        if ( $count > 0 ) {
            return;
        }

        $rows = array(
            array( 'name' => 'Bronze', 'threshold' => 0, 'multiplier' => 1.00 ),
            array( 'name' => 'Silver', 'threshold' => 1000, 'multiplier' => 1.50 ),
            array( 'name' => 'Gold', 'threshold' => 5000, 'multiplier' => 2.00 ),
        );

        foreach ( $rows as $row ) {
            $wpdb->insert(
                $table,
                array(
                    'name'       => $row['name'],
                    'threshold'  => $row['threshold'],
                    'multiplier' => $row['multiplier'],
                ),
                array( '%s', '%d', '%f' )
            );
        }
    }
}
