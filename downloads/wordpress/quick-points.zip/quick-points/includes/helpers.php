<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function qpnt_is_premium() {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

    return (bool) apply_filters( 'quick_points_is_premium', false );
}

function qpnt_cap_can_manage() {
    return current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' );
}

function qpnt_table( $suffix ) {
    global $wpdb;
    return $wpdb->prefix . $suffix;
}

function qpnt_default_settings() {
    return array(
        'points_per_currency'        => 1,
        'redemption_enabled'         => 1,
        'redemption_points'          => 100,
        'redemption_value'           => 1,
        'expiry_enabled'             => 0,
        'expiry_days'                => 365,
        'max_redeem_per_order'       => 0,
        'order_status_trigger'       => 'completed',
        'liability_warning_display'  => 1,
        'enable_referrals'           => 0,
        'enable_tiers'               => 0,
        'enable_activity_rewards'    => 0,
        'activity_registration'      => 25,
        'activity_review'            => 10,
        'activity_anniversary'       => 50,
        'activity_referral'          => 100,
        'tier_rule_mode'             => 'lifetime_points',
        'points_only_checkout'       => 0,
        'points_cash_partial'        => 1,
        'min_cart_total_for_redeem'  => 0,
    );
}

function qpnt_get_settings() {
    $saved = get_option( 'qpnt_settings', array() );
    if ( ! is_array( $saved ) ) {
        $saved = array();
    }

    return wp_parse_args( $saved, qpnt_default_settings() );
}

function qpnt_float( $val, $default = 0.0 ) {
    if ( '' === $val || null === $val ) {
        return (float) $default;
    }
    return (float) wc_format_decimal( $val );
}

function qpnt_int( $val, $default = 0 ) {
    if ( '' === $val || null === $val ) {
        return (int) $default;
    }
    return (int) $val;
}

function qpnt_cache_key( $key, $user_id ) {
    return 'qpnt_' . sanitize_key( $key ) . '_' . absint( $user_id );
}

function qpnt_get_badges_for_points( $lifetime_points ) {
    $points = (int) $lifetime_points;
    $badges = array();

    if ( $points >= 100 ) {
        $badges[] = 'Starter';
    }
    if ( $points >= 1000 ) {
        $badges[] = 'Climber';
    }
    if ( $points >= 5000 ) {
        $badges[] = 'Champion';
    }

    return $badges;
}

function qpnt_escape( $text ) {
    return esc_html( (string) $text );
}

function qpnt_escape_csv_formula( $value ) {
    $value = (string) $value;
    if ( '' === $value ) {
        return $value;
    }

    $first = substr( $value, 0, 1 );
    if ( in_array( $first, array( '=', '+', '-', '@' ), true ) ) {
        return "'" . $value;
    }

    return $value;
}
