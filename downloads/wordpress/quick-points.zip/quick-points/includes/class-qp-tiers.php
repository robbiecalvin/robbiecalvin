<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QPNT_Tiers {
    private $settings;
    private $transactions;

    public function __construct( $settings, $transactions ) {
        $this->settings     = $settings;
        $this->transactions = $transactions;
    }

    public function hooks() {
        add_filter( 'woocommerce_package_rates', array( $this, 'apply_free_shipping_perk' ), 20, 2 );
    }

    public function is_enabled() {
        return qpnt_is_premium() && (bool) $this->settings->get( 'enable_tiers', 0 );
    }

    public function get_tiers() {
        global $wpdb;
        $table = qpnt_table( 'quick_points_tiers' );

        $rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY threshold ASC", ARRAY_A );
        return is_array( $rows ) ? $rows : array();
    }

    public function get_user_tier( $user_id ) {
        $user_id = absint( $user_id );
        if ( ! $user_id || ! $this->is_enabled() ) {
            return null;
        }

        $tiers = $this->get_tiers();
        if ( empty( $tiers ) ) {
            return null;
        }

        $rule_mode = $this->settings->get( 'tier_rule_mode', 'lifetime_points' );
        $metric    = $this->get_metric_for_rule( $user_id, $rule_mode );

        $selected = null;
        foreach ( $tiers as $tier ) {
            if ( $metric >= (float) $tier['threshold'] ) {
                $selected = $tier;
            }
        }

        if ( $selected ) {
            update_user_meta( $user_id, '_qpnt_current_tier', sanitize_text_field( $selected['name'] ) );
        }

        return $selected;
    }

    public function get_multiplier_for_user( $user_id ) {
        if ( ! $this->is_enabled() ) {
            return 1.0;
        }

        $tier = $this->get_user_tier( $user_id );
        if ( ! $tier ) {
            return 1.0;
        }

        $mult = (float) ( $tier['multiplier'] ?? 1.0 );
        return $mult > 0 ? $mult : 1.0;
    }

    public function get_tier_perks( $tier_id ) {
        $all = get_option( 'qpnt_tier_perks', array() );
        if ( ! is_array( $all ) ) {
            $all = array();
        }

        $key = (string) absint( $tier_id );
        $perks = $all[ $key ] ?? array();
        if ( ! is_array( $perks ) ) {
            $perks = array();
        }

        return wp_parse_args(
            $perks,
            array(
                'exclusive_discount_percent' => 0,
                'free_shipping'             => 0,
                'early_sale_access'         => 0,
                'redemption_bonus_percent'  => 0,
            )
        );
    }

    public function save_tier_perks( $tier_id, $input ) {
        $all = get_option( 'qpnt_tier_perks', array() );
        if ( ! is_array( $all ) ) {
            $all = array();
        }

        $all[ (string) absint( $tier_id ) ] = array(
            'exclusive_discount_percent' => max( 0, qpnt_float( $input['exclusive_discount_percent'] ?? 0 ) ),
            'free_shipping'             => empty( $input['free_shipping'] ) ? 0 : 1,
            'early_sale_access'         => empty( $input['early_sale_access'] ) ? 0 : 1,
            'redemption_bonus_percent'  => max( 0, qpnt_float( $input['redemption_bonus_percent'] ?? 0 ) ),
        );

        update_option( 'qpnt_tier_perks', $all, false );
    }

    public function create_tier( $name, $threshold, $multiplier ) {
        if ( ! qpnt_cap_can_manage() || ! $this->is_enabled() ) {
            return false;
        }

        global $wpdb;
        $table = qpnt_table( 'quick_points_tiers' );

        $ok = $wpdb->insert(
            $table,
            array(
                'name'       => sanitize_text_field( $name ),
                'threshold'  => max( 0, (int) $threshold ),
                'multiplier' => max( 0.1, (float) $multiplier ),
            ),
            array( '%s', '%d', '%f' )
        );

        return false !== $ok;
    }

    public function delete_tier( $tier_id ) {
        if ( ! qpnt_cap_can_manage() || ! $this->is_enabled() ) {
            return false;
        }

        global $wpdb;
        $table = qpnt_table( 'quick_points_tiers' );
        $ok    = $wpdb->delete( $table, array( 'id' => absint( $tier_id ) ), array( '%d' ) );

        $all = get_option( 'qpnt_tier_perks', array() );
        if ( is_array( $all ) ) {
            unset( $all[ (string) absint( $tier_id ) ] );
            update_option( 'qpnt_tier_perks', $all, false );
        }

        return false !== $ok;
    }

    public function get_tier_distribution() {
        if ( ! $this->is_enabled() ) {
            return array();
        }

        global $wpdb;
        $users = $wpdb->get_col( "SELECT ID FROM {$wpdb->users}" );
        $dist = array();

        foreach ( $users as $uid ) {
            $tier = $this->get_user_tier( (int) $uid );
            $name = $tier ? (string) $tier['name'] : 'None';
            if ( ! isset( $dist[ $name ] ) ) {
                $dist[ $name ] = 0;
            }
            $dist[ $name ]++;
        }

        return $dist;
    }

    public function apply_free_shipping_perk( $rates, $package ) {
        if ( ! $this->is_enabled() || ! is_user_logged_in() ) {
            return $rates;
        }

        $tier = $this->get_user_tier( get_current_user_id() );
        if ( ! $tier ) {
            return $rates;
        }

        $perks = $this->get_tier_perks( (int) $tier['id'] );
        if ( empty( $perks['free_shipping'] ) ) {
            return $rates;
        }

        foreach ( $rates as $key => $rate ) {
            if ( isset( $rate->cost ) ) {
                $rates[ $key ]->cost = 0;
            }
        }

        return $rates;
    }

    private function get_metric_for_rule( $user_id, $rule_mode ) {
        if ( 'lifetime_points' === $rule_mode ) {
            $balance = $this->transactions->get_balance( $user_id );
            return (float) $balance['lifetime_points'];
        }

        if ( ! class_exists( 'WooCommerce' ) ) {
            return 0;
        }

        $date_after = null;
        if ( 'annual_spend' === $rule_mode ) {
            $date_after = gmdate( 'Y-01-01 00:00:00' );
        } elseif ( 'rolling_12_months' === $rule_mode ) {
            $date_after = gmdate( 'Y-m-d H:i:s', strtotime( '-12 months' ) );
        }

        $args = array(
            'customer_id' => $user_id,
            'status'      => array( 'wc-completed', 'wc-processing' ),
            'limit'       => -1,
            'return'      => 'ids',
        );

        if ( $date_after ) {
            $args['date_paid'] = '>' . $date_after;
        }

        $orders = wc_get_orders( $args );
        $sum = 0.0;

        foreach ( $orders as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( $order ) {
                $sum += (float) $order->get_total();
            }
        }

        return $sum;
    }
}
