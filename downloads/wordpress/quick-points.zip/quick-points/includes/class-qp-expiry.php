<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QPNT_Expiry {
    private $settings;
    private $transactions;

    public function __construct( $settings, $transactions ) {
        $this->settings     = $settings;
        $this->transactions = $transactions;
    }

    public function hooks() {
        add_action( 'qpnt_daily_expiry_event', array( $this, 'run_daily_expiry' ) );
    }

    public function run_daily_expiry() {
        $settings = $this->settings->all();
        if ( empty( $settings['expiry_enabled'] ) ) {
            return;
        }

        $result = $this->transactions->expire_due_points();
        update_option( 'qpnt_last_expiry_run', array(
            'ran_at'   => current_time( 'mysql' ),
            'expired'  => (int) $result['expired'],
            'rows'     => (int) $result['rows'],
        ), false );
    }
}
