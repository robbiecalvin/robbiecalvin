<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QPNT_Transactions {
    private $settings;

    public function __construct( $settings ) {
        $this->settings = $settings;
    }

    public function get_balance( $user_id, $use_cache = true ) {
        $user_id = absint( $user_id );
        if ( ! $user_id ) {
            return array( 'total_points' => 0, 'lifetime_points' => 0 );
        }

        $cache_key = qpnt_cache_key( 'balance', $user_id );
        if ( $use_cache ) {
            $cached = get_transient( $cache_key );
            if ( is_array( $cached ) ) {
                return $cached;
            }
        }

        global $wpdb;
        $table = qpnt_table( 'quick_points_balances' );
        $row   = $wpdb->get_row(
            $wpdb->prepare( "SELECT total_points, lifetime_points FROM {$table} WHERE user_id = %d", $user_id ),
            ARRAY_A
        );

        if ( ! $row ) {
            $row = array( 'total_points' => 0, 'lifetime_points' => 0 );
            $this->ensure_balance_row( $user_id );
        }

        $row['total_points']    = (int) $row['total_points'];
        $row['lifetime_points'] = (int) $row['lifetime_points'];
        update_user_meta( $user_id, 'quickwoo_points_balance', (int) $row['total_points'] );
        set_transient( $cache_key, $row, MINUTE_IN_SECONDS * 10 );

        return $row;
    }

    public function ensure_balance_row( $user_id ) {
        global $wpdb;
        $table = qpnt_table( 'quick_points_balances' );

        $wpdb->query(
            $wpdb->prepare(
                "INSERT IGNORE INTO {$table} (user_id, total_points, lifetime_points, updated_at) VALUES (%d, 0, 0, %s)",
                absint( $user_id ),
                current_time( 'mysql' )
            )
        );
    }

    public function add_points( $user_id, $points, $type, $reference_id = 0, $description = '', $is_lifetime = true ) {
        $user_id = absint( $user_id );
        $points  = (int) $points;
        if ( $user_id <= 0 || 0 === $points ) {
            return false;
        }

        $this->ensure_balance_row( $user_id );

        global $wpdb;
        $balances_table = qpnt_table( 'quick_points_balances' );
        $tx_table       = qpnt_table( 'quick_points_transactions' );

        $wpdb->query( 'START TRANSACTION' );

        try {
            if ( $points < 0 ) {
                $current = $this->get_balance( $user_id, false );
                if ( (int) $current['total_points'] + $points < 0 ) {
                    $wpdb->query( 'ROLLBACK' );
                    return false;
                }
            }

            $lifetime_add = $is_lifetime && $points > 0 ? $points : 0;

            $updated = $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$balances_table}
                     SET total_points = GREATEST(0, total_points + %d),
                         lifetime_points = lifetime_points + %d,
                         updated_at = %s
                     WHERE user_id = %d",
                    $points,
                    $lifetime_add,
                    current_time( 'mysql' ),
                    $user_id
                )
            );

            if ( false === $updated ) {
                $wpdb->query( 'ROLLBACK' );
                return false;
            }

            $inserted = $wpdb->insert(
                $tx_table,
                array(
                    'user_id'       => $user_id,
                    'points_change' => $points,
                    'type'          => sanitize_key( $type ),
                    'reference_id'  => absint( $reference_id ),
                    'description'   => wp_kses_post( $description ),
                    'created_at'    => current_time( 'mysql' ),
                ),
                array( '%d', '%d', '%s', '%d', '%s', '%s' )
            );

            if ( false === $inserted ) {
                $wpdb->query( 'ROLLBACK' );
                return false;
            }

            $tx_id = (int) $wpdb->insert_id;

            if ( $points > 0 ) {
                $this->record_expiration_batch( $user_id, $points, $tx_id );
            } elseif ( $points < 0 ) {
                $this->consume_expiration_batches( $user_id, abs( $points ) );
            }

            $wpdb->query( 'COMMIT' );

            delete_transient( qpnt_cache_key( 'balance', $user_id ) );
            delete_transient( 'qpnt_leaderboard' );
            $fresh_balance = $this->get_balance( $user_id, false );
            update_user_meta( $user_id, 'quickwoo_points_balance', (int) $fresh_balance['total_points'] );

            return $tx_id;
        } catch ( Exception $e ) {
            $wpdb->query( 'ROLLBACK' );
            return false;
        }
    }

    public function get_history( $user_id, $limit = 50 ) {
        global $wpdb;
        $table = qpnt_table( 'quick_points_transactions' );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, points_change, type, reference_id, description, created_at
                 FROM {$table}
                 WHERE user_id = %d
                 ORDER BY id DESC
                 LIMIT %d",
                absint( $user_id ),
                absint( $limit )
            ),
            ARRAY_A
        );

        return is_array( $rows ) ? $rows : array();
    }

    public function get_transactions( $args = array() ) {
        global $wpdb;
        $table = qpnt_table( 'quick_points_transactions' );

        $where  = array( '1=1' );
        $params = array();

        if ( ! empty( $args['user_id'] ) ) {
            $where[]  = 'user_id = %d';
            $params[] = absint( $args['user_id'] );
        }

        if ( ! empty( $args['type'] ) ) {
            $where[]  = 'type = %s';
            $params[] = sanitize_key( $args['type'] );
        }

        if ( ! empty( $args['date_from'] ) ) {
            $where[]  = 'created_at >= %s';
            $params[] = sanitize_text_field( $args['date_from'] ) . ' 00:00:00';
        }

        if ( ! empty( $args['date_to'] ) ) {
            $where[]  = 'created_at <= %s';
            $params[] = sanitize_text_field( $args['date_to'] ) . ' 23:59:59';
        }

        $limit  = isset( $args['limit'] ) ? absint( $args['limit'] ) : 200;
        $offset = isset( $args['offset'] ) ? absint( $args['offset'] ) : 0;

        $sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . ' ORDER BY id DESC LIMIT %d OFFSET %d';
        $params[] = $limit;
        $params[] = $offset;

        $prepared = $wpdb->prepare( $sql, $params );
        $rows     = $wpdb->get_results( $prepared, ARRAY_A );

        return is_array( $rows ) ? $rows : array();
    }

    public function get_dashboard_stats() {
        global $wpdb;

        $tx_table  = qpnt_table( 'quick_points_transactions' );
        $bal_table = qpnt_table( 'quick_points_balances' );
        $settings  = $this->settings->all();

        $issued = (int) $wpdb->get_var( "SELECT COALESCE(SUM(points_change),0) FROM {$tx_table} WHERE points_change > 0" );
        $redeem = (int) abs( (int) $wpdb->get_var( "SELECT COALESCE(SUM(points_change),0) FROM {$tx_table} WHERE type = 'redeem'" ) );
        $active = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$bal_table} WHERE total_points > 0" );
        $outstanding_points = (int) $wpdb->get_var( "SELECT COALESCE(SUM(total_points),0) FROM {$bal_table}" );

        $liability = 0.0;
        if ( (float) $settings['redemption_points'] > 0 ) {
            $liability = ( $outstanding_points / (float) $settings['redemption_points'] ) * (float) $settings['redemption_value'];
        }

        return array(
            'issued'             => $issued,
            'redeemed'           => $redeem,
            'active_users'       => $active,
            'outstanding_points' => $outstanding_points,
            'liability'          => $liability,
        );
    }

    public function get_leaderboard( $limit = 20 ) {
        $limit = max( 1, absint( $limit ) );
        $cache = get_transient( 'qpnt_leaderboard' );
        if ( is_array( $cache ) && count( $cache ) >= $limit ) {
            return array_slice( $cache, 0, $limit );
        }

        global $wpdb;
        $table = qpnt_table( 'quick_points_balances' );
        $rows  = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT user_id, total_points, lifetime_points
                 FROM {$table}
                 ORDER BY lifetime_points DESC
                 LIMIT %d",
                $limit
            ),
            ARRAY_A
        );

        if ( ! is_array( $rows ) ) {
            $rows = array();
        }

        foreach ( $rows as &$row ) {
            $user = get_userdata( (int) $row['user_id'] );
            $row['display_name'] = $user ? $user->display_name : 'User #' . (int) $row['user_id'];
        }

        set_transient( 'qpnt_leaderboard', $rows, MINUTE_IN_SECONDS * 10 );

        return $rows;
    }

    public function has_order_award( $order_id ) {
        return 'yes' === get_post_meta( absint( $order_id ), '_qpnt_points_awarded', true );
    }

    public function mark_order_awarded( $order_id ) {
        update_post_meta( absint( $order_id ), '_qpnt_points_awarded', 'yes' );
    }

    public function has_order_redeem( $order_id ) {
        return 'yes' === get_post_meta( absint( $order_id ), '_qpnt_points_redeemed', true );
    }

    public function mark_order_redeemed( $order_id ) {
        update_post_meta( absint( $order_id ), '_qpnt_points_redeemed', 'yes' );
    }

    public function get_upcoming_expirations( $user_id, $limit = 10 ) {
        global $wpdb;
        $table = qpnt_table( 'quick_points_expirations' );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, points, earned_at, expires_at
                 FROM {$table}
                 WHERE user_id = %d AND points > 0 AND expires_at >= %s
                 ORDER BY expires_at ASC
                 LIMIT %d",
                absint( $user_id ),
                current_time( 'mysql' ),
                absint( $limit )
            ),
            ARRAY_A
        );

        return is_array( $rows ) ? $rows : array();
    }

    public function expire_due_points() {
        global $wpdb;
        $exp_table = qpnt_table( 'quick_points_expirations' );

        $due_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, user_id, points
                 FROM {$exp_table}
                 WHERE points > 0 AND expires_at <= %s
                 ORDER BY expires_at ASC",
                current_time( 'mysql' )
            ),
            ARRAY_A
        );

        if ( empty( $due_rows ) ) {
            return array( 'expired' => 0, 'rows' => 0 );
        }

        $expired_total = 0;
        $processed     = 0;

        foreach ( $due_rows as $row ) {
            $points = absint( $row['points'] );
            if ( $points <= 0 ) {
                continue;
            }

            $ok = $this->add_points(
                (int) $row['user_id'],
                -1 * $points,
                'expire',
                (int) $row['id'],
                'Points expired by rule.',
                false
            );

            if ( false !== $ok ) {
                $wpdb->update(
                    $exp_table,
                    array( 'points' => 0 ),
                    array( 'id' => (int) $row['id'] ),
                    array( '%d' ),
                    array( '%d' )
                );
                $expired_total += $points;
                $processed++;
            }
        }

        return array(
            'expired' => $expired_total,
            'rows'    => $processed,
        );
    }

    private function record_expiration_batch( $user_id, $points, $reference_id ) {
        $settings = $this->settings->all();
        if ( empty( $settings['expiry_enabled'] ) ) {
            return;
        }

        $days = max( 1, absint( $settings['expiry_days'] ) );
        $now  = current_time( 'mysql' );
        $exp  = gmdate( 'Y-m-d H:i:s', strtotime( $now . ' +' . $days . ' days' ) );

        global $wpdb;
        $table = qpnt_table( 'quick_points_expirations' );

        $wpdb->insert(
            $table,
            array(
                'user_id'    => absint( $user_id ),
                'points'     => absint( $points ),
                'earned_at'  => $now,
                'expires_at' => $exp,
            ),
            array( '%d', '%d', '%s', '%s' )
        );
    }

    private function consume_expiration_batches( $user_id, $points_to_consume ) {
        $points_to_consume = absint( $points_to_consume );
        if ( $points_to_consume <= 0 ) {
            return;
        }

        global $wpdb;
        $table = qpnt_table( 'quick_points_expirations' );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, points
                 FROM {$table}
                 WHERE user_id = %d AND points > 0
                 ORDER BY expires_at ASC, id ASC",
                absint( $user_id )
            ),
            ARRAY_A
        );

        foreach ( $rows as $row ) {
            if ( $points_to_consume <= 0 ) {
                break;
            }

            $batch_points = (int) $row['points'];
            if ( $batch_points <= 0 ) {
                continue;
            }

            if ( $batch_points <= $points_to_consume ) {
                $new_points = 0;
                $points_to_consume -= $batch_points;
            } else {
                $new_points = $batch_points - $points_to_consume;
                $points_to_consume = 0;
            }

            $wpdb->update(
                $table,
                array( 'points' => $new_points ),
                array( 'id' => (int) $row['id'] ),
                array( '%d' ),
                array( '%d' )
            );
        }
    }
}
