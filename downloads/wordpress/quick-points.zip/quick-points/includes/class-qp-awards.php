<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QPNT_Awards {
    private $settings;
    private $transactions;
    private $tiers;

    public function __construct( $settings, $transactions, $tiers ) {
        $this->settings     = $settings;
        $this->transactions = $transactions;
        $this->tiers        = $tiers;
    }

    public function hooks() {
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
        add_action( 'woocommerce_order_status_changed', array( $this, 'maybe_award_order_points' ), 20, 4 );
        add_action( 'woocommerce_single_product_summary', array( $this, 'render_product_points_hint' ), 25 );
        add_action( 'woocommerce_review_order_before_payment', array( $this, 'render_checkout_points_hint' ) );
        add_action( 'woocommerce_init', array( $this, 'register_my_account_endpoint' ) );
        add_filter( 'query_vars', array( $this, 'register_query_vars' ) );
        add_filter( 'woocommerce_account_menu_items', array( $this, 'add_account_menu_item' ) );
        add_action( 'woocommerce_account_quick-points-history_endpoint', array( $this, 'render_account_history' ) );
        add_action( 'woocommerce_account_dashboard', array( $this, 'render_account_balance_widget' ) );

        add_shortcode( 'quick_points_balance', array( $this, 'shortcode_balance' ) );
        add_shortcode( 'quick_points_history', array( $this, 'shortcode_history' ) );
        add_shortcode( 'quick_points_leaderboard', array( $this, 'shortcode_leaderboard' ) );

        add_action( 'user_register', array( $this, 'maybe_award_registration_points' ) );
        add_action( 'comment_post', array( $this, 'maybe_award_review_points' ), 20, 3 );
        add_action( 'init', array( $this, 'maybe_award_anniversary_points' ) );
        add_action( 'init', array( $this, 'capture_referral' ) );

        add_action( 'woocommerce_thankyou', array( $this, 'maybe_award_referral_points' ), 20, 1 );

        add_action( 'quick_points_custom_action', array( $this, 'award_custom_action_points' ), 10, 4 );
        add_action( 'woocommerce_before_shop_loop_item_title', array( $this, 'render_tier_badge' ), 3 );
    }

    public function enqueue_frontend_assets() {
        if ( ! function_exists( 'is_woocommerce' ) ) {
            return;
        }

        if ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) {
            wp_enqueue_style( 'qpnt-frontend', QPNT_URL . 'assets/css/frontend.css', array(), QPNT_VERSION );
            wp_enqueue_script( 'qpnt-frontend', QPNT_URL . 'assets/js/frontend.js', array(), QPNT_VERSION, true );
        }
    }

    public function maybe_award_order_points( $order_id, $from, $to, $order ) {
        if ( ! $order instanceof WC_Order ) {
            $order = wc_get_order( $order_id );
        }

        if ( ! $order ) {
            return;
        }

        // Award points only when orders move to completed.
        if ( 'completed' !== sanitize_key( $to ) ) {
            return;
        }

        if ( $this->transactions->has_order_award( $order_id ) ) {
            return;
        }

        $user_id = (int) $order->get_user_id();
        if ( $user_id <= 0 ) {
            return;
        }

        $points = $this->calculate_order_points( $order );
        if ( $points <= 0 ) {
            $this->transactions->mark_order_awarded( $order_id );
            return;
        }

        $tx = $this->transactions->add_points(
            $user_id,
            $points,
            'earn',
            (int) $order_id,
            sprintf( 'Points earned from order #%d', (int) $order_id ),
            true
        );

        if ( false !== $tx ) {
            $this->transactions->mark_order_awarded( $order_id );
            $this->notify_achievement( $user_id );
        }
    }

    public function calculate_order_points( $order ) {
        if ( ! $order instanceof WC_Order ) {
            return 0;
        }

        $user_id            = (int) $order->get_user_id();
        $points_per_currency = (float) $this->settings->get( 'points_per_currency', 1 );

        if ( $points_per_currency <= 0 ) {
            return 0;
        }

        $sum = 0.0;

        foreach ( $order->get_items( 'line_item' ) as $item ) {
            $product = $item->get_product();
            if ( ! $product ) {
                continue;
            }

            $line_total = (float) $item->get_total();
            $product_id = $product->get_id();

            if ( qpnt_is_premium() ) {
                $excluded = get_post_meta( $product_id, '_qpnt_exclude_from_points', true );
                if ( 'yes' === $excluded ) {
                    continue;
                }

                $custom_rate = get_post_meta( $product_id, '_qpnt_points_per_currency', true );
                $rate = '' !== $custom_rate ? (float) $custom_rate : $points_per_currency;

                $double_points = get_post_meta( $product_id, '_qpnt_double_points', true );
                if ( 'yes' === $double_points ) {
                    $rate *= 2;
                }

                $cats = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );
                if ( is_array( $cats ) ) {
                    foreach ( $cats as $cat_id ) {
                        $mult = get_term_meta( (int) $cat_id, '_qpnt_category_multiplier', true );
                        if ( '' !== $mult && is_numeric( $mult ) ) {
                            $rate *= (float) $mult;
                            break;
                        }
                    }
                }
            } else {
                $rate = $points_per_currency;
            }

            $sum += max( 0.0, $line_total ) * max( 0.0, (float) $rate );
        }

        $multiplier = $this->tiers->get_multiplier_for_user( $user_id );
        $sum *= max( 1.0, (float) $multiplier );

        return (int) floor( $sum );
    }

    public function render_product_points_hint() {
        global $product;

        if ( ! $product instanceof WC_Product ) {
            return;
        }

        $price = (float) $product->get_price();
        if ( $price <= 0 ) {
            return;
        }

        $points = (int) floor( $price * (float) $this->settings->get( 'points_per_currency', 1 ) );
        if ( $points <= 0 ) {
            return;
        }

        echo '<p class="qpnt-points-hint">Earn approximately <strong>' . esc_html( $points ) . '</strong> points with this purchase.</p>';
    }

    public function render_checkout_points_hint() {
        if ( ! WC()->cart ) {
            return;
        }

        $subtotal = (float) WC()->cart->get_subtotal();
        if ( $subtotal <= 0 ) {
            return;
        }

        $points = (int) floor( $subtotal * (float) $this->settings->get( 'points_per_currency', 1 ) );
        echo '<p class="qpnt-checkout-earned">This order can earn about <strong>' . esc_html( $points ) . '</strong> points.</p>';
    }

    public function register_my_account_endpoint() {
        add_rewrite_endpoint( 'quick-points-history', EP_ROOT | EP_PAGES );
    }

    public function register_query_vars( $vars ) {
        $vars[] = 'quick-points-history';
        return $vars;
    }

    public function add_account_menu_item( $items ) {
        $new = array();
        foreach ( $items as $key => $label ) {
            $new[ $key ] = $label;
            if ( 'dashboard' === $key ) {
                $new['quick-points-history'] = 'Points History';
            }
        }
        return $new;
    }

    public function render_account_history() {
        if ( ! is_user_logged_in() ) {
            return;
        }

        echo $this->render_balance_and_history_html( get_current_user_id() );

        if ( qpnt_is_premium() ) {
            $upcoming = $this->transactions->get_upcoming_expirations( get_current_user_id(), 10 );
            if ( ! empty( $upcoming ) ) {
                echo '<h3>Upcoming Expirations</h3><ul class="qpnt-upcoming">';
                foreach ( $upcoming as $row ) {
                    echo '<li>' . esc_html( (int) $row['points'] ) . ' points expire on ' . esc_html( $row['expires_at'] ) . '</li>';
                }
                echo '</ul>';
            }
        }
    }

    public function render_account_balance_widget() {
        if ( ! is_user_logged_in() ) {
            return;
        }

        $balance = $this->transactions->get_balance( get_current_user_id() );
        echo '<div class="qpnt-balance">';
        echo '<h3>' . esc_html__( 'Points Balance', 'quick-points' ) . '</h3>';
        echo '<p><strong>' . esc_html( (int) $balance['total_points'] ) . '</strong></p>';
        echo '</div>';
    }

    public function shortcode_balance() {
        if ( ! is_user_logged_in() ) {
            return '<p>Please log in to view your points.</p>';
        }

        $bal = $this->transactions->get_balance( get_current_user_id() );
        return '<div class="qpnt-balance">Points Balance: <strong>' . esc_html( (int) $bal['total_points'] ) . '</strong></div>';
    }

    public function shortcode_history() {
        if ( ! is_user_logged_in() ) {
            return '<p>Please log in to view your points history.</p>';
        }

        return $this->render_balance_and_history_html( get_current_user_id() );
    }

    public function shortcode_leaderboard() {
        if ( ! qpnt_is_premium() ) {
            return '<p>Leaderboard is a premium feature.</p>';
        }

        $rows = $this->transactions->get_leaderboard( 20 );
        if ( empty( $rows ) ) {
            return '<p>No leaderboard data yet.</p>';
        }

        $html = '<table class="qpnt-table"><thead><tr><th>Rank</th><th>User</th><th>Lifetime Points</th></tr></thead><tbody>';
        $rank = 1;
        foreach ( $rows as $row ) {
            $html .= '<tr><td>' . esc_html( $rank++ ) . '</td><td>' . esc_html( $row['display_name'] ) . '</td><td>' . esc_html( (int) $row['lifetime_points'] ) . '</td></tr>';
        }
        $html .= '</tbody></table>';

        return $html;
    }

    public function maybe_award_registration_points( $user_id ) {
        if ( ! qpnt_is_premium() || ! $this->settings->get( 'enable_activity_rewards', 0 ) ) {
            return;
        }

        $points = (int) $this->settings->get( 'activity_registration', 25 );
        $this->award_activity_once( $user_id, 'register', $points, 'Registration reward' );
    }

    public function maybe_award_review_points( $comment_id, $approved, $commentdata ) {
        if ( ! qpnt_is_premium() || ! $this->settings->get( 'enable_activity_rewards', 0 ) ) {
            return;
        }

        if ( 1 !== (int) $approved ) {
            return;
        }

        $comment = get_comment( $comment_id );
        if ( ! $comment || 'product' !== get_post_type( $comment->comment_post_ID ) ) {
            return;
        }

        $user_id = (int) $comment->user_id;
        if ( $user_id <= 0 ) {
            return;
        }

        $points = (int) $this->settings->get( 'activity_review', 10 );
        $this->award_activity_once( $user_id, 'review_' . $comment_id, $points, 'Product review reward' );
    }

    public function maybe_award_anniversary_points() {
        if ( ! qpnt_is_premium() || ! $this->settings->get( 'enable_activity_rewards', 0 ) ) {
            return;
        }

        if ( ! is_user_logged_in() ) {
            return;
        }

        $user = wp_get_current_user();
        if ( ! $user || empty( $user->user_registered ) ) {
            return;
        }

        $today = gmdate( 'm-d' );
        $reg   = gmdate( 'm-d', strtotime( $user->user_registered ) );
        if ( $today !== $reg ) {
            return;
        }

        $key = 'anniversary_' . gmdate( 'Y' );
        $points = (int) $this->settings->get( 'activity_anniversary', 50 );
        $this->award_activity_once( $user->ID, $key, $points, 'Account anniversary reward' );
    }

    public function capture_referral() {
        if ( ! qpnt_is_premium() || ! $this->settings->get( 'enable_referrals', 0 ) ) {
            return;
        }

        if ( empty( $_GET['qp_ref'] ) ) {
            return;
        }

        $ref = absint( $_GET['qp_ref'] );
        if ( $ref <= 0 ) {
            return;
        }

        if ( ! session_id() ) {
            if ( ! headers_sent() ) {
                @session_start();
            }
        }

        if ( session_id() ) {
            $_SESSION['qpnt_referrer'] = $ref;
        }
    }

    public function maybe_award_referral_points( $order_id ) {
        if ( ! qpnt_is_premium() || ! $this->settings->get( 'enable_referrals', 0 ) ) {
            return;
        }

        if ( ! session_id() ) {
            return;
        }

        $referrer_id = absint( $_SESSION['qpnt_referrer'] ?? 0 );
        if ( $referrer_id <= 0 ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        $buyer_id = (int) $order->get_user_id();
        if ( $buyer_id <= 0 || $buyer_id === $referrer_id ) {
            return;
        }

        $key = 'referral_' . $order_id;
        $points = (int) $this->settings->get( 'activity_referral', 100 );
        $this->award_activity_once( $referrer_id, $key, $points, 'Referral reward from order #' . $order_id );
    }

    public function award_custom_action_points( $user_id, $points, $action_key, $description ) {
        if ( ! qpnt_is_premium() || ! $this->settings->get( 'enable_activity_rewards', 0 ) ) {
            return;
        }

        $user_id = absint( $user_id );
        $points  = (int) $points;
        if ( $user_id <= 0 || $points <= 0 ) {
            return;
        }

        $this->award_activity_once( $user_id, 'custom_' . sanitize_key( $action_key ), $points, (string) $description );
    }

    public function render_tier_badge() {
        if ( ! qpnt_is_premium() || ! is_user_logged_in() || ! $this->settings->get( 'enable_tiers', 0 ) ) {
            return;
        }

        $tier = $this->tiers->get_user_tier( get_current_user_id() );
        if ( ! $tier ) {
            return;
        }

        echo '<span class="qpnt-tier-badge">' . esc_html( $tier['name'] ) . '</span>';
    }

    private function render_balance_and_history_html( $user_id ) {
        $balance = $this->transactions->get_balance( $user_id );
        $history = $this->transactions->get_history( $user_id, 50 );
        $badges  = qpnt_get_badges_for_points( $balance['lifetime_points'] );

        $html  = '<div class="qpnt-balance-box">';
        $html .= '<p><strong>Current Balance:</strong> ' . esc_html( (int) $balance['total_points'] ) . ' points</p>';
        $html .= '<p><strong>Lifetime Points:</strong> ' . esc_html( (int) $balance['lifetime_points'] ) . '</p>';
        if ( qpnt_is_premium() && ! empty( $badges ) ) {
            $html .= '<p><strong>Badges:</strong> ' . esc_html( implode( ', ', $badges ) ) . '</p>';
        }
        $html .= '</div>';

        $html .= '<table class="qpnt-table"><thead><tr><th>Date</th><th>Type</th><th>Points</th><th>Description</th></tr></thead><tbody>';
        if ( empty( $history ) ) {
            $html .= '<tr><td colspan="4">No points history yet.</td></tr>';
        } else {
            foreach ( $history as $row ) {
                $html .= '<tr>';
                $html .= '<td>' . esc_html( $row['created_at'] ) . '</td>';
                $html .= '<td>' . esc_html( $row['type'] ) . '</td>';
                $html .= '<td>' . esc_html( (int) $row['points_change'] ) . '</td>';
                $html .= '<td>' . esc_html( $row['description'] ) . '</td>';
                $html .= '</tr>';
            }
        }
        $html .= '</tbody></table>';

        return $html;
    }

    private function award_activity_once( $user_id, $activity_key, $points, $description ) {
        $user_id      = absint( $user_id );
        $activity_key = sanitize_key( $activity_key );
        $points       = (int) $points;

        if ( $user_id <= 0 || '' === $activity_key || $points <= 0 ) {
            return;
        }

        $log = get_option( 'qpnt_activity_log', array() );
        if ( ! is_array( $log ) ) {
            $log = array();
        }

        $bucket = $user_id . ':' . $activity_key;
        if ( ! empty( $log[ $bucket ] ) ) {
            return;
        }

        // Basic abuse prevention: max 20 unique activity rewards per user/day.
        $day_key = 'rate:' . $user_id . ':' . gmdate( 'Ymd' );
        $today_count = isset( $log[ $day_key ] ) ? (int) $log[ $day_key ] : 0;
        if ( $today_count >= 20 ) {
            return;
        }

        $ok = $this->transactions->add_points( $user_id, $points, 'earn', 0, $description, true );
        if ( false === $ok ) {
            return;
        }

        $log[ $bucket ] = time();
        $log[ $day_key ] = $today_count + 1;

        if ( count( $log ) > 5000 ) {
            $log = array_slice( $log, -3000, null, true );
        }

        update_option( 'qpnt_activity_log', $log, false );
        $this->notify_achievement( $user_id );
    }

    private function notify_achievement( $user_id ) {
        if ( ! qpnt_is_premium() ) {
            return;
        }

        $balance = $this->transactions->get_balance( $user_id );
        $badges  = qpnt_get_badges_for_points( (int) $balance['lifetime_points'] );
        if ( empty( $badges ) ) {
            return;
        }

        update_user_meta( $user_id, '_qpnt_last_badges', $badges );
    }
}
