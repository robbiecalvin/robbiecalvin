<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QPNT_Admin {
    private $settings;
    private $transactions;
    private $tiers;
    private $awards;
    private $redemption;

    public function __construct( $settings, $transactions, $tiers, $awards, $redemption ) {
        $this->settings     = $settings;
        $this->transactions = $transactions;
        $this->tiers        = $tiers;
        $this->awards       = $awards;
        $this->redemption   = $redemption;
    }

    public function hooks() {
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'admin_post_qpnt_save_settings', array( $this, 'handle_save_settings' ) );
        add_action( 'admin_post_qpnt_adjust_points', array( $this, 'handle_adjust_points' ) );
        add_action( 'admin_post_qpnt_export_transactions', array( $this, 'handle_export_transactions' ) );
        add_action( 'admin_post_qpnt_add_tier', array( $this, 'handle_add_tier' ) );
        add_action( 'admin_post_qpnt_delete_tier', array( $this, 'handle_delete_tier' ) );
        add_action( 'admin_post_qpnt_save_tier_perks', array( $this, 'handle_save_tier_perks' ) );

        add_action( 'woocommerce_product_options_general_product_data', array( $this, 'render_product_point_fields' ) );
        add_action( 'woocommerce_process_product_meta', array( $this, 'save_product_point_fields' ) );
        add_action( 'product_cat_add_form_fields', array( $this, 'render_category_multiplier_add' ) );
        add_action( 'product_cat_edit_form_fields', array( $this, 'render_category_multiplier_edit' ) );
        add_action( 'created_product_cat', array( $this, 'save_category_multiplier' ) );
        add_action( 'edited_product_cat', array( $this, 'save_category_multiplier' ) );
    }

    public function register_menu() {
        add_submenu_page(
            'quickwoo',
            'Quick Points',
            'Quick Points',
            'manage_woocommerce',
            'quick-points',
            array( $this, 'render_dashboard_page' )
        );

        add_menu_page(
            'Quick Points',
            'Quick Points',
            'manage_woocommerce',
            'quick-points',
            array( $this, 'render_dashboard_page' ),
            'dashicons-awards',
            63
        );

        add_submenu_page( 'quick-points', 'Dashboard', 'Dashboard', 'manage_woocommerce', 'quick-points', array( $this, 'render_dashboard_page' ) );
        add_submenu_page( 'quick-points', 'Transactions', 'Transactions', 'manage_woocommerce', 'quick-points-transactions', array( $this, 'render_transactions_page' ) );
        if ( qpnt_is_premium() ) {
            add_submenu_page( 'quick-points', 'Tiers', 'Tiers', 'manage_woocommerce', 'quick-points-tiers', array( $this, 'render_tiers_page' ) );
        }
        add_submenu_page( 'quick-points', 'Rules', 'Rules', 'manage_woocommerce', 'quick-points-rules', array( $this, 'render_rules_page' ) );
        add_submenu_page( 'quick-points', 'Settings', 'Settings', 'manage_woocommerce', 'quick-points-settings', array( $this, 'render_settings_page' ) );
    }

    public function enqueue_assets( $hook ) {
        if ( false === strpos( $hook, 'quick-points' ) && false === strpos( $hook, 'woocommerce_page_quick-points' ) ) {
            return;
        }

        wp_enqueue_style( 'qpnt-admin', QPNT_URL . 'assets/css/admin.css', array(), QPNT_VERSION );
        wp_enqueue_script( 'qpnt-admin', QPNT_URL . 'assets/js/admin.js', array( 'jquery' ), QPNT_VERSION, true );
    }

    public function handle_save_settings() {
        if ( ! qpnt_cap_can_manage() ) {
            wp_die( 'Permission denied' );
        }

        check_admin_referer( 'qpnt_save_settings_action', 'qpnt_save_settings_nonce' );
        $this->settings->save( wp_unslash( $_POST ) );

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-points-settings', 'updated' => 1 ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_adjust_points() {
        if ( ! qpnt_cap_can_manage() ) {
            wp_die( 'Permission denied' );
        }

        check_admin_referer( 'qpnt_adjust_points_action', 'qpnt_adjust_points_nonce' );

        $user_id = absint( $_POST['user_id'] ?? 0 );
        $points  = isset( $_POST['points'] ) ? (int) $_POST['points'] : 0;
        $desc    = sanitize_text_field( wp_unslash( $_POST['description'] ?? '' ) );

        if ( $user_id > 0 && 0 !== $points ) {
            $this->transactions->add_points( $user_id, $points, 'admin_adjust', 0, $desc, $points > 0 );
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-points-transactions' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_export_transactions() {
        if ( ! qpnt_cap_can_manage() ) {
            wp_die( 'Permission denied' );
        }

        check_admin_referer( 'qpnt_export_transactions_action', 'qpnt_export_transactions_nonce' );

        $filters = array(
            'user_id'   => absint( $_GET['user_id'] ?? 0 ),
            'type'      => sanitize_key( $_GET['type'] ?? '' ),
            'date_from' => sanitize_text_field( $_GET['date_from'] ?? '' ),
            'date_to'   => sanitize_text_field( $_GET['date_to'] ?? '' ),
            'limit'     => 5000,
            'offset'    => 0,
        );

        $rows = $this->transactions->get_transactions( $filters );

        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=quick-points-transactions-' . gmdate( 'Ymd-His' ) . '.csv' );

        $out = fopen( 'php://output', 'w' );
        fputcsv( $out, array( 'id', 'user_id', 'points_change', 'type', 'reference_id', 'description', 'created_at' ) );

        foreach ( $rows as $row ) {
            $safe = array();
            foreach ( $row as $val ) {
                $safe[] = qpnt_escape_csv_formula( $val );
            }
            fputcsv( $out, $safe );
        }

        fclose( $out );
        exit;
    }

    public function handle_add_tier() {
        if ( ! qpnt_cap_can_manage() || ! qpnt_is_premium() ) {
            wp_die( 'Permission denied' );
        }

        check_admin_referer( 'qpnt_add_tier_action', 'qpnt_add_tier_nonce' );

        $name       = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
        $threshold  = (int) ( $_POST['threshold'] ?? 0 );
        $multiplier = (float) ( $_POST['multiplier'] ?? 1 );

        if ( '' !== $name ) {
            $this->tiers->create_tier( $name, $threshold, $multiplier );
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-points-tiers' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_delete_tier() {
        if ( ! qpnt_cap_can_manage() || ! qpnt_is_premium() ) {
            wp_die( 'Permission denied' );
        }

        check_admin_referer( 'qpnt_delete_tier_action', 'qpnt_delete_tier_nonce' );

        $tier_id = absint( $_GET['tier_id'] ?? 0 );
        if ( $tier_id > 0 ) {
            $this->tiers->delete_tier( $tier_id );
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-points-tiers' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_save_tier_perks() {
        if ( ! qpnt_cap_can_manage() || ! qpnt_is_premium() ) {
            wp_die( 'Permission denied' );
        }

        check_admin_referer( 'qpnt_save_tier_perks_action', 'qpnt_save_tier_perks_nonce' );

        $tier_id = absint( $_POST['tier_id'] ?? 0 );
        if ( $tier_id > 0 ) {
            $this->tiers->save_tier_perks( $tier_id, wp_unslash( $_POST ) );
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'quick-points-tiers' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function render_dashboard_page() {
        if ( ! qpnt_cap_can_manage() ) {
            wp_die( 'Permission denied' );
        }

        $stats = $this->transactions->get_dashboard_stats();
        $dist  = $this->tiers->get_tier_distribution();
        ?>
        <div class="wrap qpnt-wrap">
            <h1>Quick Points Dashboard</h1>
            <div class="qpnt-grid">
                <div class="qpnt-card"><h3>Total Points Issued</h3><p><?php echo esc_html( number_format_i18n( $stats['issued'] ) ); ?></p></div>
                <div class="qpnt-card"><h3>Total Points Redeemed</h3><p><?php echo esc_html( number_format_i18n( $stats['redeemed'] ) ); ?></p></div>
                <div class="qpnt-card"><h3>Outstanding Liability</h3><p><?php echo wp_kses_post( wc_price( $stats['liability'] ) ); ?></p></div>
                <div class="qpnt-card"><h3>Active Users</h3><p><?php echo esc_html( number_format_i18n( $stats['active_users'] ) ); ?></p></div>
            </div>

            <?php if ( qpnt_is_premium() ) : ?>
                <h2>Tier Distribution</h2>
                <div class="qpnt-card">
                    <?php if ( empty( $dist ) ) : ?>
                        <p>No tier data yet.</p>
                    <?php else : ?>
                        <ul>
                            <?php foreach ( $dist as $name => $count ) : ?>
                                <li><?php echo esc_html( $name . ': ' . $count ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    public function render_transactions_page() {
        if ( ! qpnt_cap_can_manage() ) {
            wp_die( 'Permission denied' );
        }

        $filters = array(
            'user_id'   => absint( $_GET['user_id'] ?? 0 ),
            'type'      => sanitize_key( $_GET['type'] ?? '' ),
            'date_from' => sanitize_text_field( $_GET['date_from'] ?? '' ),
            'date_to'   => sanitize_text_field( $_GET['date_to'] ?? '' ),
            'limit'     => 200,
            'offset'    => 0,
        );

        $rows = $this->transactions->get_transactions( $filters );
        ?>
        <div class="wrap qpnt-wrap">
            <h1>Quick Points Transactions</h1>

            <div class="qpnt-card">
                <form method="get">
                    <input type="hidden" name="page" value="quick-points-transactions" />
                    <label>User ID <input type="number" name="user_id" value="<?php echo esc_attr( $filters['user_id'] ); ?>" /></label>
                    <label>Type <input type="text" name="type" value="<?php echo esc_attr( $filters['type'] ); ?>" /></label>
                    <label>Date From <input type="date" name="date_from" value="<?php echo esc_attr( $filters['date_from'] ); ?>" /></label>
                    <label>Date To <input type="date" name="date_to" value="<?php echo esc_attr( $filters['date_to'] ); ?>" /></label>
                    <button class="button">Filter</button>
                </form>

                <form method="get" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:10px;">
                    <?php wp_nonce_field( 'qpnt_export_transactions_action', 'qpnt_export_transactions_nonce' ); ?>
                    <input type="hidden" name="action" value="qpnt_export_transactions" />
                    <input type="hidden" name="user_id" value="<?php echo esc_attr( $filters['user_id'] ); ?>" />
                    <input type="hidden" name="type" value="<?php echo esc_attr( $filters['type'] ); ?>" />
                    <input type="hidden" name="date_from" value="<?php echo esc_attr( $filters['date_from'] ); ?>" />
                    <input type="hidden" name="date_to" value="<?php echo esc_attr( $filters['date_to'] ); ?>" />
                    <button class="button button-secondary">Export CSV</button>
                </form>
            </div>

            <div class="qpnt-card">
                <h2>Manual Adjustment</h2>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'qpnt_adjust_points_action', 'qpnt_adjust_points_nonce' ); ?>
                    <input type="hidden" name="action" value="qpnt_adjust_points" />
                    <label>User ID <input type="number" name="user_id" required /></label>
                    <label>Points (+/-) <input type="number" name="points" required /></label>
                    <label>Description <input type="text" name="description" /></label>
                    <button class="button button-primary" type="submit">Apply</button>
                </form>
            </div>

            <div class="qpnt-card">
                <table class="widefat striped">
                    <thead><tr><th>ID</th><th>User</th><th>Points</th><th>Type</th><th>Reference</th><th>Description</th><th>Date</th></tr></thead>
                    <tbody>
                    <?php if ( empty( $rows ) ) : ?>
                        <tr><td colspan="7">No transactions found.</td></tr>
                    <?php else : ?>
                        <?php foreach ( $rows as $row ) : ?>
                            <tr>
                                <td><?php echo esc_html( $row['id'] ); ?></td>
                                <td><?php echo esc_html( $row['user_id'] ); ?></td>
                                <td><?php echo esc_html( $row['points_change'] ); ?></td>
                                <td><?php echo esc_html( $row['type'] ); ?></td>
                                <td><?php echo esc_html( $row['reference_id'] ); ?></td>
                                <td><?php echo esc_html( $row['description'] ); ?></td>
                                <td><?php echo esc_html( $row['created_at'] ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    public function render_tiers_page() {
        if ( ! qpnt_cap_can_manage() ) {
            wp_die( 'Permission denied' );
        }

        if ( ! qpnt_is_premium() ) {
            echo '<div class="wrap"><h1>Quick Points Tiers</h1><p>Premium required.</p></div>';
            return;
        }

        $tiers = $this->tiers->get_tiers();
        ?>
        <div class="wrap qpnt-wrap">
            <h1>Quick Points Tiers</h1>
            <div class="qpnt-card">
                <h2>Add Tier</h2>
                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <?php wp_nonce_field( 'qpnt_add_tier_action', 'qpnt_add_tier_nonce' ); ?>
                    <input type="hidden" name="action" value="qpnt_add_tier" />
                    <label>Name <input type="text" name="name" required /></label>
                    <label>Threshold <input type="number" name="threshold" min="0" required /></label>
                    <label>Multiplier <input type="number" name="multiplier" step="0.01" min="0.1" required /></label>
                    <button class="button button-primary" type="submit">Add Tier</button>
                </form>
            </div>
            <div class="qpnt-card">
                <table class="widefat striped">
                    <thead><tr><th>ID</th><th>Name</th><th>Threshold</th><th>Multiplier</th><th>Perks</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ( $tiers as $tier ) : ?>
                            <?php $perks = $this->tiers->get_tier_perks( (int) $tier['id'] ); ?>
                            <tr>
                                <td><?php echo esc_html( $tier['id'] ); ?></td>
                                <td><?php echo esc_html( $tier['name'] ); ?></td>
                                <td><?php echo esc_html( $tier['threshold'] ); ?></td>
                                <td><?php echo esc_html( $tier['multiplier'] ); ?></td>
                                <td>
                                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                        <?php wp_nonce_field( 'qpnt_save_tier_perks_action', 'qpnt_save_tier_perks_nonce' ); ?>
                                        <input type="hidden" name="action" value="qpnt_save_tier_perks" />
                                        <input type="hidden" name="tier_id" value="<?php echo esc_attr( $tier['id'] ); ?>" />
                                        <label>Exclusive Discount % <input type="number" step="0.01" min="0" name="exclusive_discount_percent" value="<?php echo esc_attr( $perks['exclusive_discount_percent'] ); ?>" /></label><br>
                                        <label>Redemption Bonus % <input type="number" step="0.01" min="0" name="redemption_bonus_percent" value="<?php echo esc_attr( $perks['redemption_bonus_percent'] ); ?>" /></label><br>
                                        <label><input type="checkbox" name="free_shipping" value="1" <?php checked( ! empty( $perks['free_shipping'] ) ); ?> /> Free Shipping</label>
                                        <label><input type="checkbox" name="early_sale_access" value="1" <?php checked( ! empty( $perks['early_sale_access'] ) ); ?> /> Early Sale Access</label>
                                        <button class="button button-small" type="submit">Save Perks</button>
                                    </form>
                                </td>
                                <td>
                                    <?php
                                    $delete_url = wp_nonce_url(
                                        add_query_arg(
                                            array(
                                                'action'  => 'qpnt_delete_tier',
                                                'tier_id' => $tier['id'],
                                            ),
                                            admin_url( 'admin-post.php' )
                                        ),
                                        'qpnt_delete_tier_action',
                                        'qpnt_delete_tier_nonce'
                                    );
                                    ?>
                                    <a href="<?php echo esc_url( $delete_url ); ?>" class="button button-small">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }

    public function render_rules_page() {
        if ( ! qpnt_cap_can_manage() ) {
            wp_die( 'Permission denied' );
        }

        echo '<div class="wrap qpnt-wrap"><h1>Quick Points Rules</h1><div class="qpnt-card">';
        echo '<p>Use Settings and product/category fields to configure earn rates, redemption, expiry, and premium activity/tier rules.</p>';
        echo '<ul>';
        echo '<li>Product custom earn rate: Product Edit -> General -> Quick Points fields</li>';
        echo '<li>Category multipliers: Products -> Categories -> Quick Points multiplier</li>';
        echo '<li>Activity rewards and referral toggles: Settings page</li>';
        echo '</ul>';
        echo '</div></div>';
    }

    public function render_settings_page() {
        if ( ! qpnt_cap_can_manage() ) {
            wp_die( 'Permission denied' );
        }

        $settings = $this->settings->all();
        ?>
        <div class="wrap qpnt-wrap">
            <h1>Quick Points Settings</h1>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'qpnt_save_settings_action', 'qpnt_save_settings_nonce' ); ?>
                <input type="hidden" name="action" value="qpnt_save_settings" />

                <div class="qpnt-card">
                    <table class="form-table">
                        <tr><th>Points per currency unit</th><td><input type="number" step="0.01" min="0.01" name="points_per_currency" value="<?php echo esc_attr( $settings['points_per_currency'] ); ?>" /></td></tr>
                        <tr><th>Enable redemption</th><td><label><input type="checkbox" name="redemption_enabled" value="1" <?php checked( ! empty( $settings['redemption_enabled'] ) ); ?> /> Allow customers to redeem points at checkout</label></td></tr>
                        <tr><th>Redemption rate</th><td><input type="number" min="1" name="redemption_points" value="<?php echo esc_attr( $settings['redemption_points'] ); ?>" /> points = <input type="number" step="0.01" min="0.01" name="redemption_value" value="<?php echo esc_attr( $settings['redemption_value'] ); ?>" /></td></tr>
                        <tr><th>Expiry enabled</th><td><label><input type="checkbox" name="expiry_enabled" value="1" <?php checked( ! empty( $settings['expiry_enabled'] ) ); ?> /> Enable expiry</label></td></tr>
                        <tr><th>Expiry days</th><td><input type="number" min="1" name="expiry_days" value="<?php echo esc_attr( $settings['expiry_days'] ); ?>" /></td></tr>
                        <tr><th>Max redeem per order (currency)</th><td><input type="number" step="0.01" min="0" name="max_redeem_per_order" value="<?php echo esc_attr( $settings['max_redeem_per_order'] ); ?>" /></td></tr>
                        <tr><th>Order status trigger</th><td><select name="order_status_trigger"><option value="completed" <?php selected( $settings['order_status_trigger'], 'completed' ); ?>>completed</option><option value="processing" <?php selected( $settings['order_status_trigger'], 'processing' ); ?>>processing</option></select></td></tr>
                        <tr><th>Minimum cart total for redeem</th><td><input type="number" step="0.01" min="0" name="min_cart_total_for_redeem" value="<?php echo esc_attr( $settings['min_cart_total_for_redeem'] ); ?>" /></td></tr>
                        <tr><th>Liability warning display</th><td><label><input type="checkbox" name="liability_warning_display" value="1" <?php checked( ! empty( $settings['liability_warning_display'] ) ); ?> /></label></td></tr>
                    </table>
                </div>

                <div class="qpnt-card">
                    <h2>Premium Toggles</h2>
                    <?php if ( ! qpnt_is_premium() ) : ?>
                        <p><strong>Premium is inactive.</strong> Toggle options are saved but premium-only code remains gated.</p>
                    <?php endif; ?>
                    <table class="form-table">
                        <tr><th>Enable referral system</th><td><label><input type="checkbox" name="enable_referrals" value="1" <?php checked( ! empty( $settings['enable_referrals'] ) ); ?> /></label></td></tr>
                        <tr><th>Enable tiers</th><td><label><input type="checkbox" name="enable_tiers" value="1" <?php checked( ! empty( $settings['enable_tiers'] ) ); ?> /></label></td></tr>
                        <tr><th>Enable activity rewards</th><td><label><input type="checkbox" name="enable_activity_rewards" value="1" <?php checked( ! empty( $settings['enable_activity_rewards'] ) ); ?> /></label></td></tr>
                        <tr><th>Tier rule mode</th><td><select name="tier_rule_mode"><option value="lifetime_points" <?php selected( $settings['tier_rule_mode'], 'lifetime_points' ); ?>>Lifetime points</option><option value="annual_spend" <?php selected( $settings['tier_rule_mode'], 'annual_spend' ); ?>>Annual spend</option><option value="rolling_12_months" <?php selected( $settings['tier_rule_mode'], 'rolling_12_months' ); ?>>Rolling 12 months spend</option></select></td></tr>
                        <tr><th>Registration reward points</th><td><input type="number" min="0" name="activity_registration" value="<?php echo esc_attr( $settings['activity_registration'] ); ?>" /></td></tr>
                        <tr><th>Review reward points</th><td><input type="number" min="0" name="activity_review" value="<?php echo esc_attr( $settings['activity_review'] ); ?>" /></td></tr>
                        <tr><th>Anniversary reward points</th><td><input type="number" min="0" name="activity_anniversary" value="<?php echo esc_attr( $settings['activity_anniversary'] ); ?>" /></td></tr>
                        <tr><th>Referral reward points</th><td><input type="number" min="0" name="activity_referral" value="<?php echo esc_attr( $settings['activity_referral'] ); ?>" /></td></tr>
                        <tr><th>Points-only checkout</th><td><label><input type="checkbox" name="points_only_checkout" value="1" <?php checked( ! empty( $settings['points_only_checkout'] ) ); ?> /> (advanced stub)</label></td></tr>
                        <tr><th>Points + cash partial</th><td><label><input type="checkbox" name="points_cash_partial" value="1" <?php checked( ! empty( $settings['points_cash_partial'] ) ); ?> /></label></td></tr>
                    </table>
                </div>

                <p><button class="button button-primary" type="submit">Save Settings</button></p>
            </form>
        </div>
        <?php
    }

    public function render_product_point_fields() {
        if ( ! qpnt_is_premium() ) {
            echo '<p class="form-field"><em>Premium required for product-level point rules.</em></p>';
            return;
        }

        echo '<div class="options_group">';
        woocommerce_wp_text_input(
            array(
                'id'          => '_qpnt_points_per_currency',
                'label'       => 'Points per currency unit',
                'description' => 'Custom earn rate for this product. Leave empty to use global.',
                'type'        => 'number',
                'desc_tip'    => true,
                'custom_attributes' => array( 'step' => '0.01', 'min' => '0' ),
            )
        );

        woocommerce_wp_checkbox(
            array(
                'id'          => '_qpnt_exclude_from_points',
                'label'       => 'Exclude from points',
                'description' => 'Do not award points for this product.',
            )
        );

        woocommerce_wp_checkbox(
            array(
                'id'          => '_qpnt_double_points',
                'label'       => 'Double points mode',
                'description' => 'Apply 2x points for this product.',
            )
        );
        echo '</div>';
    }

    public function save_product_point_fields( $post_id ) {
        if ( ! qpnt_cap_can_manage() || ! qpnt_is_premium() ) {
            return;
        }

        $rate = isset( $_POST['_qpnt_points_per_currency'] ) ? wc_format_decimal( wp_unslash( $_POST['_qpnt_points_per_currency'] ) ) : '';
        update_post_meta( $post_id, '_qpnt_points_per_currency', $rate );

        update_post_meta( $post_id, '_qpnt_exclude_from_points', isset( $_POST['_qpnt_exclude_from_points'] ) ? 'yes' : 'no' );
        update_post_meta( $post_id, '_qpnt_double_points', isset( $_POST['_qpnt_double_points'] ) ? 'yes' : 'no' );
    }

    public function render_category_multiplier_add() {
        if ( ! qpnt_is_premium() ) {
            return;
        }
        ?>
        <div class="form-field term-group">
            <label for="qpnt_category_multiplier">Points Multiplier</label>
            <input type="number" step="0.01" min="0" name="qpnt_category_multiplier" id="qpnt_category_multiplier" value="" />
            <p class="description">Optional category-level multiplier for product points.</p>
        </div>
        <?php
    }

    public function render_category_multiplier_edit( $term ) {
        if ( ! qpnt_is_premium() ) {
            return;
        }
        $value = get_term_meta( $term->term_id, '_qpnt_category_multiplier', true );
        ?>
        <tr class="form-field term-group-wrap">
            <th scope="row"><label for="qpnt_category_multiplier">Points Multiplier</label></th>
            <td>
                <input type="number" step="0.01" min="0" name="qpnt_category_multiplier" id="qpnt_category_multiplier" value="<?php echo esc_attr( $value ); ?>" />
                <p class="description">Optional category-level multiplier for product points.</p>
            </td>
        </tr>
        <?php
    }

    public function save_category_multiplier( $term_id ) {
        if ( ! qpnt_cap_can_manage() || ! qpnt_is_premium() ) {
            return;
        }

        if ( isset( $_POST['qpnt_category_multiplier'] ) ) {
            $val = wc_format_decimal( wp_unslash( $_POST['qpnt_category_multiplier'] ) );
            update_term_meta( $term_id, '_qpnt_category_multiplier', $val );
        }
    }
}
