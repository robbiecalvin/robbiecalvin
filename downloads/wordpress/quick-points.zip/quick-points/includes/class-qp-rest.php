<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QPNT_Rest {
    private $settings;
    private $transactions;
    private $tiers;

    public function __construct( $settings, $transactions, $tiers ) {
        $this->settings     = $settings;
        $this->transactions = $transactions;
        $this->tiers        = $tiers;
    }

    public function hooks() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes() {
        register_rest_route(
            'quick-points/v1',
            '/user/(?P<id>\d+)',
            array(
                'methods'             => 'GET',
                'callback'            => array( $this, 'get_user_points' ),
                'permission_callback' => array( $this, 'can_view_user_points' ),
            )
        );

        register_rest_route(
            'quick-points/v1',
            '/adjust',
            array(
                'methods'             => 'POST',
                'callback'            => array( $this, 'adjust_points' ),
                'permission_callback' => array( $this, 'can_adjust_points' ),
                'args'                => array(
                    'user_id' => array( 'required' => true, 'type' => 'integer' ),
                    'points'  => array( 'required' => true, 'type' => 'integer' ),
                    'description' => array( 'required' => false, 'type' => 'string' ),
                ),
            )
        );

        register_rest_route(
            'quick-points/v1',
            '/leaderboard',
            array(
                'methods'             => 'GET',
                'callback'            => array( $this, 'get_leaderboard' ),
                'permission_callback' => array( $this, 'can_view_leaderboard' ),
            )
        );
    }

    public function can_view_user_points( $request ) {
        $target_id = absint( $request->get_param( 'id' ) );
        return qpnt_cap_can_manage() || ( is_user_logged_in() && get_current_user_id() === $target_id );
    }

    public function can_adjust_points() {
        return qpnt_cap_can_manage();
    }

    public function can_view_leaderboard() {
        return qpnt_is_premium() && is_user_logged_in();
    }

    public function get_user_points( $request ) {
        if ( ! qpnt_is_premium() ) {
            return new WP_Error( 'qpnt_premium_required', 'Premium required.', array( 'status' => 403 ) );
        }

        $user_id  = absint( $request->get_param( 'id' ) );
        $balance  = $this->transactions->get_balance( $user_id );
        $tier     = $this->tiers->get_user_tier( $user_id );

        return rest_ensure_response(
            array(
                'user_id'        => $user_id,
                'total_points'   => (int) $balance['total_points'],
                'lifetime_points'=> (int) $balance['lifetime_points'],
                'tier'           => $tier ? $tier['name'] : null,
            )
        );
    }

    public function adjust_points( $request ) {
        if ( ! qpnt_is_premium() ) {
            return new WP_Error( 'qpnt_premium_required', 'Premium required.', array( 'status' => 403 ) );
        }

        $user_id = absint( $request->get_param( 'user_id' ) );
        $points  = (int) $request->get_param( 'points' );
        $desc    = sanitize_text_field( (string) $request->get_param( 'description' ) );

        if ( $user_id <= 0 || 0 === $points ) {
            return new WP_Error( 'qpnt_invalid_input', 'Invalid input.', array( 'status' => 400 ) );
        }

        $ok = $this->transactions->add_points( $user_id, $points, 'admin_adjust', 0, $desc, $points > 0 );
        if ( false === $ok ) {
            return new WP_Error( 'qpnt_adjust_failed', 'Adjustment failed.', array( 'status' => 400 ) );
        }

        return rest_ensure_response( array( 'success' => true ) );
    }

    public function get_leaderboard() {
        if ( ! qpnt_is_premium() ) {
            return new WP_Error( 'qpnt_premium_required', 'Premium required.', array( 'status' => 403 ) );
        }

        $rows = $this->transactions->get_leaderboard( 20 );
        return rest_ensure_response( $rows );
    }
}
