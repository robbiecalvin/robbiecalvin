<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QPNT_Settings {
    public function all() {
        return qpnt_get_settings();
    }

    public function get( $key, $default = null ) {
        $settings = $this->all();
        return $settings[ $key ] ?? $default;
    }

    public function save( $input ) {
        $current = $this->all();

        $out = $current;
        $out['points_per_currency']       = max( 0.01, qpnt_float( $input['points_per_currency'] ?? $current['points_per_currency'], 1 ) );
        $out['redemption_enabled']        = empty( $input['redemption_enabled'] ) ? 0 : 1;
        $out['redemption_points']         = max( 1, qpnt_int( $input['redemption_points'] ?? $current['redemption_points'], 100 ) );
        $out['redemption_value']          = max( 0.01, qpnt_float( $input['redemption_value'] ?? $current['redemption_value'], 1 ) );
        $out['expiry_enabled']            = empty( $input['expiry_enabled'] ) ? 0 : 1;
        $out['expiry_days']               = max( 1, qpnt_int( $input['expiry_days'] ?? $current['expiry_days'], 365 ) );
        $out['max_redeem_per_order']      = max( 0, qpnt_float( $input['max_redeem_per_order'] ?? $current['max_redeem_per_order'], 0 ) );
        $out['order_status_trigger']      = sanitize_key( $input['order_status_trigger'] ?? $current['order_status_trigger'] );
        $out['liability_warning_display'] = empty( $input['liability_warning_display'] ) ? 0 : 1;

        $out['enable_referrals']          = empty( $input['enable_referrals'] ) ? 0 : 1;
        $out['enable_tiers']              = empty( $input['enable_tiers'] ) ? 0 : 1;
        $out['enable_activity_rewards']   = empty( $input['enable_activity_rewards'] ) ? 0 : 1;

        $out['activity_registration']     = max( 0, qpnt_int( $input['activity_registration'] ?? $current['activity_registration'], 25 ) );
        $out['activity_review']           = max( 0, qpnt_int( $input['activity_review'] ?? $current['activity_review'], 10 ) );
        $out['activity_anniversary']      = max( 0, qpnt_int( $input['activity_anniversary'] ?? $current['activity_anniversary'], 50 ) );
        $out['activity_referral']         = max( 0, qpnt_int( $input['activity_referral'] ?? $current['activity_referral'], 100 ) );

        $out['tier_rule_mode']            = sanitize_key( $input['tier_rule_mode'] ?? $current['tier_rule_mode'] );
        $out['points_only_checkout']      = empty( $input['points_only_checkout'] ) ? 0 : 1;
        $out['points_cash_partial']       = empty( $input['points_cash_partial'] ) ? 0 : 1;
        $out['min_cart_total_for_redeem'] = max( 0, qpnt_float( $input['min_cart_total_for_redeem'] ?? $current['min_cart_total_for_redeem'], 0 ) );

        if ( ! in_array( $out['order_status_trigger'], array( 'completed', 'processing' ), true ) ) {
            $out['order_status_trigger'] = 'completed';
        }

        if ( ! in_array( $out['tier_rule_mode'], array( 'lifetime_points', 'annual_spend', 'rolling_12_months' ), true ) ) {
            $out['tier_rule_mode'] = 'lifetime_points';
        }

        update_option( 'qpnt_settings', $out, false );
        return $out;
    }
}
