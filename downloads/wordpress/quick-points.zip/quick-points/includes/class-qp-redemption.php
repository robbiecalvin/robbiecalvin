<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QPNT_Redemption {
    private $settings;
    private $transactions;
    private $tiers;

    public function __construct( $settings, $transactions, $tiers ) {
        $this->settings     = $settings;
        $this->transactions = $transactions;
        $this->tiers        = $tiers;
    }

    public function hooks() {
        add_action( 'woocommerce_before_cart_totals', array( $this, 'render_redeem_box' ) );
        add_action( 'wp_loaded', array( $this, 'handle_redeem_submission' ) );
        add_action( 'woocommerce_cart_calculate_fees', array( $this, 'apply_redemption_discount' ), 20 );
        add_action( 'woocommerce_checkout_create_order', array( $this, 'store_order_redeem_meta' ), 20, 2 );
        add_action( 'woocommerce_thankyou', array( $this, 'finalize_redemption' ), 30, 1 );
    }

    public function render_redeem_box() {
        if ( ! is_user_logged_in() || ! WC()->cart ) {
            return;
        }
        if ( ! (bool) $this->settings->get( 'redemption_enabled', 1 ) ) {
            return;
        }

        $balance = $this->transactions->get_balance( get_current_user_id() );
        $current = $this->get_requested_points();

        echo '<div class="qpnt-redeem-box">';
        echo '<h3>Redeem Points</h3>';
        echo '<p>Available points: <strong>' . esc_html( (int) $balance['total_points'] ) . '</strong></p>';
        echo '<form method="post">';
        wp_nonce_field( 'qpnt_apply_redeem', 'qpnt_redeem_nonce' );
        echo '<input type="hidden" name="qpnt_redeem_action" value="apply" />';
        echo '<input type="number" name="qpnt_redeem_points" min="0" step="1" value="' . esc_attr( (int) $current ) . '" />';
        echo '<button class="button" type="submit">Apply</button>';
        echo '<button class="button" type="submit" name="qpnt_redeem_clear" value="1">Clear</button>';
        echo '</form>';
        echo '</div>';
    }

    public function handle_redeem_submission() {
        if ( ! isset( $_POST['qpnt_redeem_action'] ) ) {
            return;
        }

        if ( ! is_user_logged_in() || ! WC()->cart ) {
            return;
        }

        if ( ! isset( $_POST['qpnt_redeem_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qpnt_redeem_nonce'] ) ), 'qpnt_apply_redeem' ) ) {
            return;
        }
        if ( ! (bool) $this->settings->get( 'redemption_enabled', 1 ) ) {
            WC()->session->set( 'qpnt_redeem_points', 0 );
            wc_add_notice( 'Points redemption is currently disabled.', 'error' );
            return;
        }

        if ( ! empty( $_POST['qpnt_redeem_clear'] ) ) {
            WC()->session->set( 'qpnt_redeem_points', 0 );
            wc_add_notice( 'Points redemption removed.', 'notice' );
            return;
        }

        $requested = max( 0, absint( $_POST['qpnt_redeem_points'] ?? 0 ) );
        $balance   = $this->transactions->get_balance( get_current_user_id() );

        $allowed_points = min( $requested, (int) $balance['total_points'] );
        $allowed_points = min( $allowed_points, $this->get_points_cap_for_cart() );

        WC()->session->set( 'qpnt_redeem_points', $allowed_points );
        wc_add_notice( 'Applied points: ' . $allowed_points, 'success' );
    }

    public function apply_redemption_discount( $cart ) {
        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
            return;
        }

        if ( ! is_user_logged_in() || ! $cart instanceof WC_Cart ) {
            return;
        }
        if ( ! (bool) $this->settings->get( 'redemption_enabled', 1 ) ) {
            return;
        }

        $points = $this->get_requested_points();
        if ( $points <= 0 ) {
            return;
        }

        $settings = $this->settings->all();
        $cart_subtotal = (float) $cart->get_subtotal();
        $min_total = (float) $settings['min_cart_total_for_redeem'];

        if ( $min_total > 0 && $cart_subtotal < $min_total ) {
            return;
        }

        $value = $this->points_to_currency( $points );
        if ( $value <= 0 ) {
            return;
        }

        $max_redeem_currency = (float) $settings['max_redeem_per_order'];
        if ( $max_redeem_currency > 0 ) {
            $value = min( $value, $max_redeem_currency );
        }

        // Prevent stacking beyond subtotal.
        $value = min( $value, $cart_subtotal );

        if ( qpnt_is_premium() && $this->settings->get( 'enable_tiers', 0 ) ) {
            $tier = $this->tiers->get_user_tier( get_current_user_id() );
            if ( $tier ) {
                $perks = $this->tiers->get_tier_perks( (int) $tier['id'] );
                $bonus = (float) ( $perks['redemption_bonus_percent'] ?? 0 );
                if ( $bonus > 0 ) {
                    $value += $value * ( $bonus / 100 );
                    $value = min( $value, $cart_subtotal );
                }
            }
        }

        if ( $value > 0 ) {
            $cart->add_fee( 'Points Discount', -1 * $value, false );
        }
    }

    public function store_order_redeem_meta( $order, $data ) {
        if ( ! $order instanceof WC_Order ) {
            return;
        }

        $points = $this->get_requested_points();
        if ( $points > 0 ) {
            $order->update_meta_data( '_qpnt_redeem_points', (int) $points );
        }
    }

    public function finalize_redemption( $order_id ) {
        if ( ! is_user_logged_in() ) {
            return;
        }

        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        if ( $this->transactions->has_order_redeem( $order_id ) ) {
            WC()->session->set( 'qpnt_redeem_points', 0 );
            return;
        }

        $user_id = (int) $order->get_user_id();
        if ( $user_id <= 0 ) {
            return;
        }

        $points = (int) $order->get_meta( '_qpnt_redeem_points', true );
        if ( $points <= 0 ) {
            WC()->session->set( 'qpnt_redeem_points', 0 );
            return;
        }

        $balance = $this->transactions->get_balance( $user_id );
        $points  = min( $points, (int) $balance['total_points'] );
        if ( $points <= 0 ) {
            WC()->session->set( 'qpnt_redeem_points', 0 );
            return;
        }

        $ok = $this->transactions->add_points(
            $user_id,
            -1 * $points,
            'redeem',
            (int) $order_id,
            sprintf( 'Redeemed points on order #%d', (int) $order_id ),
            false
        );

        if ( false !== $ok ) {
            $this->transactions->mark_order_redeemed( $order_id );
        }

        WC()->session->set( 'qpnt_redeem_points', 0 );
    }

    private function get_requested_points() {
        if ( ! WC()->session ) {
            return 0;
        }

        return max( 0, absint( WC()->session->get( 'qpnt_redeem_points', 0 ) ) );
    }

    private function points_to_currency( $points ) {
        $settings = $this->settings->all();
        $points_per_unit = max( 1, (int) $settings['redemption_points'] );
        $currency_value = max( 0.01, (float) $settings['redemption_value'] );

        $value = ( $points / $points_per_unit ) * $currency_value;

        if ( class_exists( 'WooCommerce' ) ) {
            return (float) wc_format_decimal( $value );
        }

        return round( $value, 2 );
    }

    private function get_points_cap_for_cart() {
        if ( ! WC()->cart ) {
            return 0;
        }

        $settings = $this->settings->all();
        $subtotal = (float) WC()->cart->get_subtotal();
        $points_per_unit = max( 1, (int) $settings['redemption_points'] );
        $unit_value = max( 0.01, (float) $settings['redemption_value'] );

        $max_by_subtotal = (int) floor( $subtotal / $unit_value * $points_per_unit );

        $max_setting_currency = (float) $settings['max_redeem_per_order'];
        if ( $max_setting_currency > 0 ) {
            $max_by_setting = (int) floor( $max_setting_currency / $unit_value * $points_per_unit );
            return max( 0, min( $max_by_subtotal, $max_by_setting ) );
        }

        return max( 0, $max_by_subtotal );
    }
}
