# Quick Points -- Visual To‑Do

## Dashboard

-   Remove nested containers
-   Add left-side padding to headings + inputs
-   Add margins between containers

## Transactions

-   Add left-side padding to labels + headings
-   Add container margins

## Rules Page

-   Add left-side padding
-   Improve visual hierarchy (padding, spacing)

## Settings

-   Add left-side padding to headings + subheadings
-   Add margins for hierarchy
