<?php
/**
 * Plugin Name: Quick License
 * Plugin URI: https://quickwoo.com
 * Description: Self-hosted license generation and activation authority for QuickWoo plugins.
 * Version: 1.0.0
 * Author: QuickWoo by Robbie Calvin
 * Author URI: https://quickwoo.pro
 * Text Domain: quick-license
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/quick-core/bootstrap.php';
}

if (! defined('QLIC_VERSION')) {
    define('QLIC_VERSION', '1.0.0');
}

if (! defined('QLIC_FILE')) {
    define('QLIC_FILE', __FILE__);
}

if (! defined('QLIC_PATH')) {
    define('QLIC_PATH', plugin_dir_path(__FILE__));
}

if (! defined('QLIC_URL')) {
    define('QLIC_URL', plugin_dir_url(__FILE__));
}

require_once QLIC_PATH . 'includes/class-ql-activator.php';
require_once QLIC_PATH . 'includes/class-ql-license-generator.php';
require_once QLIC_PATH . 'includes/class-ql-settings.php';
require_once QLIC_PATH . 'includes/class-ql-admin.php';
require_once QLIC_PATH . 'includes/class-ql-rest.php';
require_once QLIC_PATH . 'includes/class-ql-product-hub.php';
require_once QLIC_PATH . 'includes/class-ql-woocommerce.php';

register_activation_hook(QLIC_FILE, array('QLIC_Activator', 'activate'));

/**
 * Bootstrap plugin components.
 */
function qlic_bootstrap()
{
    $settings = new QLIC_Settings();
    $settings->register();

    if (is_admin()) {
        $admin = new QLIC_Admin($settings);
        $admin->register();
    }

    $rest = new QLIC_REST($settings);
    $rest->register();

    if (class_exists('WooCommerce')) {
        $woo = new QLIC_WooCommerce();
        $woo->register();
    }
}
add_action('plugins_loaded', 'qlic_bootstrap');

/**
 * Resolve current site domain.
 *
 * @return string
 */
function qlic_current_domain()
{
    $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
    if (!is_string($host) || $host === '') {
        return '';
    }

    return trim(strtolower($host), '.');
}

/**
 * Check whether a product slug matches a requested entitlement slug.
 *
 * @param string $license_product Product from license row.
 * @param string $requested Requested product key.
 * @return bool
 */
function qlic_product_slug_matches($license_product, $requested)
{
    $license_product = sanitize_title((string) $license_product);
    $requested = sanitize_title((string) $requested);

    if ($license_product === '' || $requested === '') {
        return false;
    }

    return $license_product === $requested || strpos($license_product, $requested . '-') === 0;
}

/**
 * Validate/activate a specific license key for the current domain.
 *
 * @param string            $license_key_raw License key.
 * @param array<int,string> $product_slugs Valid product slugs.
 * @return array<string,mixed>
 */
function qlic_activate_license_key_for_products($license_key_raw, $product_slugs)
{
    $result = array(
        'valid' => false,
        'status' => 'invalid',
        'message' => 'Invalid license key.',
        'product_slug' => '',
        'activation_limit' => 0,
        'activations' => 0,
        'expires_at' => null,
    );

    $license_key = QLIC_License_Generator::canonicalize((string) $license_key_raw);
    if ($license_key === '') {
        $result['message'] = 'License key is required.';
        return $result;
    }

    $product_slugs = is_array($product_slugs) ? $product_slugs : array();
    $normalized_slugs = array();
    foreach ($product_slugs as $slug) {
        $slug = sanitize_title((string) $slug);
        if ($slug !== '') {
            $normalized_slugs[] = $slug;
        }
    }
    $normalized_slugs = array_values(array_unique($normalized_slugs));
    if (empty($normalized_slugs)) {
        $result['message'] = 'No valid product scope configured.';
        return $result;
    }
    $normalized_slugs = qlic_expand_product_scope($normalized_slugs);

    global $wpdb;
    $licenses_table = $wpdb->prefix . 'quick_licenses';
    $activations_table = $wpdb->prefix . 'quick_license_activations';

    $license = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id, product_slug, status, activation_limit, expires_at FROM {$licenses_table} WHERE license_key = %s LIMIT 1",
            $license_key
        ),
        ARRAY_A
    );

    if (!is_array($license) || empty($license)) {
        $result['message'] = 'License not found.';
        return $result;
    }

    $license_id = isset($license['id']) ? absint($license['id']) : 0;
    $license_product = isset($license['product_slug']) ? sanitize_title((string) $license['product_slug']) : '';
    $status = isset($license['status']) ? sanitize_key((string) $license['status']) : '';
    $expires_at = isset($license['expires_at']) ? (string) $license['expires_at'] : null;
    $activation_limit = max(1, isset($license['activation_limit']) ? absint($license['activation_limit']) : 1);

    $product_match = false;
    foreach ($normalized_slugs as $slug) {
        if (qlic_product_slug_matches($license_product, $slug)) {
            $product_match = true;
            break;
        }
    }
    if (!$product_match) {
        $result['message'] = 'License does not match this product.';
        return $result;
    }

    if ($status !== 'active') {
        $result['status'] = $status !== '' ? $status : 'invalid';
        $result['message'] = 'License is not active.';
        return $result;
    }

    if (!empty($expires_at) && strtotime($expires_at) !== false && strtotime($expires_at) < time()) {
        $result['status'] = 'expired';
        $result['message'] = 'License is expired.';
        return $result;
    }

    $domain = qlic_current_domain();
    if ($domain === '') {
        $result['status'] = 'invalid';
        $result['message'] = 'Could not resolve site domain.';
        return $result;
    }

    $activation_count = (int) $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM {$activations_table} WHERE license_id = %d", $license_id)
    );

    $existing_activation_id = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT id FROM {$activations_table} WHERE license_id = %d AND domain = %s LIMIT 1",
            $license_id,
            $domain
        )
    );

    if ($existing_activation_id > 0) {
        $wpdb->update(
            $activations_table,
            array('last_check_in' => current_time('mysql')),
            array('id' => $existing_activation_id),
            array('%s'),
            array('%d')
        );

        $result['valid'] = true;
        $result['status'] = 'active';
        $result['message'] = 'License activated for this site.';
        $result['product_slug'] = $license_product;
        $result['activation_limit'] = $activation_limit;
        $result['activations'] = $activation_count;
        $result['expires_at'] = $expires_at;
        return $result;
    }

    if ($activation_count >= $activation_limit) {
        $result['status'] = 'active';
        $result['message'] = 'Activation limit reached.';
        $result['product_slug'] = $license_product;
        $result['activation_limit'] = $activation_limit;
        $result['activations'] = $activation_count;
        $result['expires_at'] = $expires_at;
        return $result;
    }

    $inserted = $wpdb->insert(
        $activations_table,
        array(
            'license_id' => $license_id,
            'domain' => $domain,
            'activated_at' => current_time('mysql'),
            'last_check_in' => current_time('mysql'),
        ),
        array('%d', '%s', '%s', '%s')
    );

    if (! $inserted) {
        $result['status'] = 'invalid';
        $result['message'] = 'Could not activate license for this domain.';
        return $result;
    }

    $activation_count++;
    $result['valid'] = true;
    $result['status'] = 'active';
    $result['message'] = 'License activated successfully.';
    $result['product_slug'] = $license_product;
    $result['activation_limit'] = $activation_limit;
    $result['activations'] = $activation_count;
    $result['expires_at'] = $expires_at;
    return $result;
}

/**
 * Read license status details for a key in product scope.
 *
 * @param string            $license_key_raw License key.
 * @param array<int,string> $product_slugs Product scope.
 * @return array<string,mixed>
 */
function qlic_get_license_status_for_key_products($license_key_raw, $product_slugs)
{
    $result = array(
        'valid' => false,
        'status' => 'invalid',
        'message' => 'Invalid license key.',
        'product_slug' => '',
        'activation_limit' => 0,
        'activations' => 0,
        'expires_at' => null,
        'domain_active' => false,
    );

    $license_key = QLIC_License_Generator::canonicalize((string) $license_key_raw);
    if ($license_key === '') {
        $result['message'] = 'License key is required.';
        return $result;
    }

    $product_slugs = is_array($product_slugs) ? $product_slugs : array();
    $normalized_slugs = array();
    foreach ($product_slugs as $slug) {
        $slug = sanitize_title((string) $slug);
        if ($slug !== '') {
            $normalized_slugs[] = $slug;
        }
    }
    $normalized_slugs = array_values(array_unique($normalized_slugs));
    if (empty($normalized_slugs)) {
        $result['message'] = 'No valid product scope configured.';
        return $result;
    }
    $normalized_slugs = qlic_expand_product_scope($normalized_slugs);

    global $wpdb;
    $licenses_table = $wpdb->prefix . 'quick_licenses';
    $activations_table = $wpdb->prefix . 'quick_license_activations';

    $license = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT id, product_slug, status, activation_limit, expires_at FROM {$licenses_table} WHERE license_key = %s LIMIT 1",
            $license_key
        ),
        ARRAY_A
    );

    if (!is_array($license) || empty($license)) {
        $result['message'] = 'License not found.';
        return $result;
    }

    $license_id = isset($license['id']) ? absint($license['id']) : 0;
    $license_product = isset($license['product_slug']) ? sanitize_title((string) $license['product_slug']) : '';
    $status = isset($license['status']) ? sanitize_key((string) $license['status']) : '';
    $expires_at = isset($license['expires_at']) ? (string) $license['expires_at'] : null;
    $activation_limit = max(1, isset($license['activation_limit']) ? absint($license['activation_limit']) : 1);

    $product_match = false;
    foreach ($normalized_slugs as $slug) {
        if (qlic_product_slug_matches($license_product, $slug)) {
            $product_match = true;
            break;
        }
    }
    if (!$product_match) {
        $result['message'] = 'License does not match this product.';
        return $result;
    }

    $activation_count = (int) $wpdb->get_var(
        $wpdb->prepare("SELECT COUNT(*) FROM {$activations_table} WHERE license_id = %d", $license_id)
    );
    $domain = qlic_current_domain();
    $domain_activation_id = 0;
    if ($domain !== '') {
        $domain_activation_id = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$activations_table} WHERE license_id = %d AND domain = %s LIMIT 1",
                $license_id,
                $domain
            )
        );
    }

    $result['status'] = $status !== '' ? $status : 'invalid';
    $result['product_slug'] = $license_product;
    $result['activation_limit'] = $activation_limit;
    $result['activations'] = $activation_count;
    $result['expires_at'] = $expires_at;
    $result['domain_active'] = $domain_activation_id > 0;

    if ($status !== 'active') {
        $result['message'] = 'License is not active.';
        return $result;
    }

    if (!empty($expires_at) && strtotime($expires_at) !== false && strtotime($expires_at) < time()) {
        $result['status'] = 'expired';
        $result['message'] = 'License is expired.';
        return $result;
    }

    $result['valid'] = true;
    $result['message'] = $domain_activation_id > 0 ? 'License is active on this domain.' : 'License is valid but not active on this domain.';
    return $result;
}

/**
 * Deactivate license key for current domain and product scope.
 *
 * @param string            $license_key_raw License key.
 * @param array<int,string> $product_slugs Product scope.
 * @return array<string,mixed>
 */
function qlic_deactivate_license_key_for_products($license_key_raw, $product_slugs)
{
    $status = qlic_get_license_status_for_key_products($license_key_raw, $product_slugs);
    if (empty($status['product_slug'])) {
        return $status;
    }

    $license_key = QLIC_License_Generator::canonicalize((string) $license_key_raw);
    if ($license_key === '') {
        $status['status'] = 'invalid';
        $status['message'] = 'License key is required.';
        return $status;
    }

    global $wpdb;
    $licenses_table = $wpdb->prefix . 'quick_licenses';
    $activations_table = $wpdb->prefix . 'quick_license_activations';

    $license_id = (int) $wpdb->get_var(
        $wpdb->prepare("SELECT id FROM {$licenses_table} WHERE license_key = %s LIMIT 1", $license_key)
    );
    if ($license_id < 1) {
        $status['status'] = 'invalid';
        $status['message'] = 'License not found.';
        return $status;
    }

    $domain = qlic_current_domain();
    if ($domain === '') {
        $status['status'] = 'invalid';
        $status['message'] = 'Could not resolve site domain.';
        return $status;
    }

    $wpdb->delete(
        $activations_table,
        array(
            'license_id' => $license_id,
            'domain' => $domain,
        ),
        array('%d', '%s')
    );

    $status = qlic_get_license_status_for_key_products($license_key, $product_slugs);
    $status['message'] = 'License deactivated for this domain.';
    return $status;
}

/**
 * Determine whether an active local license exists for any product slug.
 * Accepts exact slug or plan suffix variants (e.g. quick-forms-*).
 *
 * @param array<int,string> $product_slugs Product slugs.
 * @return bool
 */
function qlic_has_active_license_for_products($product_slugs)
{
    if (!is_array($product_slugs) || empty($product_slugs)) {
        return false;
    }

    global $wpdb;
    $licenses_table = $wpdb->prefix . 'quick_licenses';
    $activations_table = $wpdb->prefix . 'quick_license_activations';

    $licenses_exist = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $licenses_table));
    if (empty($licenses_exist)) {
        return false;
    }

    $normalized_slugs = array();
    foreach ($product_slugs as $slug) {
        $slug = sanitize_title((string) $slug);
        if ($slug !== '') {
            $normalized_slugs[] = $slug;
        }
    }
    $normalized_slugs = array_values(array_unique($normalized_slugs));
    if (empty($normalized_slugs)) {
        return false;
    }

    $rows = $wpdb->get_results(
        "SELECT id, product_slug, status, expires_at FROM {$licenses_table}",
        ARRAY_A
    );
    if (!is_array($rows) || empty($rows)) {
        return false;
    }

    $domain = qlic_current_domain();
    $activations_exist = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $activations_table));
    $domain_activations = array();
    if (!empty($activations_exist) && $domain !== '') {
        $activation_rows = $wpdb->get_results(
            $wpdb->prepare("SELECT license_id FROM {$activations_table} WHERE domain = %s", $domain),
            ARRAY_A
        );
        if (is_array($activation_rows)) {
            foreach ($activation_rows as $activation_row) {
                $license_id = isset($activation_row['license_id']) ? absint($activation_row['license_id']) : 0;
                if ($license_id > 0) {
                    $domain_activations[$license_id] = true;
                }
            }
        }
    }

    foreach ($rows as $row) {
        $license_id = isset($row['id']) ? absint($row['id']) : 0;
        $product_slug = isset($row['product_slug']) ? sanitize_title((string) $row['product_slug']) : '';
        $status = isset($row['status']) ? sanitize_key((string) $row['status']) : '';
        $expires_at = isset($row['expires_at']) ? (string) $row['expires_at'] : '';

        if ($license_id < 1 || $product_slug === '' || $status !== 'active') {
            continue;
        }

        if ($expires_at !== '' && strtotime($expires_at) !== false && strtotime($expires_at) < time()) {
            continue;
        }

        $slug_match = false;
        foreach ($normalized_slugs as $wanted_slug) {
            if ($product_slug === $wanted_slug || strpos($product_slug, $wanted_slug . '-') === 0) {
                $slug_match = true;
                break;
            }
        }
        if (!$slug_match) {
            continue;
        }

        if (!empty($activations_exist) && $domain !== '' && !isset($domain_activations[$license_id])) {
            continue;
        }

        return true;
    }

    return false;
}

/**
 * Shared premium entitlement check for Quick Woo plugins.
 *
 * @param bool                $has_access Existing access state.
 * @param string|array<mixed> $products Product slug or slug list.
 * @return bool
 */
function qlic_filter_qwoo_has_active_license($has_access, $products)
{
    if ($has_access) {
        return true;
    }

    $product_slugs = qlic_expand_product_scope($products);

    return qlic_has_active_license_for_products($product_slugs);
}
add_filter('qwoo_has_active_license', 'qlic_filter_qwoo_has_active_license', 10, 2);

/**
 * Expand requested product slugs with their relevant bundle slugs.
 *
 * @param string|array<mixed> $products Product slug or slug list.
 * @return array<int,string>
 */
function qlic_expand_product_scope($products)
{
    $requested = is_array($products) ? $products : array($products);
    $requested = array_values(
        array_unique(
            array_filter(
                array_map(
                    static function ($slug) {
                        return sanitize_title((string) $slug);
                    },
                    $requested
                )
            )
        )
    );

    $expanded = $requested;
    $expanded[] = 'quick-woo-suite';
    $expanded[] = 'quick-bundle';

    $secretary_plugins = array('quick-forms', 'quick-quotes', 'quick-schedule');
    $product_plugins = array('quick-add', 'quick-edit', 'quick-variations');
    $learn_plugins = array('quick-questions', 'quick-course-builder');

    if (!empty(array_intersect($requested, $secretary_plugins)) || in_array('quick-woo-bundle', $requested, true) || in_array('quick-secretary', $requested, true)) {
        $expanded[] = 'quick-woo-bundle';
        $expanded[] = 'quick-secretary';
    }

    if (!empty(array_intersect($requested, $product_plugins)) || in_array('quick-product-bundle', $requested, true)) {
        $expanded[] = 'quick-product-bundle';
    }

    if (!empty(array_intersect($requested, $learn_plugins)) || in_array('quick-learn-bundle', $requested, true)) {
        $expanded[] = 'quick-learn-bundle';
    }

    return array_values(array_unique($expanded));
}

/**
 * Canonical premium feature catalog for all Quick Woo plugins.
 *
 * @return array<string,array<string,array<int,string>>>
 */
function qlic_get_premium_feature_catalog()
{
    return array(
        'quick-forms' => array(
            'free' => array('form-builder', 'submissions', 'basic-fields', 'basic-email-notice'),
            'premium' => array('conditional-logic', 'quick-quotes-mapping', 'advanced-email-automation', 'exports-analytics'),
        ),
        'quick-quotes' => array(
            'free' => array('manual-quotes', 'invoice-rendering', 'quote-status-tracking'),
            'premium' => array('quick-forms-auto-quote', 'field-option-price-mapping', 'stripe-full-partial-payments', 'invoice-customizer', 'reminders-followups'),
        ),
        'quick-schedule' => array(
            'free' => array('appointment-requests', 'manual-approve-decline', 'schedule-list'),
            'premium' => array('stripe-consultation-fees', 'availability-rules', 'quick-quotes-handoff', 'calendar-sync'),
        ),
        'quick-seo' => array(
            'free' => array('spreadsheet-editor-limited-rows', 'basic-meta-editing'),
            'premium' => array('unlimited-rows', 'sitemaps', 'robots-editor', 'schema-builder', 'quick-integrations'),
        ),
        'quick-audit' => array(
            'free' => array('first-10-pages-audit'),
            'premium' => array('full-site-crawl', 'scheduled-audits', 'history-comparison', 'priority-fix-export'),
        ),
        'quick-code' => array(
            'free' => array('per-page-html-css-injection'),
            'premium' => array('global-wp-head-injection', 'global-js-injection', 'rules-conditions', 'history-rollback'),
        ),
        'quick-traffic' => array(
            'free' => array('total-page-views'),
            'premium' => array('referrer-tracking', 'device-breakdown', 'time-on-page', 'internal-click-tracking', 'events-goals'),
        ),
        'quick-site' => array(
            'free' => array('cache-purge', 'basic-optimization-toggles'),
            'premium' => array('performance-scan', 'optimization-recommendations', 'scheduled-maintenance'),
        ),
        'quick-accountant' => array(
            'free' => array('manual-transactions', 'basic-dashboard'),
            'premium' => array('recurring-invoices', 'tax-rules', 'client-statements', 'exports-integrations'),
        ),
        'quick-questions' => array(
            'free' => array('questions-answers', 'categories', 'basic-moderation'),
            'premium' => array('submission-workflows', 'moderation-queue', 'insights-reporting', 'schema-output'),
        ),
        'quick-course-builder' => array(
            'free' => array('courses-modules-tests-certificates'),
            'premium' => array('drip-content', 'paid-enrollment-automation', 'advanced-grading', 'completion-reporting'),
        ),
        'quick-add' => array(
            'free' => array('basic-bulk-add', 'templates'),
            'premium' => array('advanced-bulk-ops', 'saved-workflows', 'conditional-templates', 'audit-logs'),
        ),
        'quick-edit' => array(
            'free' => array('basic-bulk-edit'),
            'premium' => array('rule-based-bulk-edit', 'undo-history', 'scheduled-edits'),
        ),
        'quick-variations' => array(
            'free' => array('quick-variation-generation-limited'),
            'premium' => array('unlimited-generation', 'preset-profiles', 'advanced-pricing-controls'),
        ),
    );
}

/**
 * Get feature tiers for a plugin slug.
 *
 * @param string $plugin_slug Plugin slug.
 * @return array<string,array<int,string>>
 */
function qlic_get_plugin_feature_tiers($plugin_slug)
{
    $catalog = qlic_get_premium_feature_catalog();
    $plugin_slug = sanitize_title((string) $plugin_slug);

    return isset($catalog[$plugin_slug]) && is_array($catalog[$plugin_slug])
        ? $catalog[$plugin_slug]
        : array('free' => array(), 'premium' => array());
}

add_action(
    'plugins_loaded',
    static function () {
        if (function_exists('qwoo_register_plugin')) {
            qwoo_register_plugin('quick-license', array(
                'name' => 'Quick Woo License',
                'version' => QLIC_VERSION,
                'file' => QLIC_FILE,
                'features' => array('license-generation', 'license-rest-api'),
            ));
        }

        if (function_exists('qwoo_event')) {
            qwoo_event('plugin_booted', array('plugin' => 'quick-license', 'version' => QLIC_VERSION));
        }
    },
    20
);
