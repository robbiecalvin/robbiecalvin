<?php

if (! defined('ABSPATH')) {
    exit;
}

class QLIC_License_Generator
{
    /**
     * Generate a random uppercase alpha-numeric license key.
     */
    public static function generate_key($characters = 32)
    {
        $characters = max(4, absint($characters));

        if ($characters % 4 !== 0) {
            $characters += 4 - ($characters % 4);
        }

        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $alphabet_length = strlen($alphabet);
        $raw = '';

        for ($i = 0; $i < $characters; $i++) {
            $raw .= $alphabet[random_int(0, $alphabet_length - 1)];
        }

        return implode('-', str_split($raw, 4));
    }

    /**
     * Normalize user input into canonical dashed key format.
     */
    public static function canonicalize($license_key)
    {
        $normalized = strtoupper(preg_replace('/[^A-Z0-9]/', '', (string) $license_key));

        if ($normalized === '') {
            return '';
        }

        if (strlen($normalized) % 4 !== 0) {
            return $normalized;
        }

        return implode('-', str_split($normalized, 4));
    }
}
