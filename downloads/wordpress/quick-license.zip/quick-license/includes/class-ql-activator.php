<?php

if (! defined('ABSPATH')) {
    exit;
}

class QLIC_Activator
{
    /**
     * Create plugin tables and defaults.
     */
    public static function activate()
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $licenses_table = $wpdb->prefix . 'quick_licenses';
        $activations_table = $wpdb->prefix . 'quick_license_activations';

        $sql_licenses = "CREATE TABLE {$licenses_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            product_slug VARCHAR(191) NOT NULL,
            license_key VARCHAR(255) NOT NULL,
            customer_email VARCHAR(255) NOT NULL,
            activation_limit INT(11) NOT NULL DEFAULT 1,
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            expires_at DATETIME NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY license_key (license_key),
            KEY product_slug (product_slug),
            KEY customer_email (customer_email),
            KEY status (status)
        ) {$charset_collate};";

        $sql_activations = "CREATE TABLE {$activations_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            license_id BIGINT(20) UNSIGNED NOT NULL,
            domain VARCHAR(255) NOT NULL,
            activated_at DATETIME NOT NULL,
            last_check_in DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY license_domain (license_id, domain),
            KEY domain (domain),
            KEY last_check_in (last_check_in)
        ) {$charset_collate};";

        dbDelta($sql_licenses);
        dbDelta($sql_activations);

        $defaults = array(
            'rest_enabled' => 1,
            'shared_secret' => '',
            'default_activation_limit' => 1,
            'default_expiration_days' => 0,
            'email_template' => "Hello {{customer_email}},\n\nYour license key for {{product_slug}} is:\n{{license_key}}\n\nThank you.",
        );

        if (! get_option('quick_license_settings')) {
            add_option('quick_license_settings', $defaults);
        }

        update_option('qlic_db_version', QLIC_VERSION);
    }
}
