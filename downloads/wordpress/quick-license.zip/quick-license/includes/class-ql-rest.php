<?php

if (! defined('ABSPATH')) {
    exit;
}

class QLIC_REST
{
    /**
     * @var QLIC_Settings
     */
    private $settings;

    public function __construct(QLIC_Settings $settings)
    {
        $this->settings = $settings;
    }

    public function register()
    {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes()
    {
        register_rest_route(
            'quick-license/v1',
            '/validate',
            array(
                'methods' => 'POST',
                'callback' => array($this, 'validate_license'),
                'permission_callback' => '__return_true',
            )
        );
    }

    /**
     * Validate and possibly activate a license for a domain.
     */
    public function validate_license(WP_REST_Request $request)
    {
        $settings = $this->settings->get_settings();

        if (empty($settings['rest_enabled'])) {
            return new WP_REST_Response(
                array(
                    'valid' => false,
                    'status' => 'disabled',
                    'activations' => 0,
                    'activation_limit' => 0,
                    'expires_at' => null,
                    'message' => 'REST validation is disabled.',
                ),
                503
            );
        }

        $params = (array) $request->get_json_params();
        if (empty($params)) {
            $params = $request->get_params();
        }

        $license_key_raw = sanitize_text_field((string) ($params['license_key'] ?? ''));
        $product_slug = sanitize_title((string) ($params['product_slug'] ?? ''));
        $domain_raw = sanitize_text_field((string) ($params['domain'] ?? ''));

        if ($license_key_raw === '' || $product_slug === '' || $domain_raw === '') {
            return $this->response_invalid('invalid', 0, 0, null, 'Missing required fields: license_key, domain, product_slug.', 400);
        }

        $shared_secret = (string) ($settings['shared_secret'] ?? '');
        $provided_token = sanitize_text_field((string) $request->get_header('X-QL-Token'));
        if ($provided_token === '') {
            $provided_token = sanitize_text_field((string) ($params['token'] ?? ''));
        }

        if ($shared_secret !== '' && ! hash_equals($shared_secret, $provided_token)) {
            return $this->response_invalid('unauthorized', 0, 0, null, 'Invalid shared secret token.', 403);
        }

        $license_key = QLIC_License_Generator::canonicalize($license_key_raw);
        $domain = $this->normalize_domain($domain_raw);

        if ($domain === '') {
            return $this->response_invalid('invalid', 0, 0, null, 'Invalid domain value.', 400);
        }

        global $wpdb;
        $licenses_table = $wpdb->prefix . 'quick_licenses';
        $activations_table = $wpdb->prefix . 'quick_license_activations';

        $license = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, status, activation_limit, expires_at FROM {$licenses_table} WHERE license_key = %s AND product_slug = %s LIMIT 1",
                $license_key,
                $product_slug
            ),
            ARRAY_A
        );

        if (! $license) {
            return $this->response_invalid('invalid', 0, 0, null, 'License not found.');
        }

        $activation_limit = max(1, (int) $license['activation_limit']);
        $expires_at = $license['expires_at'];

        if ($license['status'] === 'disabled') {
            return $this->response_invalid('disabled', $this->count_activations((int) $license['id']), $activation_limit, $expires_at, 'License is disabled.');
        }

        if ($this->is_expired($expires_at)) {
            return $this->response_invalid('expired', $this->count_activations((int) $license['id']), $activation_limit, $expires_at, 'License is expired.');
        }

        if ($license['status'] !== 'active') {
            return $this->response_invalid($license['status'], $this->count_activations((int) $license['id']), $activation_limit, $expires_at, 'License is not active.');
        }

        $now = current_time('mysql');

        $existing_activation_id = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$activations_table} WHERE license_id = %d AND domain = %s LIMIT 1",
                (int) $license['id'],
                $domain
            )
        );

        $activation_count = $this->count_activations((int) $license['id']);

        if ($existing_activation_id > 0) {
            $wpdb->update(
                $activations_table,
                array('last_check_in' => $now),
                array('id' => $existing_activation_id),
                array('%s'),
                array('%d')
            );

            return new WP_REST_Response(
                array(
                    'valid' => true,
                    'status' => 'active',
                    'activations' => $activation_count,
                    'activation_limit' => $activation_limit,
                    'expires_at' => $expires_at,
                    'message' => 'License is valid for this domain.',
                ),
                200
            );
        }

        if ($activation_count >= $activation_limit) {
            return $this->response_invalid('active', $activation_count, $activation_limit, $expires_at, 'Activation limit reached.');
        }

        $wpdb->insert(
            $activations_table,
            array(
                'license_id' => (int) $license['id'],
                'domain' => $domain,
                'activated_at' => $now,
                'last_check_in' => $now,
            ),
            array('%d', '%s', '%s', '%s')
        );

        $activation_count = $this->count_activations((int) $license['id']);

        return new WP_REST_Response(
            array(
                'valid' => true,
                'status' => 'active',
                'activations' => $activation_count,
                'activation_limit' => $activation_limit,
                'expires_at' => $expires_at,
                'message' => 'License is valid and domain has been activated.',
            ),
            200
        );
    }

    private function response_invalid($status, $activations, $activation_limit, $expires_at, $message, $code = 200)
    {
        return new WP_REST_Response(
            array(
                'valid' => false,
                'status' => (string) $status,
                'activations' => (int) $activations,
                'activation_limit' => (int) $activation_limit,
                'expires_at' => $expires_at,
                'message' => (string) $message,
            ),
            (int) $code
        );
    }

    private function count_activations($license_id)
    {
        global $wpdb;
        $activations_table = $wpdb->prefix . 'quick_license_activations';

        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$activations_table} WHERE license_id = %d",
                (int) $license_id
            )
        );
    }

    private function is_expired($expires_at)
    {
        if (empty($expires_at)) {
            return false;
        }

        $expires_ts = strtotime((string) $expires_at);
        $now_ts = strtotime(current_time('mysql'));

        return $expires_ts !== false && $expires_ts < $now_ts;
    }

    private function normalize_domain($domain)
    {
        $domain = trim(strtolower((string) $domain));
        if ($domain === '') {
            return '';
        }

        if (strpos($domain, '://') !== false) {
            $host = wp_parse_url($domain, PHP_URL_HOST);
            if (! is_string($host) || $host === '') {
                return '';
            }

            $domain = $host;
        }

        $domain = preg_replace('/:\d+$/', '', $domain);
        $domain = trim((string) $domain, '.');

        if ($domain === '' || preg_match('/[^a-z0-9\.-]/', $domain)) {
            return '';
        }

        return $domain;
    }
}
