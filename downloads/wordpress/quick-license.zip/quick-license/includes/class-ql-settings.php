<?php

if (! defined('ABSPATH')) {
    exit;
}

class QLIC_Settings
{
    private $option_name = 'quick_license_settings';

    /**
     * Register settings hooks.
     */
    public function register()
    {
        add_action('admin_init', array($this, 'register_settings'));
    }

    /**
     * Register plugin settings, sections, and fields.
     */
    public function register_settings()
    {
        register_setting(
            'qlic_settings_group',
            $this->option_name,
            array($this, 'sanitize_settings')
        );

        add_settings_section(
            'qlic_general_section',
            __('Quick License Settings', 'quick-license'),
            '__return_false',
            'ql-settings'
        );

        add_settings_field(
            'rest_enabled',
            __('Enable REST validation', 'quick-license'),
            array($this, 'render_rest_enabled_field'),
            'ql-settings',
            'qlic_general_section'
        );

        add_settings_field(
            'shared_secret',
            __('Shared secret key', 'quick-license'),
            array($this, 'render_shared_secret_field'),
            'ql-settings',
            'qlic_general_section'
        );

        add_settings_field(
            'default_activation_limit',
            __('Default activation limit', 'quick-license'),
            array($this, 'render_default_activation_limit_field'),
            'ql-settings',
            'qlic_general_section'
        );

        add_settings_field(
            'default_expiration_days',
            __('Default expiration period (days)', 'quick-license'),
            array($this, 'render_default_expiration_days_field'),
            'ql-settings',
            'qlic_general_section'
        );

        add_settings_field(
            'email_template',
            __('License email template', 'quick-license'),
            array($this, 'render_email_template_field'),
            'ql-settings',
            'qlic_general_section'
        );
    }

    /**
     * Fetch settings merged with defaults.
     */
    public function get_settings()
    {
        $saved = get_option($this->option_name, array());

        return wp_parse_args((array) $saved, $this->get_defaults());
    }

    /**
     * Sanitize and validate settings values.
     */
    public function sanitize_settings($input)
    {
        $input = is_array($input) ? $input : array();

        return array(
            'rest_enabled' => ! empty($input['rest_enabled']) ? 1 : 0,
            'shared_secret' => sanitize_text_field((string) ($input['shared_secret'] ?? '')),
            'default_activation_limit' => max(1, absint($input['default_activation_limit'] ?? 1)),
            'default_expiration_days' => max(0, absint($input['default_expiration_days'] ?? 0)),
            'email_template' => wp_kses_post((string) ($input['email_template'] ?? '')),
        );
    }

    /**
     * Render settings page.
     */
    public function render_page()
    {
        if (! current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Quick License Settings', 'quick-license'); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('qlic_settings_group');
                do_settings_sections('ql-settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function render_rest_enabled_field()
    {
        $settings = $this->get_settings();
        ?>
        <label>
            <input type="checkbox" name="<?php echo esc_attr($this->option_name); ?>[rest_enabled]" value="1" <?php checked((int) $settings['rest_enabled'], 1); ?> />
            <?php echo esc_html__('Allow /quick-license/v1/validate requests', 'quick-license'); ?>
        </label>
        <?php
    }

    public function render_shared_secret_field()
    {
        $settings = $this->get_settings();
        ?>
        <input type="text" class="regular-text" name="<?php echo esc_attr($this->option_name); ?>[shared_secret]" value="<?php echo esc_attr($settings['shared_secret']); ?>" />
        <p class="description"><?php echo esc_html__('If set, clients must send X-QL-Token header or token body field.', 'quick-license'); ?></p>
        <?php
    }

    public function render_default_activation_limit_field()
    {
        $settings = $this->get_settings();
        ?>
        <input type="number" min="1" name="<?php echo esc_attr($this->option_name); ?>[default_activation_limit]" value="<?php echo esc_attr((string) $settings['default_activation_limit']); ?>" />
        <?php
    }

    public function render_default_expiration_days_field()
    {
        $settings = $this->get_settings();
        ?>
        <input type="number" min="0" name="<?php echo esc_attr($this->option_name); ?>[default_expiration_days]" value="<?php echo esc_attr((string) $settings['default_expiration_days']); ?>" />
        <p class="description"><?php echo esc_html__('0 means no expiration date by default.', 'quick-license'); ?></p>
        <?php
    }

    public function render_email_template_field()
    {
        $settings = $this->get_settings();
        ?>
        <textarea name="<?php echo esc_attr($this->option_name); ?>[email_template]" rows="8" cols="80"><?php echo esc_textarea($settings['email_template']); ?></textarea>
        <p class="description"><?php echo esc_html__('Available tokens: {{customer_email}}, {{license_key}}, {{product_slug}}', 'quick-license'); ?></p>
        <?php
    }

    private function get_defaults()
    {
        return array(
            'rest_enabled' => 1,
            'shared_secret' => '',
            'default_activation_limit' => 1,
            'default_expiration_days' => 0,
            'email_template' => "Hello {{customer_email}},\n\nYour license key for {{product_slug}} is:\n{{license_key}}\n\nThank you.",
        );
    }
}
