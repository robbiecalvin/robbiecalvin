<?php

if (! defined('ABSPATH')) {
    exit;
}

class QLIC_Admin
{
    /**
     * @var QLIC_Settings
     */
    private $settings;

    public function __construct(QLIC_Settings $settings)
    {
        $this->settings = $settings;
    }

    public function register()
    {
        add_action('admin_menu', array($this, 'register_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
        add_action('admin_post_ql_add_license', array($this, 'handle_add_license'));
        add_action('admin_post_ql_update_license', array($this, 'handle_update_license'));
        add_action('admin_post_ql_bulk_action', array($this, 'handle_bulk_action'));
        add_action('admin_post_ql_delete_license', array($this, 'handle_delete_license'));
        add_action('admin_post_ql_change_status', array($this, 'handle_change_status'));
        add_action('admin_notices', array($this, 'render_notice'));
    }

    public function register_menu()
    {
        add_menu_page(
            __('Quick License', 'quick-license'),
            __('Quick License', 'quick-license'),
            'manage_options',
            'ql-licenses',
            array($this, 'render_licenses_page'),
            'dashicons-admin-network',
            58
        );

        add_submenu_page(
            'ql-licenses',
            __('All Licenses', 'quick-license'),
            __('All Licenses', 'quick-license'),
            'manage_options',
            'ql-licenses',
            array($this, 'render_licenses_page')
        );

        add_submenu_page(
            'ql-licenses',
            __('Add License', 'quick-license'),
            __('Add License', 'quick-license'),
            'manage_options',
            'ql-add-license',
            array($this, 'render_add_license_page')
        );

        add_submenu_page(
            'ql-licenses',
            __('Activations', 'quick-license'),
            __('Activations', 'quick-license'),
            'manage_options',
            'ql-activations',
            array($this, 'render_activations_page')
        );

        add_submenu_page(
            'ql-licenses',
            __('Catalog Hub', 'quick-license'),
            __('Catalog Hub', 'quick-license'),
            'manage_options',
            'ql-catalog-hub',
            array($this, 'render_catalog_hub_page')
        );

        add_submenu_page(
            'ql-licenses',
            __('Settings', 'quick-license'),
            __('Settings', 'quick-license'),
            'manage_options',
            'ql-settings',
            array($this->settings, 'render_page')
        );
    }

    public function enqueue_assets($hook)
    {
        if (strpos((string) $hook, 'ql-') === false) {
            return;
        }

        wp_enqueue_style('ql-admin', QLIC_URL . 'assets/css/admin.css', array(), QLIC_VERSION);
        wp_enqueue_script('ql-admin', QLIC_URL . 'assets/js/admin.js', array('jquery'), QLIC_VERSION, true);
    }

    public function render_licenses_page()
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        global $wpdb;

        $licenses_table = $wpdb->prefix . 'quick_licenses';

        $search = sanitize_text_field((string) ($_GET['s'] ?? ''));
        $product_filter = sanitize_title((string) ($_GET['product_slug'] ?? ''));

        $where_sql = ' WHERE 1=1 ';
        $params = array();

        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where_sql .= ' AND (customer_email LIKE %s OR license_key LIKE %s) ';
            $params[] = $like;
            $params[] = $like;
        }

        if ($product_filter !== '') {
            $where_sql .= ' AND product_slug = %s ';
            $params[] = $product_filter;
        }

        $sql = "SELECT * FROM {$licenses_table} {$where_sql} ORDER BY id DESC";
        if (! empty($params)) {
            $sql = $wpdb->prepare($sql, $params);
        }

        $licenses = $wpdb->get_results($sql, ARRAY_A);

        $products = $wpdb->get_col("SELECT DISTINCT product_slug FROM {$licenses_table} ORDER BY product_slug ASC");
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('All Licenses', 'quick-license'); ?></h1>

            <form method="get" class="ql-filters">
                <input type="hidden" name="page" value="ql-licenses" />
                <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php echo esc_attr__('Search email or key', 'quick-license'); ?>" />
                <select name="product_slug">
                    <option value=""><?php echo esc_html__('All products', 'quick-license'); ?></option>
                    <?php foreach ($products as $slug) : ?>
                        <option value="<?php echo esc_attr($slug); ?>" <?php selected($product_filter, $slug); ?>><?php echo esc_html($slug); ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="button"><?php echo esc_html__('Filter', 'quick-license'); ?></button>
            </form>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('qlic_bulk_action', 'qlic_nonce'); ?>
                <input type="hidden" name="action" value="qlic_bulk_action" />
                <select name="bulk_action">
                    <option value=""><?php echo esc_html__('Bulk actions', 'quick-license'); ?></option>
                    <option value="deactivate"><?php echo esc_html__('Deactivate', 'quick-license'); ?></option>
                </select>
                <button type="submit" class="button action"><?php echo esc_html__('Apply', 'quick-license'); ?></button>

                <table class="widefat fixed striped ql-table">
                    <thead>
                        <tr>
                            <th><input type="checkbox" class="ql-check-all" /></th>
                            <th><?php echo esc_html__('ID', 'quick-license'); ?></th>
                            <th><?php echo esc_html__('Product', 'quick-license'); ?></th>
                            <th><?php echo esc_html__('License Key', 'quick-license'); ?></th>
                            <th><?php echo esc_html__('Email', 'quick-license'); ?></th>
                            <th><?php echo esc_html__('Status', 'quick-license'); ?></th>
                            <th><?php echo esc_html__('Limit', 'quick-license'); ?></th>
                            <th><?php echo esc_html__('Expires', 'quick-license'); ?></th>
                            <th><?php echo esc_html__('Created', 'quick-license'); ?></th>
                            <th><?php echo esc_html__('Actions', 'quick-license'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($licenses)) : ?>
                            <tr>
                                <td colspan="10"><?php echo esc_html__('No licenses found.', 'quick-license'); ?></td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($licenses as $license) : ?>
                                <?php
                                $edit_url = add_query_arg(
                                    array(
                                        'page' => 'ql-add-license',
                                        'edit' => (int) $license['id'],
                                    ),
                                    admin_url('admin.php')
                                );

                                $delete_url = wp_nonce_url(
                                    add_query_arg(
                                        array(
                                            'action' => 'qlic_delete_license',
                                            'id' => (int) $license['id'],
                                        ),
                                        admin_url('admin-post.php')
                                    ),
                                    'qlic_delete_license_' . (int) $license['id'],
                                    'qlic_nonce'
                                );

                                $toggle_status = $license['status'] === 'active' ? 'disabled' : 'active';
                                $status_url = wp_nonce_url(
                                    add_query_arg(
                                        array(
                                            'action' => 'qlic_change_status',
                                            'id' => (int) $license['id'],
                                            'status' => $toggle_status,
                                        ),
                                        admin_url('admin-post.php')
                                    ),
                                    'qlic_change_status_' . (int) $license['id'],
                                    'qlic_nonce'
                                );
                                ?>
                                <tr>
                                    <td><input type="checkbox" name="license_ids[]" value="<?php echo esc_attr((string) $license['id']); ?>" /></td>
                                    <td><?php echo esc_html((string) $license['id']); ?></td>
                                    <td><?php echo esc_html($license['product_slug']); ?></td>
                                    <td><code><?php echo esc_html($license['license_key']); ?></code></td>
                                    <td><?php echo esc_html($license['customer_email']); ?></td>
                                    <td><?php echo esc_html($license['status']); ?></td>
                                    <td><?php echo esc_html((string) $license['activation_limit']); ?></td>
                                    <td><?php echo esc_html($license['expires_at'] ? $license['expires_at'] : 'Never'); ?></td>
                                    <td><?php echo esc_html($license['created_at']); ?></td>
                                    <td>
                                        <a href="<?php echo esc_url($edit_url); ?>"><?php echo esc_html__('Edit', 'quick-license'); ?></a> |
                                        <a href="<?php echo esc_url($status_url); ?>"><?php echo esc_html($toggle_status === 'active' ? __('Activate', 'quick-license') : __('Disable', 'quick-license')); ?></a> |
                                        <a href="<?php echo esc_url($delete_url); ?>" onclick="return confirm('<?php echo esc_js(__('Delete this license and all activations?', 'quick-license')); ?>');"><?php echo esc_html__('Delete', 'quick-license'); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </form>
        </div>
        <?php
    }

    public function render_add_license_page()
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        $edit_id = absint($_GET['edit'] ?? 0);
        $license = null;

        if ($edit_id > 0) {
            global $wpdb;
            $licenses_table = $wpdb->prefix . 'quick_licenses';
            $license = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM {$licenses_table} WHERE id = %d LIMIT 1", $edit_id),
                ARRAY_A
            );
        }

        $settings = $this->settings->get_settings();
        $default_limit = max(1, (int) $settings['default_activation_limit']);
        ?>
        <div class="wrap">
            <h1><?php echo esc_html($license ? __('Edit License', 'quick-license') : __('Add License', 'quick-license')); ?></h1>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="ql-form">
                <?php if ($license) : ?>
                    <input type="hidden" name="action" value="qlic_update_license" />
                    <input type="hidden" name="license_id" value="<?php echo esc_attr((string) $license['id']); ?>" />
                    <?php wp_nonce_field('qlic_update_license_' . (int) $license['id'], 'qlic_nonce'); ?>
                <?php else : ?>
                    <input type="hidden" name="action" value="qlic_add_license" />
                    <?php wp_nonce_field('qlic_add_license', 'qlic_nonce'); ?>
                <?php endif; ?>

                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="product_slug"><?php echo esc_html__('Product Slug', 'quick-license'); ?></label></th>
                        <td><input type="text" id="product_slug" name="product_slug" class="regular-text" required value="<?php echo esc_attr($license['product_slug'] ?? ''); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="customer_email"><?php echo esc_html__('Customer Email', 'quick-license'); ?></label></th>
                        <td><input type="email" id="customer_email" name="customer_email" class="regular-text" required value="<?php echo esc_attr($license['customer_email'] ?? ''); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="activation_limit"><?php echo esc_html__('Activation Limit', 'quick-license'); ?></label></th>
                        <td><input type="number" min="1" id="activation_limit" name="activation_limit" required value="<?php echo esc_attr((string) ($license['activation_limit'] ?? $default_limit)); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="expires_at"><?php echo esc_html__('Expiration Date', 'quick-license'); ?></label></th>
                        <td>
                            <?php $expires_value = ! empty($license['expires_at']) ? gmdate('Y-m-d', strtotime($license['expires_at'])) : ''; ?>
                            <input type="date" id="expires_at" name="expires_at" value="<?php echo esc_attr($expires_value); ?>" />
                            <p class="description"><?php echo esc_html__('Leave empty for no expiration.', 'quick-license'); ?></p>
                        </td>
                    </tr>
                    <?php if ($license) : ?>
                        <tr>
                            <th scope="row"><label for="status"><?php echo esc_html__('Status', 'quick-license'); ?></label></th>
                            <td>
                                <select id="status" name="status">
                                    <option value="active" <?php selected($license['status'], 'active'); ?>><?php echo esc_html__('active', 'quick-license'); ?></option>
                                    <option value="expired" <?php selected($license['status'], 'expired'); ?>><?php echo esc_html__('expired', 'quick-license'); ?></option>
                                    <option value="disabled" <?php selected($license['status'], 'disabled'); ?>><?php echo esc_html__('disabled', 'quick-license'); ?></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php echo esc_html__('License Key', 'quick-license'); ?></th>
                            <td><code><?php echo esc_html($license['license_key']); ?></code></td>
                        </tr>
                    <?php endif; ?>
                </table>

                <?php submit_button($license ? __('Update License', 'quick-license') : __('Create License', 'quick-license')); ?>
            </form>
        </div>
        <?php
    }

    public function render_activations_page()
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        global $wpdb;

        $activations_table = $wpdb->prefix . 'quick_license_activations';
        $licenses_table = $wpdb->prefix . 'quick_licenses';

        $search = sanitize_text_field((string) ($_GET['s'] ?? ''));

        $sql = "SELECT a.id, a.domain, a.activated_at, a.last_check_in, l.product_slug, l.license_key, l.customer_email
                FROM {$activations_table} a
                INNER JOIN {$licenses_table} l ON l.id = a.license_id";

        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $sql .= $wpdb->prepare(' WHERE a.domain LIKE %s OR l.license_key LIKE %s OR l.customer_email LIKE %s', $like, $like, $like);
        }

        $sql .= ' ORDER BY a.id DESC';

        $rows = $wpdb->get_results($sql, ARRAY_A);
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Activations', 'quick-license'); ?></h1>

            <form method="get" class="ql-filters">
                <input type="hidden" name="page" value="ql-activations" />
                <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php echo esc_attr__('Search by domain, email, or key', 'quick-license'); ?>" />
                <button class="button"><?php echo esc_html__('Search', 'quick-license'); ?></button>
            </form>

            <table class="widefat fixed striped ql-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('ID', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Product', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('License Key', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Customer Email', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Domain', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Activated', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Last Check In', 'quick-license'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($rows)) : ?>
                        <tr>
                            <td colspan="7"><?php echo esc_html__('No activations found.', 'quick-license'); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($rows as $row) : ?>
                            <tr>
                                <td><?php echo esc_html((string) $row['id']); ?></td>
                                <td><?php echo esc_html($row['product_slug']); ?></td>
                                <td><code><?php echo esc_html($row['license_key']); ?></code></td>
                                <td><?php echo esc_html($row['customer_email']); ?></td>
                                <td><?php echo esc_html($row['domain']); ?></td>
                                <td><?php echo esc_html($row['activated_at']); ?></td>
                                <td><?php echo esc_html($row['last_check_in']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function render_catalog_hub_page()
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        $catalog = QLIC_Product_Hub::get_catalog();
        $option_map = QLIC_Product_Hub::get_plugin_settings_option_map();
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Catalog Hub', 'quick-license'); ?></h1>
            <p><?php echo esc_html__('Central registry of license products, WooCommerce IDs, and plugin entitlement scope.', 'quick-license'); ?></p>

            <?php if (! class_exists('WooCommerce') || ! function_exists('wc_get_product_id_by_sku')) : ?>
                <div class="notice notice-warning">
                    <p><?php echo esc_html__('WooCommerce is not active. Product and variation IDs are unavailable.', 'quick-license'); ?></p>
                </div>
            <?php endif; ?>

            <table class="widefat fixed striped ql-table">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Catalog Product', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Parent SKU', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Parent Product ID', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Variation SKU', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Variation ID', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Product Slug', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Activation Limit', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Plugin Scope', 'quick-license'); ?></th>
                        <th><?php echo esc_html__('Settings Option(s)', 'quick-license'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($catalog)) : ?>
                        <tr>
                            <td colspan="9"><?php echo esc_html__('No catalog entries found.', 'quick-license'); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($catalog as $product_spec) : ?>
                            <?php
                            $product_name = sanitize_text_field((string) ($product_spec['name'] ?? ''));
                            $parent_sku = sanitize_text_field((string) ($product_spec['parent_sku'] ?? ''));
                            $plugins = isset($product_spec['plugins']) && is_array($product_spec['plugins']) ? $product_spec['plugins'] : array();
                            $plugins = array_values(array_filter(array_map('sanitize_title', $plugins)));
                            $plugin_scope = empty($plugins) ? '—' : implode(', ', $plugins);

                            $settings_options = array();
                            foreach ($plugins as $plugin_slug) {
                                if (isset($option_map[$plugin_slug])) {
                                    $settings_options[] = sanitize_key($option_map[$plugin_slug]);
                                }
                            }
                            $settings_options = array_values(array_unique(array_filter($settings_options)));
                            $settings_options_display = empty($settings_options) ? '—' : implode(', ', $settings_options);

                            $parent_product_id = 0;
                            if ($parent_sku !== '' && function_exists('wc_get_product_id_by_sku')) {
                                $parent_product_id = absint(wc_get_product_id_by_sku($parent_sku));
                            }

                            $variations = isset($product_spec['variations']) && is_array($product_spec['variations']) ? $product_spec['variations'] : array();
                            if (empty($variations)) {
                                $variations = array(array());
                            }
                            ?>
                            <?php foreach ($variations as $index => $variation_spec) : ?>
                                <?php
                                $variation_sku = sanitize_text_field((string) ($variation_spec['sku'] ?? ''));
                                $variation_id = 0;
                                if ($variation_sku !== '' && function_exists('wc_get_product_id_by_sku')) {
                                    $variation_id = absint(wc_get_product_id_by_sku($variation_sku));
                                }
                                $product_slug = sanitize_title((string) ($variation_spec['product_slug'] ?? ''));
                                $activation_limit = max(1, absint($variation_spec['activation_limit'] ?? 1));
                                ?>
                                <tr>
                                    <td>
                                        <?php if (0 === $index) : ?>
                                            <?php echo esc_html($product_name !== '' ? $product_name : '—'); ?>
                                        <?php else : ?>
                                            <?php echo esc_html(''); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (0 === $index) : ?>
                                            <?php echo esc_html($parent_sku !== '' ? $parent_sku : '—'); ?>
                                        <?php else : ?>
                                            <?php echo esc_html(''); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (0 === $index) : ?>
                                            <?php echo esc_html($parent_product_id > 0 ? (string) $parent_product_id : 'Missing'); ?>
                                        <?php else : ?>
                                            <?php echo esc_html(''); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo esc_html($variation_sku !== '' ? $variation_sku : '—'); ?></td>
                                    <td><?php echo esc_html($variation_id > 0 ? (string) $variation_id : 'Missing'); ?></td>
                                    <td><?php echo esc_html($product_slug !== '' ? $product_slug : '—'); ?></td>
                                    <td><?php echo esc_html((string) $activation_limit); ?></td>
                                    <td>
                                        <?php if (0 === $index) : ?>
                                            <?php echo esc_html($plugin_scope); ?>
                                        <?php else : ?>
                                            <?php echo esc_html(''); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (0 === $index) : ?>
                                            <?php echo esc_html($settings_options_display); ?>
                                        <?php else : ?>
                                            <?php echo esc_html(''); ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function handle_add_license()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized request.', 'quick-license'));
        }

        check_admin_referer('qlic_add_license', 'qlic_nonce');

        $product_slug = sanitize_title((string) ($_POST['product_slug'] ?? ''));
        $customer_email = sanitize_email((string) ($_POST['customer_email'] ?? ''));
        $activation_limit = max(1, absint($_POST['activation_limit'] ?? 1));
        $expires_at = $this->normalize_date($_POST['expires_at'] ?? '');

        if ($product_slug === '' || $customer_email === '') {
            $this->redirect_with_notice('ql-add-license', 'error', 'Product slug and customer email are required.');
        }

        if (! is_email($customer_email)) {
            $this->redirect_with_notice('ql-add-license', 'error', 'Customer email is invalid.');
        }

        $license_key = $this->generate_unique_license_key();

        global $wpdb;
        $licenses_table = $wpdb->prefix . 'quick_licenses';

        $inserted = $wpdb->insert(
            $licenses_table,
            array(
                'product_slug' => $product_slug,
                'license_key' => $license_key,
                'customer_email' => $customer_email,
                'activation_limit' => $activation_limit,
                'status' => 'active',
                'expires_at' => $expires_at,
                'created_at' => current_time('mysql'),
            ),
            array('%s', '%s', '%s', '%d', '%s', '%s', '%s')
        );

        if (! $inserted) {
            $this->redirect_with_notice('ql-add-license', 'error', 'Failed to create license.');
        }

        $this->redirect_with_notice('ql-licenses', 'success', 'License created successfully.');
    }

    public function handle_update_license()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized request.', 'quick-license'));
        }

        $license_id = absint($_POST['license_id'] ?? 0);
        check_admin_referer('qlic_update_license_' . $license_id, 'qlic_nonce');

        if ($license_id <= 0) {
            $this->redirect_with_notice('ql-licenses', 'error', 'Invalid license ID.');
        }

        $product_slug = sanitize_title((string) ($_POST['product_slug'] ?? ''));
        $customer_email = sanitize_email((string) ($_POST['customer_email'] ?? ''));
        $activation_limit = max(1, absint($_POST['activation_limit'] ?? 1));
        $expires_at = $this->normalize_date($_POST['expires_at'] ?? '');

        $allowed_status = array('active', 'expired', 'disabled');
        $status = sanitize_text_field((string) ($_POST['status'] ?? 'active'));
        if (! in_array($status, $allowed_status, true)) {
            $status = 'active';
        }

        if ($product_slug === '' || $customer_email === '' || ! is_email($customer_email)) {
            $this->redirect_with_notice('ql-add-license', 'error', 'Invalid input values.');
        }

        global $wpdb;
        $licenses_table = $wpdb->prefix . 'quick_licenses';

        $updated = $wpdb->update(
            $licenses_table,
            array(
                'product_slug' => $product_slug,
                'customer_email' => $customer_email,
                'activation_limit' => $activation_limit,
                'status' => $status,
                'expires_at' => $expires_at,
            ),
            array('id' => $license_id),
            array('%s', '%s', '%d', '%s', '%s'),
            array('%d')
        );

        if ($updated === false) {
            $this->redirect_with_notice('ql-add-license', 'error', 'Failed to update license.', array('edit' => $license_id));
        }

        $this->redirect_with_notice('ql-licenses', 'success', 'License updated successfully.');
    }

    public function handle_bulk_action()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized request.', 'quick-license'));
        }

        check_admin_referer('qlic_bulk_action', 'qlic_nonce');

        $bulk_action = sanitize_text_field((string) ($_POST['bulk_action'] ?? ''));
        $license_ids = array_map('absint', (array) ($_POST['license_ids'] ?? array()));
        $license_ids = array_values(array_filter($license_ids));

        if ($bulk_action !== 'deactivate' || empty($license_ids)) {
            $this->redirect_with_notice('ql-licenses', 'error', 'No valid bulk action to apply.');
        }

        global $wpdb;
        $licenses_table = $wpdb->prefix . 'quick_licenses';

        $placeholders = implode(',', array_fill(0, count($license_ids), '%d'));
        $params = array_merge(array('disabled'), $license_ids);
        $query = "UPDATE {$licenses_table} SET status = %s WHERE id IN ({$placeholders})";
        $result = $wpdb->query($wpdb->prepare($query, $params));

        if ($result === false) {
            $this->redirect_with_notice('ql-licenses', 'error', 'Bulk deactivation failed.');
        }

        $this->redirect_with_notice('ql-licenses', 'success', 'Selected licenses were deactivated.');
    }

    public function handle_delete_license()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized request.', 'quick-license'));
        }

        $license_id = absint($_GET['id'] ?? 0);
        check_admin_referer('qlic_delete_license_' . $license_id, 'qlic_nonce');

        if ($license_id <= 0) {
            $this->redirect_with_notice('ql-licenses', 'error', 'Invalid license ID.');
        }

        global $wpdb;
        $licenses_table = $wpdb->prefix . 'quick_licenses';
        $activations_table = $wpdb->prefix . 'quick_license_activations';

        $wpdb->delete($activations_table, array('license_id' => $license_id), array('%d'));
        $deleted = $wpdb->delete($licenses_table, array('id' => $license_id), array('%d'));

        if (! $deleted) {
            $this->redirect_with_notice('ql-licenses', 'error', 'Failed to delete license.');
        }

        $this->redirect_with_notice('ql-licenses', 'success', 'License deleted successfully.');
    }

    public function handle_change_status()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized request.', 'quick-license'));
        }

        $license_id = absint($_GET['id'] ?? 0);
        check_admin_referer('qlic_change_status_' . $license_id, 'qlic_nonce');

        $status = sanitize_text_field((string) ($_GET['status'] ?? 'active'));
        $allowed_statuses = array('active', 'expired', 'disabled');

        if ($license_id <= 0 || ! in_array($status, $allowed_statuses, true)) {
            $this->redirect_with_notice('ql-licenses', 'error', 'Invalid status change request.');
        }

        global $wpdb;
        $licenses_table = $wpdb->prefix . 'quick_licenses';

        $updated = $wpdb->update(
            $licenses_table,
            array('status' => $status),
            array('id' => $license_id),
            array('%s'),
            array('%d')
        );

        if ($updated === false) {
            $this->redirect_with_notice('ql-licenses', 'error', 'Failed to update status.');
        }

        $this->redirect_with_notice('ql-licenses', 'success', 'License status updated.');
    }

    public function render_notice()
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        if (empty($_GET['qlic_notice']) || empty($_GET['qlic_type'])) {
            return;
        }

        $notice = sanitize_text_field(wp_unslash((string) $_GET['qlic_notice']));
        $type = sanitize_key((string) $_GET['qlic_type']);
        $class = $type === 'success' ? 'notice notice-success is-dismissible' : 'notice notice-error';

        echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($notice) . '</p></div>';
    }

    private function redirect_with_notice($page_slug, $type, $message, $extra_args = array())
    {
        $args = array_merge(
            array(
                'page' => $page_slug,
                'qlic_type' => $type,
                'qlic_notice' => $message,
            ),
            $extra_args
        );

        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        exit;
    }

    private function normalize_date($date_input)
    {
        $date_input = sanitize_text_field((string) $date_input);

        if ($date_input === '') {
            $settings = $this->settings->get_settings();
            $default_days = max(0, (int) $settings['default_expiration_days']);
            if ($default_days === 0) {
                return null;
            }

            return gmdate('Y-m-d H:i:s', strtotime('+' . $default_days . ' days'));
        }

        $timestamp = strtotime($date_input . ' 23:59:59');
        if ($timestamp === false) {
            return null;
        }

        return gmdate('Y-m-d H:i:s', $timestamp);
    }

    private function generate_unique_license_key()
    {
        global $wpdb;

        $licenses_table = $wpdb->prefix . 'quick_licenses';

        for ($i = 0; $i < 10; $i++) {
            $key = QLIC_License_Generator::generate_key(32);
            $exists = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$licenses_table} WHERE license_key = %s",
                    $key
                )
            );

            if ($exists === 0) {
                return $key;
            }
        }

        wp_die(esc_html__('Unable to generate unique license key. Try again.', 'quick-license'));
    }
}
