<?php

if (! defined('ABSPATH')) {
    exit;
}

class QLIC_Product_Hub
{
    /**
     * Canonical product catalog used by Woo catalog setup and licensing scope.
     *
     * @return array<int,array<string,mixed>>
     */
    public static function get_catalog()
    {
        return array(
            array(
                'name' => 'Quick Woo Forms',
                'description' => 'Quick Woo Forms plugin license tiers.',
                'parent_sku' => 'QW-FORMS',
                'plugins' => array('quick-forms'),
                'variations' => array(
                    array('label' => 'One Site', 'price' => '69.99', 'sku' => 'QW-FORMS-1', 'product_slug' => 'quick-forms-one-site', 'activation_limit' => 1),
                    array('label' => 'Up to 5 Sites', 'price' => '119.99', 'sku' => 'QW-FORMS-5', 'product_slug' => 'quick-forms-five-sites', 'activation_limit' => 5),
                    array('label' => 'Unlimited Sites', 'price' => '199.99', 'sku' => 'QW-FORMS-UNL', 'product_slug' => 'quick-forms-unlimited-sites', 'activation_limit' => 1000000),
                ),
            ),
            array(
                'name' => 'Quick Woo Quotes',
                'description' => 'Quick Woo Quotes plugin license tiers.',
                'parent_sku' => 'QW-QUOTES',
                'plugins' => array('quick-quotes'),
                'variations' => array(
                    array('label' => 'One Site', 'price' => '69.99', 'sku' => 'QW-QUOTES-1', 'product_slug' => 'quick-quotes-one-site', 'activation_limit' => 1),
                    array('label' => 'Up to 5 Sites', 'price' => '119.99', 'sku' => 'QW-QUOTES-5', 'product_slug' => 'quick-quotes-five-sites', 'activation_limit' => 5),
                    array('label' => 'Unlimited Sites', 'price' => '199.99', 'sku' => 'QW-QUOTES-UNL', 'product_slug' => 'quick-quotes-unlimited-sites', 'activation_limit' => 1000000),
                ),
            ),
            array(
                'name' => 'Quick Woo Schedule',
                'description' => 'Quick Woo Schedule plugin license tiers.',
                'parent_sku' => 'QW-SCHEDULE',
                'plugins' => array('quick-schedule'),
                'variations' => array(
                    array('label' => 'One Site', 'price' => '69.99', 'sku' => 'QW-SCHEDULE-1', 'product_slug' => 'quick-schedule-one-site', 'activation_limit' => 1),
                    array('label' => 'Up to 5 Sites', 'price' => '119.99', 'sku' => 'QW-SCHEDULE-5', 'product_slug' => 'quick-schedule-five-sites', 'activation_limit' => 5),
                    array('label' => 'Unlimited Sites', 'price' => '199.99', 'sku' => 'QW-SCHEDULE-UNL', 'product_slug' => 'quick-schedule-unlimited-sites', 'activation_limit' => 1000000),
                ),
            ),
            array(
                'name' => 'Quick Secretary',
                'description' => 'Bundle license for Forms + Quotes + Schedule tiers.',
                'parent_sku' => 'QW-BUNDLE',
                'plugins' => array('quick-forms', 'quick-quotes', 'quick-schedule'),
                'variations' => array(
                    array('label' => 'One Site', 'price' => '149.99', 'sku' => 'QW-BUNDLE-1', 'product_slug' => 'quick-woo-bundle-one-site', 'activation_limit' => 1),
                    array('label' => 'Up to 5 Sites', 'price' => '299.99', 'sku' => 'QW-BUNDLE-5', 'product_slug' => 'quick-woo-bundle-five-sites', 'activation_limit' => 5),
                    array('label' => 'Unlimited Sites', 'price' => '499.99', 'sku' => 'QW-BUNDLE-UNL', 'product_slug' => 'quick-woo-bundle-unlimited-sites', 'activation_limit' => 1000000),
                ),
            ),
            array(
                'name' => 'Quick Woo Variations',
                'description' => 'Quick Woo Variations plugin license tiers.',
                'parent_sku' => 'QW-VARIATIONS',
                'plugins' => array('quick-variations'),
                'variations' => array(
                    array('label' => 'One Site', 'price' => '69.99', 'sku' => 'QW-VARIATIONS-1', 'product_slug' => 'quick-variations-one-site', 'activation_limit' => 1),
                    array('label' => 'Up to 5 Sites', 'price' => '119.99', 'sku' => 'QW-VARIATIONS-5', 'product_slug' => 'quick-variations-five-sites', 'activation_limit' => 5),
                    array('label' => 'Unlimited Sites', 'price' => '199.99', 'sku' => 'QW-VARIATIONS-UNL', 'product_slug' => 'quick-variations-unlimited-sites', 'activation_limit' => 1000000),
                ),
            ),
            array(
                'name' => 'Quick Product Bundle',
                'description' => 'Bundle license for Quick Add + Quick Edit + Quick Variations.',
                'parent_sku' => 'QW-PRODUCT-BUNDLE',
                'plugins' => array('quick-add', 'quick-edit', 'quick-variations'),
                'variations' => array(
                    array('label' => 'One Site', 'price' => '149.99', 'sku' => 'QW-PRODUCT-BUNDLE-1', 'product_slug' => 'quick-product-bundle-one-site', 'activation_limit' => 1),
                    array('label' => 'Up to 5 Sites', 'price' => '299.99', 'sku' => 'QW-PRODUCT-BUNDLE-5', 'product_slug' => 'quick-product-bundle-five-sites', 'activation_limit' => 5),
                    array('label' => 'Unlimited Sites', 'price' => '499.99', 'sku' => 'QW-PRODUCT-BUNDLE-UNL', 'product_slug' => 'quick-product-bundle-unlimited-sites', 'activation_limit' => 1000000),
                ),
            ),
            array(
                'name' => 'Quick Learn Bundle',
                'description' => 'Bundle license for Quick Questions + Quick Course Builder.',
                'parent_sku' => 'QW-LEARN-BUNDLE',
                'plugins' => array('quick-questions', 'quick-course-builder'),
                'variations' => array(
                    array('label' => 'One Site', 'price' => '149.99', 'sku' => 'QW-LEARN-BUNDLE-1', 'product_slug' => 'quick-learn-bundle-one-site', 'activation_limit' => 1),
                    array('label' => 'Up to 5 Sites', 'price' => '299.99', 'sku' => 'QW-LEARN-BUNDLE-5', 'product_slug' => 'quick-learn-bundle-five-sites', 'activation_limit' => 5),
                    array('label' => 'Unlimited Sites', 'price' => '499.99', 'sku' => 'QW-LEARN-BUNDLE-UNL', 'product_slug' => 'quick-learn-bundle-unlimited-sites', 'activation_limit' => 1000000),
                ),
            ),
        );
    }

    /**
     * Product settings option mapping for automatic key registration.
     *
     * @return array<string,string>
     */
    public static function get_plugin_settings_option_map()
    {
        return array(
            'quick-forms' => 'qfrm_settings',
            'quick-quotes' => 'quick_woo_quotes_settings',
            'quick-schedule' => 'quick_woo_schedule_settings',
            'quick-variations' => 'qvar_settings',
        );
    }

    /**
     * Resolve product mapping by Woo variation/product post ID.
     *
     * @param int $post_id Product/variation post ID.
     * @return array<string,mixed>|null
     */
    public static function resolve_by_post_id($post_id)
    {
        $post_id = absint($post_id);
        if ($post_id < 1) {
            return null;
        }

        $product_slug = sanitize_title((string) get_post_meta($post_id, '_qlic_product_slug', true));
        $activation_limit = max(1, absint(get_post_meta($post_id, '_qlic_activation_limit', true)));
        $plugins = get_post_meta($post_id, '_qlic_plugins', true);
        $plugins = is_array($plugins) ? array_values(array_filter(array_map('sanitize_title', $plugins))) : array();

        if ($product_slug !== '') {
            return array(
                'product_slug' => $product_slug,
                'activation_limit' => $activation_limit,
                'plugins' => $plugins,
            );
        }

        if (! function_exists('wc_get_product')) {
            return null;
        }

        $product = wc_get_product($post_id);
        if (! $product || ! method_exists($product, 'get_sku')) {
            return null;
        }

        $sku = sanitize_text_field((string) $product->get_sku());
        if ($sku === '') {
            return null;
        }

        return self::resolve_by_sku($sku);
    }

    /**
     * Resolve mapping by SKU from central catalog.
     *
     * @param string $sku Variation SKU.
     * @return array<string,mixed>|null
     */
    public static function resolve_by_sku($sku)
    {
        $sku = sanitize_text_field((string) $sku);
        if ($sku === '') {
            return null;
        }

        foreach (self::get_catalog() as $product_spec) {
            $plugins = isset($product_spec['plugins']) && is_array($product_spec['plugins']) ? $product_spec['plugins'] : array();
            $plugins = array_values(array_filter(array_map('sanitize_title', $plugins)));
            $variations = isset($product_spec['variations']) && is_array($product_spec['variations']) ? $product_spec['variations'] : array();

            foreach ($variations as $variation_spec) {
                $variation_sku = sanitize_text_field((string) ($variation_spec['sku'] ?? ''));
                if ($variation_sku !== $sku) {
                    continue;
                }

                $product_slug = sanitize_title((string) ($variation_spec['product_slug'] ?? ''));
                if ($product_slug === '') {
                    return null;
                }

                return array(
                    'product_slug' => $product_slug,
                    'activation_limit' => max(1, absint($variation_spec['activation_limit'] ?? 1)),
                    'plugins' => $plugins,
                );
            }
        }

        return null;
    }
}
