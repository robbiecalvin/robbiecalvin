<?php

if (! defined('ABSPATH')) {
    exit;
}

class QLIC_WooCommerce
{
    private const CATALOG_VERSION = '1.2.0';
    private const CATALOG_VERSION_OPTION = 'qlic_wc_catalog_version';
    private const ORDER_ISSUED_META = '_qlic_licenses_issued';
    private const ORDER_KEYS_META = '_qlic_license_keys';

    public function register()
    {
        add_action('init', array($this, 'maybe_setup_catalog'), 40);
        add_action('woocommerce_order_status_processing', array($this, 'issue_licenses_for_order'));
        add_action('woocommerce_order_status_completed', array($this, 'issue_licenses_for_order'));
    }

    /**
     * Ensure required WooCommerce products and variations exist.
     *
     * @return void
     */
    public function maybe_setup_catalog()
    {
        if (! is_admin()) {
            return;
        }

        if (! class_exists('WooCommerce') || ! class_exists('WC_Product_Variable')) {
            return;
        }

        $current = (string) get_option(self::CATALOG_VERSION_OPTION, '');
        if (self::CATALOG_VERSION === $current) {
            return;
        }

        foreach (QLIC_Product_Hub::get_catalog() as $product_spec) {
            $this->upsert_variable_product($product_spec);
        }

        update_option(self::CATALOG_VERSION_OPTION, self::CATALOG_VERSION, false);
    }

    /**
     * @param array<string,mixed> $product_spec Product spec.
     * @return void
     */
    private function upsert_variable_product($product_spec)
    {
        $parent_sku = sanitize_text_field((string) $product_spec['parent_sku']);
        $name = sanitize_text_field((string) $product_spec['name']);
        $description = wp_kses_post((string) $product_spec['description']);
        $plugins = isset($product_spec['plugins']) && is_array($product_spec['plugins']) ? $product_spec['plugins'] : array();
        $plugins = array_values(array_filter(array_map('sanitize_title', $plugins)));
        $variation_specs = isset($product_spec['variations']) && is_array($product_spec['variations']) ? $product_spec['variations'] : array();
        if ($parent_sku === '' || $name === '' || empty($variation_specs)) {
            return;
        }

        $product_id = wc_get_product_id_by_sku($parent_sku);
        $product = $product_id > 0 ? wc_get_product($product_id) : false;

        if (! $product || ! is_a($product, 'WC_Product_Variable')) {
            $product = new WC_Product_Variable();
        }

        $product->set_name($name);
        $product->set_status('publish');
        $product->set_catalog_visibility('visible');
        $product->set_description($description);
        $product->set_short_description($description);
        $product->set_sku($parent_sku);

        $attribute = new WC_Product_Attribute();
        $attribute->set_id(0);
        $attribute->set_name('License Tier');
        $attribute->set_position(0);
        $attribute->set_visible(true);
        $attribute->set_variation(true);
        $attribute->set_options(
            array_values(
                array_map(
                    static function ($variation_spec) {
                        return sanitize_text_field((string) ($variation_spec['label'] ?? ''));
                    },
                    $variation_specs
                )
            )
        );

        $product->set_attributes(array($attribute));
        $product_id = $product->save();
        if ($product_id < 1) {
            return;
        }

        update_post_meta($product_id, '_qlic_is_license_parent', '1');

        foreach ($variation_specs as $variation_spec) {
            $this->upsert_variation($product_id, $variation_spec, $plugins);
        }
    }

    /**
     * @param int                 $parent_id Parent product ID.
     * @param array<string,mixed> $variation_spec Variation spec.
     * @param array<int,string>   $plugins Plugin entitlement slugs.
     * @return void
     */
    private function upsert_variation($parent_id, $variation_spec, $plugins)
    {
        $parent_id = absint($parent_id);
        if ($parent_id < 1) {
            return;
        }

        $sku = sanitize_text_field((string) ($variation_spec['sku'] ?? ''));
        $label = sanitize_text_field((string) ($variation_spec['label'] ?? ''));
        $price = number_format((float) ($variation_spec['price'] ?? 0), 2, '.', '');
        $product_slug = sanitize_title((string) ($variation_spec['product_slug'] ?? ''));
        $activation_limit = max(1, absint($variation_spec['activation_limit'] ?? 1));

        if ($sku === '' || $label === '' || $product_slug === '') {
            return;
        }

        $variation_id = wc_get_product_id_by_sku($sku);
        $variation = $variation_id > 0 ? wc_get_product($variation_id) : false;

        if (! $variation || ! is_a($variation, 'WC_Product_Variation')) {
            $variation = new WC_Product_Variation();
        }

        $variation->set_parent_id($parent_id);
        $variation->set_status('publish');
        $variation->set_sku($sku);
        $variation->set_regular_price($price);
        $variation->set_price($price);
        $variation->set_virtual(true);
        $variation->set_manage_stock(false);
        $variation->set_attributes(array('license-tier' => $label));
        $saved_variation_id = $variation->save();
        if ($saved_variation_id < 1) {
            return;
        }

        update_post_meta($saved_variation_id, '_qlic_product_slug', $product_slug);
        update_post_meta($saved_variation_id, '_qlic_activation_limit', $activation_limit);
        update_post_meta($saved_variation_id, '_qlic_is_license_variation', '1');
        update_post_meta($saved_variation_id, '_qlic_plugins', $plugins);
    }

    /**
     * Issue licenses from a WooCommerce order.
     *
     * @param int $order_id Order ID.
     * @return void
     */
    public function issue_licenses_for_order($order_id)
    {
        if (! class_exists('WooCommerce')) {
            return;
        }

        $order_id = absint($order_id);
        if ($order_id < 1) {
            return;
        }

        $order = wc_get_order($order_id);
        if (! $order) {
            return;
        }

        if ('1' === (string) $order->get_meta(self::ORDER_ISSUED_META, true)) {
            return;
        }

        global $wpdb;
        $licenses_table = $wpdb->prefix . 'quick_licenses';
        $licenses_table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $licenses_table));
        if (empty($licenses_table_exists)) {
            return;
        }

        $customer_email = sanitize_email((string) $order->get_billing_email());
        if (! is_email($customer_email)) {
            return;
        }

        $issued_keys = array();
        $items = $order->get_items('line_item');
        foreach ($items as $item) {
            if (! is_a($item, 'WC_Order_Item_Product')) {
                continue;
            }

            $mapping = $this->resolve_item_license_mapping($item);
            if (! is_array($mapping)) {
                continue;
            }

            $qty = max(1, absint($item->get_quantity()));
            for ($i = 0; $i < $qty; $i++) {
                $license_key = $this->create_license_row(
                    $licenses_table,
                    $mapping['product_slug'],
                    $customer_email,
                    $mapping['activation_limit']
                );
                if ($license_key !== '') {
                    $issued = array(
                        'product_slug' => $mapping['product_slug'],
                        'license_key' => $license_key,
                        'plugins' => isset($mapping['plugins']) && is_array($mapping['plugins']) ? $mapping['plugins'] : array(),
                    );
                    $issued_keys[] = $issued;
                    $this->register_issued_license_for_site($customer_email, $issued);
                }
            }
        }

        if (empty($issued_keys)) {
            return;
        }

        $order->update_meta_data(self::ORDER_ISSUED_META, '1');
        $order->update_meta_data(self::ORDER_KEYS_META, wp_json_encode($issued_keys));
        $order->save();

        $this->send_license_email($customer_email, $issued_keys);
    }

    /**
     * @param WC_Order_Item_Product $item Order item.
     * @return array<string,mixed>|null
     */
    private function resolve_item_license_mapping($item)
    {
        $variation_id = absint($item->get_variation_id());
        $product_id = absint($item->get_product_id());
        $check_ids = array_filter(array($variation_id, $product_id));

        foreach ($check_ids as $id) {
            $mapping = QLIC_Product_Hub::resolve_by_post_id($id);
            if (is_array($mapping)) {
                return $mapping;
            }
        }

        return null;
    }

    /**
     * @param string $customer_email Customer email.
     * @param array<string,mixed> $issued Issued key payload.
     * @return void
     */
    private function register_issued_license_for_site($customer_email, $issued)
    {
        $customer_email = sanitize_email((string) $customer_email);
        $license_key = sanitize_text_field((string) ($issued['license_key'] ?? ''));
        $plugins = isset($issued['plugins']) && is_array($issued['plugins']) ? $issued['plugins'] : array();
        $plugins = array_values(array_filter(array_map('sanitize_title', $plugins)));

        if (! is_email($customer_email) || $license_key === '' || empty($plugins)) {
            return;
        }

        if (function_exists('qlic_activate_license_key_for_products')) {
            $activation = qlic_activate_license_key_for_products($license_key, $plugins);
            $is_valid = ! empty($activation['valid']);
        } else {
            $activation = array('message' => 'License registration complete.');
            $is_valid = false;
        }

        $option_map = QLIC_Product_Hub::get_plugin_settings_option_map();
        foreach ($plugins as $plugin_slug) {
            if (! isset($option_map[$plugin_slug])) {
                continue;
            }

            $option_name = sanitize_key($option_map[$plugin_slug]);
            if ($option_name === '') {
                continue;
            }

            $settings = get_option($option_name, array());
            $settings = is_array($settings) ? $settings : array();
            $settings['license_key'] = $license_key;
            $settings['license_status'] = $is_valid ? 'active' : sanitize_key((string) ($activation['status'] ?? 'active'));
            $settings['license_message'] = sanitize_text_field((string) ($activation['message'] ?? 'License registered from purchase.'));
            update_option($option_name, $settings, false);
        }
    }

    /**
     * @param string $licenses_table License DB table.
     * @param string $product_slug Product slug.
     * @param string $customer_email Email.
     * @param int    $activation_limit Activation limit.
     * @return string
     */
    private function create_license_row($licenses_table, $product_slug, $customer_email, $activation_limit)
    {
        global $wpdb;

        $product_slug = sanitize_title((string) $product_slug);
        $customer_email = sanitize_email((string) $customer_email);
        $activation_limit = max(1, absint($activation_limit));
        if ($product_slug === '' || ! is_email($customer_email)) {
            return '';
        }

        $license_key = $this->generate_unique_license_key($licenses_table);
        if ($license_key === '') {
            return '';
        }

        $expires_at = $this->resolve_expires_at();
        $inserted = $wpdb->insert(
            $licenses_table,
            array(
                'product_slug' => $product_slug,
                'license_key' => $license_key,
                'customer_email' => $customer_email,
                'activation_limit' => $activation_limit,
                'status' => 'active',
                'expires_at' => $expires_at,
                'created_at' => current_time('mysql'),
            ),
            array('%s', '%s', '%s', '%d', '%s', '%s', '%s')
        );

        if (! $inserted) {
            return '';
        }

        return $license_key;
    }

    /**
     * @param string $licenses_table License DB table.
     * @return string
     */
    private function generate_unique_license_key($licenses_table)
    {
        global $wpdb;

        for ($i = 0; $i < 10; $i++) {
            $key = QLIC_License_Generator::generate_key(32);
            $exists = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$licenses_table} WHERE license_key = %s",
                    $key
                )
            );

            if ($exists === 0) {
                return $key;
            }
        }

        return '';
    }

    /**
     * @return string|null
     */
    private function resolve_expires_at()
    {
        $settings = get_option('quick_license_settings', array());
        $days = isset($settings['default_expiration_days']) ? absint($settings['default_expiration_days']) : 0;
        if ($days < 1) {
            return null;
        }

        return gmdate('Y-m-d H:i:s', strtotime('+' . $days . ' days'));
    }

    /**
     * @param string                          $customer_email Recipient email.
     * @param array<int,array<string,mixed>>  $issued_keys Issued keys.
     * @return void
     */
    private function send_license_email($customer_email, $issued_keys)
    {
        if (! is_email($customer_email) || empty($issued_keys)) {
            return;
        }

        $lines = array();
        foreach ($issued_keys as $issued) {
            $plugins = isset($issued['plugins']) && is_array($issued['plugins']) ? implode(', ', array_map('sanitize_text_field', $issued['plugins'])) : '';
            $line = sprintf(
                '%s: %s',
                sanitize_text_field((string) $issued['product_slug']),
                sanitize_text_field((string) $issued['license_key'])
            );
            if ($plugins !== '') {
                $line .= sprintf(' (%s)', $plugins);
            }
            $lines[] = $line;
        }

        $subject = __('Your Quick Woo License Keys', 'quick-license');
        $message = "Hello,\n\nYour license key(s):\n" . implode("\n", $lines) . "\n\nThank you.";
        wp_mail($customer_email, $subject, $message);
    }
}
