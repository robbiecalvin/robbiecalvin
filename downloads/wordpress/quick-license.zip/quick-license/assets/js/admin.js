(function ($) {
    'use strict';

    $(document).on('change', '.ql-check-all', function () {
        var isChecked = $(this).is(':checked');
        $('input[name="license_ids[]"]').prop('checked', isChecked);
    });
})(jQuery);
