jQuery(document).ready(function ($) {
 $('#save-robots').on('click', function () {
     const content = $('#quick-seo-robots').val();

     $.post(ajaxurl, {
         action: 'qseo_save_robots',
         nonce: quickSeo.nonce,
         content: content
     }, function (response) {
         const msg = response.success ? '✅ Saved successfully!' : '❌ ' + response.data;
         $('#robots-feedback').text(msg);
     });
 });
});
