(function () {
  const EditOverlay = {
    editMode: false,
    activeNode: null,
    activeRange: null,
    editorEl: null,

    init() {
      document.addEventListener('keydown', (e) => {
        if (e.shiftKey && e.key === 'E') {
          this.toggleEditMode();
        }

        if (e.key === 'Escape') {
          this.closeEditor();
        }
      });

      document.addEventListener('click', (e) => {
        if (!this.editMode) return;
        if (this.editorEl) return;

        const data = this.getWordFromClick(e);
        if (!data) return;

        e.preventDefault();
        e.stopPropagation();

        this.openEditor(data, e.clientX, e.clientY);
      });
    },

    toggleEditMode() {
      this.editMode = !this.editMode;
      document.body.classList.toggle('quick-seo-edit-mode', this.editMode);
      this.closeEditor();
    },

    getWordFromClick(e) {
      const pos = document.caretRangeFromPoint
        ? document.caretRangeFromPoint(e.clientX, e.clientY)
        : document.caretPositionFromPoint(e.clientX, e.clientY);

      if (!pos) return null;

      const textNode = pos.startContainer;
      if (!textNode || textNode.nodeType !== Node.TEXT_NODE) return null;

      const parent = textNode.parentElement;
      if (!parent) return null;

      const allowed = ['P','H1','H2','H3','H4','H5','H6','A','LI','FIGCAPTION','BLOCKQUOTE','LABEL'];
      if (!allowed.includes(parent.tagName)) return null;

      const text = textNode.textContent;
      const index = pos.startOffset;

      const wordBounds = this.getWordBounds(text, index);
      if (!wordBounds) return null;

      const range = document.createRange();
      range.setStart(textNode, wordBounds.start);
      range.setEnd(textNode, wordBounds.end);

      return {
        node: textNode,
        range,
        word: text.slice(wordBounds.start, wordBounds.end)
      };
    },

    getWordBounds(text, index) {
      if (!text || !text.trim()) return null;

      let start = index;
      let end = index;

      while (start > 0 && /\w/.test(text[start - 1])) start--;
      while (end < text.length && /\w/.test(text[end])) end++;

      if (start === end) return null;

      return { start, end };
    },

    openEditor({ node, range, word }, x, y) {
      this.activeNode = node;
      this.activeRange = range;

      this.highlightRange(range);

      const wrapper = document.createElement('div');
      wrapper.className = 'quick-seo-text-editor';
      wrapper.style.top = `${y + 10}px`;
      wrapper.style.left = `${x + 10}px`;

      wrapper.innerHTML = `
        <input type="text" value="${word}" />
        <div class="qs-editor-actions">
          <button data-action="save">Save</button>
          <button data-action="cancel">Cancel</button>
        </div>
      `;

      wrapper.addEventListener('click', (e) => {
        e.stopPropagation();
        const action = e.target.dataset.action;
        if (action === 'save') this.commitEdit();
        if (action === 'cancel') this.closeEditor();
      });

      document.body.appendChild(wrapper);
      this.editorEl = wrapper;
      wrapper.querySelector('input').focus();
    },

    highlightRange(range) {
      const mark = document.createElement('mark');
      mark.className = 'qs-word-highlight';
      range.surroundContents(mark);
    },

    commitEdit() {
      if (!this.editorEl || !this.activeNode) return;

      const input = this.editorEl.querySelector('input');
      const newWord = input.value;

      const mark = document.querySelector('.qs-word-highlight');
      if (!mark) return;

      const textNode = document.createTextNode(newWord);
      mark.replaceWith(textNode);

      this.closeEditor();
    },

    closeEditor() {
      const mark = document.querySelector('.qs-word-highlight');
      if (mark) {
        const textNode = document.createTextNode(mark.textContent);
        mark.replaceWith(textNode);
      }

      if (this.editorEl) this.editorEl.remove();
      this.editorEl = null;
      this.activeNode = null;
      this.activeRange = null;
    }
  };

  document.addEventListener('DOMContentLoaded', () => EditOverlay.init());
})();
