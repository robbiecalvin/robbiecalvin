(function () {
  const Overlay = {
    enabled: localStorage.getItem('quickSeoOverlay') === 'on',

    init() {
      if (this.enabled) {
        document.body.classList.add('quick-seo-overlay-active');
        this.ensureBadge();
        this.scan();
      }

      document.addEventListener('click', (e) => {
        if (e.target.closest('#wp-admin-bar-quick-seo-overlay-toggle')) {
          e.preventDefault();
          this.toggle();
        }
      });
    },

    toggle() {
      this.enabled = !this.enabled;
      localStorage.setItem(
        'quickSeoOverlay',
        this.enabled ? 'on' : 'off'
      );

      document.body.classList.toggle(
        'quick-seo-overlay-active',
        this.enabled
      );

      if (this.enabled) {
        this.ensureBadge();
        this.scan();
      } else {
        this.clear();
        this.removeBadge();
      }
    },

    ensureBadge() {
      if (document.getElementById('quick-seo-head-badge')) return;

      const badge = document.createElement('div');
      badge.id = 'quick-seo-head-badge';
      badge.innerHTML = `
        <strong>SEO Head</strong>
        <div class="qs-head-status"></div>
      `;
      document.body.appendChild(badge);
    },

    removeBadge() {
      const badge = document.getElementById('quick-seo-head-badge');
      if (badge) badge.remove();
    },

    updateHeadBadge(label, value, status) {
      const container = document.querySelector(
        '#quick-seo-head-badge .qs-head-status'
      );
      if (!container) return;

      container.innerHTML += `
        <div data-status="${status}">
          ${label}: ${value}
        </div>
      `;
    },

    scan() {
      this.clearBadge();
      this.scanH1();
      this.scanMeta();
      this.scanImages();
      this.scanLinks();
      this.scanHeadings();
      this.scanContent();
    },

    clearBadge() {
      const container = document.querySelector(
        '#quick-seo-head-badge .qs-head-status'
      );
      if (container) container.innerHTML = '';
    },

    scanH1() {
      const h1s = document.querySelectorAll('h1');

      if (h1s.length === 0) {
        document.body.setAttribute('data-quick-seo', 'error');
        return;
      }

      if (h1s.length > 1) {
        h1s.forEach(h => h.setAttribute('data-quick-seo', 'warn'));
        return;
      }

      h1s[0].setAttribute('data-quick-seo', 'good');
    },

    scanMeta() {
      this.scanTitle();
      this.scanDescription();
    },

    scanTitle() {
      const title = document.querySelector('title');

      if (!title || !title.textContent.trim()) {
        this.updateHeadBadge('Title', 'Missing', 'error');
        return;
      }

      const length = title.textContent.trim().length;

      if (length < 30 || length > 60) {
        this.updateHeadBadge('Title', length, 'warn');
        return;
      }

      this.updateHeadBadge('Title', length, 'good');
    },

    scanDescription() {
      const desc = document.querySelector('meta[name="description"]');

      if (!desc || !desc.content.trim()) {
        this.updateHeadBadge('Description', 'Missing', 'error');
        return;
      }

      const length = desc.content.trim().length;

      if (length < 70 || length > 160) {
        this.updateHeadBadge('Description', length, 'warn');
        return;
      }

      this.updateHeadBadge('Description', length, 'good');
    },

    scanImages() {
  const images = document.querySelectorAll('img');

  images.forEach(img => {
    const alt = img.getAttribute('alt');

    if (alt === null) {
      img.setAttribute('data-quick-seo', 'error');
      img.setAttribute('data-quick-seo-label', 'Missing alt');
      return;
    }

    if (!alt.trim()) {
      img.setAttribute('data-quick-seo', 'warn');
      img.setAttribute('data-quick-seo-label', 'Empty alt');
      return;
    }

    if (alt.length < 5) {
      img.setAttribute('data-quick-seo', 'warn');
      img.setAttribute('data-quick-seo-label', `Alt too short (${alt.length})`);
      return;
    }

    if (alt.length > 125) {
      img.setAttribute('data-quick-seo', 'warn');
      img.setAttribute('data-quick-seo-label', `Alt too long (${alt.length})`);
      return;
    }

    img.setAttribute('data-quick-seo', 'good');
    img.setAttribute('data-quick-seo-label', `Alt OK (${alt.length})`);
  });
},

scanLinks() {
  const links = document.querySelectorAll('a[href]');
  const hostname = window.location.hostname;

  links.forEach(link => {
    const href = link.getAttribute('href');
    const text = link.textContent.trim().toLowerCase();

    if (!href || href.startsWith('#')) return;

    const isExternal = link.hostname && link.hostname !== hostname;

    // Base status
    let status = 'good';
    let label = isExternal ? 'External link' : 'Internal link';

    // Empty anchor
    if (!text) {
      status = 'error';
      label = 'Empty anchor text';
    }

    // Bad generic anchors
    const badAnchors = ['click here', 'read more', 'learn more'];
    if (badAnchors.includes(text)) {
      status = 'warn';
      label = 'Generic anchor text';
    }

    // Too short
    if (text.length > 0 && text.length < 3) {
      status = 'warn';
      label = `Anchor too short (${text.length})`;
    }

    // Image-only links
    if (!text && link.querySelector('img')) {
      const img = link.querySelector('img');
      const alt = img.getAttribute('alt');

      if (!alt || !alt.trim()) {
        status = 'error';
        label = 'Image link missing alt';
      }
    }

    link.setAttribute('data-quick-seo', status);
    link.setAttribute('data-quick-seo-label', label);
  });
},

scanHeadings() {
  const headings = Array.from(
    document.querySelectorAll('h1, h2, h3, h4, h5, h6')
  );

  let lastLevel = 0;
  let seenH1 = false;

  headings.forEach(h => {
    const level = parseInt(h.tagName.substring(1), 10);
    let status = 'good';
    let label = `H${level}`;

    if (level === 1) {
      seenH1 = true;
    }

    if (!seenH1 && level !== 1) {
      status = 'warn';
      label = `H${level} before H1`;
    }

    if (lastLevel && level > lastLevel + 1) {
      status = 'warn';
      label = `Skipped from H${lastLevel} → H${level}`;
    }

    h.setAttribute('data-quick-seo', status);
    h.setAttribute('data-quick-seo-label', label);

    lastLevel = level;
  });
},

scanContent() {
  const content = document.querySelector('main, article, .entry-content, .content');

  if (!content) return;

  const text = content.innerText || '';
  const words = text.trim().split(/\s+/).filter(Boolean);
  const count = words.length;

  // Page-level status
  if (count < 300) {
    this.updateHeadBadge('Content', `${count} words`, 'error');
  } else if (count < 600) {
    this.updateHeadBadge('Content', `${count} words`, 'warn');
  } else {
    this.updateHeadBadge('Content', `${count} words`, 'good');
  }

  // Paragraph-level scan
  const paragraphs = content.querySelectorAll('p');

  paragraphs.forEach(p => {
    const pText = p.innerText.trim();
    if (!pText) return;

    const pWords = pText.split(/\s+/).filter(Boolean).length;

    if (pWords < 20) {
      p.setAttribute('data-quick-seo', 'warn');
      p.setAttribute('data-quick-seo-label', `Thin paragraph (${pWords})`);
      return;
    }

    if (pWords > 120) {
      p.setAttribute('data-quick-seo', 'warn');
      p.setAttribute('data-quick-seo-label', `Long paragraph (${pWords})`);
      return;
    }

    p.setAttribute('data-quick-seo', 'good');
    p.setAttribute('data-quick-seo-label', `Paragraph OK (${pWords})`);
  });
},




    clear() {
      document
        .querySelectorAll('[data-quick-seo]')
        .forEach(el => el.removeAttribute('data-quick-seo'));
    }
  };

  document.addEventListener('DOMContentLoaded', () => Overlay.init());
})();
