# Quick SEO -- Visual To‑Do

## Dashboard

-   Align all card buttons evenly across rows

## Spreadsheet Editor

-   No changes required

## Schema Editor

-   No changes required
