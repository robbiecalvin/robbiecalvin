<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
// AJAX hooks
add_action('wp_ajax_quick_seo_save_pages', 'qseo_save_pages_ajax');
add_action('wp_ajax_quick_seo_save_posts', 'qseo_save_posts_ajax');
add_action('wp_ajax_quick_seo_save_products', 'qseo_save_products_ajax');
add_action('wp_ajax_quick_seo_save_categories', 'qseo_save_categories_ajax');
add_action('wp_ajax_quick_seo_save_tags', 'qseo_save_tags_ajax');
add_action('wp_ajax_quick_seo_save_product_tags', 'qseo_save_product_tags_ajax'); // ✅ NEW
add_action('wp_ajax_quick_seo_save_post_categories', 'qseo_save_post_categories_ajax'); // ✅ NEW
add_action('wp_ajax_qseo_save_pages', 'qseo_save_pages_ajax');
add_action('wp_ajax_qseo_save_posts', 'qseo_save_posts_ajax');
add_action('wp_ajax_qseo_save_products', 'qseo_save_products_ajax');
add_action('wp_ajax_qseo_save_categories', 'qseo_save_categories_ajax');
add_action('wp_ajax_qseo_save_tags', 'qseo_save_tags_ajax');
add_action('wp_ajax_qseo_save_product_tags', 'qseo_save_product_tags_ajax');
add_action('wp_ajax_qseo_save_post_categories', 'qseo_save_post_categories_ajax');

add_action('wp_ajax_quick_seo_save_schema_template', 'qseo_save_schema_template');
add_action('wp_ajax_quick_seo_load_schema_template', 'qseo_load_schema_template');
add_action('wp_ajax_qseo_save_schema_template', 'qseo_save_schema_template');
add_action('wp_ajax_qseo_load_schema_template', 'qseo_load_schema_template');

add_action('wp_ajax_quick_seo_save_robots', 'qseo_save_robots');
add_action('wp_ajax_quick_seo_generate_sitemap', 'qseo_generate_sitemap_ajax');
add_action('wp_ajax_qseo_save_robots', 'qseo_save_robots');
add_action('wp_ajax_qseo_generate_sitemap', 'qseo_generate_sitemap_ajax');

add_action('wp_ajax_quick_seo_scan_links', 'qseo_scan_links');
add_action('wp_ajax_quick_seo_add_redirect', 'qseo_add_redirect');
add_action('wp_ajax_quick_seo_remove_redirect', 'qseo_remove_redirect');
add_action('wp_ajax_qseo_scan_links', 'qseo_scan_links');
add_action('wp_ajax_qseo_add_redirect', 'qseo_add_redirect');
add_action('wp_ajax_qseo_remove_redirect', 'qseo_remove_redirect');
