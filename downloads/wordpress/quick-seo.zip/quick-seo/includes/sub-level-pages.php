<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
function qseo_render_subpage(): void {
    $page = $_GET['page'] ?? '';

    switch ($page) {
        case 'quick-seo-pages':
            qseo_load_pages_table();
            break;
        case 'quick-seo-posts':
            qseo_load_posts_table();
            break;
        case 'quick-seo-products':
            qseo_load_products_table();
            break;
        case 'quick-seo-categories': // Product Categories
            qseo_load_categories_table();
            break;
        case 'quick-seo-tags': // Post Tags
            qseo_load_tags_table();
            break;
        case 'quick-seo-product-tags':
            qseo_load_product_tags_table();
            break;
        case 'quick-seo-post-categories':
            qseo_load_post_categories_table();
            break;
        case 'quick-seo-schema':
            qseo_render_schema_page();
            break;
        case 'quick-seo-robots':
            qseo_render_robots_editor();
            break;
        case 'quick-seo-sitemaps':
            qseo_render_sitemap_generator();
            break;
        case 'quick-seo-canonical':
            qseo_render_canonical_page();
            break;
        case 'quick-seo-redirects':
            qseo_render_broken_link_scanner();
            break;
        case 'quick-seo-integrations':
            qseo_render_integrations_page();
            break;
        default:
            echo '<div class="wrap"><h1>Coming Soon</h1><p>This module is under construction.</p></div>';
            break;
    }
}


function qseo_render_schema_page(): void {
    $types = [
        'WebPage', 'Article', 'BlogPosting', 'NewsArticle', 'Product', 'Offer', 'Person', 'Organization',
        'Event', 'LocalBusiness', 'Service', 'FAQPage', 'HowTo'
    ];
    ?>
    <div class="wrap">
        <h1>Quick SEO Schema Builder</h1>
        <p>Select a schema type, edit the JSON, and click save. This template will be injected when that type is selected in the spreadsheet editors.</p>

        <label for="schema-type">Schema Type:</label>
        <select id="schema-type">
            <?php foreach ($types as $type): ?>
                <option value="<?= esc_attr($type) ?>"><?= esc_html($type) ?></option>
            <?php endforeach; ?>
        </select>

        <textarea id="schema-json" rows="20" style="width: 100%; margin-top: 15px; font-family: monospace;"></textarea>
        <p><button id="save-schema" class="button button-primary">💾 Save Schema</button></p>
        <div id="schema-feedback" style="margin-top:10px;"></div>
    </div>
    <?php
}
