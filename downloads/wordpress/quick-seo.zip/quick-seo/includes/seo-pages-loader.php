<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function qseo_load_pages_table() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Fetch all published + draft pages
    $args = [
        'post_type'   => 'page',
        'post_status' => ['publish', 'draft'],
        'numberposts' => -1,
        'orderby'     => 'title',
        'order'       => 'ASC',
    ];

    $pages = get_posts($args);
    $data = [];

    foreach ($pages as $page) {
        $meta = get_post_meta($page->ID);

        $data[] = [
            'ID'                  => $page->ID,
            'title'               => $page->post_title, // lowercase to avoid confusion
            'focus_keyword'       => $meta['_quickseo_focus_keyword'][0] ?? '',
            'secondary_keyword'   => $meta['_quickseo_secondary_keyword'][0] ?? '',
            'seo_title'           => $meta['_quickseo_seo_title'][0] ?? '',
            'meta_description'    => $meta['_quickseo_meta_description'][0] ?? '',
            'og_title'            => $meta['_quickseo_og_title'][0] ?? '',
            'og_description'      => $meta['_quickseo_og_description'][0] ?? '',
            'og_type'             => $meta['_quickseo_og_type'][0] ?? '',
            'og_image'            => $meta['_quickseo_og_image'][0] ?? '',
            'twitter_title'       => $meta['_quickseo_twitter_title'][0] ?? '',
            'twitter_description' => $meta['_quickseo_twitter_description'][0] ?? '',
            'twitter_image'       => $meta['_quickseo_twitter_image'][0] ?? '',
            'schema'              => $meta['_quickseo_schema'][0] ?? '',
            'longtail_keyword'    => $meta['_quickseo_longtail_keyword'][0] ?? '',
            'robots'             => $meta['_quickseo_robots'][0] ?? '',
            'sitemap'            => $meta['_quickseo_sitemap'][0] ?? '',

        ];
    }

    $context = 'pages';
    include QUICK_SEO_PLUGIN_DIR . 'templates/seo-page-table.php';
    
}
