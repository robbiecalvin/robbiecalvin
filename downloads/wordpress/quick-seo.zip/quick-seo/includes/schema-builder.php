<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Save schema template
function qseo_save_schema_template() {
    check_ajax_referer('qseo_schema_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $schema_type = isset( $_POST['type'] ) ? sanitize_text_field( wp_unslash( $_POST['type'] ) ) : '';
    $schema_json = isset( $_POST['schema'] ) ? wp_unslash( $_POST['schema'] ) : '';

    if (!$schema_type || !$schema_json) {
        wp_send_json_error('Missing data');
    }

    $key = 'quickseo_schema_' . strtolower($schema_type);
    update_option($key, $schema_json);

    wp_send_json_success('Schema saved');
}

// Load schema template
function qseo_load_schema_template() {
    check_ajax_referer('qseo_schema_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $schema_type = isset( $_POST['type'] ) ? sanitize_text_field( wp_unslash( $_POST['type'] ) ) : '';
    $key = 'quickseo_schema_' . strtolower($schema_type);

$schema = get_option($key);
$decoded = json_decode($schema, true);

if (
    !$schema ||
    !is_array($decoded) ||
    count(array_filter($decoded, fn($v) => $v !== '' && $v !== [])) === 0
) {
    wp_send_json_error('No usable template');
}

    wp_send_json_success(['schema' => $schema]);
}
