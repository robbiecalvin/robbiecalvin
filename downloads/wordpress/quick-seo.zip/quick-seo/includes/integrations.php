<?php

if (!defined('ABSPATH')) {
    exit;
}

function qseo_get_integrations_settings(): array {
    $defaults = [
        'quick_audit' => 0,
        'quick_code' => 0,
        'quick_traffic' => 0,
        'quick_site' => 0,
    ];

    $saved = get_option('qseo_integrations', []);
    if (!is_array($saved)) {
        $saved = [];
    }

    $settings = wp_parse_args($saved, $defaults);
    return [
        'quick_audit' => !empty($settings['quick_audit']) ? 1 : 0,
        'quick_code' => !empty($settings['quick_code']) ? 1 : 0,
        'quick_traffic' => !empty($settings['quick_traffic']) ? 1 : 0,
        'quick_site' => !empty($settings['quick_site']) ? 1 : 0,
    ];
}

function qseo_render_integrations_page(): void {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized.', 'quick-seo'));
    }

    $settings = qseo_get_integrations_settings();
    $premium_enabled = qseo_is_premium_active();
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Quick SEO Integrations', 'quick-seo'); ?></h1>
        <?php if (!$premium_enabled) : ?>
            <div class="notice notice-warning"><p><?php esc_html_e('Integrations are a premium feature.', 'quick-seo'); ?></p></div>
        <?php endif; ?>
        <p><?php esc_html_e('Optional integrations only. Quick SEO remains fully standalone.', 'quick-seo'); ?></p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="qseo_save_integrations" />
            <?php wp_nonce_field('qseo_save_integrations', 'qseo_integrations_nonce'); ?>
            <table class="form-table" role="presentation">
                <tbody>
                    <tr>
                        <th scope="row"><?php esc_html_e('Quick Audit', 'quick-seo'); ?></th>
                        <td><label><input type="checkbox" name="quick_audit" value="1" <?php checked(1, (int) $settings['quick_audit']); ?> <?php disabled(!$premium_enabled); ?> /> <?php esc_html_e('Accept audit completion events when Quick Audit is active.', 'quick-seo'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Quick Code', 'quick-seo'); ?></th>
                        <td><label><input type="checkbox" name="quick_code" value="1" <?php checked(1, (int) $settings['quick_code']); ?> <?php disabled(!$premium_enabled); ?> /> <?php esc_html_e('Share SEO update events with Quick Code when active.', 'quick-seo'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Quick Traffic', 'quick-seo'); ?></th>
                        <td><label><input type="checkbox" name="quick_traffic" value="1" <?php checked(1, (int) $settings['quick_traffic']); ?> <?php disabled(!$premium_enabled); ?> /> <?php esc_html_e('Accept traffic events when Quick Traffic is active.', 'quick-seo'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Quick Site', 'quick-seo'); ?></th>
                        <td><label><input type="checkbox" name="quick_site" value="1" <?php checked(1, (int) $settings['quick_site']); ?> <?php disabled(!$premium_enabled); ?> /> <?php esc_html_e('Accept optimization events when Quick Site is active.', 'quick-seo'); ?></label></td>
                    </tr>
                </tbody>
            </table>
            <?php submit_button(__('Save Integrations', 'quick-seo')); ?>
        </form>
    </div>
    <?php
}

function qseo_handle_save_integrations(): void {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Unauthorized.', 'quick-seo'));
    }

    check_admin_referer('qseo_save_integrations', 'qseo_integrations_nonce');

    $premium_enabled = qseo_is_premium_active();
    $settings = [
        'quick_audit' => $premium_enabled && !empty($_POST['quick_audit']) ? 1 : 0,
        'quick_code' => $premium_enabled && !empty($_POST['quick_code']) ? 1 : 0,
        'quick_traffic' => $premium_enabled && !empty($_POST['quick_traffic']) ? 1 : 0,
        'quick_site' => $premium_enabled && !empty($_POST['quick_site']) ? 1 : 0,
    ];

    update_option('qseo_integrations', $settings, false);
    wp_safe_redirect(admin_url('admin.php?page=quick-seo-integrations'));
    exit;
}

function qseo_handle_audit_completed($payload, $context): void {
    $settings = qseo_get_integrations_settings();
    if (empty($settings['quick_audit'])) {
        return;
    }

    update_option('qseo_last_audit_event', [
        'payload' => is_array($payload) ? $payload : [],
        'context' => is_array($context) ? $context : [],
        'stored_at' => current_time('mysql'),
    ], false);
}

function qseo_emit_seo_updated($meta_id, $object_id, $meta_key, $meta_value): void {
    unset($meta_id);
    $settings = qseo_get_integrations_settings();

    if (empty($settings['quick_code']) && empty($settings['quick_traffic']) && empty($settings['quick_site'])) {
        return;
    }

    $meta_key = (string) $meta_key;
    if (strpos($meta_key, '_quickseo_') !== 0) {
        return;
    }

    do_action(
        'quickwoo_local/seo_updated',
        [
            'post_id' => absint($object_id),
            'meta_key' => sanitize_key($meta_key),
            'meta_value' => is_scalar($meta_value) ? sanitize_text_field((string) $meta_value) : '',
        ],
        [
            'source' => 'quick-seo',
            'occurred_at' => current_time('mysql'),
        ]
    );
}

add_action('admin_post_qseo_save_integrations', 'qseo_handle_save_integrations');
add_action('quickwoo_local/audit_completed', 'qseo_handle_audit_completed', 10, 2);
add_action('updated_post_meta', 'qseo_emit_seo_updated', 10, 4);
