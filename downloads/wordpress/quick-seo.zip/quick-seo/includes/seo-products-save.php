<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function qseo_save_products_ajax() {
    check_ajax_referer('qseo_save_products_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $seo_data = (isset($_POST['seo_data']) && is_array($_POST['seo_data'])) ? $_POST['seo_data'] : array();
    if (empty($seo_data)) {
        wp_send_json_success('No SEO rows to save');
    }
    if (!qseo_is_premium_active() && count($seo_data) > 2) {
        wp_send_json_error('Free tier allows saving up to 2 rows per action. Upgrade for unlimited rows.');
    }
    if (!qseo_is_premium_active() && count($seo_data) > 2) {
        wp_send_json_error('Free tier allows saving up to 2 rows per action. Upgrade for unlimited rows.');
    }

    foreach ($seo_data as $post_id => $fields) {
        $post_id = intval($post_id);
        foreach ($fields as $key => $value) {
            $meta_key = '_quickseo_' . sanitize_key($key);
            update_post_meta($post_id, $meta_key, sanitize_text_field($value));
        }
    }

    wp_send_json_success('SEO data saved successfully');
}
