<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function qseo_render_robots_editor() {
    $premium_enabled = qseo_is_premium_active();
    $path = ABSPATH . 'robots.txt';
    $content = file_exists($path) ? file_get_contents($path) : "User-agent: *\nDisallow:\n";

    echo '<div class="wrap">';
    echo '<h1>robots.txt Editor</h1>';
    if (!$premium_enabled) {
        echo '<div class="notice notice-warning"><p>robots.txt editor is a premium feature.</p></div>';
    }
    echo '<p>Edit the contents of your site\'s <code>robots.txt</code> file below.</p>';
    echo '<textarea id="quick-seo-robots" rows="15" style="width:100%; font-family: monospace;" ' . disabled(!$premium_enabled, true, false) . '>' . esc_textarea($content) . '</textarea>';
    echo '<p><button class="button button-primary" id="save-robots" ' . disabled(!$premium_enabled, true, false) . '>💾 Save robots.txt</button></p>';
    echo '<div id="robots-feedback" style="margin-top:10px;"></div>';
    echo '</div>';
}

function qseo_save_robots() {
    check_ajax_referer('qseo_schema_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }
    if (!qseo_is_premium_active()) {
        wp_send_json_error('robots.txt editor is available on premium only.');
    }

    $content = isset( $_POST['content'] ) ? (string) wp_unslash( $_POST['content'] ) : '';
    $path = ABSPATH . 'robots.txt';

    if (!is_writable(ABSPATH)) {
        wp_send_json_error('Root directory not writable');
    }

    $written = file_put_contents($path, $content);
    if ($written === false) {
        wp_send_json_error('Failed to write robots.txt');
    }

    wp_send_json_success();
}
