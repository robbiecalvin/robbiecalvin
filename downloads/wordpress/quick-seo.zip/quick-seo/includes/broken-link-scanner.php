<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function qseo_require_broken_link_permissions() {
    check_ajax_referer( 'qseo_schema_nonce', 'nonce' );

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Unauthorized', 403 );
    }
}

function qseo_render_broken_link_scanner() {
    $redirects = get_option('quickseo_redirects', []);

    echo '<div class="wrap">';
    echo '<h1>Broken Link Scanner & Redirect Manager</h1>';
    echo '<p>Scan your content for broken links and assign redirects.</p>';
    echo '<button id="scan-broken-links" class="button button-primary">🔍 Scan Site</button>';
    echo '<div id="broken-links-results" style="margin-top:20px;"></div>';

    echo '<h2>Existing Redirects</h2>';
    echo '<table class="wp-list-table widefat">';
    echo '<thead><tr><th>From</th><th>To</th><th>Action</th></tr></thead><tbody>';
    foreach ($redirects as $from => $to) {
        echo "<tr>
            <td>" . esc_html($from) . "</td>
            <td>" . esc_html($to) . "</td>
            <td><button class='remove-redirect button' data-from='" . esc_attr($from) . "'>Remove</button></td>
        </tr>";
    }
    echo '</tbody></table>';
    echo '</div>';
}
function qseo_scan_links() {
 qseo_require_broken_link_permissions();
 global $wpdb;
 $broken = [];

 $content = $wpdb->get_results("SELECT ID, post_content FROM $wpdb->posts WHERE post_status = 'publish'", ARRAY_A);

 foreach ($content as $row) {
     $doc = new DOMDocument();
     @$doc->loadHTML($row['post_content']);
     $links = $doc->getElementsByTagName('a');

     foreach ($links as $link) {
         $href = $link->getAttribute('href');
         if (strpos($href, home_url()) === 0 || strpos($href, '/') === 0) {
             $rel = parse_url($href, PHP_URL_PATH);
             if (!qseo_url_exists($rel)) {
                 $broken[$rel] = get_permalink($row['ID']);
             }
         }
     }
 }

 wp_send_json_success($broken);
}

function qseo_add_redirect() {
 qseo_require_broken_link_permissions();
 $from = isset( $_POST['from'] ) ? sanitize_text_field( wp_unslash( $_POST['from'] ) ) : '';
 $to   = isset( $_POST['to'] ) ? sanitize_text_field( wp_unslash( $_POST['to'] ) ) : '';

 if (!$from || !$to) {
     wp_send_json_error('Missing fields');
 }

 $redirects = get_option('quickseo_redirects', []);
 $redirects[$from] = $to;
 update_option('quickseo_redirects', $redirects);

 wp_send_json_success('Redirect added');
}

function qseo_remove_redirect() {
 qseo_require_broken_link_permissions();
 $from = isset( $_POST['from'] ) ? sanitize_text_field( wp_unslash( $_POST['from'] ) ) : '';

 $redirects = get_option('quickseo_redirects', []);
 unset($redirects[$from]);
 update_option('quickseo_redirects', $redirects);

 wp_send_json_success('Redirect removed');
}

function qseo_url_exists($path) {
 $url = site_url($path);
 $response = wp_remote_head($url);
 return !is_wp_error($response) && wp_remote_retrieve_response_code($response) != 404;
}
