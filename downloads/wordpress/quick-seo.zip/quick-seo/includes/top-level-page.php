<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
// 🔧 Adds the top-level admin menu page
function qseo_register_menu() {
    add_menu_page(
        'Quick SEO',
        'Quick SEO',
        'manage_options',
        'quick-seo',
        'qseo_render_dashboard',
        'dashicons-chart-line',
        26
    );

    $submenus = [
        ['Pages', 'quick-seo-pages', 'edit_pages'],
        ['Posts', 'quick-seo-posts', 'edit_posts'],
        ['Products', 'quick-seo-products', 'edit_products'],
        ['Product Categories', 'quick-seo-categories', 'manage_product_terms'],
        ['Post Tags', 'quick-seo-tags', 'manage_categories'],
        ['Product Tags', 'quick-seo-product-tags', 'manage_product_terms'],
        ['Post Categories', 'quick-seo-post-categories', 'manage_categories'],
        ['Schema', 'quick-seo-schema', 'manage_options'],
        ['Canonical', 'quick-seo-canonical', 'manage_options'],
        ['Redirects', 'quick-seo-redirects', 'manage_options'],
        ['Sitemaps', 'quick-seo-sitemaps', 'manage_options'],
        ['Robots', 'quick-seo-robots', 'manage_options'],
        ['Integrations', 'quick-seo-integrations', 'manage_options'],
    ];

    foreach ($submenus as [$label, $slug, $cap]) {
        add_submenu_page(
            'quick-seo',
            $label,
            $label,
            $cap,
            $slug,
            'qseo_render_subpage'
        );
    }
}

// 🔧 Renders the top-level Quick SEO dashboard
function qseo_render_dashboard() {
    ?>
    <div class="wrap quick-seo-dashboard">
        <h1 style="margin-bottom: 10px;">🎉 Welcome to Quick SEO</h1>
        <p style="font-size: 1.1em; margin-bottom: 30px;">You’ve unlocked full-stack SEO control. Use the tools below to dominate search rankings across your WordPress + WooCommerce site.</p>

        <div class="quick-seo-grid">
            <?php
$cards = [
    ['Pages', 'Spreadsheet SEO editor for all pages.', 'Focus + secondary keywords, meta, OG, schema, longtail.', 'quick-seo-pages'],
    ['Posts', 'Bulk SEO for WordPress posts.', 'Same format as Pages.', 'quick-seo-posts'],
    ['Products', 'Optimize WooCommerce products.', 'Add offer schema, product OG, and longtails.', 'quick-seo-products'],
    ['Product Categories', 'Edit SEO for product categories.', 'Includes category type column.', 'quick-seo-categories'],
    ['Post Tags', 'SEO control for blog tags.', 'Supports meta, keywords, and schema.', 'quick-seo-tags'],
    ['Product Tags', 'WooCommerce tag SEO editor.', 'Great for niche term ranking.', 'quick-seo-product-tags'],
    ['Post Categories', 'Edit SEO for blog categories.', 'Categorical longtail support.', 'quick-seo-post-categories'],
    ['Schema', 'Build & manage schema types.', 'WebPage, Product, Person, Service, and more.', 'quick-seo-schema'],
    ['Canonical', 'Global + page-specific canonical rules.', 'Helps prevent duplicate content.', 'quick-seo-canonical'],
    ['Redirects', 'Fix broken links + set redirects.', 'Track 404s, manage redirection.', 'quick-seo-redirects'],
    ['Sitemaps', 'Generate XML sitemaps.', 'Includes all indexed content types.', 'quick-seo-sitemaps'],
    ['Robots', 'robots.txt file editor.', 'Control crawl behavior directly.', 'quick-seo-robots'],
];
foreach ($cards as [$title, $line1, $line2, $slug]) {
    $url = admin_url("admin.php?page=$slug");

    echo "
    <div class='quick-seo-card'>
        <h3>$title</h3>
        <ul>
            <li>$line1</li>
            <li>$line2</li>
        </ul>
        <a href='$url' class='button-primary'>Open $title</a>
    </div>";
}

            ?>
        </div>
    </div>
    <?php
}
