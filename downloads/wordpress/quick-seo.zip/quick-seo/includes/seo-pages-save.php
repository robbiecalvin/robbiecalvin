<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function qseo_save_pages_ajax() {
    // Security check
    check_ajax_referer('qseo_save_pages_nonce', 'nonce');

    if (!current_user_can('edit_pages')) {
        wp_send_json_error('Unauthorized');
    }

    $seo_data = (isset($_POST['seo_data']) && is_array($_POST['seo_data'])) ? $_POST['seo_data'] : array();
    if (empty($seo_data)) {
        wp_send_json_success('No SEO rows to save');
    }
    if (!qseo_is_premium_active() && count($seo_data) > 2) {
        wp_send_json_error('Free tier allows saving up to 2 rows per action. Upgrade for unlimited rows.');
    }

    foreach ($seo_data as $post_id => $fields) {
        $post_id = intval($post_id);
        if (!$post_id || !is_array($fields)) continue;

        // Save regular fields
        foreach ($fields as $key => $value) {
            // Skip sitemap for now — handle it below
            if ($key === 'sitemap') continue;

            $meta_key = '_quickseo_' . sanitize_key($key);
            update_post_meta($post_id, $meta_key, sanitize_text_field($value));
        }

        // ✅ Handle sitemap separately to ensure unchecked = no
        $sitemap_flag = isset($fields['sitemap']) && $fields['sitemap'] === 'yes' ? 'yes' : 'no';
        update_post_meta($post_id, '_quickseo_sitemap', sanitize_text_field($sitemap_flag));
    }

    wp_send_json_success('SEO data saved successfully');
}
