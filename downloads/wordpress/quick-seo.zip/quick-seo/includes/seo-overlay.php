<?php
if (!defined('ABSPATH')) exit;

function qseo_maybe_enqueue_overlay() {
    if (
        is_admin()
        || !is_user_logged_in()
        || !current_user_can('manage_options')
    ) {
        return;
    }

$base_url = plugin_dir_url(dirname(__FILE__));

wp_enqueue_style(
    'quick-seo-overlay',
    $base_url . 'assets/css/seo-overlay.css',
    [],
    time()
);


    wp_enqueue_script(
        'quick-seo-overlay',
        QUICK_SEO_PLUGIN_URL . 'assets/js/seo-overlay.js',
        ['jquery'],
        QUICK_SEO_VERSION,
        true
    );
}
add_action('wp_enqueue_scripts', 'qseo_maybe_enqueue_overlay', 99);

add_action('admin_bar_menu', function ($bar) {
    if (
        is_admin()
        || !current_user_can('manage_options')
    ) return;

    $bar->add_node([
        'id'    => 'quick-seo-overlay-toggle',
        'title' => 'SEO Overlay',
        'href'  => '#',
        'meta'  => ['class' => 'quick-seo-overlay-toggle']
    ]);
}, 100);

