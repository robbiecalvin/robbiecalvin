<?php
/*
Plugin Name: Quick SEO
Plugin URI: https://quickwoo.pro
Description: A full-stack WordPress + WooCommerce SEO engine with spreadsheet-style bulk editing, schema injection, and total control over metadata.
Version: 3.0.0
Author: QuickWoo by Robbie Calvin
Author URI: https://quickwoo.pro
License: GPLv2 or later
Text Domain: quick-seo
*/

// ─────────────────────────────────────────────
// 🔐 SECURITY: Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/quick-core/bootstrap.php';
}

// ─────────────────────────────────────────────
// 🔧 DEFINE CONSTANTS
define('QUICK_SEO_VERSION', '3.0.0');
define('QUICK_SEO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('QUICK_SEO_PLUGIN_URL', plugin_dir_url(__FILE__));

function qseo_is_premium_active() {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

    if ( function_exists( 'qwoo_has_active_license' ) ) {
        return (bool) qwoo_has_active_license( array( 'quick-seo' ) );
    }

    return false;
}

function qseo_limit_rows_for_free( $seo_data ) {
    if ( ! is_array( $seo_data ) ) {
        return array();
    }

    if ( qseo_is_premium_active() ) {
        return $seo_data;
    }

    return array_slice( $seo_data, 0, 2, true );
}

// ─────────────────────────────────────────────
// 📦 INCLUDE CORE FILES
require_once QUICK_SEO_PLUGIN_DIR . 'includes/top-level-page.php';
require_once QUICK_SEO_PLUGIN_DIR . 'includes/sub-level-pages.php';
require_once QUICK_SEO_PLUGIN_DIR . 'includes/seo-meta-box.php';
require_once QUICK_SEO_PLUGIN_DIR . 'includes/ajax-handlers.php'; // ✅ Centralizes all AJAX
require_once QUICK_SEO_PLUGIN_DIR . 'includes/seo-overlay.php';
require_once QUICK_SEO_PLUGIN_DIR . 'includes/integrations.php';


// 🔄 AUTOLOAD REMAINING MODULES
$autoload_files = [
    'seo-pages-loader',
    'seo-pages-save',
    'seo-posts-loader',
    'seo-posts-save',
    'seo-products-loader',
    'seo-products-save',
    'seo-categories-loader',
    'seo-categories-save',
    'seo-tags-loader',
    'seo-tags-save',
    'seo-product-tags-loader',
    'seo-product-tags-save',
    'seo-post-categories-loader',
    'seo-post-categories-save',
    'sitemap-generator',
    'robots-editor',
    'canonical-suggestion',
    'broken-link-scanner',
    'schema-builder'
];

foreach ($autoload_files as $file) {
    require_once QUICK_SEO_PLUGIN_DIR . "includes/{$file}.php";
}

// ─────────────────────────────────────────────
// 📂 ADMIN MENUS
add_action('admin_menu', 'qseo_register_menu');

// ─────────────────────────────────────────────
// 🧠 METABOX SETUP
add_action('add_meta_boxes', 'qseo_add_meta_boxes');
add_action('save_post', 'qseo_save_meta_box_data');

// ─────────────────────────────────────────────
// 🎨 ADMIN SCRIPTS + STYLES
function qseo_enqueue_admin_assets($hook) {
    if (strpos($hook, 'quick-seo') === false) return;

    wp_enqueue_style('quick-seo-style', QUICK_SEO_PLUGIN_URL . 'assets/css/style.css');
    wp_enqueue_script('quick-seo-script', QUICK_SEO_PLUGIN_URL . 'assets/js/script.js', ['jquery'], null, true);

    $pages = [
        'pages' => 'seopages',
        'posts' => 'seoposts',
        'products' => 'seoproducts',
        'categories' => 'seocategories',
        'tags' => 'seotags',
        'product-tags' => 'seoproducttags',
        'post-categories' => 'seopostcategories'
    ];

    if (isset($_GET['page'])) {
        foreach ($pages as $slug => $jsFile) {
            if ($_GET['page'] === "quick-seo-$slug") {
                wp_enqueue_script("quick-seo-$slug", QUICK_SEO_PLUGIN_URL . "assets/js/$jsFile.js", ['jquery'], null, true);

                $jsVarName = 'quickSeo' . str_replace('-', '', ucwords($slug, '-'));
                $nonceKey = 'qseo_save_' . str_replace('-', '_', $slug) . '_nonce';

                wp_localize_script("quick-seo-$slug", $jsVarName, [
                    'nonce' => wp_create_nonce($nonceKey),
                    'ajaxurl' => admin_url('admin-ajax.php')
                ]);
            }
        }

        switch ($_GET['page']) {
            case 'quick-seo-robots':
                wp_enqueue_script('quick-seo-robots', QUICK_SEO_PLUGIN_URL . 'assets/js/robots.js', ['jquery'], null, true);
                break;
            case 'quick-seo-sitemaps':
                wp_enqueue_script('quick-seo-sitemap', QUICK_SEO_PLUGIN_URL . 'assets/js/sitemap.js', ['jquery'], null, true);
                break;
            case 'quick-seo-redirects':
                wp_enqueue_script('quick-seo-redirects', QUICK_SEO_PLUGIN_URL . 'assets/js/brokenlinks.js', ['jquery'], null, true);
                break;
        }
    }

    wp_localize_script('quick-seo-script', 'quickSeo', [
        'nonce' => wp_create_nonce('qseo_schema_nonce'),
        'ajaxurl' => admin_url('admin-ajax.php')
    ]);
}
add_action('admin_enqueue_scripts', 'qseo_enqueue_admin_assets');

// ─────────────────────────────────────────────
// 🧬 INJECT META INTO HEAD + LONGTAIL
add_action('wp_head', 'qseo_output_meta_tags', 1);
add_action('wp_footer', 'qseo_output_longtail_block', 100);

add_filter('pre_get_document_title', 'qseo_override_wp_title');
function qseo_override_wp_title($title) {
    if (is_singular()) {
        $custom_title = get_post_meta(get_the_ID(), '_quickseo_seo_title', true);
        if ($custom_title) {
            return $custom_title;
        }
    }
    return $title;
}

function qseo_output_meta_tags() {
 

    if (!is_singular()) return;
    global $post;

    $title         = get_post_meta($post->ID, '_quickseo_seo_title', true);
    $description   = get_post_meta($post->ID, '_quickseo_meta_description', true);
    $focus         = get_post_meta($post->ID, '_quickseo_focus_keyword', true);
    $secondary     = get_post_meta($post->ID, '_quickseo_secondary_keyword', true);
    $robots        = get_post_meta($post->ID, '_quickseo_robots', true);
    $sitemap_optin = get_post_meta($post->ID, '_quickseo_sitemap', true);
    $og_type        = get_post_meta($post->ID, '_quickseo_og_type', true);
    $og_image       = get_post_meta($post->ID, '_quickseo_og_image', true);
    $twitter_title  = get_post_meta($post->ID, '_quickseo_twitter_title', true);
    $twitter_desc   = get_post_meta($post->ID, '_quickseo_twitter_description', true);
    $twitter_image  = get_post_meta($post->ID, '_quickseo_twitter_image', true);
    $canonical_override = get_post_meta($post->ID, '_quickseo_canonical_override', true);
    $canonical = $canonical_override ?: get_permalink($post->ID);
    $og_title      = get_post_meta($post->ID, '_quickseo_og_title', true);
    $og_desc       = get_post_meta($post->ID, '_quickseo_og_description', true);
    $schema_type   = get_post_meta($post->ID, '_quickseo_schema', true);
    $keywords      = array_filter(array_map('trim', [$focus, $secondary]));
    $keywords_str  = implode(', ', $keywords);

    // BEGIN COMMENT BLOCK
    echo "<!-- INJECTED WITH QUICK SEO BY QUICKWOO -->\n";


    // META + STRUCTURED DATA OUTPUT

    if ($title) {
        echo '<title>' .esc_attr($title) . '</title>' . "\n";
    }

    if ($robots) {
        echo '<meta name="robots" content="' . esc_attr($robots) . '">' . "\n"; 
    }

    if ($description) {
        echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
    }
    if ($keywords_str) {
        echo '<meta name="keywords" content="' . esc_attr($keywords_str) . '">' . "\n";
    }

    if ($sitemap_optin === 'yes') {
        echo '<link rel="sitemap" type="application/xml" href="' . esc_url(home_url('/sitemap.xml')) . '">' . "\n";
    }

    echo '<link rel="canonical" href="' . esc_url($canonical) . '">' . "\n";
    echo '<meta property="og:url" content="' . esc_url($canonical) . '">' . "\n";
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";

    if ($og_title) {
        echo '<meta property="og:title" content="' . esc_attr($og_title) . '">' . "\n";
    }
    if ($og_desc) {
        echo '<meta property="og:description" content="' . esc_attr($og_desc) . '">' . "\n";
    }

    if ($og_type) {
    echo '<meta property="og:type" content="' . esc_attr($og_type) . '">' . "\n";
}
if ($og_image) {
    echo '<meta property="og:image" content="' . esc_url($og_image) . '">' . "\n";
}
if ($twitter_title) {
    echo '<meta name="twitter:title" content="' . esc_attr($twitter_title) . '">' . "\n";
}
if ($twitter_desc) {
    echo '<meta name="twitter:description" content="' . esc_attr($twitter_desc) . '">' . "\n";
}
if ($twitter_image) {
    echo '<meta name="twitter:image" content="' . esc_url($twitter_image) . '">' . "\n";
}


    // Inject schema
    if ($schema_type) {
        $option_key = 'quickseo_schema_' . strtolower($schema_type);
        $json = get_option($option_key);
        if (!$json) {
            $json = json_encode([
                "@context" => "https://schema.org",
                "@type" => $schema_type,
                "name" => get_the_title(),
                "url" => $canonical
            ], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        }
        echo "<script type=\"application/ld+json\">\n$json\n</script>\n";
    }

}


function qseo_output_longtail_block() {
    if (!is_singular()) return;

    global $post;
    $longtail = get_post_meta($post->ID, '_quickseo_longtail_keyword', true);
    if (!$longtail) return;

    echo '
    <!-- Quick SEO Longtail Display -->
    <div style="
        margin-top: 3rem;
        padding: 1.6rem;
        border-radius: 14px;
        background: linear-gradient(180deg, #0b1020, #0f172a);
        border: 1px solid rgba(99,102,241,0.25);
        box-shadow: 0 20px 40px rgba(0,0,0,0.35);
        font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
    ">

        <!-- Powered By -->
        <div style="
            display: grid;
            grid-template-columns: 1fr auto;
            align-items: center;
            gap: 1rem;
            padding-bottom: 1.2rem;
            margin-bottom: 1.2rem;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        ">
            <div style="
                font-size: 0.95rem;
                font-weight: 600;
                color: #c7d2fe;
                letter-spacing: 0.3px;
            ">
                This Site Powered By <span style="color:#818cf8;">Quick SEO</span> by Robert Calvin
            </div>

            <div style="
                width: 46px;
                height: 46px;
                border-radius: 10px;
                background: rgba(99,102,241,0.15);
                display: flex;
                align-items: center;
                justify-content: center;
                border: 1px solid rgba(99,102,241,0.35);
            ">
                <img 
                    src="http://localhost:10033/wp-content/uploads/2025/12/quickseofinal.png"
                    alt="Quick SEO App Logo"
                    style="
                        max-width: 70%;
                        max-height: 70%;
                        object-fit: contain;
                        opacity: 0.9;
                    "
                />
            </div>
        </div>

        <!-- Longtail Keywords -->
        <div>
            <h6 style="
                margin: 0 0 0.4rem 0;
                font-size: 0.75rem;
                font-weight: 700;
                letter-spacing: 0.08em;
                text-transform: uppercase;
                color: #94a3b8;
            ">
                Top User Related Search Queries
            </h6>

            <small style="
                display: block;
                font-size: 0.78rem;
                line-height: 1.6;
                color: #e5e7eb;
                opacity: 0.85;
            ">
                ' . esc_html($longtail) . '
            </small>
        </div>

    </div>';
}


// ─────────────────────────────────────────────
// 🔁 REDIRECT LOGIC
add_action('template_redirect', 'qseo_handle_redirects');
function qseo_handle_redirects() {
    if (is_404()) {
        $current_path = strtok($_SERVER['REQUEST_URI'], '?');
        $redirects = get_option('quickseo_redirects', []);
        if (isset($redirects[$current_path])) {
            wp_redirect(site_url($redirects[$current_path]), 301);
            exit;
        }
    }
}

// 🧹 Strip default WP-generated <title> tag from the theme
function qseo_strip_wp_title_tag($buffer) {
    return preg_replace('/<title\b[^>]*>.*?<\/title>/is', '', $buffer, 1); // remove only first occurrence
}

function qseo_start_buffer() {
    ob_start('qseo_strip_wp_title_tag');
}
add_action('template_redirect', 'qseo_start_buffer');


remove_filter('wp_robots', 'wp_robots_max_image_preview_large');
remove_action('wp_head', 'wp_robots', 1);

add_filter('wp_robots', 'qseo_override_wp_robots');
function qseo_override_wp_robots($robots) {
    global $post;
    if (!is_singular()) return $robots;

    $robots_directive = get_post_meta($post->ID, '_quickseo_robots', true);
    if ($robots_directive) {
        // Split comma-separated values into array
        $parts = array_map('trim', explode(',', $robots_directive));
        $robots = array_fill_keys($parts, true);
    }

    return $robots;
}
function qseo_enqueue_overlay_edit() {

    // Only load for logged-in users who can edit content
    if (!is_user_logged_in() || !current_user_can('edit_posts')) {
        return;
    }

    wp_enqueue_script(
        'quick-seo-overlay-edit',
        QUICK_SEO_PLUGIN_URL . 'assets/js/seo-overlay-edit.js',
        [],
        QUICK_SEO_VERSION,
        true
    );

    wp_enqueue_style(
        'quick-seo-overlay-edit',
        QUICK_SEO_PLUGIN_URL . 'assets/css/seo-overlay-edit.css',
        [],
        QUICK_SEO_VERSION
    );
}
add_action('wp_enqueue_scripts', 'qseo_enqueue_overlay_edit');

if ( ! function_exists( 'qwoo_quick_seo_license_bootstrap' ) ) {
    function qwoo_quick_seo_license_bootstrap() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu', 'qwoo_quick_seo_license_menu' );
        add_action( 'admin_post_qwoo_quick_seo_activate_license', 'qwoo_quick_seo_license_handle_activate' );
        add_action( 'admin_post_qwoo_quick_seo_deactivate_license', 'qwoo_quick_seo_license_handle_deactivate' );
    }
    add_action( 'plugins_loaded', 'qwoo_quick_seo_license_bootstrap', 30 );

    function qwoo_quick_seo_license_option_key() {
        return 'qwoo_quick_seo_license';
    }

    function qwoo_quick_seo_license_product_scope() {
        return array( 'quick-seo' );
    }

    function qwoo_quick_seo_license_get_data() {
        $defaults = array(
            'license_key' => '',
            'license_status' => 'inactive',
            'license_message' => '',
        );

        $saved = get_option( qwoo_quick_seo_license_option_key(), array() );
        $saved = is_array( $saved ) ? $saved : array();

        return wp_parse_args( $saved, $defaults );
    }

    function qwoo_quick_seo_license_save_data( $data ) {
        $data = is_array( $data ) ? $data : array();

        $clean = array(
            'license_key' => sanitize_text_field( (string) ( $data['license_key'] ?? '' ) ),
            'license_status' => sanitize_key( (string) ( $data['license_status'] ?? 'inactive' ) ),
            'license_message' => sanitize_text_field( (string) ( $data['license_message'] ?? '' ) ),
        );

        update_option( qwoo_quick_seo_license_option_key(), $clean, false );
        return $clean;
    }

    function qwoo_quick_seo_license_menu() {
        add_options_page(
            'Lseo License',
            'Lseo License',
            'manage_options',
            'qwoo-quick-seo-license',
            'qwoo_quick_seo_license_render_page'
        );
    }

    function qwoo_quick_seo_license_render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = qwoo_quick_seo_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );

        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $status = qlic_get_license_status_for_key_products( $license_key, qwoo_quick_seo_license_product_scope() );
            if ( is_array( $status ) ) {
                $data['license_status'] = sanitize_key( (string) ( $status['status'] ?? $data['license_status'] ) );
                $data['license_message'] = sanitize_text_field( (string) ( $status['message'] ?? $data['license_message'] ) );
                if ( ! empty( $status['valid'] ) && ! empty( $status['domain_active'] ) ) {
                    $data['license_status'] = 'active';
                }
                qwoo_quick_seo_license_save_data( $data );
            }
        }

        $notice = isset( $_GET['qwoo_license_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qwoo_license_notice'] ) ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Lseo License', 'quick-seo' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-seo' ), (string) ( $data['license_status'] ?? 'inactive' ) ) ); ?></p>
            <?php if ( ! empty( $data['license_message'] ) ) : ?>
                <p><?php echo esc_html( (string) $data['license_message'] ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_seo_activate_license" />
                <?php wp_nonce_field( 'qwoo_quick_seo_activate_license', 'qwoo_quick_seo_activate_license_nonce' ); ?>
                <p>
                    <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( (string) ( $data['license_key'] ?? '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button type="submit" class="button button-primary"><?php echo esc_html__( 'Activate License', 'quick-seo' ); ?></button>
                </p>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_seo_deactivate_license" />
                <?php wp_nonce_field( 'qwoo_quick_seo_deactivate_license', 'qwoo_quick_seo_deactivate_license_nonce' ); ?>
                <p><button type="submit" class="button"><?php echo esc_html__( 'Deactivate License', 'quick-seo' ); ?></button></p>
            </form>
        </div>
        <?php
    }

    function qwoo_quick_seo_license_redirect( $message ) {
        $url = add_query_arg(
            array(
                'page' => 'qwoo-quick-seo-license',
                'qwoo_license_notice' => rawurlencode( (string) $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    function qwoo_quick_seo_license_handle_activate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-seo' ) );
        }

        check_admin_referer( 'qwoo_quick_seo_activate_license', 'qwoo_quick_seo_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        if ( '' === $license_key ) {
            qwoo_quick_seo_license_save_data(
                array(
                    'license_key' => '',
                    'license_status' => 'inactive',
                    'license_message' => 'License key is required.',
                )
            );
            qwoo_quick_seo_license_redirect( 'License key is required.' );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            qwoo_quick_seo_license_save_data(
                array(
                    'license_key' => $license_key,
                    'license_status' => 'invalid',
                    'license_message' => 'Quick License plugin is required for activation.',
                )
            );
            qwoo_quick_seo_license_redirect( 'Quick License plugin is required for activation.' );
        }

        $result = qlic_activate_license_key_for_products( $license_key, qwoo_quick_seo_license_product_scope() );
        $data = array(
            'license_key' => $license_key,
            'license_status' => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'license_message' => sanitize_text_field( (string) ( $result['message'] ?? 'License validation failed.' ) ),
        );
        if ( ! empty( $result['valid'] ) ) {
            $data['license_status'] = 'active';
        }

        qwoo_quick_seo_license_save_data( $data );
        qwoo_quick_seo_license_redirect( (string) $data['license_message'] );
    }

    function qwoo_quick_seo_license_handle_deactivate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-seo' ) );
        }

        check_admin_referer( 'qwoo_quick_seo_deactivate_license', 'qwoo_quick_seo_deactivate_license_nonce' );

        $data = qwoo_quick_seo_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );
        $message = 'License deactivated.';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products( $license_key, qwoo_quick_seo_license_product_scope() );
            if ( is_array( $result ) && ! empty( $result['message'] ) ) {
                $message = sanitize_text_field( (string) $result['message'] );
            }
        }

        qwoo_quick_seo_license_save_data(
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => $message,
            )
        );

        qwoo_quick_seo_license_redirect( $message );
    }
}
