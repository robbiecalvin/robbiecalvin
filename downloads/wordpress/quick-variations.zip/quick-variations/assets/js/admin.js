(function ($) {
    'use strict';

    function toSlug(value) {
        return String(value || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    }

    function escapeHtml(value) {
        return $('<div/>').text(value == null ? '' : String(value)).html();
    }

    function csvToArray(value) {
        return String(value || '').split(',').map(function (item) {
            return item.trim();
        }).filter(Boolean);
    }

    function buildCombinations(attributeMap) {
        var combos = [{}];
        Object.keys(attributeMap).forEach(function (key) {
            var next = [];
            combos.forEach(function (combo) {
                attributeMap[key].forEach(function (opt) {
                    var copy = $.extend({}, combo);
                    copy[key] = opt;
                    next.push(copy);
                });
            });
            combos = next;
        });

        return combos;
    }

    function updateIndexes() {
        $('#qvar-blocks .qvar-block').each(function (blockIndex) {
            $(this).attr('data-block-index', blockIndex);
            $(this).find('[name]').each(function () {
                var name = $(this).attr('name');
                if (!name) {
                    return;
                }
                name = name.replace(/qvar_blocks\[[^\]]+\]/, 'qvar_blocks[' + blockIndex + ']');
                $(this).attr('name', name);
            });
        });
    }

    function collectAttributeMap($block) {
        var map = {};
        $block.find('.qvar-attr-row').each(function () {
            var name = $(this).find('input[name*="[name]"]').val();
            var values = $(this).find('input[name*="[values]"]').val();
            var key = toSlug(name);
            if (!key) {
                return;
            }
            var options = csvToArray(values);
            if (!options.length) {
                return;
            }
            map[key] = options;
        });
        return map;
    }

    function renderCombinations($block, combos) {
        var html = '<table class="widefat striped qvar-combos"><thead><tr><th>Combination</th><th>Regular Price</th><th>SKU</th><th>Stock</th></tr></thead><tbody>';
        combos.forEach(function (combo, index) {
            var comboText = Object.keys(combo).map(function (key) {
                return key + ': ' + combo[key];
            }).join(' | ');

            html += '<tr data-combo-index="' + index + '">';
            html += '<td class="qvar-combo-cell" data-combo="' + escapeHtml(JSON.stringify(combo)) + '">' + escapeHtml(comboText) + '</td>';
            html += '<td><input type="number" step="0.01" min="0" class="qvar-var-price" /></td>';
            html += '<td><input type="text" class="qvar-var-sku" /></td>';
            html += '<td><input type="number" min="0" class="qvar-var-stock" /></td>';
            html += '</tr>';
        });
        html += '</tbody></table>';

        $block.find('.qvar-combos-wrap').html(html);
    }

    function serializeVariations($block) {
        var rows = [];

        $block.find('.qvar-combos tbody tr').each(function () {
            var comboRaw = $(this).find('.qvar-combo-cell').attr('data-combo') || '{}';
            var combo = {};
            try {
                combo = JSON.parse(comboRaw);
            } catch (err) {
                combo = {};
            }

            rows.push({
                combo: combo,
                regular_price: $(this).find('.qvar-var-price').val() || '',
                sku: $(this).find('.qvar-var-sku').val() || '',
                stock_quantity: $(this).find('.qvar-var-stock').val() || ''
            });
        });

        $block.find('.qvar-variation-json').val(JSON.stringify(rows));
    }

    function createBlockFromTemplate(index) {
        var tpl = $('#qvar-block-template').html() || '';
        var html = tpl.replace(/__INDEX__/g, String(index));
        return $(html);
    }

    $(document).on('click', '#qvar-add-product', function () {
        var $wrap = $('#qvar-blocks');
        var maxBlocks = parseInt($wrap.data('max-blocks'), 10) || 2;
        var count = $wrap.find('.qvar-block').length;

        if (count >= maxBlocks) {
            window.alert((qvarAdmin.strings && qvarAdmin.strings.freeLimit) || 'Free tier supports up to two product blocks per submission.');
            return;
        }

        var $block = createBlockFromTemplate(count);
        $wrap.append($block);
        updateIndexes();
    });

    $(document).on('click', '.qvar-remove-block', function () {
        var $blocks = $('#qvar-blocks .qvar-block');
        if ($blocks.length <= 1) {
            return;
        }

        $(this).closest('.qvar-block').remove();
        updateIndexes();
    });

    $(document).on('click', '.qvar-add-attribute', function () {
        var $block = $(this).closest('.qvar-block');
        var blockIndex = $block.data('block-index');
        var idx = $block.find('.qvar-attr-row').length;

        var html = '';
        html += '<div class="qvar-attr-row">';
        html += '<input type="text" name="qvar_blocks[' + blockIndex + '][attributes][' + idx + '][name]" placeholder="Attribute name (e.g., Size)" />';
        html += '<input type="text" name="qvar_blocks[' + blockIndex + '][attributes][' + idx + '][values]" placeholder="Values (comma separated)" />';
        html += '</div>';

        $block.find('.qvar-attributes').append(html);
    });

    $(document).on('click', '.qvar-generate-combinations', function () {
        var $block = $(this).closest('.qvar-block');
        var attributeMap = collectAttributeMap($block);
        if (!Object.keys(attributeMap).length) {
            window.alert('Add at least one attribute with values.');
            return;
        }

        var combos = buildCombinations(attributeMap);
        renderCombinations($block, combos);
        serializeVariations($block);
    });

    $(document).on('input change', '.qvar-combos-wrap input', function () {
        var $block = $(this).closest('.qvar-block');
        serializeVariations($block);
    });

    $('#qvar-main-form').on('submit', function () {
        var $wrap = $('#qvar-blocks');
        var maxBlocks = parseInt($wrap.data('max-blocks'), 10) || 2;
        var count = $wrap.find('.qvar-block').length;
        if (count > maxBlocks) {
            window.alert((qvarAdmin.strings && qvarAdmin.strings.freeLimit) || 'Free tier supports up to two product blocks per submission.');
            return false;
        }

        $wrap.find('.qvar-block').each(function () {
            serializeVariations($(this));
        });
    });
})(jQuery);
