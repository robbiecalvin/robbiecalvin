<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QVAR_Admin {
    const FREE_MAX_BLOCKS = 2;

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'admin_post_qvar_generate_variations', array( $this, 'handle_generate_variations' ) );
        add_action( 'admin_post_qvar_activate_license', array( $this, 'handle_activate_license' ) );
        add_action( 'admin_post_qvar_deactivate_license', array( $this, 'handle_deactivate_license' ) );
    }

    /**
     * Register plugin menu pages.
     *
     * @return void
     */
    public function register_admin_menu() {
        add_menu_page(
            esc_html__( 'Quick Variations', 'quick-variations' ),
            esc_html__( 'Quick Variations', 'quick-variations' ),
            'manage_woocommerce',
            'quick-variations',
            array( $this, 'render_generator_page' ),
            'dashicons-randomize',
            56
        );

        add_submenu_page(
            'quick-variations',
            esc_html__( 'Variation Generator', 'quick-variations' ),
            esc_html__( 'Generator', 'quick-variations' ),
            'manage_woocommerce',
            'quick-variations',
            array( $this, 'render_generator_page' )
        );

        add_submenu_page(
            'quick-variations',
            esc_html__( 'Settings', 'quick-variations' ),
            esc_html__( 'Settings', 'quick-variations' ),
            'manage_woocommerce',
            'quick-variations-settings',
            array( $this, 'render_settings_page' )
        );
    }

    /**
     * Enqueue admin assets.
     *
     * @param string $hook Hook name.
     * @return void
     */
    public function enqueue_assets( $hook ) {
        $allowed_hooks = array(
            'toplevel_page_quick-variations',
            'quick-variations_page_quick-variations-settings',
        );

        if ( ! in_array( $hook, $allowed_hooks, true ) ) {
            return;
        }

        wp_enqueue_style(
            'qvar-admin',
            QVAR_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            QVAR_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'qvar-admin',
            QVAR_PLUGIN_URL . 'assets/js/admin.js',
            array( 'jquery' ),
            QVAR_PLUGIN_VERSION,
            true
        );

        wp_localize_script(
            'qvar-admin',
            'qvarAdmin',
            array(
                'maxBlocks' => 10000,
                'freeTier'  => false,
                'strings'   => array(
                    'freeLimit' => __( 'Free tier supports up to two product blocks per submission.', 'quick-variations' ),
                ),
            )
        );
    }

    /**
     * Render generator page.
     *
     * @return void
     */
    public function render_generator_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-variations' ) );
        }

        $products       = $this->get_variable_products();
        ?>
        <div class="wrap qvar-wrap">
            <h1><?php echo esc_html__( 'Quick Variations Generator', 'quick-variations' ); ?></h1>
            <?php $this->render_notice(); ?>

            <p><?php echo esc_html__( 'Configure variable product blocks, define attributes, generate combinations, then submit all blocks in one operation.', 'quick-variations' ); ?></p>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="qvar-main-form">
                <input type="hidden" name="action" value="qvar_generate_variations" />
                <?php wp_nonce_field( 'qvar_generate_variations', 'qvar_generate_variations_nonce' ); ?>

                <div class="qvar-toolbar">
                    <button type="button" class="button" id="qvar-add-product"><?php echo esc_html__( 'Add Product Block', 'quick-variations' ); ?></button>
                </div>

                <div class="qvar-blocks" id="qvar-blocks" data-max-blocks="<?php echo esc_attr( (string) 10000 ); ?>">
                    <?php $this->render_product_block( 0, $products ); ?>
                </div>

                <?php submit_button( __( 'Generate Variations', 'quick-variations' ) ); ?>
            </form>

            <script type="text/template" id="qvar-block-template">
                <?php
                ob_start();
                $this->render_product_block( '__INDEX__', $products );
                echo str_replace( array( "\n", "\r" ), '', ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                ?>
            </script>
        </div>
        <?php
    }

    /**
     * Render a product block.
     *
     * @param int|string $index Block index.
     * @param array      $products Variable products list.
     * @return void
     */
    private function render_product_block( $index, $products ) {
        ?>
        <section class="qvar-block" data-block-index="<?php echo esc_attr( (string) $index ); ?>">
            <div class="qvar-block__head">
                <h2><?php echo esc_html__( 'Product Block', 'quick-variations' ); ?></h2>
                <button type="button" class="button qvar-remove-block"><?php echo esc_html__( 'Remove', 'quick-variations' ); ?></button>
            </div>

            <div class="qvar-grid qvar-grid--2">
                <div class="qvar-field">
                    <label><?php echo esc_html__( 'Variable Product', 'quick-variations' ); ?></label>
                    <select name="qvar_blocks[<?php echo esc_attr( (string) $index ); ?>][product_id]" class="qvar-product-select" required>
                        <option value=""><?php echo esc_html__( 'Select a variable product...', 'quick-variations' ); ?></option>
                        <?php foreach ( $products as $product ) : ?>
                            <option value="<?php echo esc_attr( (string) $product['id'] ); ?>"><?php echo esc_html( $product['label'] ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="qvar-field">
                    <label><?php echo esc_html__( 'Block Label (optional)', 'quick-variations' ); ?></label>
                    <input type="text" name="qvar_blocks[<?php echo esc_attr( (string) $index ); ?>][label]" value="" />
                </div>
            </div>

            <div class="qvar-field">
                <strong><?php echo esc_html__( 'Attribute Creator', 'quick-variations' ); ?></strong>
                <div class="qvar-attributes">
                    <div class="qvar-attr-row">
                        <input type="text" name="qvar_blocks[<?php echo esc_attr( (string) $index ); ?>][attributes][0][name]" placeholder="<?php echo esc_attr__( 'Attribute name (e.g., Color)', 'quick-variations' ); ?>" />
                        <input type="text" name="qvar_blocks[<?php echo esc_attr( (string) $index ); ?>][attributes][0][values]" placeholder="<?php echo esc_attr__( 'Values (comma separated)', 'quick-variations' ); ?>" />
                    </div>
                </div>
                <button type="button" class="button qvar-add-attribute"><?php echo esc_html__( 'Add Attribute', 'quick-variations' ); ?></button>
            </div>

            <div class="qvar-field">
                <strong><?php echo esc_html__( 'Variation Generator', 'quick-variations' ); ?></strong>
                <p class="description"><?php echo esc_html__( 'Generate combinations and optionally edit price, SKU, and stock before submit.', 'quick-variations' ); ?></p>
                <button type="button" class="button qvar-generate-combinations"><?php echo esc_html__( 'Generate Combinations', 'quick-variations' ); ?></button>
                <div class="qvar-combos-wrap"></div>
                <input type="hidden" class="qvar-variation-json" name="qvar_blocks[<?php echo esc_attr( (string) $index ); ?>][variation_rows_json]" value="" />
            </div>
        </section>
        <?php
    }

    /**
     * Handle variation generation post action.
     *
     * @return void
     */
    public function handle_generate_variations() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-variations' ) );
        }

        check_admin_referer( 'qvar_generate_variations', 'qvar_generate_variations_nonce' );

        $blocks = isset( $_POST['qvar_blocks'] ) ? wp_unslash( $_POST['qvar_blocks'] ) : array();
        $blocks = $this->sanitize_blocks( $blocks );

        if ( empty( $blocks ) ) {
            $this->redirect_with_notice( 'quick-variations', 'error', __( 'No product blocks were submitted.', 'quick-variations' ) );
        }

        $report = array();
        $has_success = false;

        foreach ( $blocks as $block ) {
            $result = $this->process_product_block( $block );
            if ( ! empty( $result['success'] ) ) {
                $has_success = true;
            }
            $report[] = $result;
        }

        $type    = $has_success ? 'success' : 'error';
        $message = $has_success
            ? __( 'Variation processing completed. Review per-product results below.', 'quick-variations' )
            : __( 'Variation processing failed for all blocks. Review results and retry.', 'quick-variations' );

        $this->redirect_with_notice( 'quick-variations', $type, $message, $report );
    }

    /**
     * Process a single product block.
     *
     * @param array $block Block payload.
     * @return array<string,mixed>
     */
    private function process_product_block( $block ) {
        $product_id = isset( $block['product_id'] ) ? absint( $block['product_id'] ) : 0;
        $label      = isset( $block['label'] ) ? sanitize_text_field( (string) $block['label'] ) : '';

        $result = array(
            'success'  => false,
            'product'  => $product_id,
            'label'    => $label,
            'created'  => 0,
            'skipped'  => 0,
            'failed'   => 0,
            'message'  => '',
        );

        if ( $product_id < 1 ) {
            $result['message'] = __( 'Missing product selection.', 'quick-variations' );
            return $result;
        }

        $product = wc_get_product( $product_id );
        if ( ! $product || ! is_a( $product, 'WC_Product_Variable' ) ) {
            $result['message'] = __( 'Selected product is not variable. Choose a variable product.', 'quick-variations' );
            return $result;
        }

        $attribute_defs = isset( $block['attributes'] ) ? $this->sanitize_attribute_defs( $block['attributes'] ) : array();
        if ( empty( $attribute_defs ) ) {
            $result['message'] = __( 'At least one valid attribute definition is required.', 'quick-variations' );
            return $result;
        }

        $attribute_map = $this->sync_product_attributes( $product, $attribute_defs );
        $product->save();

        $variations = $this->extract_variation_rows( $block, $attribute_defs );
        if ( empty( $variations ) ) {
            $result['message'] = __( 'No variation combinations generated from the provided attributes.', 'quick-variations' );
            return $result;
        }

        $existing_signatures = $this->get_existing_variation_signatures( $product );

        foreach ( $variations as $variation_row ) {
            $combo = isset( $variation_row['combo'] ) && is_array( $variation_row['combo'] ) ? $variation_row['combo'] : array();
            $combo = $this->normalize_combo( $combo );
            if ( empty( $combo ) ) {
                $result['failed']++;
                continue;
            }

            $signature = $this->build_signature( $combo );
            if ( isset( $existing_signatures[ $signature ] ) ) {
                $result['skipped']++;
                continue;
            }

            $variation_attrs = array();
            foreach ( $combo as $attr_key => $attr_value ) {
                if ( ! isset( $attribute_map[ $attr_key ] ) ) {
                    continue;
                }
                $variation_attrs[ $attribute_map[ $attr_key ] ] = $attr_value;
            }

            if ( empty( $variation_attrs ) ) {
                $result['failed']++;
                continue;
            }

            try {
                $variation = new WC_Product_Variation();
                $variation->set_parent_id( $product_id );
                $variation->set_status( 'publish' );
                $variation->set_attributes( $variation_attrs );

                if ( isset( $variation_row['regular_price'] ) && '' !== (string) $variation_row['regular_price'] ) {
                    $variation->set_regular_price( wc_format_decimal( $variation_row['regular_price'] ) );
                    $variation->set_price( wc_format_decimal( $variation_row['regular_price'] ) );
                }

                if ( isset( $variation_row['sku'] ) && '' !== (string) $variation_row['sku'] ) {
                    $variation->set_sku( sanitize_text_field( (string) $variation_row['sku'] ) );
                }

                if ( isset( $variation_row['stock_quantity'] ) && '' !== (string) $variation_row['stock_quantity'] ) {
                    $stock = max( 0, absint( $variation_row['stock_quantity'] ) );
                    $variation->set_manage_stock( true );
                    $variation->set_stock_quantity( $stock );
                    $variation->set_stock_status( $stock > 0 ? 'instock' : 'outofstock' );
                } else {
                    $variation->set_manage_stock( false );
                }

                $saved_id = $variation->save();
                if ( $saved_id > 0 ) {
                    $result['created']++;
                    $existing_signatures[ $signature ] = true;
                } else {
                    $result['failed']++;
                }
            } catch ( Throwable $exception ) {
                $result['failed']++;
            }
        }

        $result['success'] = $result['created'] > 0 || $result['skipped'] > 0;
        $result['message'] = sprintf(
            /* translators: 1: created, 2: skipped, 3: failed */
            __( 'Created %1$d, skipped %2$d, failed %3$d.', 'quick-variations' ),
            (int) $result['created'],
            (int) $result['skipped'],
            (int) $result['failed']
        );

        return $result;
    }

    /**
     * Sanitize submitted blocks.
     *
     * @param mixed $blocks Submitted blocks.
     * @return array<int,array<string,mixed>>
     */
    private function sanitize_blocks( $blocks ) {
        if ( ! is_array( $blocks ) ) {
            return array();
        }

        $sanitized = array();
        foreach ( $blocks as $block ) {
            if ( ! is_array( $block ) ) {
                continue;
            }

            $product_id = isset( $block['product_id'] ) ? absint( $block['product_id'] ) : 0;
            if ( $product_id < 1 ) {
                continue;
            }

            $sanitized[] = array(
                'product_id'          => $product_id,
                'label'               => isset( $block['label'] ) ? sanitize_text_field( (string) $block['label'] ) : '',
                'attributes'          => isset( $block['attributes'] ) ? $block['attributes'] : array(),
                'variation_rows_json' => isset( $block['variation_rows_json'] ) ? (string) $block['variation_rows_json'] : '',
            );
        }

        return $sanitized;
    }

    /**
     * Sanitize attribute definitions.
     *
     * @param mixed $attribute_defs Raw attribute defs.
     * @return array<int,array<string,mixed>>
     */
    private function sanitize_attribute_defs( $attribute_defs ) {
        if ( ! is_array( $attribute_defs ) ) {
            return array();
        }

        $sanitized = array();
        foreach ( $attribute_defs as $attribute_def ) {
            if ( ! is_array( $attribute_def ) ) {
                continue;
            }

            $name   = isset( $attribute_def['name'] ) ? sanitize_text_field( (string) $attribute_def['name'] ) : '';
            $values = isset( $attribute_def['values'] ) ? (string) $attribute_def['values'] : '';
            $parts  = array_filter( array_map( 'wc_clean', array_map( 'trim', explode( ',', $values ) ) ) );
            $parts  = array_values( array_unique( $parts ) );

            if ( '' === $name || empty( $parts ) ) {
                continue;
            }

            $sanitized[] = array(
                'name'    => $name,
                'slug'    => sanitize_title( $name ),
                'options' => $parts,
            );
        }

        return $sanitized;
    }

    /**
     * Merge or create variation attributes on product.
     *
     * @param WC_Product_Variable $product Product object.
     * @param array               $attribute_defs Attribute defs.
     * @return array<string,string> Map slug => attribute name used on product.
     */
    private function sync_product_attributes( WC_Product_Variable $product, $attribute_defs ) {
        $current      = $product->get_attributes();
        $by_slug      = array();
        $name_map     = array();

        foreach ( $current as $attribute ) {
            if ( ! is_a( $attribute, 'WC_Product_Attribute' ) ) {
                continue;
            }
            $attr_name = (string) $attribute->get_name();
            $slug      = sanitize_title( str_replace( 'pa_', '', $attr_name ) );
            if ( '' !== $slug ) {
                $by_slug[ $slug ] = $attribute;
                $name_map[ $slug ] = $attr_name;
            }
        }

        foreach ( $attribute_defs as $index => $def ) {
            $slug    = $def['slug'];
            $options = $def['options'];

            if ( isset( $by_slug[ $slug ] ) ) {
                $attribute   = $by_slug[ $slug ];
                $merged_opts = array_values( array_unique( array_merge( $attribute->get_options(), $options ) ) );
                $attribute->set_options( $merged_opts );
                $attribute->set_visible( true );
                $attribute->set_variation( true );
                $attribute->set_position( $index );
                $name_map[ $slug ] = (string) $attribute->get_name();
                continue;
            }

            $attribute = new WC_Product_Attribute();
            $attribute->set_id( 0 );
            $attribute->set_name( $def['name'] );
            $attribute->set_options( $options );
            $attribute->set_position( $index );
            $attribute->set_visible( true );
            $attribute->set_variation( true );

            $by_slug[ $slug ]  = $attribute;
            $name_map[ $slug ] = $def['name'];
        }

        $product->set_attributes( array_values( $by_slug ) );

        return $name_map;
    }

    /**
     * Extract variations from payload or generate from attributes.
     *
     * @param array $block Product block.
     * @param array $attribute_defs Attribute defs.
     * @return array<int,array<string,mixed>>
     */
    private function extract_variation_rows( $block, $attribute_defs ) {
        $json = isset( $block['variation_rows_json'] ) ? (string) $block['variation_rows_json'] : '';
        if ( '' !== trim( $json ) ) {
            $decoded = json_decode( $json, true );
            if ( is_array( $decoded ) ) {
                $rows = array();
                foreach ( $decoded as $row ) {
                    if ( ! is_array( $row ) || empty( $row['combo'] ) || ! is_array( $row['combo'] ) ) {
                        continue;
                    }
                    $rows[] = array(
                        'combo'         => $this->normalize_combo( $row['combo'] ),
                        'regular_price' => isset( $row['regular_price'] ) ? wc_format_decimal( $row['regular_price'] ) : '',
                        'sku'           => isset( $row['sku'] ) ? sanitize_text_field( (string) $row['sku'] ) : '',
                        'stock_quantity'=> isset( $row['stock_quantity'] ) ? absint( $row['stock_quantity'] ) : '',
                    );
                }
                if ( ! empty( $rows ) ) {
                    return $rows;
                }
            }
        }

        $attribute_map = array();
        foreach ( $attribute_defs as $def ) {
            $attribute_map[ $def['slug'] ] = $def['options'];
        }

        $combos = $this->build_cartesian_combinations( $attribute_map );
        $rows   = array();
        foreach ( $combos as $combo ) {
            $rows[] = array(
                'combo'          => $combo,
                'regular_price'  => '',
                'sku'            => '',
                'stock_quantity' => '',
            );
        }

        return $rows;
    }

    /**
     * Normalize combo keys/values.
     *
     * @param array $combo Combo values.
     * @return array<string,string>
     */
    private function normalize_combo( $combo ) {
        $normalized = array();
        foreach ( (array) $combo as $key => $value ) {
            $clean_key   = sanitize_title( (string) $key );
            $clean_value = wc_clean( (string) $value );
            if ( '' !== $clean_key && '' !== $clean_value ) {
                $normalized[ $clean_key ] = $clean_value;
            }
        }
        return $normalized;
    }

    /**
     * Generate cartesian combinations for attribute map.
     *
     * @param array<string,array<int,string>> $attribute_map Attributes map.
     * @return array<int,array<string,string>>
     */
    private function build_cartesian_combinations( $attribute_map ) {
        $combinations = array( array() );

        foreach ( $attribute_map as $attribute_name => $options ) {
            $next = array();
            foreach ( $combinations as $combo ) {
                foreach ( $options as $option ) {
                    $new_combo                   = $combo;
                    $new_combo[ $attribute_name ] = wc_clean( (string) $option );
                    $next[]                      = $new_combo;
                }
            }
            $combinations = $next;
        }

        return $combinations;
    }

    /**
     * Existing variation signatures keyed for dedupe checks.
     *
     * @param WC_Product_Variable $product Product object.
     * @return array<string,bool>
     */
    private function get_existing_variation_signatures( WC_Product_Variable $product ) {
        $signatures = array();

        foreach ( $product->get_children() as $variation_id ) {
            $variation = wc_get_product( $variation_id );
            if ( ! $variation || ! is_a( $variation, 'WC_Product_Variation' ) ) {
                continue;
            }

            $attrs = $variation->get_attributes();
            if ( ! is_array( $attrs ) || empty( $attrs ) ) {
                continue;
            }

            $normalized = array();
            foreach ( $attrs as $key => $value ) {
                $key = str_replace( 'attribute_', '', (string) $key );
                $key = sanitize_title( str_replace( 'pa_', '', $key ) );
                $value = wc_clean( (string) $value );

                if ( '' !== $key && '' !== $value ) {
                    $normalized[ $key ] = $value;
                }
            }

            if ( ! empty( $normalized ) ) {
                $signatures[ $this->build_signature( $normalized ) ] = true;
            }
        }

        return $signatures;
    }

    /**
     * Build deterministic signature for combination.
     *
     * @param array<string,string> $combo Combo values.
     * @return string
     */
    private function build_signature( $combo ) {
        $parts = array();
        foreach ( $combo as $key => $value ) {
            $parts[] = sanitize_title( (string) $key ) . '=' . wc_clean( (string) $value );
        }

        sort( $parts, SORT_STRING );
        return implode( '|', $parts );
    }

    /**
     * Get variable products for dropdown.
     *
     * @return array<int,array<string,mixed>>
     */
    private function get_variable_products() {
        $rows = array();
        $products = wc_get_products(
            array(
                'type'    => 'variable',
                'limit'   => 300,
                'orderby' => 'title',
                'order'   => 'ASC',
                'status'  => array( 'publish', 'draft', 'private' ),
            )
        );

        foreach ( $products as $product ) {
            if ( ! is_a( $product, 'WC_Product' ) ) {
                continue;
            }

            $rows[] = array(
                'id'    => $product->get_id(),
                'label' => sprintf( '#%d %s', $product->get_id(), $product->get_name() ),
            );
        }

        return $rows;
    }

    /**
     * Handle license activation.
     *
     * @return void
     */
    public function handle_activate_license() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-variations' ) );
        }

        check_admin_referer( 'qvar_activate_license', 'qvar_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        $settings = $this->get_settings();

        if ( '' === $license_key ) {
            $settings['license_key'] = '';
            $settings['license_status'] = 'inactive';
            $settings['license_message'] = __( 'License key is required.', 'quick-variations' );
            update_option( QVAR_OPTION_SETTINGS, $settings );
            $this->redirect_with_notice( 'quick-variations-settings', 'error', $settings['license_message'] );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            $settings['license_key'] = $license_key;
            $settings['license_status'] = 'invalid';
            $settings['license_message'] = __( 'Quick Woo License plugin is required for activation.', 'quick-variations' );
            update_option( QVAR_OPTION_SETTINGS, $settings );
            $this->redirect_with_notice( 'quick-variations-settings', 'error', $settings['license_message'] );
        }

        $result = qlic_activate_license_key_for_products(
            $license_key,
            array(
                'quick-variations',
                'quick-variations-one-site',
                'quick-variations-five-sites',
                'quick-variations-unlimited-sites',
                'quick-product-bundle',
            )
        );

        $settings['license_key'] = $license_key;
        $settings['license_status'] = isset( $result['status'] ) ? sanitize_key( (string) $result['status'] ) : 'invalid';
        $settings['license_message'] = isset( $result['message'] ) ? sanitize_text_field( (string) $result['message'] ) : __( 'License validation failed.', 'quick-variations' );
        if ( ! empty( $result['valid'] ) ) {
            $settings['license_status'] = 'active';
        }

        update_option( QVAR_OPTION_SETTINGS, $settings );
        $this->redirect_with_notice( 'quick-variations-settings', ! empty( $result['valid'] ) ? 'success' : 'error', $settings['license_message'] );
    }

    /**
     * Handle license deactivation.
     *
     * @return void
     */
    public function handle_deactivate_license() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-variations' ) );
        }

        check_admin_referer( 'qvar_deactivate_license', 'qvar_deactivate_license_nonce' );

        $settings = $this->get_settings();
        $license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            qlic_deactivate_license_key_for_products(
                $license_key,
                array(
                    'quick-variations',
                    'quick-variations-one-site',
                    'quick-variations-five-sites',
                    'quick-variations-unlimited-sites',
                    'quick-product-bundle',
                )
            );
        }

        $settings['license_status'] = 'inactive';
        $settings['license_message'] = __( 'License deactivated.', 'quick-variations' );
        update_option( QVAR_OPTION_SETTINGS, $settings );

        $this->redirect_with_notice( 'quick-variations-settings', 'success', $settings['license_message'] );
    }

    /**
     * Render settings page.
     *
     * @return void
     */
    public function render_settings_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-variations' ) );
        }

        $settings = $this->get_settings();
        $license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';
        $license_status = isset( $settings['license_status'] ) ? sanitize_key( (string) $settings['license_status'] ) : 'inactive';
        $license_message = isset( $settings['license_message'] ) ? sanitize_text_field( (string) $settings['license_message'] ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Quick Variations Settings', 'quick-variations' ); ?></h1>
            <?php $this->render_notice(); ?>

            <h2><?php echo esc_html__( 'License Activation', 'quick-variations' ); ?></h2>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-variations' ), $license_status ) ); ?></p>
            <?php if ( '' !== $license_message ) : ?>
                <p><?php echo esc_html( $license_message ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qvar_activate_license" />
                <?php wp_nonce_field( 'qvar_activate_license', 'qvar_activate_license_nonce' ); ?>
                <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( $license_key ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                <?php submit_button( __( 'Activate License', 'quick-variations' ), 'secondary', '', false ); ?>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:8px;">
                <input type="hidden" name="action" value="qvar_deactivate_license" />
                <?php wp_nonce_field( 'qvar_deactivate_license', 'qvar_deactivate_license_nonce' ); ?>
                <?php submit_button( __( 'Deactivate License', 'quick-variations' ), 'delete', '', false ); ?>
            </form>
        </div>
        <?php
    }

    /**
     * Read plugin settings.
     *
     * @return array<string,mixed>
     */
    private function get_settings() {
        $saved = get_option( QVAR_OPTION_SETTINGS, array() );
        if ( ! is_array( $saved ) ) {
            $saved = array();
        }

        return wp_parse_args(
            $saved,
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => '',
            )
        );
    }

    /**
     * Render notice from URL args.
     *
     * @return void
     */
    private function render_notice() {
        $type = isset( $_GET['qvar_notice'] ) ? sanitize_key( wp_unslash( $_GET['qvar_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $message = isset( $_GET['qvar_message'] ) ? sanitize_text_field( wp_unslash( $_GET['qvar_message'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $report_raw = isset( $_GET['qvar_report'] ) ? wp_unslash( $_GET['qvar_report'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        if ( '' === $type || '' === $message ) {
            return;
        }

        $class = 'notice-info';
        if ( 'success' === $type ) {
            $class = 'notice-success';
        } elseif ( 'error' === $type ) {
            $class = 'notice-error';
        }

        echo '<div class="notice ' . esc_attr( $class ) . ' is-dismissible"><p>' . esc_html( $message ) . '</p>';

        $report = json_decode( (string) $report_raw, true );
        if ( is_array( $report ) && ! empty( $report ) ) {
            echo '<ul>';
            foreach ( $report as $item ) {
                $product = isset( $item['product'] ) ? absint( $item['product'] ) : 0;
                $line    = isset( $item['message'] ) ? sanitize_text_field( (string) $item['message'] ) : '';
                if ( '' === $line ) {
                    continue;
                }
                echo '<li>' . esc_html( sprintf( '#%1$d: %2$s', $product, $line ) ) . '</li>';
            }
            echo '</ul>';
        }

        echo '</div>';
    }

    /**
     * Redirect with notice query args.
     *
     * @param string $page Page slug.
     * @param string $type Notice type.
     * @param string $message Notice message.
     * @param array  $report Optional report.
     * @return void
     */
    private function redirect_with_notice( $page, $type, $message, $report = array() ) {
        $args = array(
            'page'         => sanitize_key( (string) $page ),
            'qvar_notice'  => sanitize_key( (string) $type ),
            'qvar_message' => sanitize_text_field( (string) $message ),
        );

        if ( ! empty( $report ) ) {
            $args['qvar_report'] = wp_json_encode( $report );
        }

        $url = add_query_arg( $args, admin_url( 'admin.php' ) );

        wp_safe_redirect( $url );
        exit;
    }
}
