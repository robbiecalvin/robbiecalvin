<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QVAR_Activator {
    /**
     * Activation callback.
     *
     * @return void
     */
    public static function activate() {
        // Reserved for future schema migrations.
    }
}
