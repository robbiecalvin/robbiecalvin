# Quick Variations -- Visual To‑Do

## Generator Screen

-   Change to blue buttons with white text:
    -   Add Product Bulk
    -   Remove
    -   Add Attribute
    -   Generate Combinations

## Settings Page

-   Move Activate / Deactivate License buttons below license input
-   Stack vertically
-   Make both blue with white text
