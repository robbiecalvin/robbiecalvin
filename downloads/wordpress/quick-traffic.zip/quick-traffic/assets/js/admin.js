(function () {
  function toggleCustomDateInputs() {
    var range = document.getElementById('qt-range');
    if (!range) {
      return;
    }

    var custom = range.value === 'custom';
    var inputs = document.querySelectorAll('[data-qt-custom-date="1"]');
    for (var i = 0; i < inputs.length; i++) {
      inputs[i].disabled = !custom;
      inputs[i].style.opacity = custom ? '1' : '0.55';
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    var range = document.getElementById('qt-range');
    if (range) {
      range.addEventListener('change', toggleCustomDateInputs);
      toggleCustomDateInputs();
    }
  });
})();
