# Quick Traffic -- Visual To‑Do

## Dashboard

-   Change Apply button to blue with white text

## Integrations

-   Add left-side padding to labels
