<?php

if (! defined('ABSPATH')) {
    exit;
}

class QTRF_Settings
{
    public function render()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'quick-traffic'));
        }

        $this->handle_post_actions();

        $settings = qtrf_get_settings();
        $premium_enabled = qtrf_is_premium_active();
        $editable_roles = get_editable_roles();
        $exclude_url = qtrf_get_owner_exclude_url();

        echo '<div class="wrap qt-wrap">';
        echo '<h1>' . esc_html__('Quick Traffic Settings', 'quick-traffic') . '</h1>';
        if (! $premium_enabled) {
            echo '<div class="notice notice-warning"><p>' . esc_html__('Premium unlocks IP blocking and browser exclusion controls.', 'quick-traffic') . '</p></div>';
        }

        echo '<form method="post">';
        wp_nonce_field('qtrf_save_settings', 'qtrf_settings_nonce');

        echo '<div class="qt-panel">';
        echo '<h2>' . esc_html__('Tracking Exclusions', 'quick-traffic') . '</h2>';

        echo '<h3>' . esc_html__('Excluded Roles', 'quick-traffic') . '</h3>';
        echo '<fieldset>';
        foreach ($editable_roles as $role_key => $role_data) {
            $checked = in_array($role_key, (array) $settings['excluded_roles'], true);
            echo '<label style="display:block;margin-bottom:6px;">';
            echo '<input type="checkbox" name="qtrf_settings[excluded_roles][]" value="' . esc_attr($role_key) . '" ' . checked($checked, true, false) . '> ';
            echo esc_html($role_data['name']);
            echo '</label>';
        }
        echo '</fieldset>';

        echo '<h3>' . esc_html__('Excluded IPs', 'quick-traffic') . '</h3>';
        echo '<p class="description">' . esc_html__('One IP address per line. Matching IPs are excluded at tracking time.', 'quick-traffic') . '</p>';
        echo '<textarea name="qtrf_settings[excluded_ips]" rows="8" cols="50" class="large-text code" ' . disabled(! $premium_enabled, true, false) . '>' . esc_textarea(implode("\n", (array) $settings['excluded_ips'])) . '</textarea>';

        echo '<h3>' . esc_html__('Owner Browser Exclusion', 'quick-traffic') . '</h3>';
        echo '<p><label><input type="checkbox" checked disabled> ' . esc_html__('Cookie exclusion is active when quick_traffic_exclude=1 exists', 'quick-traffic') . '</label></p>';
        echo '<p><code>' . esc_html($exclude_url) . '</code></p>';
        echo '<p><a class="button" href="' . esc_url($exclude_url) . '" target="_blank" rel="noopener noreferrer" ' . disabled(! $premium_enabled, true, false) . '>' . esc_html__('Set Cookie Now', 'quick-traffic') . '</a></p>';

        echo '</div>';

        echo '<div class="qt-panel">';
        echo '<h2>' . esc_html__('Privacy and Filtering', 'quick-traffic') . '</h2>';

        echo '<p><label><input type="checkbox" name="qtrf_settings[respect_dnt]" value="1" ' . checked((int) $settings['respect_dnt'], 1, false) . '> ' . esc_html__('Respect Do Not Track (DNT) header', 'quick-traffic') . '</label></p>';
        echo '<p><label><input type="checkbox" name="qtrf_settings[bot_filtering]" value="1" ' . checked((int) $settings['bot_filtering'], 1, false) . '> ' . esc_html__('Enable bot filtering based on user agent', 'quick-traffic') . '</label></p>';

        echo '</div>';

        echo '<div class="qt-panel">';
        echo '<h2>' . esc_html__('Data Retention', 'quick-traffic') . '</h2>';

        echo '<p><label>' . esc_html__('Event retention days', 'quick-traffic') . ' ';
        echo '<input type="number" min="1" name="qtrf_settings[events_retention_days]" value="' . esc_attr((string) $settings['events_retention_days']) . '"></label></p>';

        echo '<p><label>' . esc_html__('Daily aggregate retention days', 'quick-traffic') . ' ';
        echo '<input type="number" min="1" name="qtrf_settings[daily_retention_days]" value="' . esc_attr((string) $settings['daily_retention_days']) . '"></label></p>';

        echo '</div>';

        submit_button(__('Save Settings', 'quick-traffic'), 'primary', 'qtrf_save_settings');
        echo '</form>';

        echo '<hr>';
        echo '<div class="qt-panel qt-danger">';
        echo '<h2>' . esc_html__('Danger Zone', 'quick-traffic') . '</h2>';
        echo '<p>' . esc_html__('Reset deletes all Quick Traffic data tables content immediately.', 'quick-traffic') . '</p>';

        echo '<form method="post" onsubmit="return confirm(\'' . esc_js(__('Type YES in the confirmation field before resetting.', 'quick-traffic')) . '\');">';
        wp_nonce_field('qtrf_reset_data', 'qtrf_reset_nonce');
        echo '<p><label>' . esc_html__('Type YES to confirm reset', 'quick-traffic') . ' ';
        echo '<input type="text" name="qtrf_reset_confirm" value="" autocomplete="off"></label></p>';
        submit_button(__('Reset All Data', 'quick-traffic'), 'delete', 'qtrf_reset_data');
        echo '</form>';

        echo '</div>';
        echo '</div>';
    }

    private function handle_post_actions()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        if (isset($_POST['qtrf_save_settings'])) {
            if (! isset($_POST['qtrf_settings_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['qtrf_settings_nonce'])), 'qtrf_save_settings')) {
                wp_die(esc_html__('Invalid settings nonce.', 'quick-traffic'));
            }

            $input = isset($_POST['qtrf_settings']) ? (array) wp_unslash($_POST['qtrf_settings']) : [];
            $clean = qtrf_sanitize_settings($input);
            update_option(QTRF_OPTION_KEY, $clean, false);

            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Settings saved.', 'quick-traffic') . '</p></div>';
        }

        if (isset($_POST['qtrf_reset_data'])) {
            if (! isset($_POST['qtrf_reset_nonce']) || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['qtrf_reset_nonce'])), 'qtrf_reset_data')) {
                wp_die(esc_html__('Invalid reset nonce.', 'quick-traffic'));
            }

            $confirm = isset($_POST['qtrf_reset_confirm']) ? sanitize_text_field(wp_unslash($_POST['qtrf_reset_confirm'])) : '';
            if ($confirm !== 'YES') {
                echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Reset cancelled. Confirmation text did not match YES.', 'quick-traffic') . '</p></div>';
                return;
            }

            global $wpdb;
            $tables = [
                $wpdb->prefix . QTRF_EVENTS_TABLE,
                $wpdb->prefix . QTRF_DAILY_TABLE,
                $wpdb->prefix . QTRF_DAILY_VISITORS_TABLE,
            ];

            foreach ($tables as $table) {
                $wpdb->query("TRUNCATE TABLE {$table}");
            }

            echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('All Quick Traffic data has been reset.', 'quick-traffic') . '</p></div>';
        }
    }
}
