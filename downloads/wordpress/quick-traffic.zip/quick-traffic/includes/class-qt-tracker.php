<?php

if (! defined('ABSPATH')) {
    exit;
}

class QTRF_Tracker
{
    public static function init()
    {
        add_action('template_redirect', [__CLASS__, 'track'], 1);
    }

    public static function track()
    {
        if (self::should_skip_request()) {
            return;
        }

        if (qtrf_is_valid_owner_exclude_request()) {
            qtrf_set_owner_exclude_cookie();
            return;
        }

        $settings = qtrf_get_settings();

        if (self::is_excluded_request($settings)) {
            return;
        }

        global $wpdb;

        $events_table = $wpdb->prefix . QTRF_EVENTS_TABLE;
        $daily_table = $wpdb->prefix . QTRF_DAILY_TABLE;
        $daily_visitors_table = $wpdb->prefix . QTRF_DAILY_VISITORS_TABLE;

        $occurred_at = current_time('mysql', 1);
        $day = gmdate('Y-m-d');
        $post_id = get_queried_object_id();
        $post_id = $post_id ? absint($post_id) : null;
        $url_path = qtrf_get_request_path();
        $ref_domain = qtrf_get_referrer_domain();

        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
        $ip = qtrf_get_client_ip();
        $visitor_hash = qtrf_get_visitor_hash($ip, $ua);
        $device = qtrf_detect_device($ua);
        $status_code = self::resolve_status_code();

        $unique_inserted = $wpdb->query(
            $wpdb->prepare(
                "INSERT IGNORE INTO {$daily_visitors_table} (day, url_path, visitor_hash) VALUES (%s, %s, %s)",
                $day,
                $url_path,
                $visitor_hash
            )
        );
        $is_unique = $unique_inserted === 1 ? 1 : 0;

        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$events_table}
                (occurred_at, post_id, url_path, ref_domain, visitor_hash, device, status_code, is_unique)
                VALUES (%s, %d, %s, %s, %s, %s, %d, %d)",
                $occurred_at,
                (int) ($post_id ?? 0),
                $url_path,
                $ref_domain,
                $visitor_hash,
                $device,
                (int) $status_code,
                $is_unique
            )
        );

        $daily_sql = $wpdb->prepare(
            "INSERT INTO {$daily_table} (day, post_id, url_path, views, uniques, last_viewed)
             VALUES (%s, %d, %s, 1, %d, %s)
             ON DUPLICATE KEY UPDATE
                views = views + 1,
                uniques = uniques + VALUES(uniques),
                last_viewed = VALUES(last_viewed)",
            $day,
            (int) ($post_id ?? 0),
            $url_path,
            $is_unique,
            $occurred_at
        );

        $wpdb->query($daily_sql);

        if (class_exists('QTRF_Integrations')) {
            QTRF_Integrations::emit_traffic_recorded([
                'day' => $day,
                'post_id' => (int) ($post_id ?? 0),
                'url_path' => $url_path,
                'ref_domain' => $ref_domain,
                'device' => $device,
                'status_code' => (int) $status_code,
                'is_unique' => (int) $is_unique,
            ]);
        }
    }

    private static function should_skip_request()
    {
        if (is_admin() || wp_doing_ajax()) {
            return true;
        }

        if (defined('DOING_CRON') && DOING_CRON) {
            return true;
        }

        if (defined('REST_REQUEST') && REST_REQUEST) {
            return true;
        }

        if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) {
            return true;
        }

        $is_favicon_request = function_exists('is_favicon') ? is_favicon() : false;

        if (is_feed() || is_preview() || is_trackback() || is_robots() || $is_favicon_request) {
            return true;
        }

        $request_uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '';

        if ($request_uri !== '') {
            if (stripos($request_uri, 'wp-login.php') !== false || stripos($request_uri, 'wp-admin') !== false) {
                return true;
            }
        }

        return false;
    }

    private static function is_excluded_request($settings)
    {
        if (! empty($settings['respect_dnt']) && qtrf_request_includes_do_not_track_header()) {
            return true;
        }

        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';

        if (! empty($settings['bot_filtering']) && qtrf_is_known_bot_user_agent($ua)) {
            return true;
        }

        if (is_user_logged_in()) {
            $roles = qtrf_get_current_user_roles();
            $excluded_roles = (array) ($settings['excluded_roles'] ?? []);
            if (array_intersect($roles, $excluded_roles)) {
                return true;
            }
        }

        $ip = qtrf_get_client_ip();
        if ($ip !== '' && in_array($ip, (array) ($settings['excluded_ips'] ?? []), true)) {
            return true;
        }

        if (isset($_COOKIE['quick_traffic_exclude']) && wp_unslash($_COOKIE['quick_traffic_exclude']) === '1') {
            return true;
        }

        return false;
    }

    private static function resolve_status_code()
    {
        if (is_404()) {
            return 404;
        }

        if (is_search()) {
            return 200;
        }

        return 200;
    }
}
