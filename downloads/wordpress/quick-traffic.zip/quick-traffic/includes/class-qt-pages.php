<?php

if (! defined('ABSPATH')) {
    exit;
}

class QTRF_Pages
{
    public function render()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'quick-traffic'));
        }

        global $wpdb;

        $daily_table = $wpdb->prefix . QTRF_DAILY_TABLE;
        $sort = isset($_GET['sort']) ? sanitize_key(wp_unslash($_GET['sort'])) : 'views';
        $order = isset($_GET['order']) ? strtolower(sanitize_text_field(wp_unslash($_GET['order']))) : 'desc';
        $post_type_filter = isset($_GET['post_type']) ? sanitize_key(wp_unslash($_GET['post_type'])) : '';

        $sort_col = $sort === 'uniques' ? 'uniques' : 'views';
        $order_sql = $order === 'asc' ? 'ASC' : 'DESC';

        $where = '1=1';
        $params = [];

        if ($post_type_filter !== '') {
            $where .= ' AND p.post_type = %s';
            $params[] = $post_type_filter;
        }

        $sql = "SELECT d.url_path,
                       MAX(d.post_id) AS post_id,
                       SUM(d.views) AS views,
                       SUM(d.uniques) AS uniques,
                       MAX(d.last_viewed) AS last_viewed,
                       MAX(p.post_type) AS post_type
                FROM {$daily_table} d
                LEFT JOIN {$wpdb->posts} p ON p.ID = d.post_id
                WHERE {$where}
                GROUP BY d.url_path
                ORDER BY {$sort_col} {$order_sql}
                LIMIT 500";

        if (! empty($params)) {
            $prepared_sql = $wpdb->prepare($sql, $params);
            $rows = $wpdb->get_results($prepared_sql);
        } else {
            $rows = $wpdb->get_results($sql);
        }

        $post_types = get_post_types(['public' => true], 'objects');

        echo '<div class="wrap qt-wrap">';
        echo '<h1>' . esc_html__('Quick Traffic Pages', 'quick-traffic') . '</h1>';

        echo '<form method="get" class="qt-filter-form">';
        echo '<input type="hidden" name="page" value="quick-traffic-pages">';
        echo '<label for="qt-post-type">' . esc_html__('Post Type', 'quick-traffic') . '</label> ';
        echo '<select id="qt-post-type" name="post_type">';
        echo '<option value="">' . esc_html__('All', 'quick-traffic') . '</option>';

        foreach ($post_types as $post_type) {
            echo '<option value="' . esc_attr($post_type->name) . '" ' . selected($post_type_filter, $post_type->name, false) . '>' . esc_html($post_type->labels->singular_name) . '</option>';
        }

        echo '</select> ';

        echo '<label for="qt-sort">' . esc_html__('Sort By', 'quick-traffic') . '</label> ';
        echo '<select id="qt-sort" name="sort">';
        echo '<option value="views" ' . selected($sort_col, 'views', false) . '>' . esc_html__('Views', 'quick-traffic') . '</option>';
        echo '<option value="uniques" ' . selected($sort_col, 'uniques', false) . '>' . esc_html__('Uniques', 'quick-traffic') . '</option>';
        echo '</select> ';

        echo '<select name="order">';
        echo '<option value="desc" ' . selected($order_sql, 'DESC', false) . '>' . esc_html__('Descending', 'quick-traffic') . '</option>';
        echo '<option value="asc" ' . selected($order_sql, 'ASC', false) . '>' . esc_html__('Ascending', 'quick-traffic') . '</option>';
        echo '</select> ';

        submit_button(__('Apply', 'quick-traffic'), 'secondary', '', false);
        echo '</form>';

        if (empty($rows)) {
            echo '<p>' . esc_html__('No page data available.', 'quick-traffic') . '</p>';
            echo '</div>';
            return;
        }

        echo '<table class="widefat striped">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__('URL / Title', 'quick-traffic') . '</th>';
        echo '<th>' . esc_html__('Views', 'quick-traffic') . '</th>';
        echo '<th>' . esc_html__('Uniques', 'quick-traffic') . '</th>';
        echo '<th>' . esc_html__('Last Viewed', 'quick-traffic') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $path = (string) $row->url_path;
            $post_id = (int) $row->post_id;
            $title = $post_id > 0 ? get_the_title($post_id) : '';

            echo '<tr>';
            echo '<td>';
            echo '<strong>' . esc_html($title !== '' ? $title : $path) . '</strong><br>';
            echo '<code>' . esc_html($path) . '</code>';
            if (! empty($row->post_type)) {
                echo '<br><small>' . esc_html((string) $row->post_type) . '</small>';
            }
            echo '</td>';
            echo '<td>' . esc_html(number_format_i18n((int) $row->views)) . '</td>';
            echo '<td>' . esc_html(number_format_i18n((int) $row->uniques)) . '</td>';
            echo '<td>' . esc_html((string) get_date_from_gmt((string) $row->last_viewed, 'Y-m-d H:i:s')) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }
}
