<?php

if (! defined('ABSPATH')) {
    exit;
}

class QTRF_Dashboard
{
    public function render()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'quick-traffic'));
        }

        global $wpdb;

        $daily_table = $wpdb->prefix . QTRF_DAILY_TABLE;
        $events_table = $wpdb->prefix . QTRF_EVENTS_TABLE;

        $range = isset($_GET['range']) ? sanitize_text_field(wp_unslash($_GET['range'])) : '7d';
        $start_raw = isset($_GET['start']) ? sanitize_text_field(wp_unslash($_GET['start'])) : '';
        $end_raw = isset($_GET['end']) ? sanitize_text_field(wp_unslash($_GET['end'])) : '';
        [$start_date, $end_date, $active_range] = qtrf_parse_dashboard_date_range($range, $start_raw, $end_raw);

        $today = gmdate('Y-m-d');
        $seven_start = gmdate('Y-m-d', strtotime('-6 days'));
        $thirty_start = gmdate('Y-m-d', strtotime('-29 days'));

        $summary = [
            'today' => $this->get_views_uniques($daily_table, $today, $today),
            '7d'    => $this->get_views_uniques($daily_table, $seven_start, $today),
            '30d'   => $this->get_views_uniques($daily_table, $thirty_start, $today),
        ];

        $top_pages = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT d.url_path, MAX(d.post_id) AS post_id, SUM(d.views) AS views, SUM(d.uniques) AS uniques
                 FROM {$daily_table} d
                 WHERE d.day BETWEEN %s AND %s
                 GROUP BY d.url_path
                 ORDER BY views DESC
                 LIMIT 10",
                $seven_start,
                $today
            )
        );

        $site_host = qtrf_get_site_host();
        $top_referrers = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT e.ref_domain,
                        COUNT(*) AS views,
                        COUNT(DISTINCT e.visitor_hash) AS uniques
                 FROM {$events_table} e
                 WHERE DATE(e.occurred_at) BETWEEN %s AND %s
                   AND e.ref_domain IS NOT NULL
                   AND e.ref_domain <> ''
                   AND e.ref_domain <> %s
                 GROUP BY e.ref_domain
                 ORDER BY views DESC
                 LIMIT 10",
                $seven_start,
                $today,
                $site_host
            )
        );

        $daily_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT d.day, SUM(d.views) AS views, SUM(d.uniques) AS uniques
                 FROM {$daily_table} d
                 WHERE d.day BETWEEN %s AND %s
                 GROUP BY d.day
                 ORDER BY d.day ASC",
                $start_date,
                $end_date
            ),
            ARRAY_A
        );

        $series = $this->normalize_daily_series($daily_rows, $start_date, $end_date);

        echo '<div class="wrap qt-wrap">';
        echo '<h1>' . esc_html__('Quick Traffic Dashboard', 'quick-traffic') . '</h1>';

        $this->render_range_filter($active_range, $start_date, $end_date);
        $this->render_summary_cards($summary);
        $this->render_chart($series, $start_date, $end_date);

        echo '<div class="qt-grid-2">';
        echo '<div class="qt-panel"><h2>' . esc_html__('Top Pages (Last 7 Days)', 'quick-traffic') . '</h2>';
        $this->render_top_pages_table($top_pages);
        echo '</div>';

        echo '<div class="qt-panel"><h2>' . esc_html__('Top Referrers (Last 7 Days)', 'quick-traffic') . '</h2>';
        $this->render_top_referrers_table($top_referrers);
        echo '</div>';
        echo '</div>';

        echo '</div>';
    }

    private function get_views_uniques($daily_table, $start_date, $end_date)
    {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT COALESCE(SUM(views), 0) AS views, COALESCE(SUM(uniques), 0) AS uniques
                 FROM {$daily_table}
                 WHERE day BETWEEN %s AND %s",
                $start_date,
                $end_date
            ),
            ARRAY_A
        );

        return [
            'views'   => (int) ($row['views'] ?? 0),
            'uniques' => (int) ($row['uniques'] ?? 0),
        ];
    }

    private function render_range_filter($active_range, $start_date, $end_date)
    {
        echo '<form method="get" class="qt-range-form">';
        echo '<input type="hidden" name="page" value="quick-traffic-dashboard">';
        echo '<label for="qt-range" class="screen-reader-text">' . esc_html__('Date Range', 'quick-traffic') . '</label>';
        echo '<select id="qt-range" name="range">';

        $ranges = [
            'today'  => __('Today', 'quick-traffic'),
            '7d'     => __('Last 7 Days', 'quick-traffic'),
            '30d'    => __('Last 30 Days', 'quick-traffic'),
            'custom' => __('Custom', 'quick-traffic'),
        ];

        foreach ($ranges as $key => $label) {
            echo '<option value="' . esc_attr($key) . '" ' . selected($active_range, $key, false) . '>' . esc_html($label) . '</option>';
        }

        echo '</select>';
        echo '<input type="date" name="start" value="' . esc_attr($start_date) . '" data-qt-custom-date="1">';
        echo '<input type="date" name="end" value="' . esc_attr($end_date) . '" data-qt-custom-date="1">';
        submit_button(__('Apply', 'quick-traffic'), 'secondary', '', false);
        echo '</form>';
    }

    private function render_summary_cards($summary)
    {
        echo '<div class="qt-cards">';

        $cards = [
            'today' => __('Today', 'quick-traffic'),
            '7d'    => __('Last 7 Days', 'quick-traffic'),
            '30d'   => __('Last 30 Days', 'quick-traffic'),
        ];

        foreach ($cards as $key => $title) {
            echo '<div class="qt-card">';
            echo '<h3>' . esc_html($title) . '</h3>';
            echo '<p><strong>' . esc_html(number_format_i18n($summary[$key]['views'])) . '</strong> ' . esc_html__('Pageviews', 'quick-traffic') . '</p>';
            echo '<p><strong>' . esc_html(number_format_i18n($summary[$key]['uniques'])) . '</strong> ' . esc_html__('Uniques', 'quick-traffic') . '</p>';
            echo '</div>';
        }

        echo '</div>';
    }

    private function normalize_daily_series($rows, $start, $end)
    {
        $map = [];
        foreach ($rows as $row) {
            $map[$row['day']] = [
                'views'   => (int) $row['views'],
                'uniques' => (int) $row['uniques'],
            ];
        }

        $series = [];
        $cursor = strtotime($start);
        $end_ts = strtotime($end);

        while ($cursor <= $end_ts) {
            $day = gmdate('Y-m-d', $cursor);
            $series[] = [
                'day'     => $day,
                'views'   => (int) ($map[$day]['views'] ?? 0),
                'uniques' => (int) ($map[$day]['uniques'] ?? 0),
            ];
            $cursor = strtotime('+1 day', $cursor);
        }

        return $series;
    }

    private function render_chart($series, $start, $end)
    {
        $values = [];
        foreach ($series as $point) {
            $values[] = $point['views'];
            $values[] = $point['uniques'];
        }

        $max = max(1, (int) max($values));
        $width = 880;
        $height = 260;
        $padding = 30;
        $plot_width = $width - ($padding * 2);
        $plot_height = $height - ($padding * 2);
        $count = max(1, count($series) - 1);

        $views_points = [];
        $unique_points = [];

        foreach ($series as $idx => $point) {
            $x = $padding + (($idx / $count) * $plot_width);
            $views_y = $padding + $plot_height - (($point['views'] / $max) * $plot_height);
            $uniques_y = $padding + $plot_height - (($point['uniques'] / $max) * $plot_height);
            $views_points[] = round($x, 2) . ',' . round($views_y, 2);
            $unique_points[] = round($x, 2) . ',' . round($uniques_y, 2);
        }

        echo '<div class="qt-panel">';
        echo '<h2>' . esc_html__('Traffic Trend', 'quick-traffic') . '</h2>';
        echo '<p class="description">' . esc_html(sprintf(__('From %s to %s', 'quick-traffic'), $start, $end)) . '</p>';

        echo '<svg class="qt-chart" viewBox="0 0 ' . esc_attr((string) $width) . ' ' . esc_attr((string) $height) . '" role="img" aria-label="' . esc_attr__('Traffic chart', 'quick-traffic') . '">';
        echo '<line x1="30" y1="230" x2="850" y2="230" class="qt-axis"></line>';
        echo '<line x1="30" y1="30" x2="30" y2="230" class="qt-axis"></line>';
        echo '<polyline fill="none" class="qt-line qt-line-views" points="' . esc_attr(implode(' ', $views_points)) . '"></polyline>';
        echo '<polyline fill="none" class="qt-line qt-line-uniques" points="' . esc_attr(implode(' ', $unique_points)) . '"></polyline>';
        echo '</svg>';

        echo '<p><span class="qt-legend qt-legend-views"></span> ' . esc_html__('Views', 'quick-traffic') . ' <span class="qt-legend qt-legend-uniques"></span> ' . esc_html__('Uniques', 'quick-traffic') . '</p>';
        echo '</div>';
    }

    private function render_top_pages_table($rows)
    {
        if (empty($rows)) {
            echo '<p>' . esc_html__('No data available.', 'quick-traffic') . '</p>';
            return;
        }

        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>' . esc_html__('Page', 'quick-traffic') . '</th>';
        echo '<th>' . esc_html__('Views', 'quick-traffic') . '</th>';
        echo '<th>' . esc_html__('Uniques', 'quick-traffic') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($rows as $row) {
            $title = '';
            $path = (string) $row->url_path;
            if (! empty($row->post_id)) {
                $title = get_the_title((int) $row->post_id);
            }

            $label = $title !== '' ? $title : $path;
            echo '<tr>';
            echo '<td>' . esc_html($label) . '<br><code>' . esc_html($path) . '</code></td>';
            echo '<td>' . esc_html(number_format_i18n((int) $row->views)) . '</td>';
            echo '<td>' . esc_html(number_format_i18n((int) $row->uniques)) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    }

    private function render_top_referrers_table($rows)
    {
        if (empty($rows)) {
            echo '<p>' . esc_html__('No external referrers in range.', 'quick-traffic') . '</p>';
            return;
        }

        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>' . esc_html__('Domain', 'quick-traffic') . '</th>';
        echo '<th>' . esc_html__('Views', 'quick-traffic') . '</th>';
        echo '<th>' . esc_html__('Uniques', 'quick-traffic') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($rows as $row) {
            echo '<tr>';
            echo '<td>' . esc_html((string) $row->ref_domain) . '</td>';
            echo '<td>' . esc_html(number_format_i18n((int) $row->views)) . '</td>';
            echo '<td>' . esc_html(number_format_i18n((int) $row->uniques)) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
    }
}
