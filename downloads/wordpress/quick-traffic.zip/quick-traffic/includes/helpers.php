<?php

if (! defined('ABSPATH')) {
    exit;
}

function qtrf_get_default_settings()
{
    return [
        'excluded_roles'        => ['administrator'],
        'excluded_ips'          => [],
        'respect_dnt'           => 1,
        'bot_filtering'         => 1,
        'events_retention_days' => 30,
        'daily_retention_days'  => 365,
    ];
}

function qtrf_get_settings()
{
    $defaults = qtrf_get_default_settings();
    $stored = get_option(QTRF_OPTION_KEY, []);

    if (! is_array($stored)) {
        $stored = [];
    }

    $settings = wp_parse_args($stored, $defaults);
    $settings['excluded_roles'] = array_values(array_unique(array_filter(array_map('sanitize_key', (array) $settings['excluded_roles']))));
    $settings['excluded_ips'] = qtrf_parse_ip_lines((array) $settings['excluded_ips']);
    $settings['respect_dnt'] = empty($settings['respect_dnt']) ? 0 : 1;
    $settings['bot_filtering'] = empty($settings['bot_filtering']) ? 0 : 1;
    $settings['events_retention_days'] = max(1, absint($settings['events_retention_days']));
    $settings['daily_retention_days'] = max(1, absint($settings['daily_retention_days']));

    return $settings;
}

function qtrf_sanitize_settings($input)
{
    $defaults = qtrf_get_default_settings();
    $premium_enabled = qtrf_is_premium_active();

    $clean = [
        'excluded_roles'        => [],
        'excluded_ips'          => [],
        'respect_dnt'           => 0,
        'bot_filtering'         => 0,
        'events_retention_days' => $defaults['events_retention_days'],
        'daily_retention_days'  => $defaults['daily_retention_days'],
    ];

    if (isset($input['excluded_roles']) && is_array($input['excluded_roles'])) {
        $editable_roles = array_keys(get_editable_roles());
        $roles = array_map('sanitize_key', $input['excluded_roles']);
        $clean['excluded_roles'] = array_values(array_intersect($roles, $editable_roles));
    }

    if ($premium_enabled && isset($input['excluded_ips'])) {
        $lines = preg_split('/\r\n|\r|\n/', (string) $input['excluded_ips']);
        $clean['excluded_ips'] = qtrf_parse_ip_lines($lines ?: []);
    } elseif (! $premium_enabled) {
        $clean['excluded_ips'] = [];
    }

    $clean['respect_dnt'] = empty($input['respect_dnt']) ? 0 : 1;
    $clean['bot_filtering'] = empty($input['bot_filtering']) ? 0 : 1;
    $clean['events_retention_days'] = max(1, absint($input['events_retention_days'] ?? $defaults['events_retention_days']));
    $clean['daily_retention_days'] = max(1, absint($input['daily_retention_days'] ?? $defaults['daily_retention_days']));

    if (empty($clean['excluded_roles'])) {
        $clean['excluded_roles'] = ['administrator'];
    }

    return $clean;
}

function qtrf_parse_ip_lines($lines)
{
    $ips = [];

    foreach ((array) $lines as $line) {
        $candidate = trim((string) $line);
        if ($candidate === '') {
            continue;
        }

        if (filter_var($candidate, FILTER_VALIDATE_IP)) {
            $ips[] = $candidate;
        }
    }

    return array_values(array_unique($ips));
}

function qtrf_get_client_ip()
{
    $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];

    foreach ($keys as $key) {
        if (empty($_SERVER[$key])) {
            continue;
        }

        $raw = wp_unslash((string) $_SERVER[$key]);

        if ($key === 'HTTP_X_FORWARDED_FOR') {
            $parts = explode(',', $raw);
            $raw = trim((string) ($parts[0] ?? ''));
        }

        if (filter_var($raw, FILTER_VALIDATE_IP)) {
            return $raw;
        }
    }

    return '';
}

function qtrf_request_includes_do_not_track_header()
{
    $dnt = isset($_SERVER['HTTP_DNT']) ? trim((string) wp_unslash($_SERVER['HTTP_DNT'])) : '';
    return $dnt === '1';
}

function qtrf_is_known_bot_user_agent($ua)
{
    if ($ua === '') {
        return false;
    }

    $pattern = '/bot|crawl|spider|slurp|mediapartners|pingdom|headless|preview|crawler|facebookexternalhit|whatsapp|telegrambot|discordbot|python-requests|curl|wget|uptime/i';
    return (bool) preg_match($pattern, $ua);
}

function qtrf_detect_device($ua)
{
    $ua = strtolower($ua);

    if ($ua === '') {
        return 'unknown';
    }

    if (preg_match('/ipad|tablet|kindle|silk|playbook/', $ua)) {
        return 'tablet';
    }

    if (preg_match('/mobile|iphone|ipod|android|blackberry|iemobile|opera mini/', $ua)) {
        return 'mobile';
    }

    return 'desktop';
}

function qtrf_get_request_path()
{
    $uri = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '/';
    $path = wp_parse_url($uri, PHP_URL_PATH);
    $path = is_string($path) ? $path : '/';

    if ($path === '') {
        $path = '/';
    }

    return '/' . ltrim($path, '/');
}

function qtrf_get_referrer_domain()
{
    if (empty($_SERVER['HTTP_REFERER'])) {
        return null;
    }

    $ref = (string) wp_unslash($_SERVER['HTTP_REFERER']);
    $domain = wp_parse_url($ref, PHP_URL_HOST);

    if (! is_string($domain) || $domain === '') {
        return null;
    }

    return strtolower($domain);
}

function qtrf_get_site_host()
{
    $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
    return is_string($host) ? strtolower($host) : '';
}

function qtrf_get_visitor_hash($ip, $ua)
{
    $ua = strtolower(trim($ua));
    $visitor_id = isset($_COOKIE['qtrf_vid']) ? sanitize_text_field(wp_unslash($_COOKIE['qtrf_vid'])) : '';

    if ($visitor_id === '') {
        try {
            $visitor_id = wp_generate_uuid4();
        } catch (Exception $e) {
            $visitor_id = wp_hash(microtime(true) . wp_rand());
        }

        setcookie('qtrf_vid', $visitor_id, [
            'expires'  => time() + YEAR_IN_SECONDS,
            'path'     => COOKIEPATH ?: '/',
            'domain'   => COOKIE_DOMAIN ?: '',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);

        $_COOKIE['qtrf_vid'] = $visitor_id;
    }

    $base = $visitor_id . '|' . $ip . '|' . $ua . '|' . AUTH_SALT . '|' . home_url('/');
    return hash('sha256', $base);
}

function qtrf_get_owner_exclude_signature()
{
    $payload = 'qtrf_exclude=1|' . home_url('/');
    return hash_hmac('sha256', $payload, AUTH_SALT . '|' . home_url('/'));
}

function qtrf_get_owner_exclude_url()
{
    return add_query_arg([
        'qtrf_exclude' => '1',
        'qtrf_sig'     => qtrf_get_owner_exclude_signature(),
    ], home_url('/'));
}

function qtrf_is_valid_owner_exclude_request()
{
    if (! isset($_GET['qtrf_exclude'], $_GET['qtrf_sig'])) {
        return false;
    }

    $exclude = sanitize_text_field(wp_unslash($_GET['qtrf_exclude']));
    $sig = sanitize_text_field(wp_unslash($_GET['qtrf_sig']));

    if ($exclude !== '1') {
        return false;
    }

    $expected = qtrf_get_owner_exclude_signature();
    return hash_equals($expected, $sig);
}

function qtrf_set_owner_exclude_cookie()
{
    setcookie('quick_traffic_exclude', '1', [
        'expires'  => time() + YEAR_IN_SECONDS,
        'path'     => COOKIEPATH ?: '/',
        'domain'   => COOKIE_DOMAIN ?: '',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    $_COOKIE['quick_traffic_exclude'] = '1';
}

function qtrf_get_current_user_roles()
{
    $user = wp_get_current_user();
    if (! $user || empty($user->roles)) {
        return [];
    }

    return array_map('sanitize_key', (array) $user->roles);
}

function qtrf_parse_dashboard_date_range($range, $start_raw, $end_raw)
{
    $today = gmdate('Y-m-d');

    if ($range === 'custom') {
        $start = preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_raw) ? $start_raw : $today;
        $end = preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_raw) ? $end_raw : $today;

        if ($start > $end) {
            $tmp = $start;
            $start = $end;
            $end = $tmp;
        }

        return [$start, $end, 'custom'];
    }

    if ($range === 'today') {
        return [$today, $today, 'today'];
    }

    if ($range === '30d') {
        return [gmdate('Y-m-d', strtotime('-29 days')), $today, '30d'];
    }

    return [gmdate('Y-m-d', strtotime('-6 days')), $today, '7d'];
}
