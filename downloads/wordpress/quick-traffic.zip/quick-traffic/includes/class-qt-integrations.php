<?php

if (! defined('ABSPATH')) {
    exit;
}

class QTRF_Integrations
{
    private const OPTION_KEY = 'qtrf_integrations';

    public static function init()
    {
        add_action('admin_post_qtrf_save_integrations', [__CLASS__, 'handle_save']);

        if (self::is_enabled('quick_audit')) {
            add_action('quickwoo_local/audit_completed', [__CLASS__, 'handle_audit_completed'], 10, 2);
        }
    }

    public static function render_page()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'quick-traffic'));
        }

        $settings = self::get_settings();
        $premium_enabled = qtrf_is_premium_active();
        echo '<div class="wrap qt-wrap">';
        echo '<h1>' . esc_html__('Quick Traffic Integrations', 'quick-traffic') . '</h1>';
        if (! $premium_enabled) {
            echo '<div class="notice notice-warning"><p>' . esc_html__('Integrations are a premium feature.', 'quick-traffic') . '</p></div>';
        }
        echo '<p>' . esc_html__('Optional integrations only. Quick Traffic remains fully standalone.', 'quick-traffic') . '</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="qtrf_save_integrations" />';
        wp_nonce_field('qtrf_save_integrations', 'qtrf_integrations_nonce');

        echo '<table class="form-table" role="presentation"><tbody>';
        self::checkbox_row('quick_seo', __('Quick SEO', 'quick-traffic'), __('Share traffic signals with Quick SEO when active.', 'quick-traffic'), $settings, $premium_enabled);
        self::checkbox_row('quick_audit', __('Quick Audit', 'quick-traffic'), __('Share traffic signals with Quick Audit when active.', 'quick-traffic'), $settings, $premium_enabled);
        self::checkbox_row('quick_code', __('Quick Code', 'quick-traffic'), __('Share traffic signals with Quick Code when active.', 'quick-traffic'), $settings, $premium_enabled);
        self::checkbox_row('quick_site', __('Quick Site', 'quick-traffic'), __('Share traffic signals with Quick Site when active.', 'quick-traffic'), $settings, $premium_enabled);
        echo '</tbody></table>';

        submit_button(__('Save Integrations', 'quick-traffic'));
        echo '</form>';
        echo '</div>';
    }

    public static function handle_save()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'quick-traffic'));
        }

        check_admin_referer('qtrf_save_integrations', 'qtrf_integrations_nonce');

        $premium_enabled = qtrf_is_premium_active();
        $settings = [
            'quick_seo' => $premium_enabled && !empty($_POST['quick_seo']) ? 1 : 0,
            'quick_audit' => $premium_enabled && !empty($_POST['quick_audit']) ? 1 : 0,
            'quick_code' => $premium_enabled && !empty($_POST['quick_code']) ? 1 : 0,
            'quick_site' => $premium_enabled && !empty($_POST['quick_site']) ? 1 : 0,
        ];

        update_option(self::OPTION_KEY, $settings, false);
        wp_safe_redirect(admin_url('admin.php?page=quick-traffic-integrations'));
        exit;
    }

    public static function emit_traffic_recorded($payload)
    {
        if (!is_array($payload)) {
            $payload = [];
        }

        do_action(
            'quickwoo_local/traffic_recorded',
            $payload,
            [
                'source' => 'quick-traffic',
                'occurred_at' => current_time('mysql'),
            ]
        );
    }

    public static function handle_audit_completed($payload, $context)
    {
        if (! self::is_enabled('quick_audit')) {
            return;
        }

        update_option('qtrf_last_audit_event', [
            'payload' => is_array($payload) ? $payload : [],
            'context' => is_array($context) ? $context : [],
            'stored_at' => current_time('mysql'),
        ], false);
    }

    private static function checkbox_row($key, $label, $description, $settings, $premium_enabled = true)
    {
        echo '<tr>';
        echo '<th scope="row">' . esc_html($label) . '</th>';
        echo '<td><label><input type="checkbox" name="' . esc_attr($key) . '" value="1" ' . checked(1, (int) $settings[$key], false) . ' ' . disabled(! $premium_enabled, true, false) . '> ' . esc_html($description) . '</label></td>';
        echo '</tr>';
    }

    private static function get_settings()
    {
        $defaults = [
            'quick_seo' => 0,
            'quick_audit' => 0,
            'quick_code' => 0,
            'quick_site' => 0,
        ];

        $saved = get_option(self::OPTION_KEY, []);
        if (!is_array($saved)) {
            $saved = [];
        }

        $settings = wp_parse_args($saved, $defaults);

        return [
            'quick_seo' => !empty($settings['quick_seo']) ? 1 : 0,
            'quick_audit' => !empty($settings['quick_audit']) ? 1 : 0,
            'quick_code' => !empty($settings['quick_code']) ? 1 : 0,
            'quick_site' => !empty($settings['quick_site']) ? 1 : 0,
        ];
    }

    private static function is_enabled($key)
    {
        $settings = self::get_settings();
        return !empty($settings[$key]);
    }
}
