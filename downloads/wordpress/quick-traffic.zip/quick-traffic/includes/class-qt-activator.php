<?php

if (! defined('ABSPATH')) {
    exit;
}

class QTRF_Activator
{
    public static function activate()
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $events_table = $wpdb->prefix . QTRF_EVENTS_TABLE;
        $daily_table = $wpdb->prefix . QTRF_DAILY_TABLE;
        $daily_visitors_table = $wpdb->prefix . QTRF_DAILY_VISITORS_TABLE;

        $sql_events = "CREATE TABLE {$events_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            occurred_at DATETIME NOT NULL,
            post_id BIGINT UNSIGNED NULL,
            url_path VARCHAR(255) NOT NULL,
            ref_domain VARCHAR(191) NULL,
            visitor_hash CHAR(64) NOT NULL,
            device VARCHAR(20) NOT NULL,
            status_code SMALLINT NULL,
            is_unique TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            KEY idx_occurred_at (occurred_at),
            KEY idx_post_id (post_id),
            KEY idx_url_path (url_path),
            KEY idx_ref_domain (ref_domain),
            KEY idx_visitor_hash (visitor_hash)
        ) {$charset_collate};";

        $sql_daily = "CREATE TABLE {$daily_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            day DATE NOT NULL,
            post_id BIGINT UNSIGNED NULL,
            url_path VARCHAR(255) NOT NULL,
            views INT UNSIGNED NOT NULL DEFAULT 0,
            uniques INT UNSIGNED NOT NULL DEFAULT 0,
            last_viewed DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_day_url_post (day, url_path, post_id),
            KEY idx_day (day),
            KEY idx_post_id (post_id),
            KEY idx_url_path (url_path)
        ) {$charset_collate};";

        $sql_daily_visitors = "CREATE TABLE {$daily_visitors_table} (
            day DATE NOT NULL,
            url_path VARCHAR(255) NOT NULL,
            visitor_hash CHAR(64) NOT NULL,
            PRIMARY KEY (day, url_path, visitor_hash),
            KEY idx_day (day),
            KEY idx_url_path (url_path),
            KEY idx_visitor_hash (visitor_hash)
        ) {$charset_collate};";

        dbDelta($sql_events);
        dbDelta($sql_daily);
        dbDelta($sql_daily_visitors);

        if (! get_option(QTRF_OPTION_KEY)) {
            add_option(QTRF_OPTION_KEY, qtrf_get_default_settings());
        }

        if (! wp_next_scheduled('qtrf_daily_prune')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'qtrf_daily_prune');
        }
    }

    public static function deactivate()
    {
        $timestamp = wp_next_scheduled('qtrf_daily_prune');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'qtrf_daily_prune');
        }
    }
}
