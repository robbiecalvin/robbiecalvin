<?php

if (! defined('ABSPATH')) {
    exit;
}

class QTRF_Referrers
{
    public function render()
    {
        if (! current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'quick-traffic'));
        }

        global $wpdb;

        $events_table = $wpdb->prefix . QTRF_EVENTS_TABLE;
        $site_host = qtrf_get_site_host();

        $range = isset($_GET['range']) ? sanitize_key(wp_unslash($_GET['range'])) : '30d';
        $today = gmdate('Y-m-d');

        if ($range === '7d') {
            $start = gmdate('Y-m-d', strtotime('-6 days'));
        } else {
            $start = gmdate('Y-m-d', strtotime('-29 days'));
            $range = '30d';
        }

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT e.ref_domain,
                        COUNT(*) AS views,
                        COUNT(DISTINCT e.visitor_hash) AS uniques
                 FROM {$events_table} e
                 WHERE DATE(e.occurred_at) BETWEEN %s AND %s
                   AND e.ref_domain IS NOT NULL
                   AND e.ref_domain <> ''
                   AND e.ref_domain <> %s
                 GROUP BY e.ref_domain
                 ORDER BY views DESC
                 LIMIT 500",
                $start,
                $today,
                $site_host
            )
        );

        echo '<div class="wrap qt-wrap">';
        echo '<h1>' . esc_html__('Quick Traffic Referrers', 'quick-traffic') . '</h1>';

        echo '<form method="get" class="qt-filter-form">';
        echo '<input type="hidden" name="page" value="quick-traffic-referrers">';
        echo '<label for="qt-range">' . esc_html__('Range', 'quick-traffic') . '</label> ';
        echo '<select id="qt-range" name="range">';
        echo '<option value="7d" ' . selected($range, '7d', false) . '>' . esc_html__('Last 7 Days', 'quick-traffic') . '</option>';
        echo '<option value="30d" ' . selected($range, '30d', false) . '>' . esc_html__('Last 30 Days', 'quick-traffic') . '</option>';
        echo '</select> ';
        submit_button(__('Apply', 'quick-traffic'), 'secondary', '', false);
        echo '</form>';

        if (empty($rows)) {
            echo '<p>' . esc_html__('No referrer data available.', 'quick-traffic') . '</p>';
            echo '</div>';
            return;
        }

        echo '<table class="widefat striped">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__('Referrer Domain', 'quick-traffic') . '</th>';
        echo '<th>' . esc_html__('Views', 'quick-traffic') . '</th>';
        echo '<th>' . esc_html__('Uniques', 'quick-traffic') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($rows as $row) {
            echo '<tr>';
            echo '<td>' . esc_html((string) $row->ref_domain) . '</td>';
            echo '<td>' . esc_html(number_format_i18n((int) $row->views)) . '</td>';
            echo '<td>' . esc_html(number_format_i18n((int) $row->uniques)) . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }
}
