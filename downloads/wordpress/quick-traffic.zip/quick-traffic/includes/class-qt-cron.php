<?php

if (! defined('ABSPATH')) {
    exit;
}

class QTRF_Cron
{
    public static function init()
    {
        add_action('qtrf_daily_prune', [__CLASS__, 'prune']);

        if (! wp_next_scheduled('qtrf_daily_prune')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'qtrf_daily_prune');
        }
    }

    public static function prune()
    {
        global $wpdb;

        $settings = qtrf_get_settings();
        $events_days = max(1, absint($settings['events_retention_days']));
        $daily_days = max(1, absint($settings['daily_retention_days']));

        $events_table = $wpdb->prefix . QTRF_EVENTS_TABLE;
        $daily_table = $wpdb->prefix . QTRF_DAILY_TABLE;
        $daily_visitors_table = $wpdb->prefix . QTRF_DAILY_VISITORS_TABLE;

        $events_cutoff = gmdate('Y-m-d H:i:s', strtotime('-' . $events_days . ' days'));
        $daily_cutoff_day = gmdate('Y-m-d', strtotime('-' . $daily_days . ' days'));
        $visitors_cutoff_day = gmdate('Y-m-d', strtotime('-' . max($events_days, $daily_days) . ' days'));

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$events_table} WHERE occurred_at < %s",
                $events_cutoff
            )
        );

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$daily_table} WHERE day < %s",
                $daily_cutoff_day
            )
        );

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$daily_visitors_table} WHERE day < %s",
                $visitors_cutoff_day
            )
        );
    }
}
