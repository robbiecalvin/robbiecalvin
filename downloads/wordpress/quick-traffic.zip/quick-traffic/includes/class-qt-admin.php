<?php

if (! defined('ABSPATH')) {
    exit;
}

class QTRF_Admin
{
    private static $dashboard;
    private static $pages;
    private static $referrers;
    private static $settings;

    public static function init()
    {
        self::$dashboard = new QTRF_Dashboard();
        self::$pages = new QTRF_Pages();
        self::$referrers = new QTRF_Referrers();
        self::$settings = new QTRF_Settings();

        add_action('admin_menu', [__CLASS__, 'register_menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
    }

    public static function register_menu()
    {
        add_menu_page(
            __('Quick Traffic', 'quick-traffic'),
            __('Quick Traffic', 'quick-traffic'),
            'manage_options',
            'quick-traffic-dashboard',
            [self::$dashboard, 'render'],
            'dashicons-chart-area',
            58
        );

        add_submenu_page(
            'quick-traffic-dashboard',
            __('Dashboard', 'quick-traffic'),
            __('Dashboard', 'quick-traffic'),
            'manage_options',
            'quick-traffic-dashboard',
            [self::$dashboard, 'render']
        );

        add_submenu_page(
            'quick-traffic-dashboard',
            __('Pages', 'quick-traffic'),
            __('Pages', 'quick-traffic'),
            'manage_options',
            'quick-traffic-pages',
            [self::$pages, 'render']
        );

        add_submenu_page(
            'quick-traffic-dashboard',
            __('Referrers', 'quick-traffic'),
            __('Referrers', 'quick-traffic'),
            'manage_options',
            'quick-traffic-referrers',
            [self::$referrers, 'render']
        );

        add_submenu_page(
            'quick-traffic-dashboard',
            __('Settings', 'quick-traffic'),
            __('Settings', 'quick-traffic'),
            'manage_options',
            'quick-traffic-settings',
            [self::$settings, 'render']
        );

        add_submenu_page(
            'quick-traffic-dashboard',
            __('Integrations', 'quick-traffic'),
            __('Integrations', 'quick-traffic'),
            'manage_options',
            'quick-traffic-integrations',
            ['QTRF_Integrations', 'render_page']
        );
    }

    public static function enqueue_assets($hook)
    {
        $allowed_hooks = [
            'toplevel_page_quick-traffic-dashboard',
            'quick-traffic_page_quick-traffic-pages',
            'quick-traffic_page_quick-traffic-referrers',
            'quick-traffic_page_quick-traffic-settings',
            'quick-traffic_page_quick-traffic-integrations',
        ];

        if (! in_array($hook, $allowed_hooks, true)) {
            return;
        }

        wp_enqueue_style(
            'qt-admin',
            QTRF_PLUGIN_URL . 'assets/css/admin.css',
            [],
            QTRF_VERSION
        );

        wp_enqueue_script(
            'qt-admin',
            QTRF_PLUGIN_URL . 'assets/js/admin.js',
            [],
            QTRF_VERSION,
            true
        );

        wp_localize_script('qt-admin', 'QTAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('qtrf_admin_nonce'),
        ]);
    }
}
