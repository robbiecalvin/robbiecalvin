# quick traffic

Full edition of quick traffic

## Version
- 1.0.0

## Author
- QuickWoo by Robbie Calvin

## Full Edition Scope
- This is the full plugin build.
- Premium features and integration pathways are included.
- Intended for production deployments.

## Requirements
- WordPress 6.0+ (or plugin-declared minimum)
- PHP 7.4+ (or plugin-declared minimum)
- WooCommerce when required by this plugin

## Installation
1. In WordPress Admin, go to Plugins -> Add New -> Upload Plugin.
2. Upload this plugin folder as a zip.
3. Activate the plugin.
4. Open the plugin menu in wp-admin and configure settings.

## Support
- Website: https://quickwoo.pro

## License
- GPLv2 or later (per plugin header/license file if included).
