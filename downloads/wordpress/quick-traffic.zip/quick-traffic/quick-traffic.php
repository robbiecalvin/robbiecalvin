<?php
/**
 * Plugin Name: Quick Traffic
 * Description: Lightweight, self-hosted traffic monitoring with privacy-conscious exclusions and admin analytics.
 * Version: 1.0.0
 * Author: QuickWoo by Robbie Calvin
 * Author URI: https://quickwoo.pro
 * Text Domain: quick-traffic
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/quick-core/bootstrap.php';
}

define('QTRF_VERSION', '1.0.0');
define('QTRF_PLUGIN_FILE', __FILE__);
define('QTRF_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('QTRF_PLUGIN_URL', plugin_dir_url(__FILE__));
define('QTRF_OPTION_KEY', 'qtrf_settings');

define('QTRF_EVENTS_TABLE', 'quick_traffic_events');
define('QTRF_DAILY_TABLE', 'quick_traffic_daily');
define('QTRF_DAILY_VISITORS_TABLE', 'quick_traffic_daily_visitors');

function qtrf_is_premium_active() {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

    if ( function_exists( 'qwoo_has_active_license' ) ) {
        return (bool) qwoo_has_active_license( array( 'quick-traffic' ) );
    }

    return false;
}

require_once QTRF_PLUGIN_DIR . 'includes/helpers.php';
require_once QTRF_PLUGIN_DIR . 'includes/class-qt-activator.php';
require_once QTRF_PLUGIN_DIR . 'includes/class-qt-tracker.php';
require_once QTRF_PLUGIN_DIR . 'includes/class-qt-admin.php';
require_once QTRF_PLUGIN_DIR . 'includes/class-qt-dashboard.php';
require_once QTRF_PLUGIN_DIR . 'includes/class-qt-pages.php';
require_once QTRF_PLUGIN_DIR . 'includes/class-qt-referrers.php';
require_once QTRF_PLUGIN_DIR . 'includes/class-qt-settings.php';
require_once QTRF_PLUGIN_DIR . 'includes/class-qt-integrations.php';
require_once QTRF_PLUGIN_DIR . 'includes/class-qt-cron.php';

register_activation_hook(QTRF_PLUGIN_FILE, ['QTRF_Activator', 'activate']);
register_deactivation_hook(QTRF_PLUGIN_FILE, ['QTRF_Activator', 'deactivate']);

add_action('plugins_loaded', static function () {
    QTRF_Cron::init();
    QTRF_Tracker::init();
    QTRF_Integrations::init();

    if (is_admin()) {
        QTRF_Admin::init();
    }
});

if ( ! function_exists( 'qwoo_quick_traffic_license_bootstrap' ) ) {
    function qwoo_quick_traffic_license_bootstrap() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu', 'qwoo_quick_traffic_license_menu' );
        add_action( 'admin_post_qwoo_quick_traffic_activate_license', 'qwoo_quick_traffic_license_handle_activate' );
        add_action( 'admin_post_qwoo_quick_traffic_deactivate_license', 'qwoo_quick_traffic_license_handle_deactivate' );
    }
    add_action( 'plugins_loaded', 'qwoo_quick_traffic_license_bootstrap', 30 );

    function qwoo_quick_traffic_license_option_key() {
        return 'qwoo_quick_traffic_license';
    }

    function qwoo_quick_traffic_license_product_scope() {
        return array( 'quick-traffic' );
    }

    function qwoo_quick_traffic_license_get_data() {
        $defaults = array(
            'license_key' => '',
            'license_status' => 'inactive',
            'license_message' => '',
        );

        $saved = get_option( qwoo_quick_traffic_license_option_key(), array() );
        $saved = is_array( $saved ) ? $saved : array();

        return wp_parse_args( $saved, $defaults );
    }

    function qwoo_quick_traffic_license_save_data( $data ) {
        $data = is_array( $data ) ? $data : array();

        $clean = array(
            'license_key' => sanitize_text_field( (string) ( $data['license_key'] ?? '' ) ),
            'license_status' => sanitize_key( (string) ( $data['license_status'] ?? 'inactive' ) ),
            'license_message' => sanitize_text_field( (string) ( $data['license_message'] ?? '' ) ),
        );

        update_option( qwoo_quick_traffic_license_option_key(), $clean, false );
        return $clean;
    }

    function qwoo_quick_traffic_license_menu() {
        add_options_page(
            'Ltraffic License',
            'Ltraffic License',
            'manage_options',
            'qwoo-quick-traffic-license',
            'qwoo_quick_traffic_license_render_page'
        );
    }

    function qwoo_quick_traffic_license_render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = qwoo_quick_traffic_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );

        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $status = qlic_get_license_status_for_key_products( $license_key, qwoo_quick_traffic_license_product_scope() );
            if ( is_array( $status ) ) {
                $data['license_status'] = sanitize_key( (string) ( $status['status'] ?? $data['license_status'] ) );
                $data['license_message'] = sanitize_text_field( (string) ( $status['message'] ?? $data['license_message'] ) );
                if ( ! empty( $status['valid'] ) && ! empty( $status['domain_active'] ) ) {
                    $data['license_status'] = 'active';
                }
                qwoo_quick_traffic_license_save_data( $data );
            }
        }

        $notice = isset( $_GET['qwoo_license_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qwoo_license_notice'] ) ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Ltraffic License', 'quick-traffic' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-traffic' ), (string) ( $data['license_status'] ?? 'inactive' ) ) ); ?></p>
            <?php if ( ! empty( $data['license_message'] ) ) : ?>
                <p><?php echo esc_html( (string) $data['license_message'] ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_traffic_activate_license" />
                <?php wp_nonce_field( 'qwoo_quick_traffic_activate_license', 'qwoo_quick_traffic_activate_license_nonce' ); ?>
                <p>
                    <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( (string) ( $data['license_key'] ?? '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button type="submit" class="button button-primary"><?php echo esc_html__( 'Activate License', 'quick-traffic' ); ?></button>
                </p>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_traffic_deactivate_license" />
                <?php wp_nonce_field( 'qwoo_quick_traffic_deactivate_license', 'qwoo_quick_traffic_deactivate_license_nonce' ); ?>
                <p><button type="submit" class="button"><?php echo esc_html__( 'Deactivate License', 'quick-traffic' ); ?></button></p>
            </form>
        </div>
        <?php
    }

    function qwoo_quick_traffic_license_redirect( $message ) {
        $url = add_query_arg(
            array(
                'page' => 'qwoo-quick-traffic-license',
                'qwoo_license_notice' => rawurlencode( (string) $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    function qwoo_quick_traffic_license_handle_activate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-traffic' ) );
        }

        check_admin_referer( 'qwoo_quick_traffic_activate_license', 'qwoo_quick_traffic_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        if ( '' === $license_key ) {
            qwoo_quick_traffic_license_save_data(
                array(
                    'license_key' => '',
                    'license_status' => 'inactive',
                    'license_message' => 'License key is required.',
                )
            );
            qwoo_quick_traffic_license_redirect( 'License key is required.' );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            qwoo_quick_traffic_license_save_data(
                array(
                    'license_key' => $license_key,
                    'license_status' => 'invalid',
                    'license_message' => 'Quick License plugin is required for activation.',
                )
            );
            qwoo_quick_traffic_license_redirect( 'Quick License plugin is required for activation.' );
        }

        $result = qlic_activate_license_key_for_products( $license_key, qwoo_quick_traffic_license_product_scope() );
        $data = array(
            'license_key' => $license_key,
            'license_status' => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'license_message' => sanitize_text_field( (string) ( $result['message'] ?? 'License validation failed.' ) ),
        );
        if ( ! empty( $result['valid'] ) ) {
            $data['license_status'] = 'active';
        }

        qwoo_quick_traffic_license_save_data( $data );
        qwoo_quick_traffic_license_redirect( (string) $data['license_message'] );
    }

    function qwoo_quick_traffic_license_handle_deactivate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-traffic' ) );
        }

        check_admin_referer( 'qwoo_quick_traffic_deactivate_license', 'qwoo_quick_traffic_deactivate_license_nonce' );

        $data = qwoo_quick_traffic_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );
        $message = 'License deactivated.';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products( $license_key, qwoo_quick_traffic_license_product_scope() );
            if ( is_array( $result ) && ! empty( $result['message'] ) ) {
                $message = sanitize_text_field( (string) $result['message'] );
            }
        }

        qwoo_quick_traffic_license_save_data(
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => $message,
            )
        );

        qwoo_quick_traffic_license_redirect( $message );
    }
}
