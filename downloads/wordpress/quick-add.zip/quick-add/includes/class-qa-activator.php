<?php
/**
 * Activation logic.
 *
 * @package Quick_Add
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QADD_Activator {
	public static function activate() {
		global $wpdb;

		$table_name      = qadd_get_table_name();
		$charset_collate = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "CREATE TABLE {$table_name} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(255) NOT NULL,
			template_json LONGTEXT NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id)
		) {$charset_collate};";

		dbDelta( $sql );

		if ( false === get_option( 'qadd_settings', false ) ) {
			add_option(
				'qadd_settings',
				array(
					'default_product_status' => 'draft',
					'default_category'       => '',
					'auto_generate_sku'      => 0,
					'auto_sku_prefix'        => 'QA-',
					'auto_assign_image'      => 0,
				)
			);
		}
	}
}
