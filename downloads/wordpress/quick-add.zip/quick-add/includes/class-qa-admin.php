<?php
/**
 * Admin menu and page routing.
 *
 * @package Quick_Add
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QADD_Admin {
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	public static function register_menu() {
		$capability = 'manage_woocommerce';

		add_menu_page(
			esc_html__( 'Quick Add', 'quick-add' ),
			esc_html__( 'Quick Add', 'quick-add' ),
			$capability,
			'qa-bulk-add',
			array( 'QADD_Bulk', 'render_page' ),
			'dashicons-database-add',
			56
		);

		add_submenu_page(
			'qa-bulk-add',
			esc_html__( 'Bulk Add', 'quick-add' ),
			esc_html__( 'Bulk Add', 'quick-add' ),
			$capability,
			'qa-bulk-add',
			array( 'QADD_Bulk', 'render_page' )
		);

		add_submenu_page(
			'qa-bulk-add',
			esc_html__( 'Templates', 'quick-add' ),
			esc_html__( 'Templates', 'quick-add' ),
			$capability,
			'qa-templates',
			array( 'QADD_Templates', 'render_page' )
		);

		add_submenu_page(
			'qa-bulk-add',
			esc_html__( 'Settings', 'quick-add' ),
			esc_html__( 'Settings', 'quick-add' ),
			$capability,
			'qa-settings',
			array( 'QADD_Settings', 'render_page' )
		);
	}

	public static function enqueue_assets( $hook ) {
		$allowed_hooks = array(
			'toplevel_page_qa-bulk-add',
			'qa-bulk-add_page_qa-templates',
			'qa-bulk-add_page_qa-settings',
		);

		if ( ! in_array( $hook, $allowed_hooks, true ) ) {
			return;
		}

		wp_enqueue_style(
			'qa-admin',
			QADD_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			QADD_PLUGIN_VERSION
		);
		wp_enqueue_style(
			'qa-admin-ui',
			QADD_PLUGIN_URL . 'assets/css/admin-ui.css',
			array( 'qa-admin' ),
			QADD_PLUGIN_VERSION
		);

		wp_enqueue_script(
			'qa-admin',
			QADD_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			QADD_PLUGIN_VERSION,
			true
		);
		wp_enqueue_script(
			'qa-admin-ui',
			QADD_PLUGIN_URL . 'assets/js/admin-ui.js',
			array( 'qa-admin' ),
			QADD_PLUGIN_VERSION,
			true
		);

		wp_localize_script(
			'qa-admin',
			'qaAdmin',
			array(
				'rowTemplate' => QADD_Bulk::get_js_row_template(),
			)
		);
	}
}
