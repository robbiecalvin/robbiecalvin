<?php
/**
 * Templates CRUD.
 *
 * @package Quick_Add
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QADD_Templates {
	public static function init() {
		add_action( 'admin_post_qa_save_template', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_post_qa_delete_template', array( __CLASS__, 'handle_delete' ) );
	}

	public static function get_templates() {
		global $wpdb;
		$table = qadd_get_table_name();

		$query = "SELECT id, name, template_json, created_at FROM {$table} ORDER BY created_at DESC";
		return $wpdb->get_results( $query, ARRAY_A );
	}

	public static function get_template_by_id( $id ) {
		global $wpdb;
		$table = qadd_get_table_name();

		$sql = $wpdb->prepare( "SELECT id, name, template_json, created_at FROM {$table} WHERE id = %d", $id );
		return $wpdb->get_row( $sql, ARRAY_A );
	}

	public static function handle_save() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'quick-add' ) );
		}

		check_admin_referer( 'qadd_save_template_action', 'qadd_save_template_nonce' );

		$name         = sanitize_text_field( isset( $_POST['template_name'] ) ? wp_unslash( $_POST['template_name'] ) : '' );
		$template_raw = isset( $_POST['template_json'] ) ? wp_unslash( $_POST['template_json'] ) : '';
		$template     = json_decode( $template_raw, true );

		if ( '' === $name ) {
			self::redirect_with_message( 'qa-bulk-add', 'qadd_template_error', __( 'Template name is required.', 'quick-add' ) );
		}

		if ( ! is_array( $template ) ) {
			self::redirect_with_message( 'qa-bulk-add', 'qadd_template_error', __( 'Template JSON is invalid.', 'quick-add' ) );
		}

		$sanitized_rows = array();
		foreach ( $template as $row ) {
			$sanitized_rows[] = qadd_sanitize_product_row( $row );
		}

		global $wpdb;
		$table = qadd_get_table_name();

		$inserted = $wpdb->insert(
			$table,
			array(
				'name'          => $name,
				'template_json' => wp_json_encode( $sanitized_rows ),
				'created_at'    => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s' )
		);

		if ( false === $inserted ) {
			self::redirect_with_message( 'qa-bulk-add', 'qadd_template_error', __( 'Failed to save template.', 'quick-add' ) );
		}

		self::redirect_with_message( 'qa-bulk-add', 'qadd_template_success', __( 'Template saved.', 'quick-add' ) );
	}

	public static function handle_delete() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'quick-add' ) );
		}

		check_admin_referer( 'qadd_delete_template_action', 'qadd_delete_template_nonce' );

		$id = isset( $_POST['template_id'] ) ? absint( $_POST['template_id'] ) : 0;
		if ( $id <= 0 ) {
			self::redirect_with_message( 'qa-templates', 'qadd_template_error', __( 'Invalid template ID.', 'quick-add' ) );
		}

		global $wpdb;
		$table = qadd_get_table_name();

		$deleted = $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );

		if ( false === $deleted ) {
			self::redirect_with_message( 'qa-templates', 'qadd_template_error', __( 'Failed to delete template.', 'quick-add' ) );
		}

		self::redirect_with_message( 'qa-templates', 'qadd_template_success', __( 'Template deleted.', 'quick-add' ) );
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-add' ) );
		}

		$templates = self::get_templates();
		?>
		<div class="wrap qa-wrap">
			<h1><?php echo esc_html__( 'Quick Add Templates', 'quick-add' ); ?></h1>

			<?php self::render_notices(); ?>

			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php echo esc_html__( 'Name', 'quick-add' ); ?></th>
						<th><?php echo esc_html__( 'Created At', 'quick-add' ); ?></th>
						<th><?php echo esc_html__( 'Actions', 'quick-add' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $templates ) ) : ?>
						<tr>
							<td colspan="3"><?php echo esc_html__( 'No templates found.', 'quick-add' ); ?></td>
						</tr>
					<?php else : ?>
						<?php foreach ( $templates as $template ) : ?>
							<tr>
								<td><?php echo esc_html( $template['name'] ); ?></td>
								<td><?php echo esc_html( $template['created_at'] ); ?></td>
								<td>
									<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=qa-bulk-add&template_id=' . absint( $template['id'] ) ) ); ?>"><?php echo esc_html__( 'Load', 'quick-add' ); ?></a>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;">
										<input type="hidden" name="action" value="qadd_delete_template" />
										<input type="hidden" name="template_id" value="<?php echo esc_attr( $template['id'] ); ?>" />
										<?php wp_nonce_field( 'qadd_delete_template_action', 'qadd_delete_template_nonce' ); ?>
										<button type="submit" class="button button-link-delete" onclick="return confirm('<?php echo esc_js( __( 'Delete this template?', 'quick-add' ) ); ?>');"><?php echo esc_html__( 'Delete', 'quick-add' ); ?></button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	private static function render_notices() {
		$success = isset( $_GET['qadd_template_success'] ) ? sanitize_text_field( wp_unslash( $_GET['qadd_template_success'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$error   = isset( $_GET['qadd_template_error'] ) ? sanitize_text_field( wp_unslash( $_GET['qadd_template_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( '' !== $success ) {
			echo '<div class="notice notice-success"><p>' . esc_html( $success ) . '</p></div>';
		}

		if ( '' !== $error ) {
			echo '<div class="notice notice-error"><p>' . esc_html( $error ) . '</p></div>';
		}
	}

	private static function redirect_with_message( $page, $key, $message ) {
		$url = add_query_arg(
			array(
				'page' => $page,
				$key   => $message,
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}
}
