<?php
/**
 * Bulk page UI and submission handling.
 *
 * @package Quick_Add
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QADD_Bulk {
	public static function init() {
		add_action( 'admin_post_qa_create_products', array( __CLASS__, 'handle_create_products' ) );
	}

	public static function get_js_row_template() {
		$template = array(
			'product_name'      => '',
			'sku'               => '',
			'regular_price'     => '',
			'sale_price'        => '',
			'stock_quantity'    => '',
			'stock_status'      => 'instock',
			'category'          => '',
			'tags'              => '',
			'short_description' => '',
			'full_description'  => '',
			'product_type'      => 'simple',
			'attributes'        => '',
			'attribute_values'  => '',
			'variation_attributes' => '',
		);

		return $template;
	}

	public static function handle_create_products() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			self::error_response( __( 'Insufficient permissions.', 'quick-add' ) );
		}

		$nonce = isset( $_POST['qadd_create_products_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['qadd_create_products_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'qadd_create_products_action' ) ) {
			self::error_response( __( 'Security check failed. Please refresh and try again.', 'quick-add' ) );
		}

		$mode = isset( $_POST['qadd_input_mode'] ) ? sanitize_key( wp_unslash( $_POST['qadd_input_mode'] ) ) : 'table';
		$rows = array();

		if ( 'json' === $mode ) {
			$json = isset( $_POST['qadd_json_input'] ) ? wp_unslash( $_POST['qadd_json_input'] ) : '';
			$data = json_decode( $json, true );
			if ( ! is_array( $data ) || JSON_ERROR_NONE !== json_last_error() ) {
				self::error_response( __( 'Invalid JSON payload.', 'quick-add' ) );
			}
			$rows = $data;
		} else {
			$rows = isset( $_POST['qadd_rows'] ) ? wp_unslash( $_POST['qadd_rows'] ) : array();
			$rows = is_array( $rows ) ? $rows : array();
		}

		$rows = QADD_Processor::normalize_rows( $rows );

		if ( empty( $rows ) ) {
			self::error_response( __( 'No valid product rows were submitted.', 'quick-add' ) );
		}

		try {
			$results = QADD_Processor::create_products( $rows );
		} catch ( Throwable $exception ) {
			self::error_response( __( 'Product creation failed unexpectedly. Please review the rows and try again.', 'quick-add' ) );
		}

		self::redirect_with_payload(
			array(
				'qadd_success_count' => $results['success_count'],
				'qadd_failures'      => wp_json_encode( $results['failures'] ),
			)
		);
	}

	private static function error_response( $message ) {
		$message = sanitize_text_field( (string) $message );
		if ( wp_doing_ajax() ) {
			wp_send_json_error(
				array(
					'message' => $message,
				),
				400
			);
		}

		self::redirect_with_payload(
			array(
				'qadd_error' => $message,
			)
		);
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-add' ) );
		}

		$templates = QADD_Templates::get_templates();
		$preload   = self::get_preloaded_rows();
		?>
		<div class="wrap qa-wrap">
			<h1><?php echo esc_html__( 'Quick Add - Bulk Add', 'quick-add' ); ?></h1>

			<?php self::render_notices(); ?>

			<div class="qa-top-actions">
				<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
					<input type="hidden" name="page" value="qa-bulk-add" />
					<label for="qadd_template_id"><strong><?php echo esc_html__( 'Load Template:', 'quick-add' ); ?></strong></label>
					<select name="template_id" id="qadd_template_id">
						<option value=""><?php echo esc_html__( 'Select template', 'quick-add' ); ?></option>
						<?php foreach ( $templates as $template ) : ?>
							<option value="<?php echo esc_attr( $template['id'] ); ?>"><?php echo esc_html( $template['name'] ); ?></option>
						<?php endforeach; ?>
					</select>
					<button class="button" type="submit"><?php echo esc_html__( 'Load', 'quick-add' ); ?></button>
				</form>
			</div>

			<div class="qa-mode-switch">
				<button type="button" class="button button-primary" data-qa-mode="table"><?php echo esc_html__( 'Table Input Mode', 'quick-add' ); ?></button>
				<button type="button" class="button" data-qa-mode="json"><?php echo esc_html__( 'JSON Paste Mode', 'quick-add' ); ?></button>
			</div>

			<form id="qa-main-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qadd_create_products" />
				<input type="hidden" name="qadd_input_mode" id="qadd_input_mode" value="table" />
				<?php wp_nonce_field( 'qadd_create_products_action', 'qadd_create_products_nonce' ); ?>

				<div id="qa-table-mode" class="qa-mode-section is-active">
					<div class="qa-table-wrap">
						<table class="widefat qa-table" id="qa-products-table">
							<thead>
								<tr>
									<th><?php echo esc_html__( 'Product Name*', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'SKU', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Regular Price*', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Sale Price', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Stock Quantity', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Stock Status', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Category', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Tags', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Short Description', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Full Description', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Product Type', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Attributes', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Attribute Values', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Use In Variations', 'quick-add' ); ?></th>
									<th><?php echo esc_html__( 'Actions', 'quick-add' ); ?></th>
								</tr>
							</thead>
							<tbody id="qa-table-body"></tbody>
						</table>
					</div>
					<p>
						<button type="button" class="button" id="qa-add-row"><?php echo esc_html__( 'Add Row', 'quick-add' ); ?></button>
					</p>
				</div>

				<div id="qa-json-mode" class="qa-mode-section">
					<p>
						<label for="qadd_json_input"><strong><?php echo esc_html__( 'Paste JSON Array of Products', 'quick-add' ); ?></strong></label>
					</p>
					<textarea id="qadd_json_input" name="qadd_json_input" rows="12" class="large-text code" placeholder='[{"product_name":"Example","regular_price":"19.99"}]'></textarea>
					<p>
						<button type="button" class="button" id="qa-validate-json"><?php echo esc_html__( 'Validate & Preview JSON', 'quick-add' ); ?></button>
					</p>
					<div id="qa-json-preview"></div>
				</div>

				<p>
					<button type="submit" class="button button-primary button-large"><?php echo esc_html__( 'Create Products', 'quick-add' ); ?></button>
				</p>
			</form>

			<hr />

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="qa-save-template-form">
				<input type="hidden" name="action" value="qadd_save_template" />
				<?php wp_nonce_field( 'qadd_save_template_action', 'qadd_save_template_nonce' ); ?>
				<h2><?php echo esc_html__( 'Save Current Configuration as Template', 'quick-add' ); ?></h2>
				<p>
					<input type="text" name="template_name" id="qadd_template_name" class="regular-text" placeholder="<?php echo esc_attr__( 'Template name', 'quick-add' ); ?>" required />
				</p>
				<input type="hidden" name="template_json" id="qadd_template_json" value="<?php echo esc_attr( wp_json_encode( $preload ) ); ?>" />
				<p>
					<button type="submit" class="button"><?php echo esc_html__( 'Save Template', 'quick-add' ); ?></button>
				</p>
			</form>
		</div>
		<script>
			window.qaPreloadedRows = <?php echo wp_json_encode( $preload ); ?>;
		</script>
		<?php
	}

	private static function get_preloaded_rows() {
		$template_id = isset( $_GET['template_id'] ) ? absint( $_GET['template_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $template_id <= 0 ) {
			return array( self::get_js_row_template() );
		}

		$template = QADD_Templates::get_template_by_id( $template_id );
		if ( ! $template || empty( $template['template_json'] ) ) {
			return array( self::get_js_row_template() );
		}

		$rows = json_decode( $template['template_json'], true );
		if ( ! is_array( $rows ) || empty( $rows ) ) {
			return array( self::get_js_row_template() );
		}

		$out = array();
		foreach ( $rows as $row ) {
			$out[] = qadd_sanitize_product_row( $row );
		}

		return $out;
	}

	private static function render_notices() {
		$success_count = isset( $_GET['qadd_success_count'] ) ? absint( $_GET['qadd_success_count'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$error         = isset( $_GET['qadd_error'] ) ? sanitize_text_field( wp_unslash( $_GET['qadd_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$failures_raw  = isset( $_GET['qadd_failures'] ) ? wp_unslash( $_GET['qadd_failures'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$failures      = array();

		if ( '' !== $failures_raw ) {
			$decoded = json_decode( $failures_raw, true );
			if ( is_array( $decoded ) ) {
				$failures = $decoded;
			}
		}

		if ( null !== $success_count ) {
			echo '<div class="notice notice-success"><p>';
			echo esc_html( sprintf( __( 'Products created successfully: %d', 'quick-add' ), $success_count ) );
			echo '</p></div>';
		}

		if ( '' !== $error ) {
			echo '<div class="notice notice-error"><p>' . esc_html( $error ) . '</p></div>';
		}

		if ( ! empty( $failures ) ) {
			echo '<div class="notice notice-warning"><p><strong>' . esc_html__( 'Failed Rows:', 'quick-add' ) . '</strong></p><ul>';
			foreach ( $failures as $failure ) {
				$row    = isset( $failure['row'] ) ? absint( $failure['row'] ) : 0;
				$reason = isset( $failure['reason'] ) ? sanitize_text_field( $failure['reason'] ) : '';
				echo '<li>' . esc_html( sprintf( __( 'Row %1$d: %2$s', 'quick-add' ), $row, $reason ) ) . '</li>';
			}
			echo '</ul></div>';
		}
	}

	private static function redirect_with_payload( $args ) {
		$url = add_query_arg(
			array_merge(
				array( 'page' => 'qa-bulk-add' ),
				$args
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $url );
		exit;
	}
}
