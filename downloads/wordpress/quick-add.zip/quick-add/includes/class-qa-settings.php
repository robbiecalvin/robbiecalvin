<?php
/**
 * Settings page and registration.
 *
 * @package Quick_Add
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QADD_Settings {
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
	}

	public static function register_settings() {
		register_setting(
			'qadd_settings_group',
			'qadd_settings',
			array(
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
			)
		);
	}

	public static function sanitize_settings( $settings ) {
		$settings = is_array( $settings ) ? $settings : array();

		return array(
			'default_product_status' => isset( $settings['default_product_status'] ) && in_array( $settings['default_product_status'], array( 'draft', 'publish' ), true ) ? $settings['default_product_status'] : 'draft',
			'default_category'       => sanitize_text_field( isset( $settings['default_category'] ) ? $settings['default_category'] : '' ),
			'auto_generate_sku'      => empty( $settings['auto_generate_sku'] ) ? 0 : 1,
			'auto_sku_prefix'        => sanitize_text_field( isset( $settings['auto_sku_prefix'] ) ? $settings['auto_sku_prefix'] : '' ),
			'auto_assign_image'      => empty( $settings['auto_assign_image'] ) ? 0 : 1,
		);
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-add' ) );
		}

		$settings = qadd_get_settings();
		?>
		<div class="wrap qa-wrap">
			<h1><?php echo esc_html__( 'Quick Add Settings', 'quick-add' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'qadd_settings_group' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="qadd_default_product_status"><?php echo esc_html__( 'Default Product Status', 'quick-add' ); ?></label></th>
						<td>
							<select id="qadd_default_product_status" name="qadd_settings[default_product_status]">
								<option value="draft" <?php selected( $settings['default_product_status'], 'draft' ); ?>><?php echo esc_html__( 'Draft', 'quick-add' ); ?></option>
								<option value="publish" <?php selected( $settings['default_product_status'], 'publish' ); ?>><?php echo esc_html__( 'Publish', 'quick-add' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="qadd_default_category"><?php echo esc_html__( 'Default Category', 'quick-add' ); ?></label></th>
						<td>
							<input type="text" id="qadd_default_category" name="qadd_settings[default_category]" class="regular-text" value="<?php echo esc_attr( $settings['default_category'] ); ?>" />
							<p class="description"><?php echo esc_html__( 'Used when no category is provided in a row.', 'quick-add' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="qadd_auto_generate_sku"><?php echo esc_html__( 'Auto-generate SKU', 'quick-add' ); ?></label></th>
						<td>
							<label>
								<input type="checkbox" id="qadd_auto_generate_sku" name="qadd_settings[auto_generate_sku]" value="1" <?php checked( $settings['auto_generate_sku'], 1 ); ?> />
								<?php echo esc_html__( 'Generate SKU when empty.', 'quick-add' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="qadd_auto_sku_prefix"><?php echo esc_html__( 'Auto SKU Prefix', 'quick-add' ); ?></label></th>
						<td>
							<input type="text" id="qadd_auto_sku_prefix" name="qadd_settings[auto_sku_prefix]" class="regular-text" value="<?php echo esc_attr( $settings['auto_sku_prefix'] ); ?>" />
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="qadd_auto_assign_image"><?php echo esc_html__( 'Auto-assign image by product name', 'quick-add' ); ?></label></th>
						<td>
							<label>
								<input type="checkbox" id="qadd_auto_assign_image" name="qadd_settings[auto_assign_image]" value="1" <?php checked( $settings['auto_assign_image'], 1 ); ?> />
								<?php echo esc_html__( 'Reserved for future use. Safe to enable; no image actions are currently performed.', 'quick-add' ); ?>
							</label>
						</td>
					</tr>
				</table>
				<?php submit_button( esc_html__( 'Save Settings', 'quick-add' ) ); ?>
			</form>
		</div>
		<?php
	}
}
