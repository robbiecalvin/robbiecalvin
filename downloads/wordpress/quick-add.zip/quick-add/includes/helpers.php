<?php
/**
 * Helper functions for Quick Add.
 *
 * @package Quick_Add
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function qadd_get_table_name() {
	global $wpdb;
	return $wpdb->prefix . 'quick_add_templates';
}

function qadd_get_settings() {
	$defaults = array(
		'default_product_status' => 'draft',
		'default_category'       => '',
		'auto_generate_sku'      => 0,
		'auto_sku_prefix'        => 'QA-',
		'auto_assign_image'      => 0,
	);

	$settings = get_option( 'qadd_settings', array() );

	if ( ! is_array( $settings ) ) {
		$settings = array();
	}

	$settings = wp_parse_args( $settings, $defaults );
	$settings['default_product_status'] = in_array( $settings['default_product_status'], array( 'draft', 'publish' ), true ) ? $settings['default_product_status'] : 'draft';
	$settings['default_category']       = sanitize_text_field( $settings['default_category'] );
	$settings['auto_generate_sku']      = empty( $settings['auto_generate_sku'] ) ? 0 : 1;
	$settings['auto_sku_prefix']        = sanitize_text_field( $settings['auto_sku_prefix'] );
	$settings['auto_assign_image']      = empty( $settings['auto_assign_image'] ) ? 0 : 1;

	return $settings;
}

function qadd_sanitize_product_row( $row ) {
	$row = is_array( $row ) ? $row : array();

	$sanitized = array(
		'product_name'      => sanitize_text_field( isset( $row['product_name'] ) ? $row['product_name'] : '' ),
		'sku'               => sanitize_text_field( isset( $row['sku'] ) ? $row['sku'] : '' ),
		'regular_price'     => wc_format_decimal( isset( $row['regular_price'] ) ? $row['regular_price'] : '' ),
		'sale_price'        => wc_format_decimal( isset( $row['sale_price'] ) ? $row['sale_price'] : '' ),
		'stock_quantity'    => isset( $row['stock_quantity'] ) && '' !== $row['stock_quantity'] ? (int) $row['stock_quantity'] : '',
		'stock_status'      => sanitize_key( isset( $row['stock_status'] ) ? $row['stock_status'] : 'instock' ),
		'category'          => sanitize_text_field( isset( $row['category'] ) ? $row['category'] : '' ),
		'tags'              => sanitize_text_field( isset( $row['tags'] ) ? $row['tags'] : '' ),
		'short_description' => wp_kses_post( isset( $row['short_description'] ) ? $row['short_description'] : '' ),
		'full_description'  => wp_kses_post( isset( $row['full_description'] ) ? $row['full_description'] : '' ),
		'product_type'      => sanitize_key( isset( $row['product_type'] ) ? $row['product_type'] : 'simple' ),
		'attributes'        => sanitize_text_field( isset( $row['attributes'] ) ? $row['attributes'] : '' ),
		'attribute_values'  => sanitize_text_field( isset( $row['attribute_values'] ) ? $row['attribute_values'] : '' ),
		'variation_attributes' => sanitize_text_field( isset( $row['variation_attributes'] ) ? $row['variation_attributes'] : '' ),
	);

	if ( ! in_array( $sanitized['stock_status'], array( 'instock', 'outofstock' ), true ) ) {
		$sanitized['stock_status'] = 'instock';
	}

	if ( ! in_array( $sanitized['product_type'], array( 'simple', 'variable' ), true ) ) {
		$sanitized['product_type'] = 'simple';
	}

	return $sanitized;
}

function qadd_csv_to_array( $value ) {
	if ( '' === trim( (string) $value ) ) {
		return array();
	}

	$parts = array_map( 'trim', explode( ',', (string) $value ) );
	$parts = array_filter( $parts, static function( $part ) {
		return '' !== $part;
	} );

	return array_values( array_unique( $parts ) );
}
