<?php
/**
 * Product validation and insert processing.
 *
 * @package Quick_Add
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QADD_Processor {
	public static function normalize_rows( $rows ) {
		$rows       = is_array( $rows ) ? $rows : array();
		$normalized = array();

		foreach ( $rows as $row ) {
			$row = qadd_sanitize_product_row( $row );

			$is_empty = '' === trim( (string) $row['product_name'] )
				&& '' === trim( (string) $row['sku'] )
				&& '' === trim( (string) $row['regular_price'] )
				&& '' === trim( (string) $row['sale_price'] )
				&& '' === trim( (string) $row['stock_quantity'] )
				&& '' === trim( (string) $row['short_description'] )
				&& '' === trim( (string) $row['full_description'] );

			if ( $is_empty ) {
				continue;
			}

			$normalized[] = $row;
		}

		return $normalized;
	}

	public static function validate_rows( $rows ) {
		$rows = self::normalize_rows( $rows );

		$results      = array();
		$seen_skus    = array();
		$settings     = qadd_get_settings();
		$default_cat  = $settings['default_category'];

		foreach ( $rows as $index => $row ) {
			$row    = qadd_sanitize_product_row( $row );
			$errors = array();

			if ( '' === $row['product_name'] ) {
				$errors[] = __( 'Product Name is required.', 'quick-add' );
			}

			if ( '' === (string) $row['regular_price'] ) {
				$errors[] = __( 'Regular Price is required.', 'quick-add' );
			}

			if ( '' !== $row['sale_price'] && (float) $row['sale_price'] > (float) $row['regular_price'] ) {
				$errors[] = __( 'Sale Price cannot be greater than Regular Price.', 'quick-add' );
			}

			if ( '' !== $row['stock_quantity'] && $row['stock_quantity'] < 0 ) {
				$errors[] = __( 'Stock Quantity cannot be negative.', 'quick-add' );
			}

			if ( '' !== $row['sku'] ) {
				if ( isset( $seen_skus[ $row['sku'] ] ) ) {
					$errors[] = __( 'Duplicate SKU in submitted rows.', 'quick-add' );
				} else {
					$seen_skus[ $row['sku'] ] = true;
				}

				if ( wc_get_product_id_by_sku( $row['sku'] ) ) {
					$errors[] = __( 'SKU already exists in catalog.', 'quick-add' );
				}
			}

			if ( '' === $row['category'] && '' !== $default_cat ) {
				$row['category'] = $default_cat;
			}

			$results[] = array(
				'index'   => $index,
				'row'     => $row,
				'valid'   => empty( $errors ),
				'errors'  => $errors,
			);
		}

		return $results;
	}

	public static function create_products( $rows ) {
		global $wpdb;

		$validation = self::validate_rows( $rows );
		$settings   = qadd_get_settings();

		$success_count = 0;
		$failures      = array();

		$transaction_started = false;
		if ( self::db_supports_transactions() ) {
			$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$transaction_started = true;
		}

		wp_defer_term_counting( true );
		wp_suspend_cache_invalidation( true );

		foreach ( $validation as $item ) {
			$row_num = (int) $item['index'] + 1;

			if ( ! $item['valid'] ) {
				$failures[] = array(
					'row'    => $row_num,
					'reason' => implode( ' ', $item['errors'] ),
				);
				continue;
			}

			$row = $item['row'];

			if ( '' === $row['sku'] && ! empty( $settings['auto_generate_sku'] ) ) {
				$row['sku'] = self::generate_sku( $row['product_name'], $settings['auto_sku_prefix'] );
			}

			if ( '' !== $row['sku'] && wc_get_product_id_by_sku( $row['sku'] ) ) {
				$failures[] = array(
					'row'    => $row_num,
					'reason' => __( 'Generated/provided SKU is not unique.', 'quick-add' ),
				);
				continue;
			}

			try {
				$product = ( 'variable' === $row['product_type'] ) ? new WC_Product_Variable() : new WC_Product_Simple();
				$product->set_name( $row['product_name'] );
				$product->set_description( $row['full_description'] );
				$product->set_short_description( $row['short_description'] );
				$product->set_status( $settings['default_product_status'] );

				if ( '' !== $row['sku'] ) {
					$product->set_sku( $row['sku'] );
				}
				if ( '' !== (string) $row['regular_price'] ) {
					$product->set_regular_price( (string) $row['regular_price'] );
				}
				if ( '' !== (string) $row['sale_price'] ) {
					$product->set_sale_price( (string) $row['sale_price'] );
				}
				$product->set_stock_status( $row['stock_status'] );

				$stock_qty = '' !== (string) $row['stock_quantity'] ? max( 0, (int) $row['stock_quantity'] ) : null;
				if ( null !== $stock_qty ) {
					$product->set_manage_stock( true );
					$product->set_stock_quantity( $stock_qty );
				}

				$attributes = self::parse_attributes_from_row( $row );
				if ( ! empty( $attributes ) ) {
					$product->set_attributes( $attributes );
				}

				$product_id = $product->save();
				if ( ! $product_id ) {
					$failures[] = array(
						'row'    => $row_num,
						'reason' => __( 'Product could not be saved.', 'quick-add' ),
					);
					continue;
				}

				$categories = qadd_csv_to_array( $row['category'] );
				if ( ! empty( $categories ) ) {
					wp_set_object_terms( $product_id, $categories, 'product_cat', false );
				}

				$tags = qadd_csv_to_array( $row['tags'] );
				if ( ! empty( $tags ) ) {
					wp_set_object_terms( $product_id, $tags, 'product_tag', false );
				}

				$success_count++;
			} catch ( Throwable $exception ) {
				$failures[] = array(
					'row'    => $row_num,
					'reason' => __( 'Unexpected error during product creation.', 'quick-add' ),
				);
			}
		}

		if ( $transaction_started ) {
			$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		wp_defer_term_counting( false );
		wp_suspend_cache_invalidation( false );

		return array(
			'success_count' => $success_count,
			'failures'      => $failures,
			'validation'    => $validation,
		);
	}

	private static function db_supports_transactions() {
		global $wpdb;
		$engine = $wpdb->get_var( 'SELECT @@default_storage_engine' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		if ( ! is_string( $engine ) ) {
			return false;
		}

		return in_array( strtoupper( $engine ), array( 'INNODB', 'NDB' ), true );
	}

	private static function generate_sku( $name, $prefix ) {
		$prefix   = sanitize_text_field( $prefix );
		$base     = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $name ) );
		$base     = '' === $base ? 'ITEM' : substr( $base, 0, 10 );
		$attempts = 0;

		do {
			$attempts++;
			$candidate = $prefix . $base . '-' . wp_rand( 1000, 9999 );
		} while ( wc_get_product_id_by_sku( $candidate ) && $attempts < 20 );

		return $candidate;
	}

	private static function parse_attributes_from_row( $row ) {
		if ( ! class_exists( 'WC_Product_Attribute' ) ) {
			return array();
		}

		$attribute_names = qadd_csv_to_array( isset( $row['attributes'] ) ? (string) $row['attributes'] : '' );
		$value_groups    = preg_split( '/\s*\|\s*/', isset( $row['attribute_values'] ) ? (string) $row['attribute_values'] : '' );
		$variation_names = array_map( 'strtolower', qadd_csv_to_array( isset( $row['variation_attributes'] ) ? (string) $row['variation_attributes'] : '' ) );

		if ( empty( $attribute_names ) ) {
			return array();
		}

		$built = array();
		foreach ( $attribute_names as $index => $name ) {
			$options = array();
			if ( is_array( $value_groups ) && isset( $value_groups[ $index ] ) ) {
				$options = qadd_csv_to_array( (string) $value_groups[ $index ] );
			}

			if ( empty( $options ) ) {
				continue;
			}

			$attribute = new WC_Product_Attribute();
			$attribute->set_id( 0 );
			$attribute->set_name( wc_clean( $name ) );
			$attribute->set_options( array_values( $options ) );
			$attribute->set_visible( true );
			$attribute->set_variation( in_array( strtolower( (string) $name ), $variation_names, true ) );
			$attribute->set_position( $index );
			$built[] = $attribute;
		}

		return $built;
	}
}
