# Quick Add -- Visual To‑Do

## Admin Dashboard

-   Change background to branded sky blue
-   Add padding + margins between containers and form fields
-   Change ALL buttons to blue with white text

## Template Pages

-   No changes required

## Settings Page

-   Add left-side padding to labels
