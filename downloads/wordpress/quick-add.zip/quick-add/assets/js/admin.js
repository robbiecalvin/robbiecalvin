(function ($) {
	'use strict';

	function escapeHtml(value) {
		return $('<div/>').text(value == null ? '' : String(value)).html();
	}

	function rowMarkup(index, row) {
		var stockStatus = row.stock_status === 'outofstock' ? 'outofstock' : 'instock';
		var productType = row.product_type === 'variable' ? 'variable' : 'simple';

		return '<tr>' +
			'<td><input type="text" name="qadd_rows[' + index + '][product_name]" value="' + escapeHtml(row.product_name || '') + '" required></td>' +
			'<td><input type="text" name="qadd_rows[' + index + '][sku]" value="' + escapeHtml(row.sku || '') + '"></td>' +
			'<td><input type="number" step="0.01" min="0" name="qadd_rows[' + index + '][regular_price]" value="' + escapeHtml(row.regular_price || '') + '" required></td>' +
			'<td><input type="number" step="0.01" min="0" name="qadd_rows[' + index + '][sale_price]" value="' + escapeHtml(row.sale_price || '') + '"></td>' +
			'<td><input type="number" min="0" name="qadd_rows[' + index + '][stock_quantity]" value="' + escapeHtml(row.stock_quantity || '') + '"></td>' +
			'<td><select name="qadd_rows[' + index + '][stock_status]">' +
			'<option value="instock"' + (stockStatus === 'instock' ? ' selected' : '') + '>instock</option>' +
			'<option value="outofstock"' + (stockStatus === 'outofstock' ? ' selected' : '') + '>outofstock</option>' +
			'</select></td>' +
			'<td><input type="text" name="qadd_rows[' + index + '][category]" value="' + escapeHtml(row.category || '') + '"></td>' +
			'<td><input type="text" name="qadd_rows[' + index + '][tags]" value="' + escapeHtml(row.tags || '') + '"></td>' +
			'<td><textarea name="qadd_rows[' + index + '][short_description]">' + escapeHtml(row.short_description || '') + '</textarea></td>' +
			'<td><textarea name="qadd_rows[' + index + '][full_description]">' + escapeHtml(row.full_description || '') + '</textarea></td>' +
			'<td><select name="qadd_rows[' + index + '][product_type]">' +
			'<option value="simple"' + (productType === 'simple' ? ' selected' : '') + '>simple</option>' +
			'<option value="variable"' + (productType === 'variable' ? ' selected' : '') + '>variable</option>' +
			'</select></td>' +
			'<td><input type="text" name="qadd_rows[' + index + '][attributes]" value="' + escapeHtml(row.attributes || '') + '" placeholder="Color, Size"></td>' +
			'<td><input type="text" name="qadd_rows[' + index + '][attribute_values]" value="' + escapeHtml(row.attribute_values || '') + '" placeholder="Red,Blue | S,M,L"></td>' +
			'<td><input type="text" name="qadd_rows[' + index + '][variation_attributes]" value="' + escapeHtml(row.variation_attributes || '') + '" placeholder="Color, Size"></td>' +
			'<td><button type="button" class="button qa-remove-row">Remove Row</button></td>' +
			'</tr>';
	}

	function collectTableRows() {
		var rows = [];
		$('#qa-table-body tr').each(function () {
			var $tr = $(this);
			rows.push({
				product_name: $tr.find('input[name*="[product_name]"]').val() || '',
				sku: $tr.find('input[name*="[sku]"]').val() || '',
				regular_price: $tr.find('input[name*="[regular_price]"]').val() || '',
				sale_price: $tr.find('input[name*="[sale_price]"]').val() || '',
				stock_quantity: $tr.find('input[name*="[stock_quantity]"]').val() || '',
				stock_status: $tr.find('select[name*="[stock_status]"]').val() || 'instock',
				category: $tr.find('input[name*="[category]"]').val() || '',
				tags: $tr.find('input[name*="[tags]"]').val() || '',
				short_description: $tr.find('textarea[name*="[short_description]"]').val() || '',
				full_description: $tr.find('textarea[name*="[full_description]"]').val() || '',
				product_type: $tr.find('select[name*="[product_type]"]').val() || 'simple',
				attributes: $tr.find('input[name*="[attributes]"]').val() || '',
				attribute_values: $tr.find('input[name*="[attribute_values]"]').val() || '',
				variation_attributes: $tr.find('input[name*="[variation_attributes]"]').val() || ''
			});
		});
		return rows;
	}

	function renderRows(rows) {
		var $tbody = $('#qa-table-body');
		$tbody.empty();
		if (!rows || !rows.length) {
			rows = [window.qaPreloadedRows && window.qaPreloadedRows[0] ? window.qaPreloadedRows[0] : (window.qaAdmin ? window.qaAdmin.rowTemplate : {})];
		}
		$.each(rows, function (i, row) {
			$tbody.append(rowMarkup(i, row));
		});
	}

	function renumberRows() {
		$('#qa-table-body tr').each(function (index) {
			$(this).find('input, select, textarea').each(function () {
				var name = $(this).attr('name');
				if (name) {
					$(this).attr('name', name.replace(/qadd_rows\[\d+\]/, 'qadd_rows[' + index + ']'));
				}
			});
		});
	}

	function switchMode(mode) {
		$('#qadd_input_mode').val(mode);
		$('.qa-mode-switch .button').removeClass('button-primary').addClass('button');
		$('.qa-mode-switch .button[data-qa-mode="' + mode + '"]').addClass('button-primary').removeClass('button');
		$('.qa-mode-section').removeClass('is-active');
		if (mode === 'json') {
			$('#qa-json-mode').addClass('is-active');
		} else {
			$('#qa-table-mode').addClass('is-active');
		}
	}

	$(document).on('click', '[data-qa-mode]', function () {
		switchMode($(this).data('qa-mode'));
	});

	$(document).on('click', '#qa-add-row', function () {
		var index = $('#qa-table-body tr').length;
		var row = window.qaAdmin && window.qaAdmin.rowTemplate ? window.qaAdmin.rowTemplate : {};
		$('#qa-table-body').append(rowMarkup(index, row));
	});

	$(document).on('click', '.qa-remove-row', function () {
		var $rows = $('#qa-table-body tr');
		if ($rows.length <= 1) {
			$rows.find('input[type="text"], input[type="number"], textarea').val('');
			$rows.find('select[name*="[stock_status]"]').val('instock');
			$rows.find('select[name*="[product_type]"]').val('simple');
			return;
		}
		$(this).closest('tr').remove();
		renumberRows();
	});

	$(document).on('click', '#qa-validate-json', function () {
		var raw = $('#qadd_json_input').val();
		var $preview = $('#qa-json-preview');
		$preview.empty();

		try {
			var data = JSON.parse(raw);
			if (!Array.isArray(data)) {
				throw new Error('JSON must be an array of products.');
			}

			var header = '<table><thead><tr><th>#</th><th>Product Name</th><th>Regular Price</th><th>SKU</th><th>Status</th></tr></thead><tbody>';
			var body = '';
			data.forEach(function (row, index) {
				var hasName = row && row.product_name;
				var hasPrice = row && row.regular_price !== undefined && row.regular_price !== null && row.regular_price !== '';
				var status = hasName && hasPrice ? 'Valid' : 'Missing required fields';
				body += '<tr>' +
					'<td>' + (index + 1) + '</td>' +
					'<td>' + escapeHtml(hasName ? row.product_name : '') + '</td>' +
					'<td>' + escapeHtml(hasPrice ? row.regular_price : '') + '</td>' +
					'<td>' + escapeHtml(row && row.sku ? row.sku : '') + '</td>' +
					'<td>' + escapeHtml(status) + '</td>' +
					'</tr>';
			});
			$preview.html(header + body + '</tbody></table>');
		} catch (err) {
			$preview.html('<div class="notice notice-error"><p>' + escapeHtml(err.message) + '</p></div>');
		}
	});

	$(document).on('submit', '#qa-save-template-form', function () {
		var mode = $('#qadd_input_mode').val();
		var payload = [];

		if (mode === 'json') {
			try {
				var data = JSON.parse($('#qadd_json_input').val() || '[]');
				payload = Array.isArray(data) ? data : [];
			} catch (e) {
				payload = [];
			}
		} else {
			payload = collectTableRows();
		}

		$('#qadd_template_json').val(JSON.stringify(payload));
	});

	$(document).on('submit', '#qa-main-form', function () {
		if ($('#qadd_input_mode').val() === 'table') {
			var seen = {};
			$('#qa-table-body tr').removeClass('qa-row-error');
			$('#qa-table-body tr').each(function () {
				var $row = $(this);
				var sku = ($row.find('input[name*="[sku]"]').val() || '').trim();
				if (sku !== '') {
					if (seen[sku]) {
						$row.addClass('qa-row-error');
					} else {
						seen[sku] = true;
					}
				}
			});
		}
	});

	$(function () {
		renderRows(window.qaPreloadedRows || []);
		switchMode('table');
	});
})(jQuery);
