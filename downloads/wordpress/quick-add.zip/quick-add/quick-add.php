<?php
/**
 * Plugin Name: Quick Add
 * Description: Bulk add WooCommerce products from a table or JSON input, with validation and templates.
 * Version: 1.0.0
 * Author: QuickWoo by Robbie Calvin
 * Author URI: https://quickwoo.pro
 * Text Domain: quick-add
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/quick-core/bootstrap.php';
}

define( 'QADD_PLUGIN_VERSION', '1.0.0' );
define( 'QADD_PLUGIN_FILE', __FILE__ );
define( 'QADD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'QADD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once QADD_PLUGIN_DIR . 'includes/helpers.php';
require_once QADD_PLUGIN_DIR . 'includes/class-qa-activator.php';
require_once QADD_PLUGIN_DIR . 'includes/class-qa-templates.php';
require_once QADD_PLUGIN_DIR . 'includes/class-qa-settings.php';
require_once QADD_PLUGIN_DIR . 'includes/class-qa-processor.php';
require_once QADD_PLUGIN_DIR . 'includes/class-qa-bulk.php';
require_once QADD_PLUGIN_DIR . 'includes/class-qa-admin.php';

register_activation_hook( QADD_PLUGIN_FILE, array( 'QADD_Activator', 'activate' ) );

function qadd_is_woocommerce_active() {
	return class_exists( 'WooCommerce' );
}

function qadd_is_premium_active() {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

    if ( function_exists( 'qwoo_has_active_license' ) ) {
        return (bool) qwoo_has_active_license( array( 'quick-add' ) );
    }

    return false;
}

function qadd_admin_notice_woocommerce_required() {
	if ( qadd_is_woocommerce_active() ) {
		return;
	}

	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	echo '<div class="notice notice-error"><p>';
	echo esc_html__( 'Quick Add requires WooCommerce to be active. Plugin functionality is disabled until WooCommerce is activated.', 'quick-add' );
	echo '</p></div>';
}
add_action( 'admin_notices', 'qadd_admin_notice_woocommerce_required' );

function qadd_bootstrap() {
	if ( ! is_admin() ) {
		return;
	}

	if ( ! qadd_is_woocommerce_active() ) {
		return;
	}

	QADD_Settings::init();
	QADD_Templates::init();
	QADD_Bulk::init();
	QADD_Admin::init();
}
add_action( 'plugins_loaded', 'qadd_bootstrap' );

add_action(
    'plugins_loaded',
    static function () {
        if (function_exists('qwoo_register_plugin')) {
            qwoo_register_plugin('quick-add', array(
                'name' => 'Quick Woo Add',
                'version' => QADD_PLUGIN_VERSION,
                'file' => QADD_PLUGIN_FILE,
                'features' => array('bulk-products', 'templates', 'json-import'),
            ));
        }

        if (function_exists('qwoo_event')) {
            qwoo_event('plugin_booted', array('plugin' => 'quick-add', 'version' => QADD_PLUGIN_VERSION));
        }
    },
    20
);

if ( ! function_exists( 'qwoo_quick_add_license_bootstrap' ) ) {
    function qwoo_quick_add_license_bootstrap() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu', 'qwoo_quick_add_license_menu' );
        add_action( 'admin_post_qwoo_quick_add_activate_license', 'qwoo_quick_add_license_handle_activate' );
        add_action( 'admin_post_qwoo_quick_add_deactivate_license', 'qwoo_quick_add_license_handle_deactivate' );
    }
    add_action( 'plugins_loaded', 'qwoo_quick_add_license_bootstrap', 30 );

    function qwoo_quick_add_license_option_key() {
        return 'qwoo_quick_add_license';
    }

    function qwoo_quick_add_license_product_scope() {
        return array( 'quick-add' );
    }

    function qwoo_quick_add_license_get_data() {
        $defaults = array(
            'license_key' => '',
            'license_status' => 'inactive',
            'license_message' => '',
        );

        $saved = get_option( qwoo_quick_add_license_option_key(), array() );
        $saved = is_array( $saved ) ? $saved : array();

        return wp_parse_args( $saved, $defaults );
    }

    function qwoo_quick_add_license_save_data( $data ) {
        $data = is_array( $data ) ? $data : array();

        $clean = array(
            'license_key' => sanitize_text_field( (string) ( $data['license_key'] ?? '' ) ),
            'license_status' => sanitize_key( (string) ( $data['license_status'] ?? 'inactive' ) ),
            'license_message' => sanitize_text_field( (string) ( $data['license_message'] ?? '' ) ),
        );

        update_option( qwoo_quick_add_license_option_key(), $clean, false );
        return $clean;
    }

    function qwoo_quick_add_license_menu() {
        add_options_page(
            'Ladd License',
            'Ladd License',
            'manage_options',
            'qwoo-quick-add-license',
            'qwoo_quick_add_license_render_page'
        );
    }

    function qwoo_quick_add_license_render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = qwoo_quick_add_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );

        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $status = qlic_get_license_status_for_key_products( $license_key, qwoo_quick_add_license_product_scope() );
            if ( is_array( $status ) ) {
                $data['license_status'] = sanitize_key( (string) ( $status['status'] ?? $data['license_status'] ) );
                $data['license_message'] = sanitize_text_field( (string) ( $status['message'] ?? $data['license_message'] ) );
                if ( ! empty( $status['valid'] ) && ! empty( $status['domain_active'] ) ) {
                    $data['license_status'] = 'active';
                }
                qwoo_quick_add_license_save_data( $data );
            }
        }

        $notice = isset( $_GET['qwoo_license_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qwoo_license_notice'] ) ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Ladd License', 'quick-add' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-add' ), (string) ( $data['license_status'] ?? 'inactive' ) ) ); ?></p>
            <?php if ( ! empty( $data['license_message'] ) ) : ?>
                <p><?php echo esc_html( (string) $data['license_message'] ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_add_activate_license" />
                <?php wp_nonce_field( 'qwoo_quick_add_activate_license', 'qwoo_quick_add_activate_license_nonce' ); ?>
                <p>
                    <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( (string) ( $data['license_key'] ?? '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button type="submit" class="button button-primary"><?php echo esc_html__( 'Activate License', 'quick-add' ); ?></button>
                </p>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_add_deactivate_license" />
                <?php wp_nonce_field( 'qwoo_quick_add_deactivate_license', 'qwoo_quick_add_deactivate_license_nonce' ); ?>
                <p><button type="submit" class="button"><?php echo esc_html__( 'Deactivate License', 'quick-add' ); ?></button></p>
            </form>
        </div>
        <?php
    }

    function qwoo_quick_add_license_redirect( $message ) {
        $url = add_query_arg(
            array(
                'page' => 'qwoo-quick-add-license',
                'qwoo_license_notice' => rawurlencode( (string) $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    function qwoo_quick_add_license_handle_activate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-add' ) );
        }

        check_admin_referer( 'qwoo_quick_add_activate_license', 'qwoo_quick_add_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        if ( '' === $license_key ) {
            qwoo_quick_add_license_save_data(
                array(
                    'license_key' => '',
                    'license_status' => 'inactive',
                    'license_message' => 'License key is required.',
                )
            );
            qwoo_quick_add_license_redirect( 'License key is required.' );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            qwoo_quick_add_license_save_data(
                array(
                    'license_key' => $license_key,
                    'license_status' => 'invalid',
                    'license_message' => 'Quick License plugin is required for activation.',
                )
            );
            qwoo_quick_add_license_redirect( 'Quick License plugin is required for activation.' );
        }

        $result = qlic_activate_license_key_for_products( $license_key, qwoo_quick_add_license_product_scope() );
        $data = array(
            'license_key' => $license_key,
            'license_status' => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'license_message' => sanitize_text_field( (string) ( $result['message'] ?? 'License validation failed.' ) ),
        );
        if ( ! empty( $result['valid'] ) ) {
            $data['license_status'] = 'active';
        }

        qwoo_quick_add_license_save_data( $data );
        qwoo_quick_add_license_redirect( (string) $data['license_message'] );
    }

    function qwoo_quick_add_license_handle_deactivate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-add' ) );
        }

        check_admin_referer( 'qwoo_quick_add_deactivate_license', 'qwoo_quick_add_deactivate_license_nonce' );

        $data = qwoo_quick_add_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );
        $message = 'License deactivated.';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products( $license_key, qwoo_quick_add_license_product_scope() );
            if ( is_array( $result ) && ! empty( $result['message'] ) ) {
                $message = sanitize_text_field( (string) $result['message'] );
            }
        }

        qwoo_quick_add_license_save_data(
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => $message,
            )
        );

        qwoo_quick_add_license_redirect( $message );
    }
}
