(function ($) {
    'use strict';

    function normalizeFieldKey(value) {
        var key = $.trim(String(value || '')).toLowerCase();
        key = key.replace(/[^a-z0-9]+/g, '_');
        key = key.replace(/^_+|_+$/g, '');
        return key;
    }

    function equivalentFieldKeys(rawKey) {
        var base = normalizeFieldKey(rawKey);
        var keys = [base];

        if (base.slice(-1) === 's') {
            keys.push(base.slice(0, -1));
        } else if (base) {
            keys.push(base + 's');
        }

        return keys;
    }

    function normalizeValues(raw) {
        if ($.isArray(raw)) {
            return $.map(raw, function (v) {
                return $.trim(String(v));
            });
        }

        var text = $.trim(String(raw || ''));
        if (text === '') {
            return [];
        }

        if (text.indexOf(',') !== -1) {
            return $.map(text.split(','), function (v) {
                return $.trim(String(v));
            });
        }

        return [text];
    }

    function fieldValues($form, fieldName) {
        var wanted = equivalentFieldKeys(fieldName);
        var $inputs = $form.find('[data-qf-field-name="' + fieldName + '"]');

        if (!$inputs.length) {
            var all = $form.find('[data-qf-field-name]');
            $inputs = all.filter(function () {
                var current = normalizeFieldKey($(this).data('qfFieldName'));
                return $.inArray(current, wanted) !== -1;
            });
        }

        if (!$inputs.length) {
            return [];
        }

        var firstType = ($inputs.first().attr('type') || '').toLowerCase();

        if (firstType === 'radio') {
            var selected = $inputs.filter(':checked').val();
            return selected ? [$.trim(String(selected))] : [];
        }

        if (firstType === 'checkbox') {
            if ($inputs.length === 1) {
                return $inputs.first().is(':checked') ? ['1'] : [];
            }

            return $.map($inputs.filter(':checked'), function (el) {
                return $.trim(String($(el).val()));
            });
        }

        var value = $inputs.first().val();
        return normalizeValues(value);
    }

    function clearFieldValue($fieldWrap) {
        $fieldWrap.find('input, select, textarea').each(function () {
            var $input = $(this);
            var type = ($input.attr('type') || '').toLowerCase();

            if (type === 'radio' || type === 'checkbox') {
                $input.prop('checked', false);
                return;
            }

            if (type === 'file') {
                $input.val('');
                return;
            }

            if ($input.is('select')) {
                $input.prop('selectedIndex', 0);
                return;
            }

            $input.val('');
        });
    }

    function setFieldVisible($fieldWrap, visible) {
        $fieldWrap.find('input, select, textarea').each(function () {
            var $input = $(this);
            if ($input.data('qfOriginalRequired') === undefined) {
                $input.data('qfOriginalRequired', $input.prop('required'));
            }

            if (visible) {
                $input.prop('disabled', false);
                $input.prop('required', !!$input.data('qfOriginalRequired'));
            } else {
                $input.prop('required', false);
                $input.prop('disabled', true);
            }
        });

        if (visible) {
            $fieldWrap.show();
            return;
        }

        clearFieldValue($fieldWrap);
        $fieldWrap.hide();
    }

    function applyConditionalLogic($form) {
        $form.find('.qf-field[data-condition-field]').each(function () {
            var $fieldWrap = $(this);
            var conditionField = $.trim(String($fieldWrap.data('conditionField') || ''));
            var conditionValuesRaw = $fieldWrap.attr('data-condition-values');
            var conditionValues = [];

            if (conditionValuesRaw) {
                try {
                    conditionValues = JSON.parse(conditionValuesRaw);
                } catch (e) {
                    conditionValues = normalizeValues(conditionValuesRaw);
                }
            }

            conditionValues = $.map(conditionValues, function (v) {
                return $.trim(String(v)).toLowerCase();
            });

            if (!conditionField || !conditionValues.length) {
                setFieldVisible($fieldWrap, true);
                return;
            }

            var selectedValues = fieldValues($form, conditionField);
            var shouldShow = false;

            $.each(selectedValues, function (_, selected) {
                if ($.inArray($.trim(String(selected)).toLowerCase(), conditionValues) !== -1) {
                    shouldShow = true;
                    return false;
                }
                return true;
            });

            setFieldVisible($fieldWrap, shouldShow);
        });
    }

    $(document).on('change', '.qf-form input, .qf-form select, .qf-form textarea', function () {
        var $form = $(this).closest('.qf-form');
        applyConditionalLogic($form);
    });

    $('.qf-form').each(function () {
        applyConditionalLogic($(this));
    });

    $(document).on('submit', '.qf-form', function (e) {
        e.preventDefault();

        var $form = $(this);
        var $message = $form.find('.qf-form-message');
        var formData = new FormData(this);

        $message.removeClass('qf-error qf-success').text('');

        $.ajax({
            url: QuickForms.ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                if (!response || !response.success) {
                    var msg = response && response.data && response.data.message ? response.data.message : 'Submission failed.';
                    $message.addClass('qf-error').text(msg);
                    return;
                }

                var successMsg = response.data && response.data.message ? response.data.message : 'Submitted successfully.';
                $message.addClass('qf-success').text(successMsg);

                if (response.data && response.data.redirect) {
                    window.location.href = response.data.redirect;
                    return;
                }

                $form.trigger('reset');
                applyConditionalLogic($form);
            },
            error: function (xhr) {
                var response = xhr.responseJSON;
                var msg = response && response.data && response.data.message ? response.data.message : 'Submission failed.';
                $message.addClass('qf-error').text(msg);
            }
        });
    });
})(jQuery);
