(function ($) {
    'use strict';

    function rowTemplate(index) {
        var types = ['text', 'email', 'phone', 'textarea', 'dropdown', 'checkbox', 'radio', 'consent', 'hidden', 'file'];
        var typeOptions = '';

        for (var i = 0; i < types.length; i++) {
            var label = types[i].charAt(0).toUpperCase() + types[i].slice(1);
            typeOptions += '<option value="' + types[i] + '">' + label + '</option>';
        }

        return '<tr class="qf-field-row">' +
            '<td><select name="fields[' + index + '][type]" class="qf-type">' + typeOptions + '</select></td>' +
            '<td><input type="text" name="fields[' + index + '][label]" value="" /></td>' +
            '<td><input type="text" name="fields[' + index + '][name]" value="" /></td>' +
            '<td><input type="checkbox" name="fields[' + index + '][required]" value="1" /></td>' +
            '<td><input type="text" name="fields[' + index + '][placeholder]" value="" /></td>' +
            '<td><input type="text" name="fields[' + index + '][default]" value="" /></td>' +
            '<td><textarea name="fields[' + index + '][options]"></textarea></td>' +
            '<td><input type="text" name="fields[' + index + '][conditional_field]" value="" placeholder="service_type" /></td>' +
            '<td><input type="text" name="fields[' + index + '][conditional_values]" value="" placeholder="basic,standard" /></td>' +
            '<td><input type="number" min="0" name="fields[' + index + '][min_length]" value="0" /></td>' +
            '<td><input type="number" min="0" name="fields[' + index + '][max_length]" value="0" /></td>' +
            '<td><input type="text" name="fields[' + index + '][regex]" value="" /></td>' +
            '<td><input type="text" name="fields[' + index + '][allowed_mime]" value="" /></td>' +
            '<td><input type="number" min="0" name="fields[' + index + '][max_size_mb]" value="0" /></td>' +
            '<td><button class="button qf-move-up" type="button">↑</button> <button class="button qf-move-down" type="button">↓</button></td>' +
            '<td><button type="button" class="button qf-remove-row">Remove</button></td>' +
            '</tr>';
    }

    function reindexRows() {
        $('#qf-fields-table tbody tr.qf-field-row').each(function (i) {
            $(this).find('input, select, textarea').each(function () {
                var name = $(this).attr('name');
                if (!name) {
                    return;
                }
                $(this).attr('name', name.replace(/fields\[\d+\]/, 'fields[' + i + ']'));
            });
        });
    }

    $(document).on('click', '#qf-add-field', function () {
        var count = $('#qf-fields-table tbody tr.qf-field-row').length;
        $('#qf-fields-table tbody').append(rowTemplate(count));
    });

    $(document).on('click', '.qf-remove-row', function () {
        $(this).closest('tr').remove();
        reindexRows();
    });

    $(document).on('click', '.qf-move-up', function () {
        var row = $(this).closest('tr');
        row.prev().before(row);
        reindexRows();
    });

    $(document).on('click', '.qf-move-down', function () {
        var row = $(this).closest('tr');
        row.next().after(row);
        reindexRows();
    });
})(jQuery);
