<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="wrap">
    <h1><?php esc_html_e( 'Submission Details', 'quick-forms' ); ?></h1>
    <p><a href="<?php echo esc_url( admin_url( 'admin.php?page=quick-forms-submissions' ) ); ?>" class="button button-secondary"><?php esc_html_e( 'Back to Submissions', 'quick-forms' ); ?></a></p>

    <?php if ( empty( $submission ) ) : ?>
        <div class="notice notice-error"><p><?php esc_html_e( 'Submission not found.', 'quick-forms' ); ?></p></div>
    <?php else : ?>
        <?php $data = qfrm_decode_json_array( $submission['submitted_data_json'] ); ?>
        <?php $files = qfrm_decode_json_array( $submission['files_json'] ); ?>

        <table class="widefat striped">
            <tbody>
                <tr>
                    <th><?php esc_html_e( 'Submission ID', 'quick-forms' ); ?></th>
                    <td><?php echo absint( $submission['id'] ); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Form', 'quick-forms' ); ?></th>
                    <td><?php echo esc_html( $submission['form_name'] ); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Status', 'quick-forms' ); ?></th>
                    <td><?php echo esc_html( ucfirst( $submission['status'] ) ); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Created', 'quick-forms' ); ?></th>
                    <td><?php echo esc_html( $submission['created_at'] ); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'IP Hash', 'quick-forms' ); ?></th>
                    <td><code><?php echo esc_html( $submission['ip_hash'] ); ?></code></td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'User Agent', 'quick-forms' ); ?></th>
                    <td><?php echo esc_html( isset( $submission['user_agent'] ) ? $submission['user_agent'] : '' ); ?></td>
                </tr>
            </tbody>
        </table>

        <h2><?php esc_html_e( 'Field Data', 'quick-forms' ); ?></h2>
        <table class="widefat striped">
            <thead><tr><th><?php esc_html_e( 'Field', 'quick-forms' ); ?></th><th><?php esc_html_e( 'Value', 'quick-forms' ); ?></th></tr></thead>
            <tbody>
                <?php if ( empty( $data ) ) : ?>
                    <tr><td colspan="2"><?php esc_html_e( 'No field data found.', 'quick-forms' ); ?></td></tr>
                <?php else : ?>
                    <?php foreach ( $data as $key => $value ) : ?>
                        <tr>
                            <td><?php echo esc_html( $key ); ?></td>
                            <td><?php echo esc_html( is_scalar( $value ) ? (string) $value : wp_json_encode( $value ) ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <h2><?php esc_html_e( 'Files', 'quick-forms' ); ?></h2>
        <table class="widefat striped">
            <thead><tr><th><?php esc_html_e( 'Field', 'quick-forms' ); ?></th><th><?php esc_html_e( 'File', 'quick-forms' ); ?></th></tr></thead>
            <tbody>
                <?php if ( empty( $files ) ) : ?>
                    <tr><td colspan="2"><?php esc_html_e( 'No uploaded files.', 'quick-forms' ); ?></td></tr>
                <?php else : ?>
                    <?php foreach ( $files as $key => $file ) : ?>
                        <tr>
                            <td><?php echo esc_html( $key ); ?></td>
                            <td>
                                <?php if ( ! empty( $file['url'] ) ) : ?>
                                    <a href="<?php echo esc_url( $file['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( isset( $file['name'] ) ? $file['name'] : __( 'Download', 'quick-forms' ) ); ?></a>
                                <?php else : ?>
                                    <?php echo esc_html( isset( $file['name'] ) ? $file['name'] : '' ); ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
