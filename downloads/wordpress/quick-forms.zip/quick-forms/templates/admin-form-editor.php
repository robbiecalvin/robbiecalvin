<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$form_id      = isset( $form['id'] ) ? absint( $form['id'] ) : 0;
$form_name    = isset( $form['name'] ) ? $form['name'] : '';
$form_slug    = isset( $form['slug'] ) ? $form['slug'] : '';
$global_email = qfrm_get_settings()['default_notification_email'];
$global_settings = qfrm_get_settings();
$premium_enabled = qfrm_is_premium_active();
$qf_quote_integration_enabled = ! empty( $global_settings['integrate_quick_quotes'] );

$defaults = array(
    'quote_type'              => '',
    'submission_mode'         => 'capture_only',
    'success_message'         => 'Thank you! Your submission has been received.',
    'admin_notification'      => 1,
    'notification_recipients' => $global_email,
    'email_subject'           => 'New submission for {{form_name}}',
    'redirect_url'            => '',
    'save_to_db'              => 1,
    'spam_protection'         => 1,
);

$form_settings = wp_parse_args( $form_settings, $defaults );

if ( isset( $_GET['qfrm_error'] ) ) {
    echo '<div class="notice notice-error"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['qfrm_error'] ) ) ) . '</p></div>';
}
?>
<div class="wrap">
    <h1><?php echo $form_id ? esc_html__( 'Edit Form', 'quick-forms' ) : esc_html__( 'Add New Form', 'quick-forms' ); ?></h1>

    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="qf-form-editor">
        <input type="hidden" name="action" value="qfrm_save_form" />
        <input type="hidden" name="form_id" value="<?php echo absint( $form_id ); ?>" />
        <?php wp_nonce_field( 'qfrm_save_form', 'qfrm_nonce' ); ?>

        <table class="form-table">
            <tr>
                <th><label for="qfrm_name"><?php esc_html_e( 'Form Name', 'quick-forms' ); ?></label></th>
                <td><input id="qfrm_name" name="name" type="text" class="regular-text" value="<?php echo esc_attr( $form_name ); ?>" required /></td>
            </tr>
            <tr>
                <th><label for="qfrm_slug"><?php esc_html_e( 'Slug', 'quick-forms' ); ?></label></th>
                <td><input id="qfrm_slug" name="slug" type="text" class="regular-text" value="<?php echo esc_attr( $form_slug ); ?>" /></td>
            </tr>
            <tr>
                <th><label for="qfrm_quote_type"><?php esc_html_e( 'Quote Type Key', 'quick-forms' ); ?></label></th>
                <td>
                    <input id="qfrm_quote_type" name="settings[quote_type]" type="text" class="regular-text" value="<?php echo esc_attr( $form_settings['quote_type'] ); ?>" />
                    <p class="description"><?php esc_html_e( 'Use a machine key like web-design or seo. Then render via [quick_form quote_type="web-design"].', 'quick-forms' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="qfrm_submission_mode"><?php esc_html_e( 'Submission Mode', 'quick-forms' ); ?></label></th>
                <td>
                    <select id="qfrm_submission_mode" name="settings[submission_mode]">
                        <option value="capture_only" <?php selected( $form_settings['submission_mode'], 'capture_only' ); ?>><?php esc_html_e( 'Capture Only (Thank You)', 'quick-forms' ); ?></option>
                        <option value="instant_estimate" <?php selected( $form_settings['submission_mode'], 'instant_estimate' ); ?> <?php disabled( ! $premium_enabled || ! $qf_quote_integration_enabled ); ?>><?php esc_html_e( 'Instant Estimate (Create Invoice)', 'quick-forms' ); ?></option>
                    </select>
                    <p class="description"><?php esc_html_e( 'Capture Only stores submissions and shows a thank-you message. Instant Estimate creates a Quick Quote invoice and redirects the client to it.', 'quick-forms' ); ?></p>
                    <?php if ( ! $qf_quote_integration_enabled ) : ?>
                        <p class="description"><?php esc_html_e( 'Enable Quick Quotes integration in Quick Forms Settings to use Instant Estimate mode.', 'quick-forms' ); ?></p>
                    <?php endif; ?>
                </td>
            </tr>
        </table>

        <h2><?php esc_html_e( 'Fields', 'quick-forms' ); ?></h2>
        <?php if ( ! $premium_enabled ) : ?>
            <div class="notice notice-warning inline"><p><?php esc_html_e( 'Conditional logic and admin email notifications are premium features.', 'quick-forms' ); ?></p></div>
        <?php endif; ?>

        <table class="widefat striped" id="qf-fields-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Type', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Label', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Name Key', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Required', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Placeholder', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Default', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Options (one per line)', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Show If Field', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Show If Value(s)', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Min', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Max', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Regex', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'File Types', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'File Max MB', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Order', 'quick-forms' ); ?></th>
                    <th><?php esc_html_e( 'Delete', 'quick-forms' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if ( ! empty( $fields ) ) : ?>
                    <?php foreach ( $fields as $i => $field ) : ?>
                        <tr class="qf-field-row">
                            <td>
                                <select name="fields[<?php echo absint( $i ); ?>][type]" class="qf-type">
                                    <?php foreach ( array( 'text', 'email', 'phone', 'textarea', 'dropdown', 'checkbox', 'radio', 'consent', 'hidden', 'file' ) as $type ) : ?>
                                        <option value="<?php echo esc_attr( $type ); ?>" <?php selected( $field['type'], $type ); ?>><?php echo esc_html( ucfirst( $type ) ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td><input type="text" name="fields[<?php echo absint( $i ); ?>][label]" value="<?php echo esc_attr( isset( $field['label'] ) ? $field['label'] : '' ); ?>" /></td>
                            <td><input type="text" name="fields[<?php echo absint( $i ); ?>][name]" value="<?php echo esc_attr( isset( $field['name'] ) ? $field['name'] : '' ); ?>" /></td>
                            <td><input type="checkbox" name="fields[<?php echo absint( $i ); ?>][required]" value="1" <?php checked( ! empty( $field['required'] ) ); ?> /></td>
                            <td><input type="text" name="fields[<?php echo absint( $i ); ?>][placeholder]" value="<?php echo esc_attr( isset( $field['placeholder'] ) ? $field['placeholder'] : '' ); ?>" /></td>
                            <td><input type="text" name="fields[<?php echo absint( $i ); ?>][default]" value="<?php echo esc_attr( isset( $field['default'] ) ? $field['default'] : '' ); ?>" /></td>
                            <td><textarea name="fields[<?php echo absint( $i ); ?>][options]"><?php echo esc_textarea( isset( $field['options'] ) ? ( is_array( $field['options'] ) ? implode( "\n", $field['options'] ) : $field['options'] ) : '' ); ?></textarea></td>
                            <td><input type="text" name="fields[<?php echo absint( $i ); ?>][conditional_field]" value="<?php echo esc_attr( isset( $field['conditional_field'] ) ? $field['conditional_field'] : '' ); ?>" placeholder="service_type" <?php disabled( ! $premium_enabled ); ?> /></td>
                            <td><input type="text" name="fields[<?php echo absint( $i ); ?>][conditional_values]" value="<?php echo esc_attr( isset( $field['conditional_values'] ) && is_array( $field['conditional_values'] ) ? implode( ',', $field['conditional_values'] ) : ( isset( $field['conditional_values'] ) ? $field['conditional_values'] : '' ) ); ?>" placeholder="basic,standard" <?php disabled( ! $premium_enabled ); ?> /></td>
                            <td><input type="number" min="0" name="fields[<?php echo absint( $i ); ?>][min_length]" value="<?php echo esc_attr( isset( $field['min_length'] ) ? absint( $field['min_length'] ) : 0 ); ?>" /></td>
                            <td><input type="number" min="0" name="fields[<?php echo absint( $i ); ?>][max_length]" value="<?php echo esc_attr( isset( $field['max_length'] ) ? absint( $field['max_length'] ) : 0 ); ?>" /></td>
                            <td><input type="text" name="fields[<?php echo absint( $i ); ?>][regex]" value="<?php echo esc_attr( isset( $field['regex'] ) ? $field['regex'] : '' ); ?>" /></td>
                            <td><input type="text" name="fields[<?php echo absint( $i ); ?>][allowed_mime]" value="<?php echo esc_attr( isset( $field['allowed_mime'] ) ? $field['allowed_mime'] : '' ); ?>" /></td>
                            <td><input type="number" min="0" name="fields[<?php echo absint( $i ); ?>][max_size_mb]" value="<?php echo esc_attr( isset( $field['max_size_mb'] ) ? absint( $field['max_size_mb'] ) : 0 ); ?>" /></td>
                            <td>
                                <button class="button qf-move-up" type="button">↑</button>
                                <button class="button qf-move-down" type="button">↓</button>
                            </td>
                            <td><button type="button" class="button qf-remove-row"><?php esc_html_e( 'Remove', 'quick-forms' ); ?></button></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <p><button type="button" class="button button-secondary" id="qf-add-field"><?php esc_html_e( 'Add Field', 'quick-forms' ); ?></button></p>

        <h2><?php esc_html_e( 'Form Settings', 'quick-forms' ); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="qfrm_success_message"><?php esc_html_e( 'Success Message', 'quick-forms' ); ?></label></th>
                <td><textarea id="qfrm_success_message" name="settings[success_message]" class="large-text"><?php echo esc_textarea( $form_settings['success_message'] ); ?></textarea></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Admin Email Notification', 'quick-forms' ); ?></th>
                <td><label><input type="checkbox" name="settings[admin_notification]" value="1" <?php checked( ! empty( $form_settings['admin_notification'] ) ); ?> <?php disabled( ! $premium_enabled ); ?> /> <?php esc_html_e( 'Enable', 'quick-forms' ); ?></label></td>
            </tr>
            <tr>
                <th><label for="qfrm_recipients"><?php esc_html_e( 'Notification Recipients', 'quick-forms' ); ?></label></th>
                <td><input id="qfrm_recipients" type="text" class="regular-text" name="settings[notification_recipients]" value="<?php echo esc_attr( $form_settings['notification_recipients'] ); ?>" <?php disabled( ! $premium_enabled ); ?> /><p class="description"><?php esc_html_e( 'Comma-separated emails.', 'quick-forms' ); ?></p></td>
            </tr>
            <tr>
                <th><label for="qfrm_email_subject"><?php esc_html_e( 'Email Subject Template', 'quick-forms' ); ?></label></th>
                <td><input id="qfrm_email_subject" type="text" class="regular-text" name="settings[email_subject]" value="<?php echo esc_attr( $form_settings['email_subject'] ); ?>" <?php disabled( ! $premium_enabled ); ?> /><p class="description"><?php esc_html_e( 'Supports {{form_name}}.', 'quick-forms' ); ?></p></td>
            </tr>
            <tr>
                <th><label for="qfrm_redirect_url"><?php esc_html_e( 'Redirect URL', 'quick-forms' ); ?></label></th>
                <td><input id="qfrm_redirect_url" type="url" class="regular-text" name="settings[redirect_url]" value="<?php echo esc_attr( $form_settings['redirect_url'] ); ?>" /></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Save to Database', 'quick-forms' ); ?></th>
                <td><label><input type="checkbox" name="settings[save_to_db]" value="1" <?php checked( ! empty( $form_settings['save_to_db'] ) ); ?> /> <?php esc_html_e( 'Enable', 'quick-forms' ); ?></label></td>
            </tr>
            <tr>
                <th><?php esc_html_e( 'Spam Protection', 'quick-forms' ); ?></th>
                <td><label><input type="checkbox" name="settings[spam_protection]" value="1" <?php checked( ! empty( $form_settings['spam_protection'] ) ); ?> /> <?php esc_html_e( 'Enable honeypot + rate limit', 'quick-forms' ); ?></label></td>
            </tr>
        </table>

        <?php submit_button( $form_id ? __( 'Update Form', 'quick-forms' ) : __( 'Create Form', 'quick-forms' ) ); ?>
    </form>
</div>
