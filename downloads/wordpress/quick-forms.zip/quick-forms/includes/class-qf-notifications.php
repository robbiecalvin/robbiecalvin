<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QFRM_Notifications {

    public function hooks() {
        add_action( 'admin_notices', array( $this, 'render_admin_notice' ) );
        add_action( 'admin_post_qfrm_dismiss_notice', array( $this, 'dismiss_notice' ) );
        add_action( 'admin_post_qf_dismiss_notice', array( $this, 'dismiss_notice' ) );
    }

    public function render_admin_notice() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $count = qfrm_new_submissions_count();
        if ( $count < 1 ) {
            return;
        }

        $dismiss_url = wp_nonce_url(
            admin_url( 'admin-post.php?action=qfrm_dismiss_notice' ),
            'qfrm_dismiss_notice',
            'qfrm_notice_nonce'
        );

        $submissions_url = admin_url( 'admin.php?page=quick-forms-submissions' );

        ?>
        <div class="notice notice-info is-dismissible qf-admin-notice">
            <p>
                <?php
                printf(
                    esc_html__( 'Quick Forms: You have %d new submissions.', 'quick-forms' ),
                    absint( $count )
                );
                ?>
                <a href="<?php echo esc_url( $submissions_url ); ?>"><?php esc_html_e( 'View submissions', 'quick-forms' ); ?></a>
            </p>
            <p>
                <a class="button button-secondary" href="<?php echo esc_url( $dismiss_url ); ?>"><?php esc_html_e( 'Dismiss', 'quick-forms' ); ?></a>
            </p>
        </div>
        <?php
    }

    public function dismiss_notice() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        check_admin_referer( 'qfrm_dismiss_notice', 'qfrm_notice_nonce' );
        qfrm_reset_new_submission_count();

        wp_safe_redirect( admin_url( 'admin.php?page=quick-forms-submissions' ) );
        exit;
    }
}
