<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QFRM_Submissions {

    public function hooks() {
        add_action( 'admin_post_qfrm_mark_submission', array( $this, 'handle_mark_status' ) );
        add_action( 'admin_post_qf_mark_submission', array( $this, 'handle_mark_status' ) );
        add_action( 'admin_post_qfrm_delete_submission', array( $this, 'handle_delete_submission' ) );
        add_action( 'admin_post_qf_delete_submission', array( $this, 'handle_delete_submission' ) );
        add_action( 'admin_post_qfrm_export_csv', array( $this, 'handle_export_csv' ) );
        add_action( 'admin_post_qf_export_csv', array( $this, 'handle_export_csv' ) );
    }

    public function get_counts_by_form() {
        global $wpdb;

        $table = qfrm_table_submissions();
        $rows  = $wpdb->get_results( "SELECT form_id, COUNT(*) as total, SUM(CASE WHEN status = 'new' THEN 1 ELSE 0 END) as new_count FROM {$table} GROUP BY form_id", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        $mapped = array();
        foreach ( $rows as $row ) {
            $mapped[ absint( $row['form_id'] ) ] = array(
                'total' => absint( $row['total'] ),
                'new'   => absint( $row['new_count'] ),
            );
        }

        return $mapped;
    }

    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        $submission_id = isset( $_GET['submission_id'] ) ? absint( $_GET['submission_id'] ) : 0;

        if ( $submission_id ) {
            $submission = $this->get_submission( $submission_id );
            include QUICK_FORMS_PATH . 'templates/admin-submission-view.php';
            return;
        }

        $forms = ( new QFRM_Builder() )->get_forms();

        $filters = array(
            'form_id'    => isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0,
            'status'     => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '',
            'date_start' => isset( $_GET['date_start'] ) ? sanitize_text_field( wp_unslash( $_GET['date_start'] ) ) : '',
            'date_end'   => isset( $_GET['date_end'] ) ? sanitize_text_field( wp_unslash( $_GET['date_end'] ) ) : '',
            'paged'      => isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1,
        );

        $per_page    = 20;
        $query_data  = $this->query_submissions( $filters, $per_page );
        $submissions = $query_data['rows'];
        $total       = $query_data['total'];
        $total_pages = (int) ceil( $total / $per_page );

        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Quick Forms Submissions', 'quick-forms' ); ?></h1>

            <form method="get" class="qf-filters">
                <input type="hidden" name="page" value="quick-forms-submissions" />
                <select name="form_id">
                    <option value="0"><?php esc_html_e( 'All forms', 'quick-forms' ); ?></option>
                    <?php foreach ( $forms as $form ) : ?>
                        <option value="<?php echo absint( $form['id'] ); ?>" <?php selected( $filters['form_id'], absint( $form['id'] ) ); ?>>
                            <?php echo esc_html( $form['name'] ); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="status">
                    <option value=""><?php esc_html_e( 'All statuses', 'quick-forms' ); ?></option>
                    <option value="new" <?php selected( $filters['status'], 'new' ); ?>><?php esc_html_e( 'New', 'quick-forms' ); ?></option>
                    <option value="read" <?php selected( $filters['status'], 'read' ); ?>><?php esc_html_e( 'Read', 'quick-forms' ); ?></option>
                </select>

                <input type="date" name="date_start" value="<?php echo esc_attr( $filters['date_start'] ); ?>" />
                <input type="date" name="date_end" value="<?php echo esc_attr( $filters['date_end'] ); ?>" />
                <button type="submit" class="button button-secondary"><?php esc_html_e( 'Filter', 'quick-forms' ); ?></button>
            </form>

            <p>
                <?php if ( $filters['form_id'] ) : ?>
                    <?php $export_url = wp_nonce_url( admin_url( 'admin-post.php?action=qfrm_export_csv&form_id=' . absint( $filters['form_id'] ) ), 'qfrm_export_csv', 'qfrm_nonce' ); ?>
                    <a href="<?php echo esc_url( $export_url ); ?>" class="button button-primary"><?php esc_html_e( 'Export CSV for Selected Form', 'quick-forms' ); ?></a>
                <?php endif; ?>
            </p>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'ID', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Form', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'quick-forms' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $submissions ) ) : ?>
                        <tr><td colspan="5"><?php esc_html_e( 'No submissions found.', 'quick-forms' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $submissions as $submission ) : ?>
                            <?php $view_url = admin_url( 'admin.php?page=quick-forms-submissions&submission_id=' . absint( $submission['id'] ) ); ?>
                            <?php $toggle_to = ( 'new' === $submission['status'] ) ? 'read' : 'new'; ?>
                            <?php
                            $mark_url = wp_nonce_url(
                                admin_url( 'admin-post.php?action=qfrm_mark_submission&id=' . absint( $submission['id'] ) . '&status=' . $toggle_to ),
                                'qfrm_mark_submission_' . absint( $submission['id'] ),
                                'qfrm_nonce'
                            );
                            $delete_url = wp_nonce_url(
                                admin_url( 'admin-post.php?action=qfrm_delete_submission&id=' . absint( $submission['id'] ) ),
                                'qfrm_delete_submission_' . absint( $submission['id'] ),
                                'qfrm_nonce'
                            );
                            ?>
                            <tr>
                                <td><?php echo absint( $submission['id'] ); ?></td>
                                <td><?php echo esc_html( $submission['form_name'] ); ?></td>
                                <td><?php echo esc_html( ucfirst( $submission['status'] ) ); ?></td>
                                <td><?php echo esc_html( $submission['created_at'] ); ?></td>
                                <td>
                                    <a href="<?php echo esc_url( $view_url ); ?>"><?php esc_html_e( 'View', 'quick-forms' ); ?></a> |
                                    <a href="<?php echo esc_url( $mark_url ); ?>"><?php echo esc_html( 'new' === $submission['status'] ? __( 'Mark Read', 'quick-forms' ) : __( 'Mark New', 'quick-forms' ) ); ?></a> |
                                    <a href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this submission?', 'quick-forms' ) ); ?>')"><?php esc_html_e( 'Delete', 'quick-forms' ); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php if ( $total_pages > 1 ) : ?>
                <div class="tablenav"><div class="tablenav-pages">
                    <?php
                    echo wp_kses_post(
                        paginate_links(
                            array(
                                'base'      => add_query_arg( 'paged', '%#%' ),
                                'format'    => '',
                                'current'   => $filters['paged'],
                                'total'     => $total_pages,
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                            )
                        )
                    );
                    ?>
                </div></div>
            <?php endif; ?>
        </div>
        <?php
    }

    public function query_submissions( $filters, $per_page = 20 ) {
        global $wpdb;

        $sub_table  = qfrm_table_submissions();
        $form_table = qfrm_table_forms();

        $where  = ' WHERE 1=1 ';
        $params = array();

        if ( ! empty( $filters['form_id'] ) ) {
            $where    .= ' AND s.form_id = %d ';
            $params[] = absint( $filters['form_id'] );
        }

        if ( ! empty( $filters['status'] ) && in_array( $filters['status'], array( 'new', 'read' ), true ) ) {
            $where    .= ' AND s.status = %s ';
            $params[] = $filters['status'];
        }

        if ( ! empty( $filters['date_start'] ) ) {
            $where    .= ' AND DATE(s.created_at) >= %s ';
            $params[] = $filters['date_start'];
        }

        if ( ! empty( $filters['date_end'] ) ) {
            $where    .= ' AND DATE(s.created_at) <= %s ';
            $params[] = $filters['date_end'];
        }

        $count_sql = "SELECT COUNT(*) FROM {$sub_table} s {$where}";
        if ( ! empty( $params ) ) {
            $count_sql = $wpdb->prepare( $count_sql, $params );
        }
        $total     = (int) $wpdb->get_var( $count_sql );

        $offset = ( max( 1, absint( $filters['paged'] ) ) - 1 ) * $per_page;

        $rows_sql = "SELECT s.*, f.name AS form_name
                    FROM {$sub_table} s
                    LEFT JOIN {$form_table} f ON f.id = s.form_id
                    {$where}
                    ORDER BY s.id DESC
                    LIMIT %d OFFSET %d";

        $row_params   = $params;
        $row_params[] = absint( $per_page );
        $row_params[] = absint( $offset );

        $rows_sql = $wpdb->prepare( $rows_sql, $row_params );
        $rows     = $wpdb->get_results( $rows_sql, ARRAY_A );

        return array(
            'rows'  => $rows,
            'total' => $total,
        );
    }

    public function get_submission( $submission_id ) {
        global $wpdb;

        $sub_table  = qfrm_table_submissions();
        $form_table = qfrm_table_forms();

        $sql = $wpdb->prepare(
            "SELECT s.*, f.name AS form_name
            FROM {$sub_table} s
            LEFT JOIN {$form_table} f ON f.id = s.form_id
            WHERE s.id = %d
            LIMIT 1",
            absint( $submission_id )
        );

        return $wpdb->get_row( $sql, ARRAY_A );
    }

    public function handle_mark_status() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        $submission_id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
        $status        = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : 'read';

        check_admin_referer( 'qfrm_mark_submission_' . $submission_id, 'qfrm_nonce' );

        if ( ! in_array( $status, array( 'new', 'read' ), true ) ) {
            $status = 'read';
        }

        global $wpdb;
        $table = qfrm_table_submissions();

        $sql = $wpdb->prepare( "UPDATE {$table} SET status = %s WHERE id = %d", $status, $submission_id );
        $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        wp_safe_redirect( admin_url( 'admin.php?page=quick-forms-submissions' ) );
        exit;
    }

    public function handle_delete_submission() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        $submission_id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
        check_admin_referer( 'qfrm_delete_submission_' . $submission_id, 'qfrm_nonce' );

        global $wpdb;
        $table = qfrm_table_submissions();

        $sql = $wpdb->prepare( "DELETE FROM {$table} WHERE id = %d", $submission_id );
        $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        wp_safe_redirect( admin_url( 'admin.php?page=quick-forms-submissions' ) );
        exit;
    }

    public function handle_export_csv() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        check_admin_referer( 'qfrm_export_csv', 'qfrm_nonce' );

        $form_id = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0;
        if ( ! $form_id ) {
            wp_die( esc_html__( 'Form ID is required.', 'quick-forms' ) );
        }

        global $wpdb;
        $table = qfrm_table_submissions();

        $sql  = $wpdb->prepare( "SELECT * FROM {$table} WHERE form_id = %d ORDER BY id DESC", $form_id );
        $rows = $wpdb->get_results( $sql, ARRAY_A );

        $filename = 'quick-forms-submissions-' . $form_id . '-' . gmdate( 'Ymd-His' ) . '.csv';

        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=' . $filename );

        $out = fopen( 'php://output', 'w' );
        fputcsv( $out, array( 'Submission ID', 'Form ID', 'Status', 'Created At', 'Data JSON', 'Files JSON' ) );

        foreach ( $rows as $row ) {
            fputcsv(
                $out,
                array(
                    $row['id'],
                    $row['form_id'],
                    $row['status'],
                    $row['created_at'],
                    $row['submitted_data_json'],
                    $row['files_json'],
                )
            );
        }

        fclose( $out );
        exit;
    }
}
