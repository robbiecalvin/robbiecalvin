<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QFRM_Builder {

    public function get_forms() {
        global $wpdb;
        $table = qfrm_table_forms();

        return $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    }

    public function get_form( $form_id ) {
        global $wpdb;
        $table = qfrm_table_forms();

        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", absint( $form_id ) );
        return $wpdb->get_row( $sql, ARRAY_A );
    }

    public function get_form_by_slug( $slug ) {
        global $wpdb;
        $table = qfrm_table_forms();

        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE slug = %s LIMIT 1", sanitize_title( $slug ) );
        return $wpdb->get_row( $sql, ARRAY_A );
    }

    public function get_active_form_by_quote_type( $quote_type ) {
        $quote_type = sanitize_title( $quote_type );
        if ( '' === $quote_type ) {
            return null;
        }

        $forms = $this->get_forms();
        foreach ( $forms as $form ) {
            if ( 'active' !== $form['status'] ) {
                continue;
            }

            $settings = qfrm_decode_json_array( $form['settings_json'] );
            $current  = isset( $settings['quote_type'] ) ? sanitize_title( $settings['quote_type'] ) : '';

            if ( $quote_type === $current ) {
                return $form;
            }
        }

        return null;
    }

    public function save_form( $form_id, $raw ) {
        global $wpdb;

        $table = qfrm_table_forms();

        $name = isset( $raw['name'] ) ? sanitize_text_field( wp_unslash( $raw['name'] ) ) : '';
        if ( '' === $name ) {
            return new WP_Error( 'qfrm_invalid_name', __( 'Form name is required.', 'quick-forms' ) );
        }

        $slug = isset( $raw['slug'] ) ? sanitize_title( wp_unslash( $raw['slug'] ) ) : '';
        if ( '' === $slug ) {
            $slug = sanitize_title( $name );
        }

        $fields   = $this->sanitize_fields( isset( $raw['fields'] ) ? $raw['fields'] : array() );
        $settings = $this->sanitize_form_settings( isset( $raw['settings'] ) ? $raw['settings'] : array() );

        if ( empty( $fields ) ) {
            return new WP_Error( 'qfrm_invalid_fields', __( 'At least one field is required.', 'quick-forms' ) );
        }

        if ( $form_id ) {
            $existing = $this->get_form( $form_id );
            if ( ! $existing ) {
                return new WP_Error( 'qfrm_not_found', __( 'Form not found.', 'quick-forms' ) );
            }

            $maybe_conflict = $this->get_form_by_slug( $slug );
            if ( $maybe_conflict && absint( $maybe_conflict['id'] ) !== absint( $form_id ) ) {
                $slug .= '-' . absint( $form_id );
            }

            $sql = $wpdb->prepare(
                "UPDATE {$table}
                SET name = %s,
                    slug = %s,
                    fields_json = %s,
                    settings_json = %s,
                    updated_at = %s
                WHERE id = %d",
                $name,
                $slug,
                wp_json_encode( $fields ),
                wp_json_encode( $settings ),
                qfrm_now_mysql(),
                absint( $form_id )
            );

            $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            return absint( $form_id );
        }

        $maybe_conflict = $this->get_form_by_slug( $slug );
        if ( $maybe_conflict ) {
            $slug .= '-' . time();
        }

        $sql = $wpdb->prepare(
            "INSERT INTO {$table}
            (name, slug, fields_json, settings_json, status, created_at, updated_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s)",
            $name,
            $slug,
            wp_json_encode( $fields ),
            wp_json_encode( $settings ),
            'active',
            qfrm_now_mysql(),
            qfrm_now_mysql()
        );

        $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return absint( $wpdb->insert_id );
    }

    public function delete_form( $form_id ) {
        global $wpdb;

        $forms_table       = qfrm_table_forms();
        $submissions_table = qfrm_table_submissions();

        $sql_sub = $wpdb->prepare( "DELETE FROM {$submissions_table} WHERE form_id = %d", absint( $form_id ) );
        $wpdb->query( $sql_sub ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        $sql = $wpdb->prepare( "DELETE FROM {$forms_table} WHERE id = %d", absint( $form_id ) );
        return (bool) $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    }

    public function duplicate_form( $form_id ) {
        $form = $this->get_form( $form_id );
        if ( ! $form ) {
            return new WP_Error( 'qfrm_not_found', __( 'Form not found.', 'quick-forms' ) );
        }

        $settings = qfrm_decode_json_array( $form['settings_json'] );
        if ( ! empty( $settings['quote_type'] ) ) {
            $settings['quote_type'] = sanitize_title( $settings['quote_type'] ) . '-copy-' . time();
        }

        $payload = array(
            'name'     => $form['name'] . ' (Copy)',
            'slug'     => $form['slug'] . '-copy-' . time(),
            'fields'   => qfrm_decode_json_array( $form['fields_json'] ),
            'settings' => $settings,
        );

        return $this->save_form( 0, $payload );
    }

    public function set_status( $form_id, $status ) {
        global $wpdb;

        $table  = qfrm_table_forms();
        $status = ( 'inactive' === $status ) ? 'inactive' : 'active';

        $sql = $wpdb->prepare(
            "UPDATE {$table} SET status = %s, updated_at = %s WHERE id = %d",
            $status,
            qfrm_now_mysql(),
            absint( $form_id )
        );

        return (bool) $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    }

    public function sanitize_fields( $fields ) {
        if ( ! is_array( $fields ) ) {
            return array();
        }

        $premium_enabled = qfrm_is_premium_active();
        $allowed_types = array( 'text', 'email', 'phone', 'textarea', 'dropdown', 'checkbox', 'radio', 'consent', 'hidden', 'file' );
        $output        = array();

        foreach ( $fields as $field ) {
            if ( ! is_array( $field ) ) {
                continue;
            }

            $type = isset( $field['type'] ) ? sanitize_key( $field['type'] ) : '';
            if ( ! in_array( $type, $allowed_types, true ) ) {
                continue;
            }

            $name = isset( $field['name'] ) ? sanitize_key( $field['name'] ) : '';
            if ( '' === $name ) {
                continue;
            }

            $clean = array(
                'type'         => $type,
                'label'        => isset( $field['label'] ) ? sanitize_text_field( $field['label'] ) : ucfirst( $name ),
                'name'         => $name,
                'required'     => empty( $field['required'] ) ? 0 : 1,
                'placeholder'  => isset( $field['placeholder'] ) ? sanitize_text_field( $field['placeholder'] ) : '',
                'default'      => isset( $field['default'] ) ? sanitize_text_field( $field['default'] ) : '',
                'options'      => array(),
                'conditional_field' => '',
                'conditional_values' => array(),
                'min_length'   => isset( $field['min_length'] ) ? absint( $field['min_length'] ) : 0,
                'max_length'   => isset( $field['max_length'] ) ? absint( $field['max_length'] ) : 0,
                'regex'        => isset( $field['regex'] ) ? sanitize_text_field( $field['regex'] ) : '',
                'allowed_mime' => isset( $field['allowed_mime'] ) ? sanitize_text_field( $field['allowed_mime'] ) : '',
                'max_size_mb'  => isset( $field['max_size_mb'] ) ? absint( $field['max_size_mb'] ) : 0,
            );

            if ( in_array( $type, array( 'dropdown', 'radio', 'checkbox' ), true ) ) {
                $opts = array();
                if ( isset( $field['options'] ) ) {
                    if ( is_array( $field['options'] ) ) {
                        $opts = $field['options'];
                    } else {
                        $opts = explode( "\n", (string) $field['options'] );
                    }
                }

                $clean_opts = array();
                foreach ( $opts as $opt ) {
                    $opt = sanitize_text_field( $opt );
                    if ( '' !== $opt ) {
                        $clean_opts[] = $opt;
                    }
                }
                $clean['options'] = array_values( $clean_opts );
            }

            if ( 'consent' === $type ) {
                $clean['required'] = 1;
            }

            $conditional_field = isset( $field['conditional_field'] ) ? sanitize_key( $field['conditional_field'] ) : '';
            if ( $conditional_field === $name ) {
                $conditional_field = '';
            }

            $conditional_values = array();
            if ( isset( $field['conditional_values'] ) ) {
                if ( is_array( $field['conditional_values'] ) ) {
                    $raw_values = $field['conditional_values'];
                } else {
                    $raw_values = explode( ',', (string) $field['conditional_values'] );
                }

                foreach ( $raw_values as $raw_value ) {
                    $value = sanitize_text_field( trim( (string) $raw_value ) );
                    if ( '' !== $value ) {
                        $conditional_values[] = $value;
                    }
                }
            }

            if ( $premium_enabled && '' !== $conditional_field && ! empty( $conditional_values ) ) {
                $clean['conditional_field']  = $conditional_field;
                $clean['conditional_values'] = array_values( array_unique( $conditional_values ) );
            }

            $output[] = $clean;
        }

        return $output;
    }

    public function sanitize_form_settings( $settings ) {
        if ( ! is_array( $settings ) ) {
            $settings = array();
        }

        $global = qfrm_get_settings();
        $premium_enabled = qfrm_is_premium_active();
        $submission_mode = isset( $settings['submission_mode'] ) && 'instant_estimate' === sanitize_key( (string) $settings['submission_mode'] ) ? 'instant_estimate' : 'capture_only';
        if ( ! $premium_enabled || empty( $global['integrate_quick_quotes'] ) ) {
            $submission_mode = 'capture_only';
        }

        return array(
            'quote_type'              => isset( $settings['quote_type'] ) ? sanitize_title( $settings['quote_type'] ) : '',
            'submission_mode'         => $submission_mode,
            'success_message'         => isset( $settings['success_message'] ) ? sanitize_textarea_field( $settings['success_message'] ) : 'Thank you! Your submission has been received.',
            'admin_notification'      => $premium_enabled && ! empty( $settings['admin_notification'] ) ? 1 : 0,
            'notification_recipients' => isset( $settings['notification_recipients'] ) ? sanitize_text_field( $settings['notification_recipients'] ) : $global['default_notification_email'],
            'email_subject'           => isset( $settings['email_subject'] ) ? sanitize_text_field( $settings['email_subject'] ) : 'New submission for {{form_name}}',
            'redirect_url'            => isset( $settings['redirect_url'] ) ? esc_url_raw( $settings['redirect_url'] ) : '',
            'save_to_db'              => isset( $settings['save_to_db'] ) ? ( empty( $settings['save_to_db'] ) ? 0 : 1 ) : 1,
            'spam_protection'         => isset( $settings['spam_protection'] ) ? ( empty( $settings['spam_protection'] ) ? 0 : 1 ) : 1,
        );
    }
}
