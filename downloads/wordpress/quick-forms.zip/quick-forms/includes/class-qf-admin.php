<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QFRM_Admin {

    private $builder;
    private $submissions;
    private $settings;

    public function __construct() {
        $this->builder     = new QFRM_Builder();
        $this->submissions = new QFRM_Submissions();
        $this->settings    = new QFRM_Settings();
    }

    public function hooks() {
        add_action( 'admin_menu', array( $this, 'admin_menu' ) );
        add_action( 'admin_init', array( $this, 'admin_init' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'admin_post_qfrm_save_form', array( $this, 'handle_save_form' ) );
        add_action( 'admin_post_qf_save_form', array( $this, 'handle_save_form' ) );
        add_action( 'admin_post_qfrm_form_action', array( $this, 'handle_form_action' ) );
        add_action( 'admin_post_qf_form_action', array( $this, 'handle_form_action' ) );
        add_action( 'admin_post_qfrm_activate_license', array( $this, 'handle_activate_license' ) );
        add_action( 'admin_post_qfrm_deactivate_license', array( $this, 'handle_deactivate_license' ) );
        add_action( 'admin_post_qfrm_save_style', array( $this, 'handle_save_style' ) );

        $this->submissions->hooks();
    }

    public function admin_init() {
        $this->settings->register();
    }

    public function enqueue_assets( $hook ) {
        if ( false === strpos( $hook, 'quick-forms' ) ) {
            return;
        }

        wp_enqueue_style( 'quick-forms-admin', QUICK_FORMS_URL . 'assets/css/admin.css', array(), QUICK_FORMS_VERSION );
        wp_enqueue_style( 'quick-forms-admin-ui', QUICK_FORMS_URL . 'assets/css/admin-ui.css', array( 'quick-forms-admin' ), QUICK_FORMS_VERSION );
        wp_enqueue_script( 'quick-forms-admin', QUICK_FORMS_URL . 'assets/js/admin.js', array( 'jquery' ), QUICK_FORMS_VERSION, true );
        wp_enqueue_script( 'quick-forms-admin-ui', QUICK_FORMS_URL . 'assets/js/admin-ui.js', array( 'quick-forms-admin' ), QUICK_FORMS_VERSION, true );
    }

    public function admin_menu() {
        add_menu_page(
            __( 'Quick Forms', 'quick-forms' ),
            __( 'Quick Forms', 'quick-forms' ),
            'manage_options',
            'quick-forms',
            array( $this, 'render_forms_page' ),
            'dashicons-feedback',
            56
        );

        add_submenu_page(
            'quick-forms',
            __( 'Forms', 'quick-forms' ),
            __( 'Forms', 'quick-forms' ),
            'manage_options',
            'quick-forms',
            array( $this, 'render_forms_page' )
        );

        add_submenu_page(
            'quick-forms',
            __( 'Add New', 'quick-forms' ),
            __( 'Add New', 'quick-forms' ),
            'manage_options',
            'quick-forms-add-new',
            array( $this, 'render_add_edit_page' )
        );

        add_submenu_page(
            'quick-forms',
            __( 'Submissions', 'quick-forms' ),
            __( 'Submissions', 'quick-forms' ),
            'manage_options',
            'quick-forms-submissions',
            array( $this, 'render_submissions_page' )
        );

        add_submenu_page(
            'quick-forms',
            __( 'Settings', 'quick-forms' ),
            __( 'Settings', 'quick-forms' ),
            'manage_options',
            'quick-forms-settings',
            array( $this, 'render_settings_page' )
        );

        add_submenu_page(
            'quick-forms',
            __( 'Style', 'quick-forms' ),
            __( 'Style', 'quick-forms' ),
            'manage_options',
            'quick-forms-style',
            array( $this, 'render_style_page' )
        );
    }

    public function render_forms_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        $forms  = $this->builder->get_forms();
        $counts = $this->submissions->get_counts_by_form();
        $settings = qfrm_get_settings();
        $license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';
        $license_status = isset( $settings['license_status'] ) ? sanitize_key( (string) $settings['license_status'] ) : 'inactive';
        $license_data = null;
        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $license_data = qlic_get_license_status_for_key_products(
                $license_key,
                array(
                    'quick-forms',
                    'quick-forms-one-site',
                    'quick-forms-five-sites',
                    'quick-forms-unlimited-sites',
                    'quick-woo-bundle',
                    'quick-woo-suite',
                    'quick-bundle',
                    'quick-secretary',
                )
            );
            if ( is_array( $license_data ) ) {
                $license_status = isset( $license_data['status'] ) ? sanitize_key( (string) $license_data['status'] ) : $license_status;
                if ( ! empty( $license_data['valid'] ) && ! empty( $license_data['domain_active'] ) ) {
                    $license_status = 'active';
                }
            }
        }

        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline"><?php esc_html_e( 'Quick Forms', 'quick-forms' ); ?></h1>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=quick-forms-add-new' ) ); ?>" class="page-title-action"><?php esc_html_e( 'Add New', 'quick-forms' ); ?></a>
            <div class="notice notice-info inline">
                <p>
                    <strong><?php esc_html_e( 'License:', 'quick-forms' ); ?></strong>
                    <?php echo esc_html( ucfirst( $license_status ) ); ?>
                    <?php if ( is_array( $license_data ) && ! empty( $license_data['product_slug'] ) ) : ?>
                        <?php echo esc_html( sprintf( __( ' (%s)', 'quick-forms' ), (string) $license_data['product_slug'] ) ); ?>
                    <?php endif; ?>
                    <?php if ( is_array( $license_data ) && isset( $license_data['activations'], $license_data['activation_limit'] ) ) : ?>
                        <?php echo esc_html( sprintf( __( ' - Activations: %1$s/%2$s', 'quick-forms' ), (string) $license_data['activations'], (string) $license_data['activation_limit'] ) ); ?>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=quick-forms-settings' ) ); ?>"><?php esc_html_e( 'Manage License', 'quick-forms' ); ?></a>
                </p>
            </div>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'ID', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Name', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Quote Type', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Slug', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Submissions', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Shortcode', 'quick-forms' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'quick-forms' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $forms ) ) : ?>
                        <tr><td colspan="8"><?php esc_html_e( 'No forms found.', 'quick-forms' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $forms as $form ) : ?>
                            <?php
                            $form_id   = absint( $form['id'] );
                            $form_stat = isset( $counts[ $form_id ] ) ? $counts[ $form_id ] : array( 'total' => 0, 'new' => 0 );
                            $form_settings = qfrm_decode_json_array( $form['settings_json'] );
                            $quote_type    = isset( $form_settings['quote_type'] ) ? sanitize_title( $form_settings['quote_type'] ) : '';

                            $edit_url = admin_url( 'admin.php?page=quick-forms-add-new&form_id=' . $form_id );
                            $dup_url  = wp_nonce_url( admin_url( 'admin-post.php?action=qfrm_form_action&do=duplicate&id=' . $form_id ), 'qfrm_form_action_' . $form_id, 'qfrm_nonce' );
                            $del_url  = wp_nonce_url( admin_url( 'admin-post.php?action=qfrm_form_action&do=delete&id=' . $form_id ), 'qfrm_form_action_' . $form_id, 'qfrm_nonce' );
                            $toggle   = ( 'active' === $form['status'] ) ? 'inactive' : 'active';
                            $tog_url  = wp_nonce_url( admin_url( 'admin-post.php?action=qfrm_form_action&do=toggle&id=' . $form_id . '&status=' . $toggle ), 'qfrm_form_action_' . $form_id, 'qfrm_nonce' );
                            ?>
                            <tr>
                                <td><?php echo $form_id; ?></td>
                                <td><?php echo esc_html( $form['name'] ); ?></td>
                                <td><code><?php echo esc_html( $quote_type ? $quote_type : '-' ); ?></code></td>
                                <td><?php echo esc_html( $form['slug'] ); ?></td>
                                <td><?php echo esc_html( ucfirst( $form['status'] ) ); ?></td>
                                <td>
                                    <?php
                                    printf(
                                        esc_html__( '%1$d total (%2$d new)', 'quick-forms' ),
                                        absint( $form_stat['total'] ),
                                        absint( $form_stat['new'] )
                                    );
                                    ?>
                                </td>
                                <td>
                                    <code>[quick_form id="<?php echo $form_id; ?>"]</code>
                                    <?php if ( $quote_type ) : ?>
                                        <br /><code>[quick_form quote_type="<?php echo esc_attr( $quote_type ); ?>"]</code>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'quick-forms' ); ?></a> |
                                    <a href="<?php echo esc_url( $dup_url ); ?>"><?php esc_html_e( 'Duplicate', 'quick-forms' ); ?></a> |
                                    <a href="<?php echo esc_url( $tog_url ); ?>"><?php echo esc_html( 'active' === $form['status'] ? __( 'Deactivate', 'quick-forms' ) : __( 'Activate', 'quick-forms' ) ); ?></a> |
                                    <a href="<?php echo esc_url( $del_url ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this form and all submissions?', 'quick-forms' ) ); ?>')"><?php esc_html_e( 'Delete', 'quick-forms' ); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function render_add_edit_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        $form_id = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0;
        $form    = $form_id ? $this->builder->get_form( $form_id ) : null;

        $fields = array();
        $form_settings = array();

        if ( $form ) {
            $fields        = qfrm_decode_json_array( $form['fields_json'] );
            $form_settings = qfrm_decode_json_array( $form['settings_json'] );
        }

        include QUICK_FORMS_PATH . 'templates/admin-form-editor.php';
    }

    public function render_submissions_page() {
        $this->submissions->render_page();
    }

    public function render_settings_page() {
        $this->settings->render_page();
    }

    public function render_style_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        $settings = qfrm_get_settings();
        $custom_css = isset( $settings['custom_form_css'] ) ? (string) $settings['custom_form_css'] : '';
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Quick Forms Style', 'quick-forms' ); ?></h1>
            <p><?php esc_html_e( 'Add custom CSS for Quick Forms frontend forms.', 'quick-forms' ); ?></p>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qfrm_save_style" />
                <?php wp_nonce_field( 'qfrm_save_style', 'qfrm_save_style_nonce' ); ?>
                <textarea name="custom_form_css" rows="18" class="large-text code"><?php echo esc_textarea( $custom_css ); ?></textarea>
                <?php submit_button( __( 'Save Style', 'quick-forms' ) ); ?>
            </form>
        </div>
        <?php
    }

    public function handle_save_form() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        check_admin_referer( 'qfrm_save_form', 'qfrm_nonce' );

        $form_id = isset( $_POST['form_id'] ) ? absint( $_POST['form_id'] ) : 0;

        $raw = array(
            'name'     => isset( $_POST['name'] ) ? wp_unslash( $_POST['name'] ) : '',
            'slug'     => isset( $_POST['slug'] ) ? wp_unslash( $_POST['slug'] ) : '',
            'fields'   => isset( $_POST['fields'] ) ? wp_unslash( $_POST['fields'] ) : array(),
            'settings' => isset( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : array(),
        );

        $result = $this->builder->save_form( $form_id, $raw );

        if ( is_wp_error( $result ) ) {
            $target = admin_url( 'admin.php?page=quick-forms-add-new' );
            if ( $form_id ) {
                $target = add_query_arg( 'form_id', $form_id, $target );
            }
            $target = add_query_arg( 'qfrm_error', rawurlencode( $result->get_error_message() ), $target );
            wp_safe_redirect( $target );
            exit;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=quick-forms' ) );
        exit;
    }

    public function handle_form_action() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        $form_id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
        $action  = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : '';

        check_admin_referer( 'qfrm_form_action_' . $form_id, 'qfrm_nonce' );

        if ( 'delete' === $action ) {
            $this->builder->delete_form( $form_id );
        } elseif ( 'duplicate' === $action ) {
            $this->builder->duplicate_form( $form_id );
        } elseif ( 'toggle' === $action ) {
            $status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : 'inactive';
            $this->builder->set_status( $form_id, $status );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=quick-forms' ) );
        exit;
    }

    public function handle_activate_license() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        check_admin_referer( 'qfrm_activate_license', 'qfrm_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        $settings = qfrm_get_settings();

        if ( '' === $license_key ) {
            $settings['license_key'] = '';
            $settings['license_status'] = 'inactive';
            $settings['license_message'] = __( 'License key is required.', 'quick-forms' );
            update_option( 'qfrm_settings', $settings );
            wp_safe_redirect( admin_url( 'admin.php?page=quick-forms-settings' ) );
            exit;
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            $settings['license_key'] = $license_key;
            $settings['license_status'] = 'invalid';
            $settings['license_message'] = __( 'Quick Woo License plugin is required for activation.', 'quick-forms' );
            update_option( 'qfrm_settings', $settings );
            wp_safe_redirect( admin_url( 'admin.php?page=quick-forms-settings' ) );
            exit;
        }

        $result = qlic_activate_license_key_for_products(
            $license_key,
            array(
                'quick-forms',
                'quick-forms-one-site',
                'quick-forms-five-sites',
                'quick-forms-unlimited-sites',
                'quick-woo-bundle',
                'quick-woo-suite',
                'quick-bundle',
                    'quick-secretary',
                )
        );

        $settings['license_key'] = $license_key;
        $settings['license_status'] = isset( $result['status'] ) ? sanitize_key( (string) $result['status'] ) : 'invalid';
        $settings['license_message'] = isset( $result['message'] ) ? sanitize_text_field( (string) $result['message'] ) : __( 'License validation failed.', 'quick-forms' );
        if ( ! empty( $result['valid'] ) ) {
            $settings['license_status'] = 'active';
        }

        update_option( 'qfrm_settings', $settings );
        wp_safe_redirect( admin_url( 'admin.php?page=quick-forms-settings' ) );
        exit;
    }

    public function handle_deactivate_license() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        check_admin_referer( 'qfrm_deactivate_license', 'qfrm_deactivate_license_nonce' );

        $settings = qfrm_get_settings();
        $license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products(
                $license_key,
                array(
                    'quick-forms',
                    'quick-forms-one-site',
                    'quick-forms-five-sites',
                    'quick-forms-unlimited-sites',
                    'quick-woo-bundle',
                    'quick-woo-suite',
                    'quick-bundle',
                    'quick-secretary',
                )
            );
            $settings['license_status'] = 'inactive';
            $settings['license_message'] = isset( $result['message'] ) ? sanitize_text_field( (string) $result['message'] ) : __( 'License deactivated.', 'quick-forms' );
        } else {
            $settings['license_status'] = 'inactive';
            $settings['license_message'] = __( 'License deactivated.', 'quick-forms' );
        }

        update_option( 'qfrm_settings', $settings );
        wp_safe_redirect( admin_url( 'admin.php?page=quick-forms-settings' ) );
        exit;
    }

    public function handle_save_style() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'quick-forms' ) );
        }

        check_admin_referer( 'qfrm_save_style', 'qfrm_save_style_nonce' );

        $settings = qfrm_get_settings();
        $settings['custom_form_css'] = isset( $_POST['custom_form_css'] ) ? wp_kses_post( (string) wp_unslash( $_POST['custom_form_css'] ) ) : '';
        update_option( 'qfrm_settings', qfrm_sanitize_settings( $settings ) );
        wp_safe_redirect( admin_url( 'admin.php?page=quick-forms-style' ) );
        exit;
    }
}
