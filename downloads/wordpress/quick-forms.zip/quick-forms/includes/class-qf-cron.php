<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QFRM_Cron {

    public function hooks() {
        add_action( 'qfrm_daily_cleanup', array( $this, 'cleanup_submissions' ) );
    }

    public function cleanup_submissions() {
        global $wpdb;

        $settings       = qfrm_get_settings();
        $retention_days = max( 1, absint( $settings['retention_days'] ) );
        $cutoff_gmt     = gmdate( 'Y-m-d H:i:s', time() - ( DAY_IN_SECONDS * $retention_days ) );
        $cutoff_local   = get_date_from_gmt( $cutoff_gmt );

        $table = qfrm_table_submissions();

        $sql = $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $cutoff_local );
        $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    }
}
