<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QFRM_Settings {

    public function register() {
        register_setting( 'qfrm_settings_group', 'qfrm_settings', array( $this, 'sanitize' ) );

        add_settings_section(
            'qfrm_main_settings',
            __( 'Global Settings', 'quick-forms' ),
            '__return_false',
            'quick-forms-settings'
        );

        add_settings_field( 'default_notification_email', __( 'Default Notification Email', 'quick-forms' ), array( $this, 'field_default_notification_email' ), 'quick-forms-settings', 'qfrm_main_settings' );
        add_settings_field( 'rate_limit_window', __( 'Rate Limit Window (seconds)', 'quick-forms' ), array( $this, 'field_rate_limit_window' ), 'quick-forms-settings', 'qfrm_main_settings' );
        add_settings_field( 'rate_limit_max_submits', __( 'Max Submissions in Window', 'quick-forms' ), array( $this, 'field_rate_limit_max_submits' ), 'quick-forms-settings', 'qfrm_main_settings' );
        add_settings_field( 'allowed_upload_mimes', __( 'Allowed Upload Extensions', 'quick-forms' ), array( $this, 'field_allowed_upload_mimes' ), 'quick-forms-settings', 'qfrm_main_settings' );
        add_settings_field( 'max_upload_size_mb', __( 'Max Upload Size (MB)', 'quick-forms' ), array( $this, 'field_max_upload_size_mb' ), 'quick-forms-settings', 'qfrm_main_settings' );
        add_settings_field( 'store_user_agent', __( 'Store User Agent', 'quick-forms' ), array( $this, 'field_store_user_agent' ), 'quick-forms-settings', 'qfrm_main_settings' );
        add_settings_field( 'retention_days', __( 'Data Retention (days)', 'quick-forms' ), array( $this, 'field_retention_days' ), 'quick-forms-settings', 'qfrm_main_settings' );
        add_settings_field( 'integrate_quick_quotes', __( 'Quick Quotes Integration', 'quick-forms' ), array( $this, 'field_integrate_quick_quotes' ), 'quick-forms-settings', 'qfrm_main_settings' );
        add_settings_field( 'integrate_quick_schedule', __( 'Quick Schedule Integration', 'quick-forms' ), array( $this, 'field_integrate_quick_schedule' ), 'quick-forms-settings', 'qfrm_main_settings' );
    }

    public function sanitize( $input ) {
        if ( ! is_array( $input ) ) {
            $input = array();
        }

        return qfrm_sanitize_settings( $input );
    }

    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-forms' ) );
        }

        $settings = qfrm_get_settings();
        $license_status = isset( $settings['license_status'] ) ? sanitize_key( (string) $settings['license_status'] ) : 'inactive';
        $license_message = isset( $settings['license_message'] ) ? sanitize_text_field( (string) $settings['license_message'] ) : '';
        $license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';
        $license_data = null;
        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $license_data = qlic_get_license_status_for_key_products(
                $license_key,
                array(
                    'quick-forms',
                    'quick-forms-one-site',
                    'quick-forms-five-sites',
                    'quick-forms-unlimited-sites',
                    'quick-woo-bundle',
                    'quick-woo-suite',
                    'quick-bundle',
                    'quick-secretary',
                )
            );
            if ( is_array( $license_data ) ) {
                $license_status = isset( $license_data['status'] ) ? sanitize_key( (string) $license_data['status'] ) : $license_status;
                if ( ! empty( $license_data['valid'] ) && ! empty( $license_data['domain_active'] ) ) {
                    $license_status = 'active';
                }
            }
        }

        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Quick Forms Settings', 'quick-forms' ); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'qfrm_settings_group' );
                do_settings_sections( 'quick-forms-settings' );
                submit_button();
                ?>
            </form>

            <hr />
            <h2><?php esc_html_e( 'License Activation', 'quick-forms' ); ?></h2>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-forms' ), $license_status ) ); ?></p>
            <?php if ( '' !== $license_message ) : ?>
                <p><?php echo esc_html( $license_message ); ?></p>
            <?php endif; ?>
            <?php if ( is_array( $license_data ) && ! empty( $license_data['product_slug'] ) ) : ?>
                <p><?php echo esc_html( sprintf( __( 'Plan: %s', 'quick-forms' ), (string) $license_data['product_slug'] ) ); ?></p>
                <p><?php echo esc_html( sprintf( __( 'Activations: %1$s / %2$s', 'quick-forms' ), (string) $license_data['activations'], (string) $license_data['activation_limit'] ) ); ?></p>
                <p><?php echo esc_html( sprintf( __( 'Expires: %s', 'quick-forms' ), ! empty( $license_data['expires_at'] ) ? (string) $license_data['expires_at'] : __( 'Never', 'quick-forms' ) ) ); ?></p>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qfrm_activate_license" />
                <?php wp_nonce_field( 'qfrm_activate_license', 'qfrm_activate_license_nonce' ); ?>
                <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( $license_key ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                <?php submit_button( __( 'Activate License', 'quick-forms' ), 'secondary', '', false ); ?>
            </form>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:8px;">
                <input type="hidden" name="action" value="qfrm_deactivate_license" />
                <?php wp_nonce_field( 'qfrm_deactivate_license', 'qfrm_deactivate_license_nonce' ); ?>
                <?php submit_button( __( 'Deactivate License', 'quick-forms' ), 'delete', '', false ); ?>
            </form>
        </div>
        <?php
    }

    private function get_setting( $key ) {
        $settings = qfrm_get_settings();
        return isset( $settings[ $key ] ) ? $settings[ $key ] : '';
    }

    public function field_default_notification_email() {
        printf(
            '<input type="email" class="regular-text" name="qfrm_settings[default_notification_email]" value="%s" />',
            esc_attr( $this->get_setting( 'default_notification_email' ) )
        );
    }

    public function field_rate_limit_window() {
        printf(
            '<input type="number" min="5" class="small-text" name="qfrm_settings[rate_limit_window]" value="%d" />',
            absint( $this->get_setting( 'rate_limit_window' ) )
        );
    }

    public function field_rate_limit_max_submits() {
        printf(
            '<input type="number" min="1" class="small-text" name="qfrm_settings[rate_limit_max_submits]" value="%d" />',
            absint( $this->get_setting( 'rate_limit_max_submits' ) )
        );
    }

    public function field_allowed_upload_mimes() {
        printf(
            '<input type="text" class="regular-text" name="qfrm_settings[allowed_upload_mimes]" value="%s" />',
            esc_attr( $this->get_setting( 'allowed_upload_mimes' ) )
        );
        echo '<p class="description">' . esc_html__( 'Comma-separated extensions, e.g. jpg,png,pdf', 'quick-forms' ) . '</p>';
    }

    public function field_max_upload_size_mb() {
        printf(
            '<input type="number" min="1" class="small-text" name="qfrm_settings[max_upload_size_mb]" value="%d" />',
            absint( $this->get_setting( 'max_upload_size_mb' ) )
        );
    }

    public function field_store_user_agent() {
        printf(
            '<label><input type="checkbox" name="qfrm_settings[store_user_agent]" value="1" %s /> %s</label>',
            checked( 1, absint( $this->get_setting( 'store_user_agent' ) ), false ),
            esc_html__( 'Store user agent string with submissions.', 'quick-forms' )
        );
    }

    public function field_retention_days() {
        printf(
            '<input type="number" min="1" class="small-text" name="qfrm_settings[retention_days]" value="%d" />',
            absint( $this->get_setting( 'retention_days' ) )
        );
    }

    public function field_integrate_quick_quotes() {
        $premium_enabled = qfrm_is_premium_active();
        printf(
            '<label><input type="checkbox" name="qfrm_settings[integrate_quick_quotes]" value="1" %s %s /> %s</label>',
            checked( 1, absint( $this->get_setting( 'integrate_quick_quotes' ) ), false ),
            disabled( ! $premium_enabled, true, false ),
            esc_html__( 'Enable integration with Quick Quotes.', 'quick-forms' )
        );
    }

    public function field_integrate_quick_schedule() {
        $premium_enabled = qfrm_is_premium_active();
        printf(
            '<label><input type="checkbox" name="qfrm_settings[integrate_quick_schedule]" value="1" %s %s /> %s</label>',
            checked( 1, absint( $this->get_setting( 'integrate_quick_schedule' ) ), false ),
            disabled( ! $premium_enabled, true, false ),
            esc_html__( 'Enable integration with Quick Schedule.', 'quick-forms' )
        );
        if ( ! $premium_enabled ) {
            echo '<p class="description">' . esc_html__( 'Cross-plugin integrations are premium features.', 'quick-forms' ) . '</p>';
        }
    }
}
