<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QFRM_Activator {

    public static function activate() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate   = $wpdb->get_charset_collate();
        $forms_table       = qfrm_table_forms();
        $submissions_table = qfrm_table_submissions();

        $sql_forms = "CREATE TABLE {$forms_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            slug VARCHAR(191) NOT NULL,
            fields_json LONGTEXT NOT NULL,
            settings_json LONGTEXT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug)
        ) {$charset_collate};";

        $sql_submissions = "CREATE TABLE {$submissions_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            form_id BIGINT UNSIGNED NOT NULL,
            submitted_data_json LONGTEXT NOT NULL,
            files_json LONGTEXT NULL,
            ip_hash VARCHAR(64) NOT NULL,
            user_agent TEXT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'new',
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY form_id (form_id),
            KEY status (status),
            KEY created_at (created_at)
        ) {$charset_collate};";

        dbDelta( $sql_forms );
        dbDelta( $sql_submissions );

        if ( false === get_option( 'qfrm_settings', false ) ) {
            update_option( 'qfrm_settings', qfrm_default_settings() );
        }

        if ( false === get_option( 'qfrm_new_submissions_count', false ) ) {
            update_option( 'qfrm_new_submissions_count', 0 );
        }

        if ( ! wp_next_scheduled( 'qfrm_daily_cleanup' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'qfrm_daily_cleanup' );
        }
    }

    public static function deactivate() {
        $timestamp = wp_next_scheduled( 'qfrm_daily_cleanup' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'qfrm_daily_cleanup' );
        }
    }
}
