<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QFRM_Shortcode {

    public function hooks() {
        add_shortcode( 'quick_form', array( $this, 'render_shortcode' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
    }

    public function register_assets() {
        wp_register_style( 'quick-forms-frontend', QUICK_FORMS_URL . 'assets/css/frontend.css', array(), QUICK_FORMS_VERSION );
        wp_register_script( 'quick-forms-frontend', QUICK_FORMS_URL . 'assets/js/frontend.js', array( 'jquery' ), QUICK_FORMS_VERSION, true );

        wp_localize_script(
            'quick-forms-frontend',
            'QuickForms',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'qfrm_submit' ),
            )
        );
    }

    public function render_shortcode( $atts ) {
        $atts = shortcode_atts(
            array(
                'id'         => 0,
                'quote_type' => '',
            ),
            $atts,
            'quick_form'
        );

        $builder = new QFRM_Builder();
        $form    = null;

        $form_id = absint( $atts['id'] );
        if ( $form_id ) {
            $form = $builder->get_form( $form_id );
        } elseif ( ! empty( $atts['quote_type'] ) ) {
            $form = $builder->get_active_form_by_quote_type( $atts['quote_type'] );
        }

        if ( ! $form || 'active' !== $form['status'] ) {
            return '';
        }

        $fields   = qfrm_decode_json_array( $form['fields_json'] );
        $settings = qfrm_decode_json_array( $form['settings_json'] );

        wp_enqueue_style( 'quick-forms-frontend' );
        wp_enqueue_script( 'quick-forms-frontend' );
        $global_settings = qfrm_get_settings();
        $custom_css = isset( $global_settings['custom_form_css'] ) ? (string) $global_settings['custom_form_css'] : '';
        if ( '' !== trim( $custom_css ) ) {
            wp_add_inline_style( 'quick-forms-frontend', $custom_css );
        }

        ob_start();
        ?>
        <form class="qf-form" method="post" enctype="multipart/form-data" data-form-id="<?php echo absint( $form['id'] ); ?>">
            <div class="qf-form-message" aria-live="polite"></div>
            <?php foreach ( $fields as $field ) : ?>
                <?php $this->render_field( $field ); ?>
            <?php endforeach; ?>

            <div class="qf-honeypot-wrap" aria-hidden="true">
                <label for="qfrm_hp_<?php echo absint( $form['id'] ); ?>">Website</label>
                <input type="text" id="qfrm_hp_<?php echo absint( $form['id'] ); ?>" name="qfrm_hp" value="" tabindex="-1" autocomplete="off" />
            </div>

            <input type="hidden" name="action" value="qfrm_submit" />
            <input type="hidden" name="qfrm_nonce" value="<?php echo esc_attr( wp_create_nonce( 'qfrm_submit' ) ); ?>" />
            <input type="hidden" name="form_id" value="<?php echo absint( $form['id'] ); ?>" />

            <button type="submit" class="qf-submit-button"><?php esc_html_e( 'Submit', 'quick-forms' ); ?></button>
        </form>
        <?php
        return ob_get_clean();
    }

    private function render_field( $field ) {
        $type        = isset( $field['type'] ) ? $field['type'] : 'text';
        $name        = isset( $field['name'] ) ? $field['name'] : '';
        $label       = isset( $field['label'] ) ? $field['label'] : $name;
        $required    = ! empty( $field['required'] );
        $placeholder = isset( $field['placeholder'] ) ? $field['placeholder'] : '';
        $default     = isset( $field['default'] ) ? $field['default'] : '';
        $conditional_field  = isset( $field['conditional_field'] ) ? sanitize_key( (string) $field['conditional_field'] ) : '';
        $conditional_values = isset( $field['conditional_values'] ) && is_array( $field['conditional_values'] ) ? $field['conditional_values'] : array();

        if ( '' === $name ) {
            return;
        }

        $required_attr = $required ? 'required aria-required="true"' : '';

        if ( 'hidden' === $type ) {
            printf(
                '<input type="hidden" name="%s" value="%s" />',
                esc_attr( $name ),
                esc_attr( $default )
            );
            return;
        }

        $wrapper_attributes = ' class="qf-field qf-field-' . esc_attr( $type ) . '"';
        if ( '' !== $conditional_field && ! empty( $conditional_values ) ) {
            $encoded_values = wp_json_encode( array_values( array_map( 'sanitize_text_field', $conditional_values ) ) );
            $wrapper_attributes .= ' data-condition-field="' . esc_attr( $conditional_field ) . '"';
            $wrapper_attributes .= ' data-condition-values="' . esc_attr( $encoded_values ) . '"';
        }

        echo '<div' . $wrapper_attributes . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

        if ( 'checkbox' !== $type && 'radio' !== $type ) {
            echo '<label for="qfrm_' . esc_attr( $name ) . '">' . esc_html( $label );
            if ( $required ) {
                echo ' <span class="qf-required">*</span>';
            }
            echo '</label>';
        }

        switch ( $type ) {
            case 'textarea':
                printf(
                    '<textarea id="qfrm_%1$s" name="%1$s" data-qf-field-name="%1$s" placeholder="%2$s" %3$s>%4$s</textarea>',
                    esc_attr( $name ),
                    esc_attr( $placeholder ),
                    $required_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                    esc_textarea( $default )
                );
                break;

            case 'dropdown':
                $options = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
                printf(
                    '<select id="qfrm_%1$s" name="%1$s" data-qf-field-name="%1$s" %2$s>',
                    esc_attr( $name ),
                    $required_attr // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                );
                echo '<option value="">' . esc_html__( 'Select', 'quick-forms' ) . '</option>';
                foreach ( $options as $opt ) {
                    printf( '<option value="%1$s">%2$s</option>', esc_attr( $opt ), esc_html( $opt ) );
                }
                echo '</select>';
                break;

            case 'radio':
                $options = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
                foreach ( $options as $idx => $opt ) {
                    $id = 'qfrm_' . $name . '_' . $idx;
                    printf(
                        '<label for="%1$s"><input type="radio" id="%1$s" name="%2$s" value="%3$s" %4$s /> %5$s</label>',
                        esc_attr( $id ),
                        esc_attr( $name ),
                        esc_attr( $opt ),
                        $required_attr . ' data-qf-field-name="' . esc_attr( $name ) . '"', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                        esc_html( $opt )
                    );
                }
                break;

            case 'checkbox':
                $options = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
                if ( ! empty( $options ) ) {
                    echo '<fieldset class="qf-checkbox-group">';
                    echo '<legend>' . esc_html( $label );
                    if ( $required ) {
                        echo ' <span class="qf-required">*</span>';
                    }
                    echo '</legend>';

                    foreach ( $options as $idx => $opt ) {
                        $id = 'qfrm_' . $name . '_' . $idx;
                        $required_checkbox_attr = $required && 0 === (int) $idx ? 'required aria-required="true"' : '';
                        printf(
                            '<label for="%1$s"><input type="checkbox" id="%1$s" name="%2$s[]" data-qf-field-name="%2$s" value="%3$s" %4$s /> %5$s</label>',
                            esc_attr( $id ),
                            esc_attr( $name ),
                            esc_attr( $opt ),
                            $required_checkbox_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                            esc_html( $opt )
                        );
                    }
                    echo '</fieldset>';
                    break;
                }

                printf(
                    '<label for="qfrm_%1$s"><input type="checkbox" id="qfrm_%1$s" name="%1$s" data-qf-field-name="%1$s" value="1" %2$s /> %3$s%4$s</label>',
                    esc_attr( $name ),
                    $required_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                    esc_html( $label ),
                    $required ? ' <span class="qf-required">*</span>' : ''
                );
                break;

            case 'consent':
                printf(
                    '<label for="qfrm_%1$s"><input type="checkbox" id="qfrm_%1$s" name="%1$s" data-qf-field-name="%1$s" value="1" %2$s /> %3$s%4$s</label>',
                    esc_attr( $name ),
                    $required_attr, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                    esc_html( $label ),
                    $required ? ' <span class="qf-required">*</span>' : ''
                );
                break;

            case 'file':
                printf(
                    '<input type="file" id="qfrm_%1$s" name="%1$s" data-qf-field-name="%1$s" %2$s />',
                    esc_attr( $name ),
                    $required_attr // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                );
                break;

            case 'email':
                printf(
                    '<input type="email" id="qfrm_%1$s" name="%1$s" data-qf-field-name="%1$s" placeholder="%2$s" value="%3$s" %4$s />',
                    esc_attr( $name ),
                    esc_attr( $placeholder ),
                    esc_attr( $default ),
                    $required_attr // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                );
                break;

            case 'phone':
                printf(
                    '<input type="tel" id="qfrm_%1$s" name="%1$s" data-qf-field-name="%1$s" placeholder="%2$s" value="%3$s" %4$s />',
                    esc_attr( $name ),
                    esc_attr( $placeholder ),
                    esc_attr( $default ),
                    $required_attr // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                );
                break;

            default:
                printf(
                    '<input type="text" id="qfrm_%1$s" name="%1$s" data-qf-field-name="%1$s" placeholder="%2$s" value="%3$s" %4$s />',
                    esc_attr( $name ),
                    esc_attr( $placeholder ),
                    esc_attr( $default ),
                    $required_attr // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                );
                break;
        }

        echo '</div>';
    }
}
