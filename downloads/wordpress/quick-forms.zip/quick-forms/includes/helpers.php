<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function qfrm_table_forms() {
    global $wpdb;
    return $wpdb->prefix . 'quick_forms';
}

function qfrm_table_submissions() {
    global $wpdb;
    return $wpdb->prefix . 'quick_form_submissions';
}

function qfrm_now_mysql() {
    return current_time( 'mysql' );
}

function qfrm_default_settings() {
    return array(
        'default_notification_email' => get_option( 'admin_email' ),
        'rate_limit_window'          => 60,
        'rate_limit_max_submits'     => 3,
        'allowed_upload_mimes'       => 'jpg,jpeg,png,pdf,doc,docx',
        'max_upload_size_mb'         => 5,
        'store_user_agent'           => 1,
        'retention_days'             => 365,
        'integrate_quick_quotes'     => 1,
        'integrate_quick_schedule'   => 1,
        'custom_form_css'            => '',
        'license_key'                => '',
        'license_status'             => 'inactive',
        'license_message'            => '',
    );
}

function qfrm_get_settings() {
    $saved = get_option( 'qfrm_settings', array() );
    if ( ! is_array( $saved ) ) {
        $saved = array();
    }

    return wp_parse_args( $saved, qfrm_default_settings() );
}

function qfrm_sanitize_settings( $settings ) {
    $defaults = qfrm_default_settings();
    $premium_enabled = qfrm_is_premium_active();

    return array(
        'default_notification_email' => sanitize_email( isset( $settings['default_notification_email'] ) ? $settings['default_notification_email'] : $defaults['default_notification_email'] ),
        'rate_limit_window'          => max( 5, absint( isset( $settings['rate_limit_window'] ) ? $settings['rate_limit_window'] : $defaults['rate_limit_window'] ) ),
        'rate_limit_max_submits'     => max( 1, absint( isset( $settings['rate_limit_max_submits'] ) ? $settings['rate_limit_max_submits'] : $defaults['rate_limit_max_submits'] ) ),
        'allowed_upload_mimes'       => sanitize_text_field( isset( $settings['allowed_upload_mimes'] ) ? $settings['allowed_upload_mimes'] : $defaults['allowed_upload_mimes'] ),
        'max_upload_size_mb'         => max( 1, absint( isset( $settings['max_upload_size_mb'] ) ? $settings['max_upload_size_mb'] : $defaults['max_upload_size_mb'] ) ),
        'store_user_agent'           => empty( $settings['store_user_agent'] ) ? 0 : 1,
        'retention_days'             => max( 1, absint( isset( $settings['retention_days'] ) ? $settings['retention_days'] : $defaults['retention_days'] ) ),
        'integrate_quick_quotes'     => $premium_enabled && ! empty( $settings['integrate_quick_quotes'] ) ? 1 : 0,
        'integrate_quick_schedule'   => $premium_enabled && ! empty( $settings['integrate_quick_schedule'] ) ? 1 : 0,
        'custom_form_css'            => isset( $settings['custom_form_css'] ) ? wp_kses_post( (string) $settings['custom_form_css'] ) : '',
        'license_key'                => sanitize_text_field( isset( $settings['license_key'] ) ? $settings['license_key'] : $defaults['license_key'] ),
        'license_status'             => sanitize_key( isset( $settings['license_status'] ) ? $settings['license_status'] : $defaults['license_status'] ),
        'license_message'            => sanitize_text_field( isset( $settings['license_message'] ) ? $settings['license_message'] : $defaults['license_message'] ),
    );
}

function qfrm_update_settings( $settings ) {
    $clean = qfrm_sanitize_settings( is_array( $settings ) ? $settings : array() );
    update_option( 'qfrm_settings', $clean );
}

function qfrm_decode_json_array( $json ) {
    if ( empty( $json ) || ! is_string( $json ) ) {
        return array();
    }

    $decoded = json_decode( $json, true );
    return is_array( $decoded ) ? $decoded : array();
}

function qfrm_hash_ip() {
    $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '';
    return hash( 'sha256', $ip . wp_salt( 'nonce' ) );
}

function qfrm_new_submissions_count() {
    return absint( get_option( 'qfrm_new_submissions_count', 0 ) );
}

function qfrm_increment_new_submission_count() {
    $count = qfrm_new_submissions_count();
    update_option( 'qfrm_new_submissions_count', $count + 1 );
}

function qfrm_reset_new_submission_count() {
    update_option( 'qfrm_new_submissions_count', 0 );
}

function qfrm_allowed_upload_mimes() {
    $settings = qfrm_get_settings();
    $raw      = isset( $settings['allowed_upload_mimes'] ) ? $settings['allowed_upload_mimes'] : '';

    $exts = array_filter( array_map( 'trim', explode( ',', strtolower( $raw ) ) ) );

    $all_mimes = wp_get_mime_types();
    $allowed   = array();

    foreach ( $all_mimes as $ext_key => $mime ) {
        $possible = explode( '|', $ext_key );
        foreach ( $possible as $ext ) {
            if ( in_array( strtolower( $ext ), $exts, true ) ) {
                if ( strpos( strtolower( $mime ), 'php' ) !== false ) {
                    continue;
                }
                $allowed[ $ext ] = $mime;
            }
        }
    }

    return $allowed;
}

function qfrm_is_premium_active() {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

    if ( function_exists( 'qwoo_has_active_license' ) ) {
        return (bool) qwoo_has_active_license( array( 'quick-forms' ) );
    }

    return false;
}
