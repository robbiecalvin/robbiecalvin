<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QFRM_Ajax {

    public function hooks() {
        add_action( 'wp_ajax_qfrm_submit', array( $this, 'submit' ) );
        add_action( 'wp_ajax_nopriv_qfrm_submit', array( $this, 'submit' ) );
        add_action( 'wp_ajax_quick_forms_submit', array( $this, 'submit' ) );
        add_action( 'wp_ajax_nopriv_quick_forms_submit', array( $this, 'submit' ) );
    }

    public function submit() {
        check_ajax_referer( 'qfrm_submit', 'qfrm_nonce' );

        $form_id = isset( $_POST['form_id'] ) ? absint( $_POST['form_id'] ) : 0;
        if ( ! $form_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid form.', 'quick-forms' ) ), 400 );
        }

        $builder = new QFRM_Builder();
        $form    = $builder->get_form( $form_id );

        if ( ! $form || 'active' !== $form['status'] ) {
            wp_send_json_error( array( 'message' => __( 'Form not available.', 'quick-forms' ) ), 404 );
        }

        $fields   = qfrm_decode_json_array( $form['fields_json'] );
        $settings = qfrm_decode_json_array( $form['settings_json'] );

        $spam_enabled = isset( $settings['spam_protection'] ) ? (bool) $settings['spam_protection'] : true;

        if ( $spam_enabled && ! empty( $_POST['qfrm_hp'] ) ) {
            wp_send_json_success(
                array(
                    'message'  => __( 'Thank you! Your submission has been received.', 'quick-forms' ),
                    'redirect' => '',
                )
            );
        }

        $ip_hash = qfrm_hash_ip();

        if ( $spam_enabled && $this->is_rate_limited( $ip_hash ) ) {
            wp_send_json_error( array( 'message' => __( 'Please wait before submitting again.', 'quick-forms' ) ), 429 );
        }

        $validation = $this->validate_and_sanitize_submission( $fields, $_POST, $_FILES );
        if ( is_wp_error( $validation ) ) {
            wp_send_json_error( array( 'message' => $validation->get_error_message() ), 422 );
        }

        $submitted_data = $validation['data'];
        $files_data     = $validation['files'];
        $submission_mode = isset( $settings['submission_mode'] ) && 'instant_estimate' === sanitize_key( (string) $settings['submission_mode'] ) ? 'instant_estimate' : 'capture_only';
        $global_settings = qfrm_get_settings();
        $can_integrate_quotes = qfrm_is_premium_active() && ! empty( $global_settings['integrate_quick_quotes'] );
        if ( 'instant_estimate' === $submission_mode && ! $can_integrate_quotes ) {
            $submission_mode = 'capture_only';
        }

        $save_to_db = isset( $settings['save_to_db'] ) ? (bool) $settings['save_to_db'] : true;

        $submission_id = 0;

        if ( $save_to_db ) {
            $inserted = $this->store_submission( $form_id, $submitted_data, $files_data, $ip_hash );
            if ( is_wp_error( $inserted ) ) {
                wp_send_json_error( array( 'message' => $inserted->get_error_message() ), 500 );
            }

            $submission_id = absint( $inserted );
        }
        qfrm_increment_new_submission_count();
        $this->record_rate_hit( $ip_hash );

        if ( function_exists( 'qwoo_event' ) ) {
            qwoo_event(
                'form_submitted',
                array(
                    'plugin'        => 'quick-forms',
                    'form_id'       => absint( $form_id ),
                    'submission_id' => $submission_id,
                    'submitted_data'=> $submitted_data,
                    'files_data'    => $files_data,
                ),
                array(
                    'source' => 'quick-forms',
                )
            );
        }

        $event_payload = array(
            'form_id'        => absint( $form_id ),
            'submission_id'  => $submission_id,
            'submitted_data' => $submitted_data,
            'files_data'     => $files_data,
            'form'           => $form,
        );

        $instant_invoice_url = '';
        if ( 'instant_estimate' === $submission_mode && function_exists( 'qquo_create_quote_from_quick_forms_submission' ) ) {
            $quote_result = qquo_create_quote_from_quick_forms_submission( $event_payload );
            if ( is_array( $quote_result ) ) {
                if ( ! empty( $quote_result['quote_id'] ) ) {
                    $event_payload['_qquo_quote_id'] = absint( $quote_result['quote_id'] );
                }
                if ( ! empty( $quote_result['invoice_url'] ) ) {
                    $instant_invoice_url = esc_url_raw( (string) $quote_result['invoice_url'] );
                }
            }
        }

        do_action( 'quick_forms/submitted', $event_payload );

        if ( 'instant_estimate' === $submission_mode && '' === $instant_invoice_url && $submission_id > 0 && function_exists( 'qquo_get_quote_id_for_form_submission' ) && function_exists( 'qquo_get_public_invoice_url' ) ) {
            $quote_id = absint( qquo_get_quote_id_for_form_submission( $submission_id ) );
            if ( $quote_id > 0 ) {
                $instant_invoice_url = esc_url_raw( (string) qquo_get_public_invoice_url( $quote_id ) );
            }
        }

        if ( qfrm_is_premium_active() && ! empty( $settings['admin_notification'] ) ) {
            $this->send_notification_email( $form, $submitted_data, $files_data, $settings );
        }

        $success_message = ! empty( $settings['success_message'] ) ? $settings['success_message'] : __( 'Thank you! Your submission has been received.', 'quick-forms' );
        $redirect_url    = ! empty( $settings['redirect_url'] ) ? esc_url_raw( $settings['redirect_url'] ) : '';
        if ( 'instant_estimate' === $submission_mode && '' !== $instant_invoice_url ) {
            $success_message = __( 'Your estimate is ready. Redirecting now...', 'quick-forms' );
            $redirect_url    = $instant_invoice_url;
        }

        wp_send_json_success(
            array(
                'message'  => $success_message,
                'redirect' => $redirect_url,
            )
        );
    }

    private function is_rate_limited( $ip_hash ) {
        $settings = qfrm_get_settings();
        $window   = absint( $settings['rate_limit_window'] );
        $max      = absint( $settings['rate_limit_max_submits'] );

        $window = max( 5, $window );
        $max    = max( 1, $max );

        $bucket = get_transient( 'qfrm_rate_' . $ip_hash );
        if ( ! is_array( $bucket ) || empty( $bucket['count'] ) ) {
            return false;
        }

        $count = absint( $bucket['count'] );
        return $count >= $max;
    }

    private function record_rate_hit( $ip_hash ) {
        $settings = qfrm_get_settings();
        $window   = max( 5, absint( $settings['rate_limit_window'] ) );

        $key    = 'qfrm_rate_' . $ip_hash;
        $bucket = get_transient( $key );
        if ( ! is_array( $bucket ) ) {
            $bucket = array( 'count' => 0 );
        }

        $bucket['count'] = absint( $bucket['count'] ) + 1;
        set_transient( $key, $bucket, $window );
    }

    private function validate_and_sanitize_submission( $fields, $raw_post, $raw_files ) {
        $data       = array();
        $files_data = array();

        foreach ( $fields as $field ) {
            $type     = isset( $field['type'] ) ? $field['type'] : 'text';
            $name     = isset( $field['name'] ) ? $field['name'] : '';
            $label    = isset( $field['label'] ) ? $field['label'] : $name;
            $required = ! empty( $field['required'] );

            if ( '' === $name ) {
                continue;
            }

            if ( ! $this->is_field_visible_for_submission( $field, $raw_post ) ) {
                continue;
            }

            if ( 'file' === $type ) {
                $file_result = $this->handle_file_field( $field, $raw_files, $required );
                if ( is_wp_error( $file_result ) ) {
                    return $file_result;
                }

                if ( ! empty( $file_result ) ) {
                    $files_data[ $name ] = $file_result;
                }
                continue;
            }

            $value = isset( $raw_post[ $name ] ) ? wp_unslash( $raw_post[ $name ] ) : '';
            $checkbox_options = ( 'checkbox' === $type && isset( $field['options'] ) && is_array( $field['options'] ) && ! empty( $field['options'] ) );

            if ( is_array( $value ) && ! $checkbox_options ) {
                $value = implode( ',', array_map( 'sanitize_text_field', $value ) );
            }

            switch ( $type ) {
                case 'email':
                    $value = sanitize_email( $value );
                    if ( $required && '' === $value ) {
                        return new WP_Error( 'qfrm_required_email', sprintf( __( '%s is required.', 'quick-forms' ), $label ) );
                    }
                    if ( '' !== $value && ! is_email( $value ) ) {
                        return new WP_Error( 'qfrm_invalid_email', sprintf( __( '%s must be a valid email.', 'quick-forms' ), $label ) );
                    }
                    break;

                case 'textarea':
                    $value = sanitize_textarea_field( $value );
                    break;

                case 'phone':
                    $value = preg_replace( '/[^0-9\+\-\(\)\s]/', '', (string) $value );
                    $value = sanitize_text_field( $value );
                    break;

                case 'checkbox':
                    if ( $checkbox_options ) {
                        $raw_values = isset( $raw_post[ $name ] ) ? wp_unslash( $raw_post[ $name ] ) : array();
                        if ( ! is_array( $raw_values ) ) {
                            $raw_values = array( $raw_values );
                        }

                        $allowed_options = array();
                        foreach ( $field['options'] as $opt ) {
                            $opt = sanitize_text_field( (string) $opt );
                            if ( '' !== $opt ) {
                                $allowed_options[] = $opt;
                            }
                        }

                        $selected_values = array();
                        foreach ( $raw_values as $raw_value ) {
                            $raw_value = sanitize_text_field( (string) $raw_value );
                            if ( '' === $raw_value ) {
                                continue;
                            }
                            if ( ! in_array( $raw_value, $allowed_options, true ) ) {
                                return new WP_Error( 'qfrm_invalid_option', sprintf( __( '%s has an invalid value.', 'quick-forms' ), $label ) );
                            }
                            $selected_values[] = $raw_value;
                        }

                        if ( $required && empty( $selected_values ) ) {
                            return new WP_Error( 'qfrm_required_field', sprintf( __( '%s is required.', 'quick-forms' ), $label ) );
                        }

                        $value = implode( ', ', array_values( array_unique( $selected_values ) ) );
                    } else {
                        $value = empty( $value ) ? '0' : '1';
                        if ( $required && '1' !== $value ) {
                            return new WP_Error( 'qfrm_required_consent', sprintf( __( '%s is required.', 'quick-forms' ), $label ) );
                        }
                    }
                    break;

                case 'consent':
                    $value = empty( $value ) ? '0' : '1';
                    if ( $required && '1' !== $value ) {
                        return new WP_Error( 'qfrm_required_consent', sprintf( __( '%s is required.', 'quick-forms' ), $label ) );
                    }
                    break;

                case 'dropdown':
                case 'radio':
                    $value   = sanitize_text_field( $value );
                    $options = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
                    if ( '' !== $value && ! in_array( $value, $options, true ) ) {
                        return new WP_Error( 'qfrm_invalid_option', sprintf( __( '%s has an invalid value.', 'quick-forms' ), $label ) );
                    }
                    break;

                case 'hidden':
                case 'text':
                default:
                    $value = sanitize_text_field( $value );
                    break;
            }

            if ( $required && in_array( $type, array( 'text', 'email', 'phone', 'textarea', 'dropdown', 'radio' ), true ) && '' === $value ) {
                return new WP_Error( 'qfrm_required_field', sprintf( __( '%s is required.', 'quick-forms' ), $label ) );
            }

            $min = isset( $field['min_length'] ) ? absint( $field['min_length'] ) : 0;
            $max = isset( $field['max_length'] ) ? absint( $field['max_length'] ) : 0;

            if ( $min > 0 && mb_strlen( (string) $value ) < $min ) {
                return new WP_Error( 'qfrm_min_length', sprintf( __( '%s must be at least %d characters.', 'quick-forms' ), $label, $min ) );
            }

            if ( $max > 0 && mb_strlen( (string) $value ) > $max ) {
                return new WP_Error( 'qfrm_max_length', sprintf( __( '%s must be %d characters or fewer.', 'quick-forms' ), $label, $max ) );
            }

            $regex = isset( $field['regex'] ) ? trim( (string) $field['regex'] ) : '';
            if ( '' !== $regex && '' !== $value ) {
                $pattern = '/' . str_replace( '/', '\/', $regex ) . '/';
                $result  = @preg_match( $pattern, (string) $value );
                if ( false === $result || 0 === $result ) {
                    return new WP_Error( 'qfrm_regex_failed', sprintf( __( '%s format is invalid.', 'quick-forms' ), $label ) );
                }
            }

            $data[ $name ] = $value;
        }

        return array(
            'data'  => $data,
            'files' => $files_data,
        );
    }

    private function is_field_visible_for_submission( $field, $raw_post ) {
        $conditional_field = isset( $field['conditional_field'] ) ? sanitize_key( (string) $field['conditional_field'] ) : '';
        $conditional_values = isset( $field['conditional_values'] ) && is_array( $field['conditional_values'] ) ? $field['conditional_values'] : array();

        if ( '' === $conditional_field || empty( $conditional_values ) ) {
            return true;
        }

        $configured = array();
        foreach ( $conditional_values as $value ) {
            $value = strtolower( sanitize_text_field( trim( (string) $value ) ) );
            if ( '' !== $value ) {
                $configured[] = $value;
            }
        }

        if ( empty( $configured ) ) {
            return true;
        }

        $current_values = $this->get_raw_post_values( $raw_post, $conditional_field );
        if ( empty( $current_values ) ) {
            return false;
        }

        foreach ( $current_values as $submitted_value ) {
            if ( in_array( strtolower( $submitted_value ), $configured, true ) ) {
                return true;
            }
        }

        return false;
    }

    private function get_raw_post_values( $raw_post, $field_name ) {
        if ( ! is_array( $raw_post ) ) {
            return array();
        }

        $resolved_key = $this->resolve_post_field_key( $raw_post, $field_name );
        if ( '' === $resolved_key || ! isset( $raw_post[ $resolved_key ] ) ) {
            return array();
        }

        $raw_value = wp_unslash( $raw_post[ $resolved_key ] );
        $values    = array();

        if ( is_array( $raw_value ) ) {
            foreach ( $raw_value as $item ) {
                $item = sanitize_text_field( trim( (string) $item ) );
                if ( '' !== $item ) {
                    $values[] = $item;
                }
            }
            return $values;
        }

        $clean_value = sanitize_text_field( trim( (string) $raw_value ) );
        if ( '' === $clean_value ) {
            return array();
        }

        if ( false !== strpos( $clean_value, ',' ) ) {
            $parts = explode( ',', $clean_value );
            foreach ( $parts as $part ) {
                $part = sanitize_text_field( trim( (string) $part ) );
                if ( '' !== $part ) {
                    $values[] = $part;
                }
            }
            return $values;
        }

        return array( $clean_value );
    }

    private function resolve_post_field_key( $raw_post, $wanted_field_name ) {
        $wanted_variants = $this->build_equivalent_field_keys( $wanted_field_name );
        foreach ( $wanted_variants as $variant ) {
            if ( isset( $raw_post[ $variant ] ) ) {
                return $variant;
            }
        }

        foreach ( $raw_post as $existing_key => $value ) {
            $existing_variants = $this->build_equivalent_field_keys( $existing_key );
            foreach ( $existing_variants as $existing_variant ) {
                if ( in_array( $existing_variant, $wanted_variants, true ) && isset( $raw_post[ $existing_key ] ) ) {
                    return (string) $existing_key;
                }
            }
        }

        return '';
    }

    private function build_equivalent_field_keys( $raw_key ) {
        $key = sanitize_key( (string) $raw_key );
        if ( '' === $key ) {
            return array();
        }

        $variants = array( $key );
        if ( 's' === substr( $key, -1 ) ) {
            $variants[] = substr( $key, 0, -1 );
        } else {
            $variants[] = $key . 's';
        }

        return array_values( array_unique( array_filter( $variants ) ) );
    }

    private function handle_file_field( $field, $raw_files, $required ) {
        $name = isset( $field['name'] ) ? $field['name'] : '';
        if ( '' === $name ) {
            return array();
        }

        if ( empty( $raw_files[ $name ] ) || ! isset( $raw_files[ $name ]['error'] ) || UPLOAD_ERR_NO_FILE === (int) $raw_files[ $name ]['error'] ) {
            if ( $required ) {
                return new WP_Error( 'qfrm_required_file', __( 'A required file is missing.', 'quick-forms' ) );
            }
            return array();
        }

        if ( UPLOAD_ERR_OK !== (int) $raw_files[ $name ]['error'] ) {
            return new WP_Error( 'qfrm_upload_error', __( 'File upload failed.', 'quick-forms' ) );
        }

        $settings          = qfrm_get_settings();
        $global_max_bytes  = absint( $settings['max_upload_size_mb'] ) * 1024 * 1024;
        $field_max_bytes   = ! empty( $field['max_size_mb'] ) ? absint( $field['max_size_mb'] ) * 1024 * 1024 : 0;
        $max_allowed_bytes = $field_max_bytes > 0 ? min( $field_max_bytes, $global_max_bytes ) : $global_max_bytes;

        if ( (int) $raw_files[ $name ]['size'] > $max_allowed_bytes ) {
            return new WP_Error( 'qfrm_file_size', __( 'Uploaded file exceeds allowed size.', 'quick-forms' ) );
        }

        $allowed_mimes = qfrm_allowed_upload_mimes();

        $field_mimes = array();
        if ( ! empty( $field['allowed_mime'] ) ) {
            $parts = array_filter( array_map( 'trim', explode( ',', strtolower( $field['allowed_mime'] ) ) ) );
            foreach ( $parts as $ext ) {
                if ( isset( $allowed_mimes[ $ext ] ) ) {
                    $field_mimes[ $ext ] = $allowed_mimes[ $ext ];
                }
            }
        }

        $mimes = ! empty( $field_mimes ) ? $field_mimes : $allowed_mimes;

        if ( empty( $mimes ) ) {
            return new WP_Error( 'qfrm_no_mimes', __( 'File uploads are not configured.', 'quick-forms' ) );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';

        $overrides = array(
            'test_form' => false,
            'mimes'     => $mimes,
        );

        $file = $raw_files[ $name ];

        $checked = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], $mimes );
        if ( empty( $checked['ext'] ) || empty( $checked['type'] ) ) {
            return new WP_Error( 'qfrm_invalid_file_type', __( 'File type is not allowed.', 'quick-forms' ) );
        }

        if ( false !== strpos( strtolower( (string) $checked['type'] ), 'php' ) ) {
            return new WP_Error( 'qfrm_invalid_file_type', __( 'Executable uploads are not allowed.', 'quick-forms' ) );
        }

        $uploaded = wp_handle_upload( $file, $overrides );

        if ( isset( $uploaded['error'] ) ) {
            return new WP_Error( 'qfrm_handle_upload_error', sanitize_text_field( $uploaded['error'] ) );
        }

        return array(
            'name' => sanitize_file_name( $file['name'] ),
            'type' => sanitize_mime_type( $uploaded['type'] ),
            'size' => absint( $file['size'] ),
            'path' => sanitize_text_field( $uploaded['file'] ),
            'url'  => esc_url_raw( $uploaded['url'] ),
        );
    }

    private function store_submission( $form_id, $submitted_data, $files_data, $ip_hash ) {
        global $wpdb;

        $settings   = qfrm_get_settings();
        $user_agent = null;

        if ( ! empty( $settings['store_user_agent'] ) && isset( $_SERVER['HTTP_USER_AGENT'] ) ) {
            $user_agent = sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) );
        }

        $table = qfrm_table_submissions();

        $sql = $wpdb->prepare(
            "INSERT INTO {$table}
            (form_id, submitted_data_json, files_json, ip_hash, user_agent, status, created_at)
            VALUES (%d, %s, %s, %s, %s, %s, %s)",
            absint( $form_id ),
            wp_json_encode( $submitted_data ),
            ! empty( $files_data ) ? wp_json_encode( $files_data ) : null,
            $ip_hash,
            $user_agent,
            'new',
            qfrm_now_mysql()
        );

        $result = $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        if ( false === $result ) {
            return new WP_Error( 'qfrm_db_error', __( 'Could not save submission.', 'quick-forms' ) );
        }

        return absint( $wpdb->insert_id );
    }

    private function send_notification_email( $form, $submitted_data, $files_data, $settings ) {
        $global = qfrm_get_settings();

        $recipients_raw = ! empty( $settings['notification_recipients'] ) ? $settings['notification_recipients'] : $global['default_notification_email'];
        $recipients     = array_filter( array_map( 'trim', explode( ',', $recipients_raw ) ) );
        $recipients     = array_filter( $recipients, 'is_email' );

        if ( empty( $recipients ) ) {
            return;
        }

        $subject = ! empty( $settings['email_subject'] ) ? $settings['email_subject'] : 'New submission for {{form_name}}';
        $subject = str_replace( '{{form_name}}', $form['name'], $subject );

        $body = "New Quick Forms submission\n\n";
        $body .= 'Form: ' . $form['name'] . "\n";
        $body .= 'Time: ' . qfrm_now_mysql() . "\n\n";

        foreach ( $submitted_data as $key => $value ) {
            $body .= $key . ': ' . $value . "\n";
        }

        if ( ! empty( $files_data ) ) {
            $body .= "\nFiles:\n";
            foreach ( $files_data as $key => $file ) {
                $body .= $key . ': ' . ( isset( $file['url'] ) ? $file['url'] : '' ) . "\n";
            }
        }

        wp_mail( $recipients, $subject, $body );
    }
}
