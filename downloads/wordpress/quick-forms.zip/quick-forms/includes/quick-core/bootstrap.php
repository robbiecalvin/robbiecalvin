<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$active_plugins = (array) get_option( 'active_plugins', array() );
if ( in_array( 'quick-core/quick-core.php', $active_plugins, true ) ) {
    return;
}

if ( is_multisite() ) {
    $network_active = (array) get_site_option( 'active_sitewide_plugins', array() );
    if ( isset( $network_active['quick-core/quick-core.php'] ) ) {
        return;
    }
}

if ( defined( 'QUICK_CORE_VERSION' ) && version_compare( QUICK_CORE_VERSION, '1.0.0', '>' ) ) {
    return;
}

if ( defined( 'QUICK_CORE_UI_BOOTSTRAPPED' ) ) {
    return;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    define( 'QUICK_CORE_VERSION', '1.0.0' );
}

if ( ! defined( 'QUICK_CORE_PATH' ) ) {
    define( 'QUICK_CORE_PATH', __DIR__ . '/' );
}

if ( ! defined( 'QUICK_CORE_URL' ) ) {
    define( 'QUICK_CORE_URL', trailingslashit( plugins_url( '', __FILE__ ) ) );
}

if ( ! defined( 'QUICK_CORE_ASSETS_URL' ) ) {
    define( 'QUICK_CORE_ASSETS_URL', QUICK_CORE_URL . 'assets/' );
}

define( 'QUICK_CORE_UI_BOOTSTRAPPED', true );

require_once QUICK_CORE_PATH . 'includes/helpers.php';
require_once QUICK_CORE_PATH . 'includes/class-quick-ui.php';

Quick_UI::instance()->hooks();
