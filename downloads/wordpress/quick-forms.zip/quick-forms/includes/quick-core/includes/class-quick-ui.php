<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'Quick_UI' ) ) {
    class Quick_UI {
        private static $instance = null;

        public static function instance() {
            if ( null === self::$instance ) {
                self::$instance = new self();
            }

            return self::$instance;
        }

        public function hooks() {
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ), 999 );
            add_action( 'admin_head', array( $this, 'render_admin_menu_icons' ), 999 );
        }

        public function enqueue( $hook ) {
            if ( ! quick_core_is_quick_admin_page( $hook ) ) {
                return;
            }

            wp_register_style(
                'quick-core-ui',
                QUICK_CORE_ASSETS_URL . 'css/quick-core.css',
                array(),
                quick_core_asset_version()
            );

            wp_register_script(
                'quick-core-ui',
                QUICK_CORE_ASSETS_URL . 'js/quick-core.js',
                array(),
                quick_core_asset_version(),
                true
            );

            wp_enqueue_style( 'quick-core-ui' );
            wp_enqueue_script( 'quick-core-ui' );
        }

        public function render_admin_menu_icons() {
            if ( ! is_admin() ) {
                return;
            }

            $icons = get_option( 'quick_ui_admin_icons', array() );
            if ( ! is_array( $icons ) || empty( $icons ) ) {
                return;
            }

            $css = '';
            foreach ( $icons as $menu_slug => $url ) {
                $menu_slug = sanitize_key( (string) $menu_slug );
                $url       = esc_url_raw( (string) $url );
                if ( '' === $menu_slug || '' === $url ) {
                    continue;
                }

                $selector = '#adminmenu #toplevel_page_' . $menu_slug . ' .wp-menu-image:before';
                $css     .= $selector . '{content:\"\" !important;display:block;width:20px;height:20px;margin-top:7px;background-image:url(\"' . esc_url( $url ) . '\");background-size:18px 18px;background-repeat:no-repeat;background-position:center;}' . "\n";
            }

            if ( '' !== $css ) {
                echo '<style id=\"quick-ui-admin-icons\">' . $css . '</style>';
            }
        }

        public static function button( $text, $type = 'primary' ) {
            $allowed = array( 'primary', 'success', 'danger', 'secondary' );
            $type    = in_array( $type, $allowed, true ) ? $type : 'primary';
            $class   = 'quick-btn quick-btn-' . $type;

            return '<button type="button" class="' . esc_attr( $class ) . '">' . esc_html( $text ) . '</button>';
        }

        public static function card( $title, $content ) {
            $html  = '<div class="quick-card">';
            $html .= '<h3 class="quick-card-title">' . esc_html( $title ) . '</h3>';
            $html .= '<div class="quick-card-content">' . wp_kses_post( $content ) . '</div>';
            $html .= '</div>';

            return $html;
        }

        public static function notice( $message, $type ) {
            $allowed = array( 'success', 'warning', 'error', 'info' );
            $type    = in_array( $type, $allowed, true ) ? $type : 'info';

            return '<div class="quick-notice quick-notice-' . esc_attr( $type ) . '"><p>' . esc_html( $message ) . '</p></div>';
        }

        public static function panel( $title, $content ) {
            $html  = '<section class="quick-panel">';
            $html .= '<header class="quick-panel-header"><h2>' . esc_html( $title ) . '</h2></header>';
            $html .= '<div class="quick-panel-content">' . wp_kses_post( $content ) . '</div>';
            $html .= '</section>';

            return $html;
        }

        public static function input( $name, $value, $type = 'text' ) {
            $allowed = array( 'text', 'number', 'email', 'url', 'password', 'search' );
            $type    = in_array( $type, $allowed, true ) ? $type : 'text';

            return '<input class="quick-input" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $value ) . '">';
        }

        public static function table( $headers, $rows ) {
            $headers = is_array( $headers ) ? $headers : array();
            $rows    = is_array( $rows ) ? $rows : array();

            $html  = '<table class="quick-table widefat striped"><thead><tr>';
            foreach ( $headers as $header ) {
                $html .= '<th>' . esc_html( (string) $header ) . '</th>';
            }
            $html .= '</tr></thead><tbody>';

            if ( empty( $rows ) ) {
                $colspan = max( 1, count( $headers ) );
                $html   .= '<tr><td colspan="' . esc_attr( (string) $colspan ) . '">No data found.</td></tr>';
            } else {
                foreach ( $rows as $row ) {
                    $row  = is_array( $row ) ? $row : array();
                    $html .= '<tr>';
                    foreach ( $row as $cell ) {
                        $html .= '<td>' . wp_kses_post( (string) $cell ) . '</td>';
                    }
                    $html .= '</tr>';
                }
            }

            $html .= '</tbody></table>';

            return $html;
        }
    }
}
