<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'quick_core_is_quick_admin_page' ) ) {
    function quick_core_is_quick_admin_page( $hook = '' ) {
        if ( ! is_admin() ) {
            return false;
        }

        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        $targets = array( 'quick-', 'qseo', 'qwoo', 'qmail', 'qship', 'qp-', 'qi-' );

        foreach ( $targets as $target ) {
            if ( '' !== $hook && false !== strpos( (string) $hook, $target ) ) {
                return true;
            }
            if ( '' !== $page && 0 === strpos( $page, $target ) ) {
                return true;
            }
        }

        if ( function_exists( 'get_current_screen' ) ) {
            $screen = get_current_screen();
            if ( $screen && ! empty( $screen->id ) ) {
                foreach ( $targets as $target ) {
                    if ( false !== strpos( (string) $screen->id, $target ) ) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}

if ( ! function_exists( 'quick_core_asset_version' ) ) {
    function quick_core_asset_version() {
        return defined( 'QUICK_CORE_VERSION' ) ? QUICK_CORE_VERSION : '1.0.0';
    }
}

if ( ! function_exists( 'quick_core_require_guard' ) ) {
    function quick_core_require_guard( $capability = 'manage_options', $nonce_action = '', $nonce_name = '_wpnonce' ) {
        if ( ! current_user_can( $capability ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-core' ) );
        }

        if ( '' !== $nonce_action ) {
            check_admin_referer( $nonce_action, $nonce_name );
        }
    }
}

if ( ! function_exists( 'quick_core_require_ajax_guard' ) ) {
    function quick_core_require_ajax_guard( $capability = 'manage_options', $nonce_action = '', $nonce_name = 'nonce' ) {
        if ( ! current_user_can( $capability ) ) {
            wp_send_json_error( array( 'message' => esc_html__( 'Unauthorized request.', 'quick-core' ) ), 403 );
        }

        if ( '' !== $nonce_action ) {
            check_ajax_referer( $nonce_action, $nonce_name );
        }
    }
}
