(function () {
  if (window.QuickUI) {
    return;
  }

  var toastStack;

  function ensureToastStack() {
    if (!toastStack) {
      toastStack = document.createElement('div');
      toastStack.className = 'quick-toast-stack';
      document.body.appendChild(toastStack);
    }
    return toastStack;
  }

  function showToast(message, type, timeout) {
    var stack = ensureToastStack();
    var toast = document.createElement('div');
    var safeType = type || 'info';
    toast.className = 'quick-toast quick-toast-' + safeType;
    toast.textContent = String(message || '');
    stack.appendChild(toast);

    setTimeout(function () {
      toast.remove();
    }, typeof timeout === 'number' ? timeout : 3500);
  }

  function setLoading(target, loading) {
    var element = typeof target === 'string' ? document.querySelector(target) : target;
    if (!element) {
      return;
    }

    if (loading) {
      element.setAttribute('aria-busy', 'true');
      element.classList.add('is-loading');
      element.dataset.quickUiLabel = element.textContent;
      if (element.tagName === 'BUTTON' || element.tagName === 'A') {
        element.textContent = 'Loading...';
      }
    } else {
      element.removeAttribute('aria-busy');
      element.classList.remove('is-loading');
      if (element.dataset.quickUiLabel) {
        element.textContent = element.dataset.quickUiLabel;
      }
    }
  }

  function confirmDelete(message, onConfirm) {
    var ok = window.confirm(message || 'Are you sure you want to delete this item?');
    if (ok && typeof onConfirm === 'function') {
      onConfirm();
    }
    return ok;
  }

  function showModal(id) {
    var modal = document.getElementById(id);
    if (!modal) {
      return;
    }
    modal.classList.add('is-open');
  }

  function hideModal(id) {
    var modal = document.getElementById(id);
    if (!modal) {
      return;
    }
    modal.classList.remove('is-open');
  }

  document.addEventListener('click', function (event) {
    var trigger = event.target.closest('[data-quick-confirm-delete]');
    if (trigger) {
      var msg = trigger.getAttribute('data-quick-confirm-delete');
      if (!confirmDelete(msg)) {
        event.preventDefault();
      }
      return;
    }

    var openTrigger = event.target.closest('[data-quick-modal-open]');
    if (openTrigger) {
      showModal(openTrigger.getAttribute('data-quick-modal-open'));
      return;
    }

    var closeTrigger = event.target.closest('[data-quick-modal-close]');
    if (closeTrigger) {
      hideModal(closeTrigger.getAttribute('data-quick-modal-close'));
      return;
    }

    var modalBackground = event.target.classList.contains('quick-modal') ? event.target : null;
    if (modalBackground) {
      modalBackground.classList.remove('is-open');
    }
  });

  window.QuickUI = {
    showModal: showModal,
    hideModal: hideModal,
    confirmDelete: confirmDelete,
    setLoading: setLoading,
    toast: showToast
  };
})();
