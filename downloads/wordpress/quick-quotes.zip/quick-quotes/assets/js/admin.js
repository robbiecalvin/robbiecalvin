(function ($) {
	'use strict';

	function formatNumber(value) {
		var num = parseFloat(value);
		if (isNaN(num)) {
			return '0.00';
		}
		return num.toFixed(2);
	}

	function calculateTotals() {
		var subtotal = 0;
		$('.qq-line-price').each(function () {
			var price = parseFloat($(this).val());
			if (!isNaN(price) && price > 0) {
				subtotal += price;
			}
		});

		var taxPercent = parseFloat($('#qq-tax-percent').val());
		var discountPercent = parseFloat($('#qq-discount-percent').val());
		taxPercent = isNaN(taxPercent) ? 0 : Math.max(0, Math.min(100, taxPercent));
		discountPercent = isNaN(discountPercent) ? 0 : Math.max(0, Math.min(100, discountPercent));

		var taxAmount = subtotal * (taxPercent / 100);
		var discountAmount = subtotal * (discountPercent / 100);
		var finalTotal = Math.max(0, subtotal + taxAmount - discountAmount);

		$('#qq-subtotal').text(formatNumber(subtotal));
		$('#qq-tax-amount').text(formatNumber(taxAmount));
		$('#qq-discount-amount').text(formatNumber(discountAmount));
		$('#qq-final-total').text(formatNumber(finalTotal));
	}

	function bindEvents() {
		$('#qq-add-line-item').on('click', function () {
			var row = '<div class="qq-line-item-row">'
				+ '<input type="text" name="line_description[]" placeholder="Description" class="regular-text qq-line-description" required>'
				+ '<input type="number" step="0.01" min="0" name="line_price[]" placeholder="Price" class="small-text qq-line-price" required>'
				+ '<button type="button" class="button qq-remove-line-item">Remove</button>'
				+ '</div>';
			$('#qq-line-items').append(row);
		});

		$(document).on('click', '.qq-remove-line-item', function () {
			if ($('.qq-line-item-row').length <= 1) {
				return;
			}
			$(this).closest('.qq-line-item-row').remove();
			calculateTotals();
		});

		$(document).on('input', '.qq-line-price, #qq-tax-percent, #qq-discount-percent', calculateTotals);
		$(document).on('blur', '.qq-line-price, #qq-tax-percent, #qq-discount-percent', calculateTotals);

		$(document).on('click', '.qq-delete-link', function (event) {
			if (!window.confirm('Are you sure you want to delete this quote?')) {
				event.preventDefault();
			}
		});
	}

	$(document).ready(function () {
		bindEvents();
		calculateTotals();
	});
})(jQuery);
