(function ($) {
	'use strict';

	function formatNumber(value) {
		var num = parseFloat(value);
		if (isNaN(num)) {
			return '0.00';
		}
		return num.toFixed(2);
	}

	function calculateTotals() {
		var subtotal = 0;
		$('#qq-front-line-items input[name="line_price[]"]').each(function () {
			var price = parseFloat($(this).val());
			if (!isNaN(price) && price > 0) {
				subtotal += price;
			}
		});

		var taxPercent = parseFloat($('#qq-front-tax').val());
		var discountPercent = parseFloat($('#qq-front-discount').val());
		taxPercent = isNaN(taxPercent) ? 0 : Math.max(0, Math.min(100, taxPercent));
		discountPercent = isNaN(discountPercent) ? 0 : Math.max(0, Math.min(100, discountPercent));

		var taxAmount = subtotal * (taxPercent / 100);
		var discountAmount = subtotal * (discountPercent / 100);
		var finalTotal = Math.max(0, subtotal + taxAmount - discountAmount);

		$('#qq-front-subtotal').text(formatNumber(subtotal));
		$('#qq-front-tax-amount').text(formatNumber(taxAmount));
		$('#qq-front-discount-amount').text(formatNumber(discountAmount));
		$('#qq-front-final-total').text(formatNumber(finalTotal));
	}

	function showMessage(type, message) {
		var $message = $('#qq-front-message');
		$message.removeClass('qq-error qq-success').addClass(type === 'error' ? 'qq-error' : 'qq-success');
		$message.text(message);
	}

	function resetLineItems() {
		var row = '<div class="qq-line-item-row">'
			+ '<input type="text" name="line_description[]" placeholder="Description" required />'
			+ '<input type="number" name="line_price[]" step="0.01" min="0" placeholder="Price" required />'
			+ '<button type="button" class="qq-remove-line-item">Remove</button>'
			+ '</div>';
		$('#qq-front-line-items').html(row);
	}

	function bindEvents() {
		$(document).on('click', '.qq-add-line-item', function () {
			var row = '<div class="qq-line-item-row">'
				+ '<input type="text" name="line_description[]" placeholder="Description" required />'
				+ '<input type="number" name="line_price[]" step="0.01" min="0" placeholder="Price" required />'
				+ '<button type="button" class="qq-remove-line-item">Remove</button>'
				+ '</div>';
			$('#qq-front-line-items').append(row);
		});

		$(document).on('click', '.qq-remove-line-item', function () {
			if ($('#qq-front-line-items .qq-line-item-row').length <= 1) {
				return;
			}
			$(this).closest('.qq-line-item-row').remove();
			calculateTotals();
		});

		$(document).on('input', '#qq-front-line-items input[name="line_price[]"], #qq-front-tax, #qq-front-discount', calculateTotals);
		$(document).on('blur', '#qq-front-line-items input[name="line_price[]"], #qq-front-tax, #qq-front-discount', calculateTotals);

		$('#qq-frontend-form').on('submit', function (event) {
			event.preventDefault();

			var $form = $(this);
			var $submit = $form.find('.qq-submit');
			var hasValidLineItem = false;

			$('#qq-front-line-items .qq-line-item-row').each(function () {
				var desc = $(this).find('input[name="line_description[]"]').val();
				var price = parseFloat($(this).find('input[name="line_price[]"]').val());
				if (desc && !isNaN(price) && price >= 0) {
					hasValidLineItem = true;
				}
			});

			if (!hasValidLineItem) {
				showMessage('error', 'Please add at least one valid line item.');
				return;
			}

			var data = $form.serializeArray();
			data.push({ name: 'action', value: 'qquo_submit_quote' });
			data.push({ name: 'nonce', value: QQFrontendData.nonce });

			$submit.prop('disabled', true).text('Submitting...');
			showMessage('success', '');

			$.ajax({
				url: QQFrontendData.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: data
			})
				.done(function (response) {
					if (response && response.success) {
						showMessage('success', response.data && response.data.message ? response.data.message : QQFrontendData.successMsg);
						$form[0].reset();
						resetLineItems();
						calculateTotals();
					} else {
						var message = response && response.data && response.data.message ? response.data.message : QQFrontendData.errorMsg;
						showMessage('error', message);
					}
				})
				.fail(function (xhr) {
					var message = QQFrontendData.errorMsg;
					if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
						message = xhr.responseJSON.data.message;
					}
					showMessage('error', message);
				})
				.always(function () {
					$submit.prop('disabled', false).text('Submit Quote Request');
				});
		});
	}

	$(document).ready(function () {
		bindEvents();
		calculateTotals();
	});
})(jQuery);
