<?php
/**
 * Shortcode class.
 *
 * @package QuickQuotes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles frontend shortcode rendering.
 */
class QQUO_Shortcode {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_shortcode( 'quick_quote_form', array( $this, 'render_quote_form_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
	}

	/**
	 * Register frontend assets.
	 *
	 * @return void
	 */
	public function register_assets() {
		wp_register_style(
			'qq-frontend-css',
			QQUO_PLUGIN_URL . 'assets/css/frontend.css',
			array(),
			QQUO_PLUGIN_VERSION
		);

		wp_register_script(
			'qq-frontend-js',
			QQUO_PLUGIN_URL . 'assets/js/frontend.js',
			array( 'jquery' ),
			QQUO_PLUGIN_VERSION,
			true
		);
	}

	/**
	 * Render shortcode output.
	 *
	 * @return string
	 */
	public function render_quote_form_shortcode() {
		$settings = $this->get_settings();
		$custom_fields = $this->get_custom_fields_config();

		wp_enqueue_style( 'qq-frontend-css' );
		wp_enqueue_script( 'qq-frontend-js' );
		$custom_form_css = isset( $settings['custom_form_css'] ) ? (string) $settings['custom_form_css'] : '';
		if ( '' !== trim( $custom_form_css ) ) {
			wp_add_inline_style( 'qq-frontend-css', $custom_form_css );
		}
		wp_localize_script(
			'qq-frontend-js',
			'QQFrontendData',
			array(
				'ajax_url'   => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'qquo_frontend_nonce' ),
				'successMsg' => __( 'Quote request submitted successfully.', 'quick-quotes' ),
				'errorMsg'   => __( 'There was an error submitting your quote request.', 'quick-quotes' ),
			)
		);

		ob_start();
		?>
		<div class="qq-frontend-wrap">
			<form id="qq-frontend-form" class="qq-frontend-form" method="post">
				<div class="qq-field-row">
					<label for="qq-front-client-name"><?php echo esc_html__( 'Client Name', 'quick-quotes' ); ?> *</label>
					<input type="text" id="qq-front-client-name" name="client_name" required />
				</div>

				<div class="qq-field-row">
					<label for="qq-front-client-email"><?php echo esc_html__( 'Client Email', 'quick-quotes' ); ?> *</label>
					<input type="email" id="qq-front-client-email" name="client_email" required />
				</div>

				<div class="qq-field-row">
					<label for="qq-front-project-type"><?php echo esc_html__( 'Project Type', 'quick-quotes' ); ?> *</label>
					<select id="qq-front-project-type" name="project_type" required>
						<option value=""><?php echo esc_html__( 'Select project type', 'quick-quotes' ); ?></option>
						<?php foreach ( $this->get_project_types() as $project_type ) : ?>
							<option value="<?php echo esc_attr( $project_type ); ?>"><?php echo esc_html( $project_type ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<?php foreach ( $custom_fields as $field ) : ?>
					<div class="qq-field-row">
						<label for="qq-front-custom-<?php echo esc_attr( $field['key'] ); ?>">
							<?php echo esc_html( $field['label'] ); ?>
							<?php if ( ! empty( $field['required'] ) ) : ?>*<?php endif; ?>
						</label>
						<?php if ( 'textarea' === $field['type'] ) : ?>
							<textarea id="qq-front-custom-<?php echo esc_attr( $field['key'] ); ?>" name="custom_field[<?php echo esc_attr( $field['key'] ); ?>]" rows="3" <?php echo ! empty( $field['required'] ) ? 'required' : ''; ?>></textarea>
						<?php elseif ( 'select' === $field['type'] ) : ?>
							<select id="qq-front-custom-<?php echo esc_attr( $field['key'] ); ?>" name="custom_field[<?php echo esc_attr( $field['key'] ); ?>]" <?php echo ! empty( $field['required'] ) ? 'required' : ''; ?>>
								<option value=""><?php echo esc_html__( 'Select an option', 'quick-quotes' ); ?></option>
								<?php foreach ( $field['options'] as $option ) : ?>
									<option value="<?php echo esc_attr( $option ); ?>"><?php echo esc_html( $option ); ?></option>
								<?php endforeach; ?>
							</select>
						<?php else : ?>
							<input type="<?php echo esc_attr( $field['type'] ); ?>" id="qq-front-custom-<?php echo esc_attr( $field['key'] ); ?>" name="custom_field[<?php echo esc_attr( $field['key'] ); ?>]" <?php echo ! empty( $field['required'] ) ? 'required' : ''; ?> />
						<?php endif; ?>
					</div>
				<?php endforeach; ?>

				<div class="qq-field-row">
					<label><?php echo esc_html__( 'Line Items', 'quick-quotes' ); ?> *</label>
					<div id="qq-front-line-items" class="qq-line-items">
						<div class="qq-line-item-row">
							<input type="text" name="line_description[]" placeholder="<?php echo esc_attr__( 'Description', 'quick-quotes' ); ?>" required />
							<input type="number" name="line_price[]" step="0.01" min="0" placeholder="<?php echo esc_attr__( 'Price', 'quick-quotes' ); ?>" required />
							<button type="button" class="qq-remove-line-item"><?php echo esc_html__( 'Remove', 'quick-quotes' ); ?></button>
						</div>
					</div>
					<button type="button" class="qq-add-line-item"><?php echo esc_html__( 'Add Line Item', 'quick-quotes' ); ?></button>
				</div>

				<div class="qq-field-row qq-percent-row">
					<div>
						<label for="qq-front-tax"><?php echo esc_html__( 'Tax %', 'quick-quotes' ); ?></label>
						<input type="number" id="qq-front-tax" name="tax_percent" min="0" max="100" step="0.01" value="<?php echo esc_attr( (string) $settings['default_tax_percent'] ); ?>" />
					</div>
					<div>
						<label for="qq-front-discount"><?php echo esc_html__( 'Discount %', 'quick-quotes' ); ?></label>
						<input type="number" id="qq-front-discount" name="discount_percent" min="0" max="100" step="0.01" value="<?php echo esc_attr( (string) $settings['default_discount_percent'] ); ?>" />
					</div>
				</div>

				<div class="qq-field-row">
					<label for="qq-front-notes"><?php echo esc_html__( 'Notes', 'quick-quotes' ); ?></label>
					<textarea id="qq-front-notes" name="notes" rows="4"></textarea>
				</div>

				<div class="qq-totals-box">
					<p><strong><?php echo esc_html__( 'Subtotal:', 'quick-quotes' ); ?></strong> <span id="qq-front-subtotal">0.00</span></p>
					<p><strong><?php echo esc_html__( 'Tax Amount:', 'quick-quotes' ); ?></strong> <span id="qq-front-tax-amount">0.00</span></p>
					<p><strong><?php echo esc_html__( 'Discount Amount:', 'quick-quotes' ); ?></strong> <span id="qq-front-discount-amount">0.00</span></p>
					<p><strong><?php echo esc_html__( 'Final Total:', 'quick-quotes' ); ?></strong> <span id="qq-front-final-total">0.00</span></p>
				</div>

				<div class="qq-field-row">
					<button type="submit" class="qq-submit"><?php echo esc_html__( 'Submit Quote Request', 'quick-quotes' ); ?></button>
				</div>
				<div class="qq-form-message" id="qq-front-message" aria-live="polite"></div>
			</form>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Get settings.
	 *
	 * @return array<string,string>
	 */
	private function get_settings() {
		$defaults = array(
			'default_tax_percent'      => '0',
			'default_discount_percent' => '0',
		);

		$settings = get_option( QQUO_OPTION_SETTINGS, array() );
		return wp_parse_args( $settings, $defaults );
	}

	/**
	 * Get project type options.
	 *
	 * @return array<int,string>
	 */
	private function get_project_types() {
		return array(
			'Website Design',
			'Ecommerce',
			'SEO',
			'Content Marketing',
			'Consulting',
			'Maintenance',
			'Custom',
		);
	}

	/**
	 * Get custom field configuration from form builder.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private function get_custom_fields_config() {
		$fields = get_option( QQUO_OPTION_CUSTOM_FIELDS, array() );
		if ( empty( $fields ) || ! is_array( $fields ) ) {
			return array();
		}

		$supported_types = array( 'text', 'email', 'tel', 'textarea', 'select' );
		$sanitized       = array();

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$key   = isset( $field['key'] ) ? sanitize_key( $field['key'] ) : '';
			$label = isset( $field['label'] ) ? sanitize_text_field( $field['label'] ) : '';
			$type  = isset( $field['type'] ) ? sanitize_key( $field['type'] ) : 'text';

			if ( '' === $key || '' === $label || ! in_array( $type, $supported_types, true ) ) {
				continue;
			}

			$options = array();
			if ( 'select' === $type && isset( $field['options'] ) && is_array( $field['options'] ) ) {
				foreach ( $field['options'] as $option ) {
					$option = sanitize_text_field( $option );
					if ( '' !== $option ) {
						$options[] = $option;
					}
				}
			}

			$sanitized[] = array(
				'key'      => $key,
				'label'    => $label,
				'type'     => $type,
				'required' => ! empty( $field['required'] ),
				'options'  => $options,
			);
		}

		return $sanitized;
	}
}
