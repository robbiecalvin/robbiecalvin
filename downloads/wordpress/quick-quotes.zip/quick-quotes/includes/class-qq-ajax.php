<?php
/**
 * AJAX handler class.
 *
 * @package QuickQuotes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles frontend AJAX requests.
 */
class QQUO_Ajax {
	private static $instance = null;

	/**
	 * Constructor.
	 */
	public function __construct() {
		self::$instance = $this;
		add_action( 'wp_ajax_qquo_submit_quote', array( $this, 'handle_frontend_quote_submission' ) );
		add_action( 'wp_ajax_nopriv_qquo_submit_quote', array( $this, 'handle_frontend_quote_submission' ) );
		add_action( 'wp_ajax_qq_submit_quote', array( $this, 'handle_frontend_quote_submission' ) );
		add_action( 'wp_ajax_nopriv_qq_submit_quote', array( $this, 'handle_frontend_quote_submission' ) );
		add_action( 'template_redirect', array( $this, 'maybe_render_public_invoice' ) );
		add_action( 'quick_woo/event/quote_draft_created_from_form', array( $this, 'handle_quote_draft_created_from_form' ), 10, 2 );
		add_action( 'quick_forms/submitted', array( $this, 'handle_quick_forms_submission' ), 10, 1 );
	}

	public static function instance() {
		return self::$instance;
	}

	/**
	 * Handle frontend quote submission.
	 *
	 * @return void
	 */
	public function handle_frontend_quote_submission() {
		check_ajax_referer( 'qquo_frontend_nonce', 'nonce' );

		$client_name      = isset( $_POST['client_name'] ) ? sanitize_text_field( wp_unslash( $_POST['client_name'] ) ) : '';
		$client_email     = isset( $_POST['client_email'] ) ? sanitize_email( wp_unslash( $_POST['client_email'] ) ) : '';
		$project_type     = isset( $_POST['project_type'] ) ? sanitize_text_field( wp_unslash( $_POST['project_type'] ) ) : '';
		$tax_percent      = isset( $_POST['tax_percent'] ) ? $this->sanitize_percentage( wp_unslash( $_POST['tax_percent'] ) ) : 0;
		$discount_percent = isset( $_POST['discount_percent'] ) ? $this->sanitize_percentage( wp_unslash( $_POST['discount_percent'] ) ) : 0;
		$notes            = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '';
		$raw_custom       = isset( $_POST['custom_field'] ) && is_array( $_POST['custom_field'] ) ? wp_unslash( $_POST['custom_field'] ) : array();

		$line_descriptions = isset( $_POST['line_description'] ) ? (array) wp_unslash( $_POST['line_description'] ) : array();
		$line_prices       = isset( $_POST['line_price'] ) ? (array) wp_unslash( $_POST['line_price'] ) : array();

		if ( empty( $client_name ) || empty( $client_email ) || empty( $project_type ) || ! is_email( $client_email ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Please complete all required fields with valid values.', 'quick-quotes' ),
				),
				400
			);
		}

		$line_items = array();
		$subtotal   = 0.0;

		foreach ( $line_descriptions as $index => $description ) {
			$clean_description = sanitize_text_field( $description );
			$price             = isset( $line_prices[ $index ] ) ? (float) $line_prices[ $index ] : 0;
			$price             = max( 0, round( $price, 2 ) );

			if ( '' === $clean_description ) {
				continue;
			}

			$line_items[] = array(
				'description' => $clean_description,
				'price'       => $price,
			);
			$subtotal    += $price;
		}

		if ( empty( $line_items ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Please add at least one valid line item.', 'quick-quotes' ),
				),
				400
			);
		}

		$custom_fields = $this->sanitize_custom_fields( $raw_custom );
		if ( is_wp_error( $custom_fields ) ) {
			wp_send_json_error(
				array(
					'message' => $custom_fields->get_error_message(),
				),
				400
			);
		}

		$compiled_notes = $notes;
		if ( ! empty( $custom_fields ) ) {
			$compiled_notes = $this->append_custom_fields_to_notes( $notes, $custom_fields );
		}

		$totals = $this->calculate_totals( $subtotal, $tax_percent, $discount_percent );

		global $wpdb;
		$table_name = $wpdb->prefix . 'quick_quotes';
		$now        = current_time( 'mysql' );
		$encoded    = wp_json_encode( $line_items );
		$status     = 'pending';

		$query = $wpdb->prepare(
			"INSERT INTO {$table_name}
			(client_name, client_email, project_type, line_items, subtotal, tax_percent, discount_percent, total, due_today, payment_mode, payment_percent, stripe_payment_url, notes, status, created_at)
			VALUES (%s, %s, %s, %s, %f, %f, %f, %f, %f, %s, %f, %s, %s, %s, %s)",
			$client_name,
			$client_email,
			$project_type,
			$encoded,
			$totals['subtotal'],
			$tax_percent,
			$discount_percent,
			$totals['final_total'],
			$totals['final_total'],
			'full',
			100,
			'',
			$compiled_notes,
			$status,
			$now
		);

		$inserted = $wpdb->query( $query );

		if ( false === $inserted ) {
			wp_send_json_error(
				array(
					'message' => __( 'Could not save your quote request. Please try again.', 'quick-quotes' ),
				),
				500
			);
		}

		$quote_id = absint( $wpdb->insert_id );
		$this->maybe_sync_to_quick_forms(
			$quote_id,
			$client_name,
			$client_email,
			$project_type,
			$line_items,
			$totals,
			$compiled_notes,
			$custom_fields
		);

		$this->maybe_send_notification_email( $client_name, $client_email, $project_type, $totals['final_total'], $custom_fields );
		$this->maybe_send_customer_invoice_email_by_quote_id( $quote_id );

		if ( function_exists( 'qwoo_event' ) ) {
			qwoo_event(
				'quote_created',
				array(
					'plugin'      => 'quick-quotes',
					'quote_id'    => $quote_id,
					'project_type'=> $project_type,
					'total'       => number_format( (float) $totals['final_total'], 2, '.', '' ),
				),
				array(
					'source' => 'quick-quotes',
				)
			);
		}

		wp_send_json_success(
			array(
				'message' => __( 'Quote request submitted successfully.', 'quick-quotes' ),
				'total'   => number_format( $totals['final_total'], 2, '.', '' ),
			)
		);
	}

	/**
	 * Handle quote draft event emitted by Quick Woo Core.
	 *
	 * @param array<string,mixed> $payload Event payload.
	 * @param array<string,mixed> $context Event context.
	 * @return void
	 */
	public function handle_quote_draft_created_from_form( $payload, $context ) {
		if ( ! is_array( $payload ) ) {
			return;
		}

		$quote_id = isset( $payload['quote_id'] ) ? absint( $payload['quote_id'] ) : 0;
		if ( $quote_id < 1 ) {
			return;
		}

		$this->maybe_send_customer_invoice_email_by_quote_id( $quote_id );
	}

	/**
	 * Handle direct Quick Forms submission integration.
	 *
	 * @param array<string,mixed> $event Event payload from Quick Forms.
	 * @return void
	 */
	public function handle_quick_forms_submission( $event ) {
		$this->create_quote_from_quick_forms_event( $event );
	}

	public function create_quote_from_quick_forms_event( $event ) {
		$result = array(
			'quote_id'    => 0,
			'invoice_url' => '',
		);

		if ( ! is_array( $event ) ) {
			return $result;
		}
		if ( ! empty( $event['_qquo_quote_id'] ) ) {
			$existing_quote_id = absint( $event['_qquo_quote_id'] );
			if ( $existing_quote_id > 0 ) {
				$result['quote_id'] = $existing_quote_id;
				$result['invoice_url'] = $this->get_or_create_public_invoice_url( $existing_quote_id );
				return $result;
			}
		}
		if ( ! qquo_is_premium_active() ) {
			return $result;
		}

		$settings = $this->get_quote_settings();
		if ( '1' !== $settings['qf_to_quote_enabled'] ) {
			return $result;
		}

		$form_id        = isset( $event['form_id'] ) ? absint( $event['form_id'] ) : 0;
		$submission_id  = isset( $event['submission_id'] ) ? absint( $event['submission_id'] ) : 0;
		$submitted_data = isset( $event['submitted_data'] ) && is_array( $event['submitted_data'] ) ? $event['submitted_data'] : array();
		$form           = isset( $event['form'] ) && is_array( $event['form'] ) ? $event['form'] : array();
		if ( empty( $submitted_data ) ) {
			return $result;
		}

		if ( $submission_id > 0 && $this->get_quote_id_for_form_submission( $submission_id ) > 0 ) {
			$existing_quote_id = $this->get_quote_id_for_form_submission( $submission_id );
			$result['quote_id'] = $existing_quote_id;
			$result['invoice_url'] = $this->get_or_create_public_invoice_url( $existing_quote_id );
			return $result;
		}

		$client_name  = $this->extract_client_name( $submitted_data );
		$client_email = $this->extract_client_email( $submitted_data );
		$project_type = $this->extract_project_type( $submitted_data, $form );

		if ( '' === $client_name ) {
			$client_name = __( 'Quick Woo Lead', 'quick-quotes' );
		}
		if ( ! is_email( $client_email ) ) {
			$client_email = get_option( 'admin_email', '' );
		}
		if ( '' === $project_type ) {
			$project_type = __( 'General', 'quick-quotes' );
		}

		$line_items = $this->build_line_items_from_form_submission( $form_id, $submitted_data, $form, $submission_id );
		if ( empty( $line_items ) ) {
			$line_items = array(
				array(
					'description' => sprintf( __( 'Submission #%d', 'quick-quotes' ), max( 1, $submission_id ) ),
					'qty'         => 1,
					'unit_price'  => 0,
					'price'       => 0,
				),
			);
		}

		$subtotal = 0.0;
		foreach ( $line_items as $item ) {
			$subtotal += isset( $item['price'] ) ? (float) $item['price'] : 0;
		}
		$subtotal = round( $subtotal, 2 );
		$form_invoice_config = $this->get_quick_forms_form_invoice_config( $form_id );
		$payment_percent = isset( $form_invoice_config['due_percent'] ) ? max( 0, min( 100, (float) $form_invoice_config['due_percent'] ) ) : 100.0;
		$due_today = round( $subtotal * ( $payment_percent / 100 ), 2 );
		$payment_action = isset( $form_invoice_config['payment_action'] ) ? sanitize_key( (string) $form_invoice_config['payment_action'] ) : 'pay_at_invoice';
		$payment_mode = 'book_consultation' === $payment_action ? 'consultation' : ( ( $payment_percent > 0 && $payment_percent < 100 ) ? 'percentage' : 'full' );
		$stripe_payment_url = '';

		$notes_parts = array(
			sprintf( __( 'Auto-created from Quick Forms submission #%d.', 'quick-quotes' ), max( 1, $submission_id ) ),
			wp_json_encode( $submitted_data ),
		);

		global $wpdb;
		$table_name = $wpdb->prefix . 'quick_quotes';
		$query      = $wpdb->prepare(
			"INSERT INTO {$table_name}
			(client_name, client_email, project_type, line_items, subtotal, tax_percent, discount_percent, total, due_today, payment_mode, payment_percent, stripe_payment_url, notes, status, created_at)
			VALUES (%s, %s, %s, %s, %f, %f, %f, %f, %f, %s, %f, %s, %s, %s, %s)",
			$client_name,
			$client_email,
			$project_type,
			wp_json_encode( $line_items ),
			$subtotal,
			0,
			0,
			$subtotal,
			$due_today,
			$payment_mode,
			$payment_percent,
			$stripe_payment_url,
			implode( "\n\n", $notes_parts ),
			'pending',
			current_time( 'mysql' )
		);

		$inserted = $wpdb->query( $query );
		if ( false === $inserted ) {
			return $result;
		}

		$quote_id = absint( $wpdb->insert_id );
		if ( $submission_id > 0 && $quote_id > 0 ) {
			$this->store_form_submission_quote_map( $submission_id, $quote_id );
		}

		if ( $quote_id > 0 && 'consultation' !== $payment_mode ) {
			$charge_amount = $due_today > 0 ? $due_today : $subtotal;
			$checkout = $this->create_woocommerce_checkout_for_quote( $quote_id, $charge_amount, $client_name, $project_type );
			if ( is_array( $checkout ) && ! empty( $checkout['checkout_url'] ) ) {
				$stripe_payment_url = esc_url_raw( (string) $checkout['checkout_url'] );
				$wpdb->query(
					$wpdb->prepare(
						"UPDATE {$table_name} SET stripe_payment_url = %s WHERE id = %d",
						$stripe_payment_url,
						$quote_id
					)
				);
			}
		}

		$this->maybe_send_customer_invoice_email_by_quote_id( $quote_id );
		$result['quote_id'] = $quote_id;
		$result['invoice_url'] = $this->get_or_create_public_invoice_url( $quote_id );

		return $result;
	}

	/**
	 * Maybe send email notification.
	 *
	 * @param string $client_name Client name.
	 * @param string $client_email Client email.
	 * @param string $project_type Project type.
	 * @param float  $final_total Final total.
	 * @param array<int,array<string,string>> $custom_fields Additional custom fields.
	 * @return void
	 */
	private function maybe_send_notification_email( $client_name, $client_email, $project_type, $final_total, $custom_fields ) {
		if ( ! qquo_is_premium_active() ) {
			return;
		}

		$settings = get_option( QQUO_OPTION_SETTINGS, array() );

		$enabled = isset( $settings['email_notifications'] ) && '1' === $settings['email_notifications'];
		$email   = isset( $settings['notification_email'] ) ? sanitize_email( $settings['notification_email'] ) : '';

		if ( ! $enabled || ! is_email( $email ) ) {
			return;
		}

		$subject = __( 'New Quick Quote Request', 'quick-quotes' );
		$message = sprintf(
			/* translators: 1: client name, 2: client email, 3: project type, 4: final total. */
			__( "A new quote request has been submitted.\n\nClient: %1$s\nEmail: %2$s\nProject Type: %3$s\nEstimated Total: %4$s", 'quick-quotes' ),
			$client_name,
			$client_email,
			$project_type,
			number_format_i18n( $final_total, 2 )
		);

		if ( ! empty( $custom_fields ) ) {
			$message .= "\n\n" . __( 'Additional Fields:', 'quick-quotes' );
			foreach ( $custom_fields as $field ) {
				$message .= "\n" . $field['label'] . ': ' . $field['value'];
			}
		}

		wp_mail( $email, $subject, $message );
	}

	/**
	 * Get supported custom field configuration.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private function get_custom_fields_config() {
		$fields = get_option( QQUO_OPTION_CUSTOM_FIELDS, array() );
		if ( empty( $fields ) || ! is_array( $fields ) ) {
			return array();
		}

		$supported = array( 'text', 'email', 'tel', 'textarea', 'select' );
		$result    = array();

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$key   = isset( $field['key'] ) ? sanitize_key( $field['key'] ) : '';
			$label = isset( $field['label'] ) ? sanitize_text_field( $field['label'] ) : '';
			$type  = isset( $field['type'] ) ? sanitize_key( $field['type'] ) : 'text';

			if ( '' === $key || '' === $label || ! in_array( $type, $supported, true ) ) {
				continue;
			}

			$options = array();
			if ( 'select' === $type && isset( $field['options'] ) && is_array( $field['options'] ) ) {
				foreach ( $field['options'] as $option ) {
					$option = sanitize_text_field( $option );
					if ( '' !== $option ) {
						$options[] = $option;
					}
				}
			}

			$result[] = array(
				'key'      => $key,
				'label'    => $label,
				'type'     => $type,
				'required' => ! empty( $field['required'] ),
				'options'  => $options,
			);
		}

		return $result;
	}

	/**
	 * Sanitize and validate custom field payload from frontend.
	 *
	 * @param array<string,mixed> $raw_custom Raw custom field values.
	 * @return array<int,array<string,string>>|\WP_Error
	 */
	private function sanitize_custom_fields( $raw_custom ) {
		$config = $this->get_custom_fields_config();
		if ( empty( $config ) ) {
			return array();
		}

		$sanitized = array();
		foreach ( $config as $field ) {
			$key      = $field['key'];
			$value    = isset( $raw_custom[ $key ] ) ? sanitize_text_field( (string) $raw_custom[ $key ] ) : '';
			$required = ! empty( $field['required'] );

			if ( $required && '' === $value ) {
				return new \WP_Error( 'qquo_required_custom_field', sprintf( __( '%s is required.', 'quick-quotes' ), $field['label'] ) );
			}

			if ( '' === $value ) {
				continue;
			}

			if ( 'email' === $field['type'] && ! is_email( $value ) ) {
				return new \WP_Error( 'qquo_invalid_custom_field', sprintf( __( '%s must be a valid email.', 'quick-quotes' ), $field['label'] ) );
			}

			if ( 'select' === $field['type'] && ! empty( $field['options'] ) && ! in_array( $value, $field['options'], true ) ) {
				return new \WP_Error( 'qquo_invalid_custom_field', sprintf( __( '%s has an invalid value.', 'quick-quotes' ), $field['label'] ) );
			}

			$sanitized[] = array(
				'key'   => $key,
				'label' => $field['label'],
				'value' => $value,
			);
		}

		return $sanitized;
	}

	/**
	 * Append custom field values to saved notes.
	 *
	 * @param string                               $notes Base notes.
	 * @param array<int,array<string,string>> $custom_fields Additional fields.
	 * @return string
	 */
	private function append_custom_fields_to_notes( $notes, $custom_fields ) {
		$custom_lines = array( __( 'Additional Fields:', 'quick-quotes' ) );
		foreach ( $custom_fields as $field ) {
			$custom_lines[] = $field['label'] . ': ' . $field['value'];
		}

		$custom_text = implode( "\n", $custom_lines );
		if ( '' === trim( $notes ) ) {
			return $custom_text;
		}

		return $notes . "\n\n" . $custom_text;
	}

	/**
	 * Create a linked Quick Forms submission when integration is enabled.
	 *
	 * @param int                                  $quote_id Quote ID.
	 * @param string                               $client_name Client name.
	 * @param string                               $client_email Client email.
	 * @param string                               $project_type Project type.
	 * @param array<int,array<string,mixed>>       $line_items Line items.
	 * @param array<string,float>                  $totals Calculated totals.
	 * @param string                               $notes Notes text.
	 * @param array<int,array<string,string>>      $custom_fields Additional custom fields.
	 * @return void
	 */
	private function maybe_sync_to_quick_forms( $quote_id, $client_name, $client_email, $project_type, $line_items, $totals, $notes, $custom_fields ) {
		if ( ! qquo_is_premium_active() ) {
			return;
		}

		$settings = get_option( QQUO_OPTION_SETTINGS, array() );
		$enabled  = isset( $settings['qf_integration_enabled'] ) && '1' === (string) $settings['qf_integration_enabled'];

		if ( ! $enabled || ! function_exists( 'qfrm_table_submissions' ) ) {
			return;
		}

		$form_id = $this->resolve_quick_forms_form_id( $project_type, $settings );
		if ( $form_id < 1 ) {
			return;
		}

		$submitted_data = array(
			'quote_id'          => (string) absint( $quote_id ),
			'client_name'       => (string) $client_name,
			'client_email'      => (string) $client_email,
			'project_type'      => (string) $project_type,
			'subtotal'          => number_format( (float) $totals['subtotal'], 2, '.', '' ),
			'tax_amount'        => number_format( (float) $totals['tax_amount'], 2, '.', '' ),
			'discount_amount'   => number_format( (float) $totals['discount_amount'], 2, '.', '' ),
			'final_total'       => number_format( (float) $totals['final_total'], 2, '.', '' ),
			'line_items_json'   => wp_json_encode( $line_items ),
			'notes'             => (string) $notes,
			'source_plugin'     => 'quick-quotes',
		);

		if ( ! empty( $custom_fields ) ) {
			$submitted_data['custom_fields_json'] = wp_json_encode( $custom_fields );
			foreach ( $custom_fields as $field ) {
				if ( empty( $field['key'] ) || ! isset( $field['value'] ) ) {
					continue;
				}
				$submitted_data[ 'qquo_' . sanitize_key( $field['key'] ) ] = sanitize_text_field( $field['value'] );
			}
		}

		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : null;
		$ip_hash    = function_exists( 'qf_hash_ip' ) ? qf_hash_ip() : hash( 'sha256', ( isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '' ) . wp_salt( 'nonce' ) );

		global $wpdb;
		$table = qfrm_table_submissions();

		$query = $wpdb->prepare(
			"INSERT INTO {$table}
			(form_id, submitted_data_json, files_json, ip_hash, user_agent, status, created_at)
			VALUES (%d, %s, %s, %s, %s, %s, %s)",
			$form_id,
			wp_json_encode( $submitted_data ),
			null,
			$ip_hash,
			$user_agent,
			'new',
			current_time( 'mysql' )
		);

		$created = $wpdb->query( $query );
		if ( false !== $created && function_exists( 'qf_increment_new_submission_count' ) ) {
			qf_increment_new_submission_count();
		}
	}

	/**
	 * Resolve target Quick Forms form ID for sync.
	 *
	 * @param string              $project_type Quote project type.
	 * @param array<string,mixed> $settings Quick Quotes settings.
	 * @return int
	 */
	private function resolve_quick_forms_form_id( $project_type, $settings ) {
		$default_form_id   = isset( $settings['qf_default_form_id'] ) ? absint( $settings['qf_default_form_id'] ) : 0;
		$match_quote_type  = isset( $settings['qf_match_project_type'] ) && '1' === (string) $settings['qf_match_project_type'];

		if ( $match_quote_type && class_exists( 'QFRM_Builder' ) ) {
			$builder = new QFRM_Builder();
			$form    = $builder->get_active_form_by_quote_type( $project_type );
			if ( is_array( $form ) && ! empty( $form['id'] ) ) {
				return absint( $form['id'] );
			}
		}

		return $default_form_id;
	}

	/**
	 * Build line items from configured Quick Forms field pricing.
	 *
	 * @param int                 $form_id Form ID.
	 * @param array<string,mixed> $submitted_data Form data.
	 * @param array<string,mixed> $form Form payload.
	 * @param int                 $submission_id Submission ID.
	 * @return array<int,array<string,mixed>>
	 */
	private function build_line_items_from_form_submission( $form_id, $submitted_data, $form, $submission_id ) {
		$form_id      = absint( $form_id );
		$pricing_map  = $this->get_quick_forms_pricing_for_form( $form_id );
		$field_labels = $this->get_form_field_label_map( $form );
		$line_items   = array();

		foreach ( $pricing_map as $field_key => $field_config ) {
			$field_key = sanitize_key( $field_key );
			if ( '' === $field_key || ! isset( $submitted_data[ $field_key ] ) ) {
				continue;
			}

			$base_amount    = 0.0;
			$option_amounts = array();

			if ( is_array( $field_config ) ) {
				$base_amount = isset( $field_config['amount'] ) ? $this->parse_amount( $field_config['amount'] ) : 0.0;
				if ( isset( $field_config['options'] ) && is_array( $field_config['options'] ) ) {
					foreach ( $field_config['options'] as $option_label => $option_amount ) {
						$option_label = sanitize_text_field( (string) $option_label );
						if ( '' === $option_label ) {
							continue;
						}

						$clean_option_amount = $this->parse_amount( $option_amount );
						if ( $clean_option_amount <= 0 ) {
							continue;
						}

						$option_amounts[ $this->normalize_option_key( $option_label ) ] = $clean_option_amount;
					}
				}
			} else {
				$base_amount = $this->parse_amount( $field_config );
			}

			$value = $submitted_data[ $field_key ];
			if ( ! $this->has_billable_submission_value( $value ) ) {
				continue;
			}

			$line_amount = 0.0;
			if ( ! empty( $option_amounts ) ) {
				$selected_values = $this->extract_selected_option_values( $value );
				foreach ( $selected_values as $selected_value ) {
					$selected_key = $this->normalize_option_key( $selected_value );
					if ( isset( $option_amounts[ $selected_key ] ) ) {
						$line_amount += (float) $option_amounts[ $selected_key ];
					}
				}
			}

			if ( $line_amount <= 0 && $base_amount > 0 ) {
				$line_amount = $base_amount;
			}

			if ( $line_amount <= 0 ) {
				continue;
			}

			$label      = isset( $field_labels[ $field_key ] ) ? $field_labels[ $field_key ] : $field_key;
			$value_text = $this->normalize_field_value_for_label( $value );
			$desc       = '' !== $value_text ? $label . ': ' . $value_text : $label;

			$line_items[] = array(
				'description' => $desc,
				'qty'         => 1.0,
				'unit_price'  => round( $line_amount, 2 ),
				'price'       => round( $line_amount, 2 ),
			);
		}

		if ( ! empty( $line_items ) ) {
			return $line_items;
		}

		return array(
			array(
				'description' => sprintf( __( 'Submission #%d', 'quick-quotes' ), max( 1, $submission_id ) ),
				'qty'         => 1.0,
				'unit_price'  => 0.0,
				'price'       => 0.0,
			),
		);
	}

	/**
	 * Get quote settings.
	 *
	 * @return array<string,string>
	 */
	private function get_quote_settings() {
		$defaults = array(
			'qf_to_quote_enabled' => '1',
			'qf_integration_enabled' => '1',
		);

		$settings = get_option( QQUO_OPTION_SETTINGS, array() );
		if ( ! is_array( $settings ) || ! isset( $settings['qf_to_quote_enabled'] ) ) {
			$legacy = get_option( 'qquo_settings', array() );
			if ( is_array( $legacy ) && isset( $legacy['qf_to_quote_enabled'] ) ) {
				$settings = $legacy;
				update_option( QQUO_OPTION_SETTINGS, $settings );
			}
		}
		$settings = wp_parse_args( is_array( $settings ) ? $settings : array(), $defaults );
		if ( ! isset( $settings['qf_to_quote_enabled'] ) && isset( $settings['qf_integration_enabled'] ) ) {
			$settings['qf_to_quote_enabled'] = '1' === (string) $settings['qf_integration_enabled'] ? '1' : '0';
		}
		$settings['qf_integration_enabled'] = '1' === (string) $settings['qf_to_quote_enabled'] ? '1' : '0';

		return $settings;
	}

	/**
	 * Get field pricing map for a Quick Form.
	 *
	 * @param int $form_id Quick Forms form ID.
	 * @return array<string,mixed>
	 */
	private function get_quick_forms_pricing_for_form( $form_id ) {
		$form_id = absint( $form_id );
		if ( $form_id < 1 ) {
			return array();
		}

		$map = get_option( QQUO_OPTION_QF_FIELD_PRICING, array() );
		if ( ! is_array( $map ) || empty( $map ) ) {
			$legacy_map = get_option( 'qquo_qf_field_pricing', array() );
			if ( is_array( $legacy_map ) && ! empty( $legacy_map ) ) {
				$map = $legacy_map;
				update_option( QQUO_OPTION_QF_FIELD_PRICING, $map );
			}
		}
		if ( ! is_array( $map ) || empty( $map[ $form_id ] ) || ! is_array( $map[ $form_id ] ) ) {
			return array();
		}

		$form_map = $map[ $form_id ];
		$output   = array();

		foreach ( $form_map as $field_key => $field_config ) {
			$field_key = sanitize_key( (string) $field_key );
			if ( '' === $field_key ) {
				continue;
			}

			$output[ $field_key ] = array(
				'amount'  => '',
				'options' => array(),
			);

			if ( is_array( $field_config ) ) {
				$output[ $field_key ]['amount'] = isset( $field_config['amount'] ) ? sanitize_text_field( (string) $field_config['amount'] ) : '';
				if ( isset( $field_config['options'] ) && is_array( $field_config['options'] ) ) {
					foreach ( $field_config['options'] as $option_name => $option_amount ) {
						$option_name = sanitize_text_field( (string) $option_name );
						if ( '' === $option_name ) {
							continue;
						}
						$output[ $field_key ]['options'][ $option_name ] = sanitize_text_field( (string) $option_amount );
					}
				}
			} else {
				$output[ $field_key ]['amount'] = sanitize_text_field( (string) $field_config );
			}
		}

		return $output;
	}

	/**
	 * Get per-form invoice config for Quick Forms generated quotes.
	 *
	 * @param int $form_id Quick Forms form ID.
	 * @return array<string,mixed>
	 */
	private function get_quick_forms_form_invoice_config( $form_id ) {
		$form_id = absint( $form_id );
		if ( $form_id < 1 ) {
			return array(
				'due_percent'    => 100,
				'payment_action' => 'pay_at_invoice',
			);
		}

		$config_map = get_option( QQUO_OPTION_QF_FORM_CONFIG, array() );
		if ( ! is_array( $config_map ) || empty( $config_map[ $form_id ] ) || ! is_array( $config_map[ $form_id ] ) ) {
			return array(
				'due_percent'    => 100,
				'payment_action' => 'pay_at_invoice',
			);
		}

		$raw = $config_map[ $form_id ];
		$due_percent = isset( $raw['due_percent'] ) ? max( 0, min( 100, round( (float) $raw['due_percent'], 2 ) ) ) : 100;
		$payment_action = isset( $raw['payment_action'] ) ? sanitize_key( (string) $raw['payment_action'] ) : 'pay_at_invoice';
		if ( ! in_array( $payment_action, array( 'pay_at_invoice', 'book_consultation' ), true ) ) {
			$payment_action = 'pay_at_invoice';
		}

		return array(
			'due_percent'    => $due_percent,
			'payment_action' => $payment_action,
		);
	}

	private function create_woocommerce_checkout_for_quote( $quote_id, $amount, $client_name, $project_type ) {
		$amount = max( 0, round( (float) $amount, 2 ) );
		if ( $amount <= 0 ) {
			return array();
		}
		if ( ! class_exists( 'WooCommerce' ) ) {
			return array();
		}

		$product_name = sprintf(
			/* translators: 1: quote id, 2: project type */
			__( 'Quote Payment #%1$d - %2$s', 'quick-quotes' ),
			absint( $quote_id ),
			sanitize_text_field( (string) $project_type )
		);

		$product_id = wp_insert_post(
			array(
				'post_type'    => 'product',
				'post_status'  => 'publish',
				'post_title'   => $product_name,
				'post_content' => '',
			),
			true
		);

		if ( is_wp_error( $product_id ) || $product_id < 1 ) {
			return array();
		}

		$price = number_format( $amount, 2, '.', '' );

		update_post_meta( $product_id, '_regular_price', $price );
		update_post_meta( $product_id, '_price', $price );
		update_post_meta( $product_id, '_virtual', 'yes' );
		update_post_meta( $product_id, '_sold_individually', 'yes' );
		update_post_meta( $product_id, '_manage_stock', 'no' );
		update_post_meta( $product_id, '_stock_status', 'instock' );
		update_post_meta( $product_id, '_visibility', 'hidden' );
		update_post_meta( $product_id, '_qwoo_quote_id', absint( $quote_id ) );
		update_post_meta( $product_id, '_qwoo_quote_client_name', sanitize_text_field( (string) $client_name ) );

		$checkout_url = '';
		if ( function_exists( 'wc_get_checkout_url' ) ) {
			$checkout_url = add_query_arg(
				array(
					'add-to-cart' => absint( $product_id ),
					'quantity'    => 1,
				),
				wc_get_checkout_url()
			);
		}

		return array(
			'product_id'   => absint( $product_id ),
			'checkout_url' => esc_url_raw( $checkout_url ),
		);
	}

	/**
	 * Build field label map from Quick Forms payload.
	 *
	 * @param array<string,mixed> $form Form payload.
	 * @return array<string,string>
	 */
	private function get_form_field_label_map( $form ) {
		$labels = array();
		$raw_fields = isset( $form['fields_json'] ) ? json_decode( (string) $form['fields_json'], true ) : array();
		if ( ! is_array( $raw_fields ) ) {
			return $labels;
		}

		foreach ( $raw_fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$name = isset( $field['name'] ) ? sanitize_key( (string) $field['name'] ) : '';
			if ( '' === $name ) {
				continue;
			}

			$labels[ $name ] = isset( $field['label'] ) ? sanitize_text_field( (string) $field['label'] ) : $name;
		}

		return $labels;
	}

	/**
	 * Whether a submitted field has a billable value.
	 *
	 * @param mixed $value Submitted value.
	 * @return bool
	 */
	private function has_billable_submission_value( $value ) {
		if ( is_array( $value ) ) {
			return ! empty( $value );
		}

		$value = trim( (string) $value );
		return '' !== $value && '0' !== $value;
	}

	/**
	 * Convert submitted value into label-safe display text.
	 *
	 * @param mixed $value Submitted field value.
	 * @return string
	 */
	private function normalize_field_value_for_label( $value ) {
		if ( is_array( $value ) ) {
			$clean = array();
			foreach ( $value as $part ) {
				$part = sanitize_text_field( (string) $part );
				if ( '' !== $part ) {
					$clean[] = $part;
				}
			}
			return implode( ', ', $clean );
		}

		return sanitize_text_field( (string) $value );
	}

	/**
	 * Normalize submitted value(s) for option price matching.
	 *
	 * @param mixed $value Submitted value.
	 * @return array<int,string>
	 */
	private function extract_selected_option_values( $value ) {
		$values = array();
		if ( is_array( $value ) ) {
			$values = $value;
		} else {
			$raw = sanitize_text_field( (string) $value );
			if ( false !== strpos( $raw, ',' ) ) {
				$values = explode( ',', $raw );
			} else {
				$values = array( $raw );
			}
		}

		$output = array();
		foreach ( $values as $item ) {
			$item = sanitize_text_field( trim( (string) $item ) );
			if ( '' !== $item ) {
				$output[] = $item;
			}
		}

		return $output;
	}

	/**
	 * Normalize option text for tolerant matching.
	 *
	 * @param string $raw_option Option text.
	 * @return string
	 */
	private function normalize_option_key( $raw_option ) {
		$normalized = strtolower( trim( sanitize_text_field( (string) $raw_option ) ) );
		return preg_replace( '/\s+/', ' ', $normalized );
	}

	/**
	 * Extract best-effort client name.
	 *
	 * @param array<string,mixed> $submitted_data Form submission payload.
	 * @return string
	 */
	private function extract_client_name( $submitted_data ) {
		$candidate_keys = array( 'client_name', 'full_name', 'name', 'your_name', 'first_name', 'last_name' );
		$value          = $this->pick_first_matching_field_value( $submitted_data, $candidate_keys );
		return sanitize_text_field( $value );
	}

	/**
	 * Extract best-effort client email.
	 *
	 * @param array<string,mixed> $submitted_data Form submission payload.
	 * @return string
	 */
	private function extract_client_email( $submitted_data ) {
		$candidate_keys = array( 'client_email', 'email', 'your_email', 'contact_email' );
		$value          = $this->pick_first_matching_field_value( $submitted_data, $candidate_keys );
		$value          = sanitize_email( $value );

		if ( is_email( $value ) ) {
			return $value;
		}

		foreach ( $submitted_data as $field_value ) {
			$maybe_email = sanitize_email( (string) $field_value );
			if ( is_email( $maybe_email ) ) {
				return $maybe_email;
			}
		}

		return '';
	}

	/**
	 * Extract best-effort project type.
	 *
	 * @param array<string,mixed> $submitted_data Form submission payload.
	 * @param array<string,mixed> $form Form payload.
	 * @return string
	 */
	private function extract_project_type( $submitted_data, $form ) {
		$candidate_keys = array( 'project_type', 'quote_type', 'service', 'subject' );
		$value          = $this->pick_first_matching_field_value( $submitted_data, $candidate_keys );
		if ( '' !== $value ) {
			return sanitize_text_field( $value );
		}

		return isset( $form['name'] ) ? sanitize_text_field( (string) $form['name'] ) : '';
	}

	/**
	 * Pick first non-empty value by key priority.
	 *
	 * @param array<string,mixed> $submitted_data Form submission payload.
	 * @param array<int,string>   $candidate_keys Candidate field keys.
	 * @return string
	 */
	private function pick_first_matching_field_value( $submitted_data, $candidate_keys ) {
		if ( ! is_array( $submitted_data ) ) {
			return '';
		}

		foreach ( $candidate_keys as $key ) {
			$key = sanitize_key( $key );
			if ( '' === $key || ! array_key_exists( $key, $submitted_data ) ) {
				continue;
			}

			$value = $this->normalize_field_value_for_label( $submitted_data[ $key ] );
			if ( '' !== trim( $value ) ) {
				return $value;
			}
		}

		return '';
	}

	/**
	 * Parse amount.
	 *
	 * @param mixed $raw_value Raw value.
	 * @return float
	 */
	private function parse_amount( $raw_value ) {
		$value = preg_replace( '/[^0-9.\-]/', '', (string) $raw_value );
		if ( '' === $value || ! is_numeric( $value ) ) {
			return 0.0;
		}

		return max( 0, round( (float) $value, 2 ) );
	}

	/**
	 * Get mapped quote id by form submission id.
	 *
	 * @param int $submission_id Submission ID.
	 * @return int
	 */
	private function get_quote_id_for_form_submission( $submission_id ) {
		$submission_id = absint( $submission_id );
		if ( $submission_id < 1 ) {
			return 0;
		}

		$map = get_option( QQUO_OPTION_QF_SUBMISSION_QUOTE_MAP, array() );
		$map = is_array( $map ) ? $map : array();
		return isset( $map[ $submission_id ] ) ? absint( $map[ $submission_id ] ) : 0;
	}

	public function get_quote_id_by_form_submission( $submission_id ) {
		return $this->get_quote_id_for_form_submission( $submission_id );
	}

	/**
	 * Store form submission to quote map.
	 *
	 * @param int $submission_id Submission ID.
	 * @param int $quote_id Quote ID.
	 * @return void
	 */
	private function store_form_submission_quote_map( $submission_id, $quote_id ) {
		$submission_id = absint( $submission_id );
		$quote_id      = absint( $quote_id );
		if ( $submission_id < 1 || $quote_id < 1 ) {
			return;
		}

		$map = get_option( QQUO_OPTION_QF_SUBMISSION_QUOTE_MAP, array() );
		$map = is_array( $map ) ? $map : array();
		$map[ $submission_id ] = $quote_id;
		if ( count( $map ) > 2000 ) {
			$map = array_slice( $map, -2000, null, true );
		}
		update_option( QQUO_OPTION_QF_SUBMISSION_QUOTE_MAP, $map, false );
	}

	/**
	 * Send public invoice link email to quote customer.
	 *
	 * @param int $quote_id Quote ID.
	 * @return void
	 */
	private function maybe_send_customer_invoice_email_by_quote_id( $quote_id ) {
		$quote = $this->get_quote_by_id( $quote_id );
		if ( ! $quote || empty( $quote->client_email ) || ! is_email( $quote->client_email ) ) {
			return;
		}

		$invoice_url = $this->get_or_create_public_invoice_url( $quote_id );
		if ( '' === $invoice_url ) {
			return;
		}

		$subject = sprintf(
			/* translators: %d: quote id. */
			__( 'Your Quick Woo Invoice #%d', 'quick-quotes' ),
			absint( $quote_id )
		);
		$message = sprintf(
			/* translators: 1: client name, 2: invoice URL. */
			__( "Hi %1\$s,\n\nYour invoice estimate is ready. You can view it here:\n%2\$s\n\nThank you.", 'quick-quotes' ),
			sanitize_text_field( (string) $quote->client_name ),
			$invoice_url
		);

		wp_mail( sanitize_email( (string) $quote->client_email ), $subject, $message );
	}

	/**
	 * Render a public invoice view by token.
	 *
	 * @return void
	 */
	public function maybe_render_public_invoice() {
		$quote_id = isset( $_GET['qquo_invoice'] ) ? absint( $_GET['qquo_invoice'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$token    = isset( $_GET['qquo_token'] ) ? sanitize_text_field( wp_unslash( $_GET['qquo_token'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( $quote_id < 1 || '' === $token ) {
			return;
		}

		$expected = $this->get_invoice_token_for_quote( $quote_id );
		if ( '' === $expected || ! hash_equals( $expected, $token ) ) {
			status_header( 403 );
			wp_die( esc_html__( 'Invalid invoice token.', 'quick-quotes' ) );
		}

		$quote = $this->get_quote_by_id( $quote_id );
		if ( ! $quote ) {
			status_header( 404 );
			wp_die( esc_html__( 'Invoice not found.', 'quick-quotes' ) );
		}

		$template = get_option( QQUO_OPTION_INVOICE_TEMPLATE, array() );
		$template = wp_parse_args(
			is_array( $template ) ? $template : array(),
			array(
				'company_name'  => get_bloginfo( 'name' ),
				'accent_color'  => '#1d4ed8',
				'invoice_title' => __( 'Quote Invoice', 'quick-quotes' ),
				'footer_text'   => __( 'Thank you for your business.', 'quick-quotes' ),
			)
		);

		$line_items = json_decode( (string) $quote->line_items, true );
		if ( ! is_array( $line_items ) ) {
			$line_items = array();
		}

		$tax_amount      = round( (float) $quote->subtotal * ( (float) $quote->tax_percent / 100 ), 2 );
		$discount_amount = round( (float) $quote->subtotal * ( (float) $quote->discount_percent / 100 ), 2 );
		$premium_enabled = qquo_is_premium_active();
		$payment_mode    = isset( $quote->payment_mode ) ? sanitize_key( (string) $quote->payment_mode ) : 'full';
		if ( ! $premium_enabled ) {
			$payment_mode = 'full';
		}
		$payment_percent = isset( $quote->payment_percent ) ? max( 0, min( 100, (float) $quote->payment_percent ) ) : 100;
		$due_today       = isset( $quote->due_today ) ? max( 0, (float) $quote->due_today ) : (float) $quote->total;
		$stripe_url      = $premium_enabled && isset( $quote->stripe_payment_url ) ? esc_url_raw( (string) $quote->stripe_payment_url ) : '';
		$settings        = get_option( QQUO_OPTION_SETTINGS, array() );
		$quick_schedule_integration_enabled = $premium_enabled && isset( $settings['quick_schedule_integration_enabled'] ) && '1' === (string) $settings['quick_schedule_integration_enabled'];
		$schedule_url    = $premium_enabled && isset( $settings['quick_schedule_page_url'] ) ? esc_url_raw( (string) $settings['quick_schedule_page_url'] ) : '';
		if ( ! $quick_schedule_integration_enabled ) {
			$schedule_url = '';
		}
		$schedule_page_id = 0;
		if ( '' !== $schedule_url ) {
			$schedule_page_id = absint( url_to_postid( $schedule_url ) );
		}
		if ( $schedule_page_id < 1 ) {
			$schedule_page_id = $this->find_quick_schedule_page_id();
		}
		if ( $schedule_page_id > 0 ) {
			$schedule_url = add_query_arg( 'page_id', $schedule_page_id, home_url( '/' ) );
		} elseif ( '' === $schedule_url ) {
			$schedule_url = $this->find_quick_schedule_page_url();
		}
		$schedule_link   = '';
		if ( '' !== $schedule_url && 'consultation' === $payment_mode ) {
			$schedule_link = add_query_arg(
				array(
					'quote_id'  => absint( $quote->id ),
					'name'      => (string) $quote->client_name,
					'email'     => (string) $quote->client_email,
					'amount'    => number_format( (float) $quote->total, 2, '.', '' ),
					'due_today' => number_format( (float) $due_today, 2, '.', '' ),
				),
				$schedule_url
			);
		}

		nocache_headers();
		$custom_invoice_css = isset( $settings['custom_invoice_css'] ) ? (string) $settings['custom_invoice_css'] : '';
		?>
		<!doctype html>
		<html <?php language_attributes(); ?>>
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>" />
			<meta name="viewport" content="width=device-width, initial-scale=1" />
			<title><?php echo esc_html( (string) $template['invoice_title'] ); ?></title>
			<style>
				body{font-family:Arial,sans-serif;background:#f5f6f8;padding:24px;color:#111}
				.qq-invoice{max-width:880px;margin:0 auto;background:#fff;border:1px solid #ddd;padding:24px}
				.qq-head{display:flex;justify-content:space-between;gap:16px;border-bottom:2px solid <?php echo esc_html( sanitize_hex_color( (string) $template['accent_color'] ) ? sanitize_hex_color( (string) $template['accent_color'] ) : '#1d4ed8' ); ?>;padding-bottom:12px}
				table{width:100%;border-collapse:collapse;margin-top:18px}
				th,td{padding:8px;border-bottom:1px solid #e5e7eb;text-align:left}
				.qq-total{font-size:20px;font-weight:700}
				.qq-meta p{margin:4px 0}
				.qq-actions{margin-top:24px;padding-top:16px;border-top:1px solid #e5e7eb}
				.qq-btn{display:inline-block;background:#1f6ef5;color:#fff !important;text-decoration:none;padding:12px 16px;border-radius:6px;border:1px solid #1f6ef5;font-weight:600}
				<?php echo wp_strip_all_tags( $custom_invoice_css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</style>
		</head>
		<body>
			<div class="qq-invoice">
				<div class="qq-head">
					<div>
						<h1><?php echo esc_html( (string) $template['invoice_title'] ); ?></h1>
						<p><?php echo esc_html( (string) $template['company_name'] ); ?></p>
					</div>
					<div class="qq-meta">
						<p><strong><?php echo esc_html__( 'Invoice #', 'quick-quotes' ); ?></strong> <?php echo esc_html( (string) $quote->id ); ?></p>
						<p><strong><?php echo esc_html__( 'Date', 'quick-quotes' ); ?></strong> <?php echo esc_html( (string) $quote->created_at ); ?></p>
						<p><strong><?php echo esc_html__( 'Status', 'quick-quotes' ); ?></strong> <?php echo esc_html( ucfirst( (string) $quote->status ) ); ?></p>
					</div>
				</div>
				<p><strong><?php echo esc_html__( 'Bill To:', 'quick-quotes' ); ?></strong> <?php echo esc_html( (string) $quote->client_name ); ?> (<?php echo esc_html( (string) $quote->client_email ); ?>)</p>
				<table>
					<thead><tr><th><?php echo esc_html__( 'Description', 'quick-quotes' ); ?></th><th><?php echo esc_html__( 'Qty', 'quick-quotes' ); ?></th><th><?php echo esc_html__( 'Unit', 'quick-quotes' ); ?></th><th><?php echo esc_html__( 'Amount', 'quick-quotes' ); ?></th></tr></thead>
					<tbody>
						<?php foreach ( $line_items as $item ) : ?>
							<tr>
								<td><?php echo esc_html( isset( $item['description'] ) ? (string) $item['description'] : '' ); ?></td>
								<td><?php echo esc_html( isset( $item['qty'] ) ? (string) $item['qty'] : '1' ); ?></td>
								<td><?php echo esc_html( number_format_i18n( isset( $item['unit_price'] ) ? (float) $item['unit_price'] : ( isset( $item['price'] ) ? (float) $item['price'] : 0 ), 2 ) ); ?></td>
								<td><?php echo esc_html( number_format_i18n( isset( $item['price'] ) ? (float) $item['price'] : 0, 2 ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<p><strong><?php echo esc_html__( 'Subtotal:', 'quick-quotes' ); ?></strong> <?php echo esc_html( number_format_i18n( (float) $quote->subtotal, 2 ) ); ?></p>
				<p><strong><?php echo esc_html__( 'Tax:', 'quick-quotes' ); ?></strong> <?php echo esc_html( number_format_i18n( $tax_amount, 2 ) ); ?></p>
				<p><strong><?php echo esc_html__( 'Discount:', 'quick-quotes' ); ?></strong> <?php echo esc_html( number_format_i18n( $discount_amount, 2 ) ); ?></p>
				<p class="qq-total"><strong><?php echo esc_html__( 'Total Estimate:', 'quick-quotes' ); ?></strong> <?php echo esc_html( number_format_i18n( (float) $quote->total, 2 ) ); ?></p>
				<p><strong><?php echo esc_html__( 'Due Today:', 'quick-quotes' ); ?></strong> <?php echo esc_html( number_format_i18n( $due_today, 2 ) ); ?></p>
				<p><strong><?php echo esc_html__( 'Payment Mode:', 'quick-quotes' ); ?></strong> <?php echo esc_html( ucfirst( $payment_mode ) ); ?><?php echo 'percentage' === $payment_mode ? esc_html( ' (' . number_format_i18n( $payment_percent, 2 ) . '%)' ) : ''; ?></p>
				<?php if ( 'consultation' === $payment_mode ) : ?>
					<?php if ( '' === $schedule_link ) : ?>
						<p><?php echo esc_html__( 'Follow-up consultation is required. Please contact us to schedule.', 'quick-quotes' ); ?></p>
					<?php endif; ?>
				<?php elseif ( '' !== $stripe_url ) : ?>
					<p><a href="<?php echo esc_url( $stripe_url ); ?>"><?php echo esc_html__( 'Pay Now', 'quick-quotes' ); ?></a></p>
				<?php else : ?>
					<p><?php echo esc_html__( 'Payment link will be provided by your service provider.', 'quick-quotes' ); ?></p>
				<?php endif; ?>
				<p><?php echo esc_html( (string) $template['footer_text'] ); ?></p>
				<?php if ( '' !== $schedule_link ) : ?>
					<div class="qq-actions">
						<a class="qq-btn" href="<?php echo esc_url( $schedule_link ); ?>"><?php echo esc_html__( 'Book Consultation', 'quick-quotes' ); ?></a>
					</div>
				<?php endif; ?>
			</div>
		</body>
		</html>
		<?php
		exit;
	}

	/**
	 * Find a published page that contains a Quick Schedule shortcode.
	 *
	 * @return string
	 */
	private function find_quick_schedule_page_url() {
		global $wpdb;

		$like_primary = '%' . $wpdb->esc_like( '[quick_schedule_appointment_page' ) . '%';
		$like_fallback = '%' . $wpdb->esc_like( '[quick_schedule_booking' ) . '%';

		$page_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = %s
				AND post_status = %s
				AND (post_content LIKE %s OR post_content LIKE %s)
				ORDER BY ID ASC
				LIMIT 1",
				'page',
				'publish',
				$like_primary,
				$like_fallback
			)
		);

		if ( $page_id < 1 ) {
			return '';
		}

		return get_permalink( $page_id ) ?: '';
	}

	/**
	 * Find Quick Schedule page ID by shortcode lookup.
	 *
	 * @return int
	 */
	private function find_quick_schedule_page_id() {
		global $wpdb;

		$like_primary = '%' . $wpdb->esc_like( '[quick_schedule_appointment_page' ) . '%';
		$like_fallback = '%' . $wpdb->esc_like( '[quick_schedule_booking' ) . '%';

		$page_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = %s
				AND post_status = %s
				AND (post_content LIKE %s OR post_content LIKE %s)
				ORDER BY ID ASC
				LIMIT 1",
				'page',
				'publish',
				$like_primary,
				$like_fallback
			)
		);

		return $page_id > 0 ? $page_id : 0;
	}

	/**
	 * Get quote by ID.
	 *
	 * @param int $quote_id Quote ID.
	 * @return object|null
	 */
	private function get_quote_by_id( $quote_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . 'quick_quotes';
		$query      = $wpdb->prepare( "SELECT * FROM {$table_name} WHERE id = %d LIMIT 1", absint( $quote_id ) );
		return $wpdb->get_row( $query );
	}

	/**
	 * Get or create invoice URL.
	 *
	 * @param int $quote_id Quote ID.
	 * @return string
	 */
	private function get_or_create_public_invoice_url( $quote_id ) {
		$quote_id = absint( $quote_id );
		if ( $quote_id < 1 ) {
			return '';
		}

		$token = $this->get_invoice_token_for_quote( $quote_id );
		if ( '' === $token ) {
			$token = wp_generate_password( 32, false, false );
			$this->set_invoice_token_for_quote( $quote_id, $token );
		}

		return add_query_arg(
			array(
				'qquo_invoice' => $quote_id,
				'qquo_token'   => $token,
			),
			home_url( '/' )
		);
	}

	public function get_public_invoice_url( $quote_id ) {
		return $this->get_or_create_public_invoice_url( $quote_id );
	}

	/**
	 * Get invoice token for quote.
	 *
	 * @param int $quote_id Quote ID.
	 * @return string
	 */
	private function get_invoice_token_for_quote( $quote_id ) {
		$tokens = get_option( QQUO_OPTION_INVOICE_TOKENS, array() );
		if ( ! is_array( $tokens ) ) {
			return '';
		}

		return isset( $tokens[ absint( $quote_id ) ] ) ? sanitize_text_field( (string) $tokens[ absint( $quote_id ) ] ) : '';
	}

	/**
	 * Set invoice token for quote.
	 *
	 * @param int    $quote_id Quote ID.
	 * @param string $token Invoice token.
	 * @return void
	 */
	private function set_invoice_token_for_quote( $quote_id, $token ) {
		$quote_id = absint( $quote_id );
		$token    = sanitize_text_field( (string) $token );
		if ( $quote_id < 1 || '' === $token ) {
			return;
		}

		$tokens             = get_option( QQUO_OPTION_INVOICE_TOKENS, array() );
		$tokens             = is_array( $tokens ) ? $tokens : array();
		$tokens[ $quote_id ] = $token;
		if ( count( $tokens ) > 2000 ) {
			$tokens = array_slice( $tokens, -2000, null, true );
		}
		update_option( QQUO_OPTION_INVOICE_TOKENS, $tokens, false );
	}

	/**
	 * Sanitize percentage value.
	 *
	 * @param mixed $value Raw value.
	 * @return float
	 */
	private function sanitize_percentage( $value ) {
		$percent = (float) $value;
		$percent = max( 0, min( 100, $percent ) );
		return round( $percent, 2 );
	}

	/**
	 * Calculate totals.
	 *
	 * @param float $subtotal Subtotal.
	 * @param float $tax_percent Tax percent.
	 * @param float $discount_percent Discount percent.
	 * @return array<string,float>
	 */
	private function calculate_totals( $subtotal, $tax_percent, $discount_percent ) {
		$subtotal        = round( (float) $subtotal, 2 );
		$tax_amount      = round( $subtotal * ( (float) $tax_percent / 100 ), 2 );
		$discount_amount = round( $subtotal * ( (float) $discount_percent / 100 ), 2 );
		$final_total     = max( 0, round( $subtotal + $tax_amount - $discount_amount, 2 ) );

		return array(
			'subtotal'        => $subtotal,
			'tax_amount'      => $tax_amount,
			'discount_amount' => $discount_amount,
			'final_total'     => $final_total,
		);
	}
}
