<?php
/**
 * Admin class.
 *
 * @package QuickQuotes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles admin pages and actions.
 */
class QQUO_Admin {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

		add_action( 'admin_post_qquo_save_quote', array( $this, 'handle_save_quote' ) );
		add_action( 'admin_post_qq_save_quote', array( $this, 'handle_save_quote' ) );
		add_action( 'admin_post_qquo_delete_quote', array( $this, 'handle_delete_quote' ) );
		add_action( 'admin_post_qq_delete_quote', array( $this, 'handle_delete_quote' ) );
		add_action( 'admin_post_qquo_update_status', array( $this, 'handle_update_status' ) );
		add_action( 'admin_post_qq_update_status', array( $this, 'handle_update_status' ) );
		add_action( 'admin_post_qquo_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_qq_save_settings', array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_qquo_save_form_builder', array( $this, 'handle_save_form_builder' ) );
		add_action( 'admin_post_qq_save_form_builder', array( $this, 'handle_save_form_builder' ) );
		add_action( 'admin_post_qquo_save_invoice_template', array( $this, 'handle_save_invoice_template' ) );
		add_action( 'admin_post_qq_save_invoice_template', array( $this, 'handle_save_invoice_template' ) );
		add_action( 'admin_post_qquo_activate_license', array( $this, 'handle_activate_license' ) );
		add_action( 'admin_post_qquo_deactivate_license', array( $this, 'handle_deactivate_license' ) );
		add_action( 'admin_post_qquo_save_style', array( $this, 'handle_save_style' ) );
	}

	/**
	 * Register admin menu and submenus.
	 *
	 * @return void
	 */
	public function register_admin_menu() {
		add_menu_page(
			esc_html__( 'Quick Quotes', 'quick-quotes' ),
			esc_html__( 'Quick Quotes', 'quick-quotes' ),
			'manage_options',
			'quick-quotes',
			array( $this, 'render_all_quotes_page' ),
			'dashicons-media-spreadsheet',
			26
		);

		add_submenu_page(
			'quick-quotes',
			esc_html__( 'All Quotes', 'quick-quotes' ),
			esc_html__( 'All Quotes', 'quick-quotes' ),
			'manage_options',
			'quick-quotes',
			array( $this, 'render_all_quotes_page' )
		);

		add_submenu_page(
			'quick-quotes',
			esc_html__( 'Add New Quote', 'quick-quotes' ),
			esc_html__( 'Add New', 'quick-quotes' ),
			'manage_options',
			'quick-quotes-add-new',
			array( $this, 'render_quote_form_page' )
		);

		add_submenu_page(
			'quick-quotes',
			esc_html__( 'Quick Quotes Settings', 'quick-quotes' ),
			esc_html__( 'Settings', 'quick-quotes' ),
			'manage_options',
			'quick-quotes-settings',
			array( $this, 'render_settings_page' )
		);

		add_submenu_page(
			'quick-quotes',
			esc_html__( 'Form Builder', 'quick-quotes' ),
			esc_html__( 'Form Builder', 'quick-quotes' ),
			'manage_options',
			'quick-quotes-form-builder',
			array( $this, 'render_form_builder_page' )
		);

		add_submenu_page(
			'quick-quotes',
			esc_html__( 'Invoice Customizer', 'quick-quotes' ),
			esc_html__( 'Invoice Customizer', 'quick-quotes' ),
			'manage_options',
			'quick-quotes-invoice-customizer',
			array( $this, 'render_invoice_customizer_page' )
		);

		add_submenu_page(
			'quick-quotes',
			esc_html__( 'Style', 'quick-quotes' ),
			esc_html__( 'Style', 'quick-quotes' ),
			'manage_options',
			'quick-quotes-style',
			array( $this, 'render_style_page' )
		);

		add_submenu_page(
			null,
			esc_html__( 'Quote Invoice', 'quick-quotes' ),
			esc_html__( 'Quote Invoice', 'quick-quotes' ),
			'manage_options',
			'quick-quotes-invoice',
			array( $this, 'render_invoice_page' )
		);
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook_suffix Admin hook suffix.
	 * @return void
	 */
	public function enqueue_admin_assets( $hook_suffix ) {
		$allowed_hooks = array(
			'toplevel_page_quick-quotes',
			'quick-quotes_page_quick-quotes-add-new',
			'quick-quotes_page_quick-quotes-settings',
			'quick-quotes_page_quick-quotes-form-builder',
			'quick-quotes_page_quick-quotes-invoice-customizer',
			'quick-quotes_page_quick-quotes-invoice',
		);

		if ( ! in_array( $hook_suffix, $allowed_hooks, true ) ) {
			return;
		}

		$settings = $this->get_settings();

		wp_enqueue_style(
			'qq-admin-css',
			QQUO_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			QQUO_PLUGIN_VERSION
		);
		wp_enqueue_style(
			'qq-admin-ui-css',
			QQUO_PLUGIN_URL . 'assets/css/admin-ui.css',
			array( 'qq-admin-css' ),
			QQUO_PLUGIN_VERSION
		);

		wp_enqueue_script(
			'qq-admin-js',
			QQUO_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			QQUO_PLUGIN_VERSION,
			true
		);
		wp_enqueue_script(
			'qq-admin-ui-js',
			QQUO_PLUGIN_URL . 'assets/js/admin-ui.js',
			array( 'qq-admin-js' ),
			QQUO_PLUGIN_VERSION,
			true
		);

		wp_localize_script(
			'qq-admin-js',
			'QQAdminData',
			array(
				'ajax_url'         => admin_url( 'admin-ajax.php' ),
				'nonce'            => wp_create_nonce( 'qquo_admin_nonce' ),
				'default_tax'      => $settings['default_tax_percent'],
				'default_discount' => $settings['default_discount_percent'],
			)
		);
	}

	/**
	 * Render quotes list page.
	 *
	 * @return void
	 */
	public function render_all_quotes_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-quotes' ) );
		}

		global $wpdb;

		$table_name = $this->get_table_name();
		$quotes     = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table_name} ORDER BY created_at DESC LIMIT %d", 500 ) );
		$settings = $this->get_settings();
		$license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';
		$license_status = isset( $settings['license_status'] ) ? sanitize_key( (string) $settings['license_status'] ) : 'inactive';
		$license_data = null;
		if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
			$license_data = qlic_get_license_status_for_key_products(
				$license_key,
				array(
					'quick-quotes',
					'quick-quotes-one-site',
					'quick-quotes-five-sites',
					'quick-quotes-unlimited-sites',
					'quick-woo-bundle',
					'quick-woo-suite',
					'quick-bundle',
                    'quick-secretary',
                )
			);
			if ( is_array( $license_data ) ) {
				$license_status = isset( $license_data['status'] ) ? sanitize_key( (string) $license_data['status'] ) : $license_status;
				if ( ! empty( $license_data['valid'] ) && ! empty( $license_data['domain_active'] ) ) {
					$license_status = 'active';
				}
			}
		}
		?>
		<div class="wrap qq-admin-wrap">
			<h1 class="wp-heading-inline"><?php echo esc_html__( 'Quick Quotes', 'quick-quotes' ); ?></h1>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=quick-quotes-add-new' ) ); ?>" class="page-title-action"><?php echo esc_html__( 'Add New', 'quick-quotes' ); ?></a>
			<?php $this->render_admin_notice(); ?>
			<div class="notice notice-info inline">
				<p>
					<strong><?php echo esc_html__( 'License:', 'quick-quotes' ); ?></strong>
					<?php echo esc_html( ucfirst( $license_status ) ); ?>
					<?php if ( is_array( $license_data ) && ! empty( $license_data['product_slug'] ) ) : ?>
						<?php echo esc_html( sprintf( __( ' (%s)', 'quick-quotes' ), (string) $license_data['product_slug'] ) ); ?>
					<?php endif; ?>
					<?php if ( is_array( $license_data ) && isset( $license_data['activations'], $license_data['activation_limit'] ) ) : ?>
						<?php echo esc_html( sprintf( __( ' - Activations: %1$s/%2$s', 'quick-quotes' ), (string) $license_data['activations'], (string) $license_data['activation_limit'] ) ); ?>
					<?php endif; ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=quick-quotes-settings' ) ); ?>"><?php echo esc_html__( 'Manage License', 'quick-quotes' ); ?></a>
				</p>
			</div>

			<table class="widefat fixed striped qq-table">
				<thead>
					<tr>
						<th><?php echo esc_html__( 'ID', 'quick-quotes' ); ?></th>
						<th><?php echo esc_html__( 'Client Name', 'quick-quotes' ); ?></th>
						<th><?php echo esc_html__( 'Email', 'quick-quotes' ); ?></th>
						<th><?php echo esc_html__( 'Project Type', 'quick-quotes' ); ?></th>
						<th><?php echo esc_html__( 'Total', 'quick-quotes' ); ?></th>
						<th><?php echo esc_html__( 'Status', 'quick-quotes' ); ?></th>
						<th><?php echo esc_html__( 'Created', 'quick-quotes' ); ?></th>
						<th><?php echo esc_html__( 'Actions', 'quick-quotes' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $quotes ) ) : ?>
						<tr>
							<td colspan="8"><?php echo esc_html__( 'No quotes found.', 'quick-quotes' ); ?></td>
						</tr>
					<?php else : ?>
						<?php foreach ( $quotes as $quote ) : ?>
							<tr>
								<td><?php echo esc_html( (string) $quote->id ); ?></td>
								<td><?php echo esc_html( $quote->client_name ); ?></td>
								<td><?php echo esc_html( $quote->client_email ); ?></td>
								<td><?php echo esc_html( $quote->project_type ); ?></td>
								<td><?php echo esc_html( number_format_i18n( (float) $quote->total, 2 ) ); ?></td>
								<td><span class="qq-status qq-status-<?php echo esc_attr( strtolower( $quote->status ) ); ?>"><?php echo esc_html( ucfirst( $quote->status ) ); ?></span></td>
								<td><?php echo esc_html( $quote->created_at ); ?></td>
								<td>
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=quick-quotes-add-new&quote_id=' . absint( $quote->id ) ) ); ?>"><?php echo esc_html__( 'Edit', 'quick-quotes' ); ?></a>
									|
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=quick-quotes-invoice&quote_id=' . absint( $quote->id ) ) ); ?>"><?php echo esc_html__( 'Invoice', 'quick-quotes' ); ?></a>
									|
									<a href="<?php echo esc_url( $this->get_status_url( $quote->id, 'pending' ) ); ?>"><?php echo esc_html__( 'Pending', 'quick-quotes' ); ?></a>
									|
									<a href="<?php echo esc_url( $this->get_status_url( $quote->id, 'approved' ) ); ?>"><?php echo esc_html__( 'Approve', 'quick-quotes' ); ?></a>
									|
									<a href="<?php echo esc_url( $this->get_status_url( $quote->id, 'rejected' ) ); ?>"><?php echo esc_html__( 'Reject', 'quick-quotes' ); ?></a>
									|
									<a class="qq-delete-link" href="<?php echo esc_url( $this->get_delete_url( $quote->id ) ); ?>"><?php echo esc_html__( 'Delete', 'quick-quotes' ); ?></a>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/**
	 * Render add/edit quote page.
	 *
	 * @return void
	 */
	public function render_quote_form_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-quotes' ) );
		}

		$quote_id = isset( $_GET['quote_id'] ) ? absint( $_GET['quote_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$quote    = $quote_id ? $this->get_quote_by_id( $quote_id ) : null;
		$premium_enabled = qquo_is_premium_active();

		$settings = $this->get_settings();

		$data = array(
			'id'               => $quote ? (int) $quote->id : 0,
			'client_name'      => $quote ? $quote->client_name : '',
			'client_email'     => $quote ? $quote->client_email : '',
			'project_type'     => $quote ? $quote->project_type : '',
			'line_items'       => $quote ? json_decode( $quote->line_items, true ) : array(),
			'tax_percent'      => $quote ? (string) $quote->tax_percent : (string) $settings['default_tax_percent'],
			'discount_percent' => $quote ? (string) $quote->discount_percent : (string) $settings['default_discount_percent'],
			'due_today'        => $quote ? (string) $quote->due_today : '0',
			'payment_mode'     => $quote ? (string) $quote->payment_mode : 'full',
			'payment_percent'  => $quote ? (string) $quote->payment_percent : '50',
			'stripe_payment_url' => $quote ? (string) $quote->stripe_payment_url : '',
			'notes'            => $quote ? $quote->notes : '',
		);

		if ( empty( $data['line_items'] ) || ! is_array( $data['line_items'] ) ) {
			$data['line_items'] = array(
				array(
					'description' => '',
					'price'       => '',
				),
			);
		}
		?>
		<div class="wrap qq-admin-wrap">
			<h1><?php echo esc_html( $quote ? __( 'Edit Quote', 'quick-quotes' ) : __( 'Add New Quote', 'quick-quotes' ) ); ?></h1>
			<?php if ( ! $premium_enabled ) : ?>
				<div class="notice notice-warning inline"><p><?php echo esc_html__( 'Stripe payment controls and consultation mode are premium features.', 'quick-quotes' ); ?></p></div>
			<?php endif; ?>
			<?php $this->render_admin_notice(); ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="qq-form" id="qq-admin-quote-form">
				<input type="hidden" name="action" value="qquo_save_quote" />
				<input type="hidden" name="quote_id" value="<?php echo esc_attr( (string) $data['id'] ); ?>" />
				<?php wp_nonce_field( 'qquo_save_quote', 'qquo_save_quote_nonce' ); ?>

				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row"><label for="qq-client-name"><?php echo esc_html__( 'Client Name', 'quick-quotes' ); ?></label></th>
							<td><input name="client_name" type="text" id="qq-client-name" value="<?php echo esc_attr( $data['client_name'] ); ?>" class="regular-text" required></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-client-email"><?php echo esc_html__( 'Client Email', 'quick-quotes' ); ?></label></th>
							<td><input name="client_email" type="email" id="qq-client-email" value="<?php echo esc_attr( $data['client_email'] ); ?>" class="regular-text" required></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-project-type"><?php echo esc_html__( 'Project Type', 'quick-quotes' ); ?></label></th>
							<td>
								<select name="project_type" id="qq-project-type" required>
									<option value=""><?php echo esc_html__( 'Select project type', 'quick-quotes' ); ?></option>
									<?php foreach ( $this->get_project_types() as $project_type ) : ?>
										<option value="<?php echo esc_attr( $project_type ); ?>" <?php selected( $data['project_type'], $project_type ); ?>><?php echo esc_html( $project_type ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
					</tbody>
				</table>

				<h2><?php echo esc_html__( 'Line Items', 'quick-quotes' ); ?></h2>
				<div id="qq-line-items" class="qq-line-items">
					<?php foreach ( $data['line_items'] as $line_item ) : ?>
						<div class="qq-line-item-row">
							<input type="text" name="line_description[]" value="<?php echo esc_attr( isset( $line_item['description'] ) ? $line_item['description'] : '' ); ?>" placeholder="<?php echo esc_attr__( 'Description', 'quick-quotes' ); ?>" class="regular-text qq-line-description" required>
							<input type="number" step="0.01" min="0" name="line_price[]" value="<?php echo esc_attr( isset( $line_item['price'] ) ? (string) $line_item['price'] : '' ); ?>" placeholder="<?php echo esc_attr__( 'Price', 'quick-quotes' ); ?>" class="small-text qq-line-price" required>
							<button type="button" class="button qq-remove-line-item"><?php echo esc_html__( 'Remove', 'quick-quotes' ); ?></button>
						</div>
					<?php endforeach; ?>
				</div>
				<p><button type="button" class="button" id="qq-add-line-item"><?php echo esc_html__( 'Add Line Item', 'quick-quotes' ); ?></button></p>

				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row"><label for="qq-tax-percent"><?php echo esc_html__( 'Tax %', 'quick-quotes' ); ?></label></th>
							<td><input type="number" min="0" max="100" step="0.01" name="tax_percent" id="qq-tax-percent" class="small-text" value="<?php echo esc_attr( $data['tax_percent'] ); ?>" required></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-discount-percent"><?php echo esc_html__( 'Discount %', 'quick-quotes' ); ?></label></th>
							<td><input type="number" min="0" max="100" step="0.01" name="discount_percent" id="qq-discount-percent" class="small-text" value="<?php echo esc_attr( $data['discount_percent'] ); ?>" required></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-payment-mode"><?php echo esc_html__( 'Payment Mode', 'quick-quotes' ); ?></label></th>
							<td>
								<select name="payment_mode" id="qq-payment-mode">
									<option value="full" <?php selected( 'full', $data['payment_mode'] ); ?>><?php echo esc_html__( 'Pay Full Invoice', 'quick-quotes' ); ?></option>
									<?php if ( $premium_enabled ) : ?>
										<option value="percentage" <?php selected( 'percentage', $data['payment_mode'] ); ?>><?php echo esc_html__( 'Pay Percentage', 'quick-quotes' ); ?></option>
										<option value="consultation" <?php selected( 'consultation', $data['payment_mode'] ); ?>><?php echo esc_html__( 'Follow-up Consultation', 'quick-quotes' ); ?></option>
									<?php endif; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-payment-percent"><?php echo esc_html__( 'Payment Percentage %', 'quick-quotes' ); ?></label></th>
							<td><input type="number" min="0" max="100" step="0.01" name="payment_percent" id="qq-payment-percent" class="small-text" value="<?php echo esc_attr( $data['payment_percent'] ); ?>" <?php disabled( ! $premium_enabled ); ?>></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-due-today"><?php echo esc_html__( 'Due Today Amount', 'quick-quotes' ); ?></label></th>
							<td><input type="number" min="0" step="0.01" name="due_today" id="qq-due-today" class="small-text" value="<?php echo esc_attr( $data['due_today'] ); ?>" <?php disabled( ! $premium_enabled ); ?>></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-stripe-payment-url"><?php echo esc_html__( 'Stripe Payment URL', 'quick-quotes' ); ?></label></th>
							<td><input type="url" name="stripe_payment_url" id="qq-stripe-payment-url" class="regular-text" value="<?php echo esc_attr( $data['stripe_payment_url'] ); ?>" placeholder="https://buy.stripe.com/..." <?php disabled( ! $premium_enabled ); ?> /></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-notes"><?php echo esc_html__( 'Notes', 'quick-quotes' ); ?></label></th>
							<td><textarea name="notes" id="qq-notes" class="large-text" rows="4"><?php echo esc_textarea( $data['notes'] ); ?></textarea></td>
						</tr>
					</tbody>
				</table>

				<div class="qq-totals-box">
					<p><strong><?php echo esc_html__( 'Subtotal:', 'quick-quotes' ); ?></strong> <span id="qq-subtotal">0.00</span></p>
					<p><strong><?php echo esc_html__( 'Tax Amount:', 'quick-quotes' ); ?></strong> <span id="qq-tax-amount">0.00</span></p>
					<p><strong><?php echo esc_html__( 'Discount Amount:', 'quick-quotes' ); ?></strong> <span id="qq-discount-amount">0.00</span></p>
					<p><strong><?php echo esc_html__( 'Final Total:', 'quick-quotes' ); ?></strong> <span id="qq-final-total">0.00</span></p>
				</div>

				<?php submit_button( $quote ? __( 'Update Quote', 'quick-quotes' ) : __( 'Save Quote', 'quick-quotes' ) ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render settings page.
	 *
	 * @return void
	 */
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-quotes' ) );
		}

		$settings = $this->get_settings();
		$quick_forms_available = $this->is_quick_forms_available();
		$premium_enabled = qquo_is_premium_active();
		$license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';
		$license_status = isset( $settings['license_status'] ) ? sanitize_key( (string) $settings['license_status'] ) : 'inactive';
		$license_message = isset( $settings['license_message'] ) ? sanitize_text_field( (string) $settings['license_message'] ) : '';
		$license_data = null;
		if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
			$license_data = qlic_get_license_status_for_key_products(
				$license_key,
				array(
					'quick-quotes',
					'quick-quotes-one-site',
					'quick-quotes-five-sites',
					'quick-quotes-unlimited-sites',
					'quick-woo-bundle',
					'quick-woo-suite',
					'quick-bundle',
                    'quick-secretary',
                )
			);
			if ( is_array( $license_data ) ) {
				$license_status = isset( $license_data['status'] ) ? sanitize_key( (string) $license_data['status'] ) : $license_status;
				if ( ! empty( $license_data['valid'] ) && ! empty( $license_data['domain_active'] ) ) {
					$license_status = 'active';
				}
			}
		}
		?>
		<div class="wrap qq-admin-wrap">
			<h1><?php echo esc_html__( 'Quick Quotes Settings', 'quick-quotes' ); ?></h1>
			<?php if ( ! $premium_enabled ) : ?>
				<div class="notice notice-warning inline"><p><?php echo esc_html__( 'Quick Forms automation, email notifications, Stripe and Quick Schedule integrations are premium features.', 'quick-quotes' ); ?></p></div>
			<?php endif; ?>
			<?php $this->render_admin_notice(); ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qquo_save_settings" />
				<?php wp_nonce_field( 'qquo_save_settings', 'qquo_save_settings_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row"><label for="qq-default-tax"><?php echo esc_html__( 'Default Tax %', 'quick-quotes' ); ?></label></th>
							<td><input type="number" min="0" max="100" step="0.01" id="qq-default-tax" name="default_tax_percent" class="small-text" value="<?php echo esc_attr( (string) $settings['default_tax_percent'] ); ?>" required /></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-default-discount"><?php echo esc_html__( 'Default Discount %', 'quick-quotes' ); ?></label></th>
							<td><input type="number" min="0" max="100" step="0.01" id="qq-default-discount" name="default_discount_percent" class="small-text" value="<?php echo esc_attr( (string) $settings['default_discount_percent'] ); ?>" required /></td>
						</tr>
						<tr>
							<th scope="row"><?php echo esc_html__( 'Email Notifications', 'quick-quotes' ); ?></th>
							<td><label><input type="checkbox" name="email_notifications" value="1" <?php checked( '1', $settings['email_notifications'] ); ?> <?php disabled( ! $premium_enabled ); ?> /> <?php echo esc_html__( 'Enable email notifications for new frontend quote requests', 'quick-quotes' ); ?></label></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-notification-email"><?php echo esc_html__( 'Notification Email', 'quick-quotes' ); ?></label></th>
							<td><input type="email" id="qq-notification-email" name="notification_email" class="regular-text" value="<?php echo esc_attr( $settings['notification_email'] ); ?>" required <?php disabled( ! $premium_enabled ); ?> /></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-quick-schedule-page-url"><?php echo esc_html__( 'Quick Schedule Page URL', 'quick-quotes' ); ?></label></th>
							<td><input type="url" id="qq-quick-schedule-page-url" name="quick_schedule_page_url" class="regular-text" value="<?php echo esc_attr( $settings['quick_schedule_page_url'] ); ?>" placeholder="https://your-site.com/schedule/" <?php disabled( ! $premium_enabled ); ?> /></td>
						</tr>
						<tr>
							<th scope="row"><?php echo esc_html__( 'Quick Forms Integration', 'quick-quotes' ); ?></th>
							<td>
								<input type="hidden" name="qf_to_quote_enabled" value="0" />
								<label>
									<input type="checkbox" name="qf_to_quote_enabled" value="1" <?php checked( '1', $settings['qf_to_quote_enabled'] ); ?> <?php disabled( ! $premium_enabled ); ?> />
									<?php echo esc_html__( 'Create Quick Quote drafts from Quick Forms submissions', 'quick-quotes' ); ?>
								</label>
								<?php if ( ! $quick_forms_available ) : ?>
									<p><?php echo esc_html__( 'Quick Forms plugin is not currently detected in this request. You can still keep this enabled.', 'quick-quotes' ); ?></p>
								<?php else : ?>
									<p>
										<?php echo esc_html__( 'Configure per-field pricing on the Form Builder page.', 'quick-quotes' ); ?>
										<a href="<?php echo esc_url( admin_url( 'admin.php?page=quick-quotes-form-builder' ) ); ?>"><?php echo esc_html__( 'Open Form Builder', 'quick-quotes' ); ?></a>
									</p>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php echo esc_html__( 'Quick Schedule Integration', 'quick-quotes' ); ?></th>
							<td>
								<input type="hidden" name="quick_schedule_integration_enabled" value="0" />
								<label>
									<input type="checkbox" name="quick_schedule_integration_enabled" value="1" <?php checked( '1', $settings['quick_schedule_integration_enabled'] ); ?> <?php disabled( ! $premium_enabled ); ?> />
									<?php echo esc_html__( 'Enable invoice handoff to Quick Schedule booking page', 'quick-quotes' ); ?>
								</label>
							</td>
						</tr>
					</tbody>
				</table>
				<?php submit_button( __( 'Save Settings', 'quick-quotes' ) ); ?>
			</form>
			<hr />
			<h2><?php echo esc_html__( 'License Activation', 'quick-quotes' ); ?></h2>
			<p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-quotes' ), $license_status ) ); ?></p>
			<?php if ( '' !== $license_message ) : ?>
				<p><?php echo esc_html( $license_message ); ?></p>
			<?php endif; ?>
			<?php if ( is_array( $license_data ) && ! empty( $license_data['product_slug'] ) ) : ?>
				<p><?php echo esc_html( sprintf( __( 'Plan: %s', 'quick-quotes' ), (string) $license_data['product_slug'] ) ); ?></p>
				<p><?php echo esc_html( sprintf( __( 'Activations: %1$s / %2$s', 'quick-quotes' ), (string) $license_data['activations'], (string) $license_data['activation_limit'] ) ); ?></p>
				<p><?php echo esc_html( sprintf( __( 'Expires: %s', 'quick-quotes' ), ! empty( $license_data['expires_at'] ) ? (string) $license_data['expires_at'] : __( 'Never', 'quick-quotes' ) ) ); ?></p>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qquo_activate_license" />
				<?php wp_nonce_field( 'qquo_activate_license', 'qquo_activate_license_nonce' ); ?>
				<input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( $license_key ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
				<?php submit_button( __( 'Activate License', 'quick-quotes' ), 'secondary', '', false ); ?>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:8px;">
				<input type="hidden" name="action" value="qquo_deactivate_license" />
				<?php wp_nonce_field( 'qquo_deactivate_license', 'qquo_deactivate_license_nonce' ); ?>
				<?php submit_button( __( 'Deactivate License', 'quick-quotes' ), 'delete', '', false ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render style page.
	 *
	 * @return void
	 */
	public function render_style_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-quotes' ) );
		}

		$settings = $this->get_settings();
		?>
		<div class="wrap qq-admin-wrap">
			<h1><?php echo esc_html__( 'Quick Quotes Style', 'quick-quotes' ); ?></h1>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qquo_save_style" />
				<?php wp_nonce_field( 'qquo_save_style', 'qquo_save_style_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row"><label for="qquo_form_css"><?php echo esc_html__( 'Quote Form CSS', 'quick-quotes' ); ?></label></th>
							<td><textarea id="qquo_form_css" name="custom_form_css" rows="12" class="large-text code"><?php echo esc_textarea( (string) $settings['custom_form_css'] ); ?></textarea></td>
						</tr>
						<tr>
							<th scope="row"><label for="qquo_invoice_css"><?php echo esc_html__( 'Invoice CSS', 'quick-quotes' ); ?></label></th>
							<td><textarea id="qquo_invoice_css" name="custom_invoice_css" rows="12" class="large-text code"><?php echo esc_textarea( (string) $settings['custom_invoice_css'] ); ?></textarea></td>
						</tr>
					</tbody>
				</table>
				<?php submit_button( __( 'Save Style', 'quick-quotes' ) ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render form builder page.
	 *
	 * @return void
	 */
	public function render_form_builder_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-quotes' ) );
		}

		if ( ! qquo_is_premium_active() ) {
			echo '<div class="wrap qq-admin-wrap"><h1>' . esc_html__( 'Quick Forms Quote Config', 'quick-quotes' ) . '</h1><div class="notice notice-warning inline"><p>' . esc_html__( 'This integration is a premium feature.', 'quick-quotes' ) . '</p></div></div>';
			return;
		}

		$this->render_quick_forms_pricing_builder_page();
	}

	/**
	 * Render Quick Forms pricing configuration UI.
	 *
	 * @return void
	 */
	private function render_quick_forms_pricing_builder_page() {
		$quick_forms_available = $this->is_quick_forms_available();
		$form_configs          = $quick_forms_available ? $this->get_quick_forms_form_configs() : array();
		$pricing_map           = $this->get_quick_forms_pricing_map();
		$form_config_map       = $this->get_quick_forms_form_config_map();
		$selected_form_id      = isset( $_GET['qf_form_id'] ) ? absint( $_GET['qf_form_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$selected_form         = null;

		if ( ! empty( $form_configs ) ) {
			if ( $selected_form_id < 1 ) {
				$selected_form_id = absint( $form_configs[0]['id'] );
			}

			foreach ( $form_configs as $form_config ) {
				if ( absint( $form_config['id'] ) === $selected_form_id ) {
					$selected_form = $form_config;
					break;
				}
			}

			if ( null === $selected_form ) {
				$selected_form    = $form_configs[0];
				$selected_form_id = absint( $selected_form['id'] );
			}
		}
		?>
		<div class="wrap qq-admin-wrap">
			<h1><?php echo esc_html__( 'Quick Forms Quote Config', 'quick-quotes' ); ?></h1>
			<?php $this->render_admin_notice(); ?>
			<p><?php echo esc_html__( 'Select a Quick Form, then assign dollar values to fields. Leave blank to ignore a field. Dropdown and radio fields can also price each option.', 'quick-quotes' ); ?></p>
			<?php if ( ! $quick_forms_available ) : ?>
				<p><?php echo esc_html__( 'Quick Forms plugin is not available. Activate Quick Forms to configure this page.', 'quick-quotes' ); ?></p>
			<?php elseif ( empty( $form_configs ) ) : ?>
				<p><?php echo esc_html__( 'No Quick Forms found yet. Create a form in Quick Forms first.', 'quick-quotes' ); ?></p>
			<?php else : ?>
				<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
					<input type="hidden" name="page" value="quick-quotes-form-builder" />
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row"><label for="qq-qf-form-selector"><?php echo esc_html__( 'Quick Form', 'quick-quotes' ); ?></label></th>
								<td>
									<select id="qq-qf-form-selector" name="qf_form_id">
										<?php foreach ( $form_configs as $form_config ) : ?>
											<option value="<?php echo esc_attr( (string) absint( $form_config['id'] ) ); ?>" <?php selected( $selected_form_id, absint( $form_config['id'] ) ); ?>>
												<?php echo esc_html( sanitize_text_field( $form_config['name'] ) . ' (#' . absint( $form_config['id'] ) . ')' ); ?>
											</option>
										<?php endforeach; ?>
									</select>
									<?php submit_button( __( 'Load Form', 'quick-quotes' ), 'secondary', '', false ); ?>
								</td>
							</tr>
						</tbody>
					</table>
				</form>

				<?php
				$fields    = isset( $selected_form['fields'] ) && is_array( $selected_form['fields'] ) ? $selected_form['fields'] : array();
				$form_name = isset( $selected_form['name'] ) ? sanitize_text_field( $selected_form['name'] ) : '';
				$current_form_config = isset( $form_config_map[ $selected_form_id ] ) && is_array( $form_config_map[ $selected_form_id ] ) ? $form_config_map[ $selected_form_id ] : array();
				$due_percent = isset( $current_form_config['due_percent'] ) ? (string) $current_form_config['due_percent'] : '100';
				$payment_action = isset( $current_form_config['payment_action'] ) ? sanitize_key( (string) $current_form_config['payment_action'] ) : 'pay_at_invoice';
				if ( ! in_array( $payment_action, array( 'pay_at_invoice', 'book_consultation' ), true ) ) {
					$payment_action = 'pay_at_invoice';
				}
				?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="qquo_save_form_builder" />
					<input type="hidden" name="qquo_builder_mode" value="qf_pricing" />
					<input type="hidden" name="qf_selected_form_id" value="<?php echo esc_attr( (string) $selected_form_id ); ?>" />
					<?php wp_nonce_field( 'qquo_save_form_builder', 'qquo_save_form_builder_nonce' ); ?>
					<h2><?php echo esc_html( $form_name . ' (#' . $selected_form_id . ')' ); ?></h2>
					<table class="widefat striped qq-builder-table">
						<thead>
							<tr>
								<th><?php echo esc_html__( 'Field Name', 'quick-quotes' ); ?></th>
								<th><?php echo esc_html__( 'Input Type', 'quick-quotes' ); ?></th>
								<th><?php echo esc_html__( 'Dollar Value', 'quick-quotes' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php if ( empty( $fields ) ) : ?>
								<tr><td colspan="3"><?php echo esc_html__( 'No fields in this form.', 'quick-quotes' ); ?></td></tr>
							<?php else : ?>
								<?php foreach ( $fields as $field ) : ?>
									<?php
									$field_name = isset( $field['name'] ) ? sanitize_key( $field['name'] ) : '';
									$field_type = isset( $field['type'] ) ? sanitize_key( $field['type'] ) : 'text';
									$options    = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
									if ( '' === $field_name ) {
										continue;
									}

									$current_amount = '';
									if ( isset( $pricing_map[ $selected_form_id ][ $field_name ] ) && is_array( $pricing_map[ $selected_form_id ][ $field_name ] ) ) {
										$current_amount = isset( $pricing_map[ $selected_form_id ][ $field_name ]['amount'] ) ? (string) $pricing_map[ $selected_form_id ][ $field_name ]['amount'] : '';
									}
									?>
									<tr>
										<td><code><?php echo esc_html( $field_name ); ?></code></td>
										<td><?php echo esc_html( $field_type ); ?></td>
										<td>
											<input
												type="number"
												step="0.01"
												min="0"
												class="small-text"
												name="qf_pricing[<?php echo esc_attr( (string) $selected_form_id ); ?>][<?php echo esc_attr( $field_name ); ?>][amount]"
												value="<?php echo esc_attr( $current_amount ); ?>"
											/>
										</td>
									</tr>
									<?php if ( in_array( $field_type, array( 'dropdown', 'radio', 'checkbox' ), true ) && ! empty( $options ) ) : ?>
										<?php foreach ( $options as $option_value ) : ?>
											<?php
											$option_value = sanitize_text_field( (string) $option_value );
											if ( '' === $option_value ) {
												continue;
											}
											$option_amount = '';
											if ( isset( $pricing_map[ $selected_form_id ][ $field_name ]['options'][ $option_value ] ) ) {
												$option_amount = (string) $pricing_map[ $selected_form_id ][ $field_name ]['options'][ $option_value ];
											}
											?>
											<tr>
												<td><code><?php echo esc_html( $field_name . ' -> ' . $option_value ); ?></code></td>
												<td><?php echo esc_html__( 'option', 'quick-quotes' ); ?></td>
												<td>
													<input
														type="number"
														step="0.01"
														min="0"
														class="small-text"
														name="qf_pricing[<?php echo esc_attr( (string) $selected_form_id ); ?>][<?php echo esc_attr( $field_name ); ?>][options][<?php echo esc_attr( $option_value ); ?>]"
														value="<?php echo esc_attr( $option_amount ); ?>"
													/>
												</td>
											</tr>
										<?php endforeach; ?>
									<?php endif; ?>
								<?php endforeach; ?>
							<?php endif; ?>
						</tbody>
					</table>
					<h3><?php echo esc_html__( 'Invoice Behavior For This Form', 'quick-quotes' ); ?></h3>
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row"><label for="qq-qf-due-percent"><?php echo esc_html__( 'Due Today (%)', 'quick-quotes' ); ?></label></th>
								<td>
									<input id="qq-qf-due-percent" type="number" min="0" max="100" step="0.01" class="small-text" name="qf_form_config[<?php echo esc_attr( (string) $selected_form_id ); ?>][due_percent]" value="<?php echo esc_attr( $due_percent ); ?>" />
									<p class="description"><?php echo esc_html__( 'Percent of estimated total due when the invoice is created from this form. Example: 25 means deposit invoice.', 'quick-quotes' ); ?></p>
								</td>
							</tr>
							<tr>
								<th scope="row"><label for="qq-qf-payment-action"><?php echo esc_html__( 'Client Checkout Path', 'quick-quotes' ); ?></label></th>
								<td>
									<select id="qq-qf-payment-action" name="qf_form_config[<?php echo esc_attr( (string) $selected_form_id ); ?>][payment_action]">
										<option value="pay_at_invoice" <?php selected( $payment_action, 'pay_at_invoice' ); ?>><?php echo esc_html__( 'Pay At Invoice', 'quick-quotes' ); ?></option>
										<option value="book_consultation" <?php selected( $payment_action, 'book_consultation' ); ?>><?php echo esc_html__( 'Book Consultation', 'quick-quotes' ); ?></option>
									</select>
									<p class="description"><?php echo esc_html__( 'Pay At Invoice auto-generates a unique WooCommerce product and checkout link for the quote due amount. Book Consultation routes to Quick Schedule with quote context.', 'quick-quotes' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
					<?php submit_button( __( 'Save Form Config', 'quick-quotes' ) ); ?>
				</form>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render invoice customizer page.
	 *
	 * @return void
	 */
	public function render_invoice_customizer_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-quotes' ) );
		}

		$template = $this->get_invoice_template_settings();
		?>
		<div class="wrap qq-admin-wrap">
			<h1><?php echo esc_html__( 'Invoice Renderer Customizer', 'quick-quotes' ); ?></h1>
			<?php $this->render_admin_notice(); ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="qquo_save_invoice_template" />
				<?php wp_nonce_field( 'qquo_save_invoice_template', 'qquo_save_invoice_template_nonce' ); ?>
				<table class="form-table" role="presentation">
					<tbody>
						<tr>
							<th scope="row"><label for="qq-company-name"><?php echo esc_html__( 'Company Name', 'quick-quotes' ); ?></label></th>
							<td><input type="text" id="qq-company-name" name="company_name" class="regular-text" value="<?php echo esc_attr( $template['company_name'] ); ?>" required></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-company-address"><?php echo esc_html__( 'Company Address', 'quick-quotes' ); ?></label></th>
							<td><textarea id="qq-company-address" name="company_address" class="large-text" rows="3"><?php echo esc_textarea( $template['company_address'] ); ?></textarea></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-company-email"><?php echo esc_html__( 'Company Email', 'quick-quotes' ); ?></label></th>
							<td><input type="email" id="qq-company-email" name="company_email" class="regular-text" value="<?php echo esc_attr( $template['company_email'] ); ?>"></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-company-phone"><?php echo esc_html__( 'Company Phone', 'quick-quotes' ); ?></label></th>
							<td><input type="text" id="qq-company-phone" name="company_phone" class="regular-text" value="<?php echo esc_attr( $template['company_phone'] ); ?>"></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-logo-url"><?php echo esc_html__( 'Logo URL', 'quick-quotes' ); ?></label></th>
							<td><input type="url" id="qq-logo-url" name="logo_url" class="regular-text" value="<?php echo esc_attr( $template['logo_url'] ); ?>"></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-accent-color"><?php echo esc_html__( 'Accent Color', 'quick-quotes' ); ?></label></th>
							<td><input type="text" id="qq-accent-color" name="accent_color" class="regular-text" value="<?php echo esc_attr( $template['accent_color'] ); ?>" pattern="^#([A-Fa-f0-9]{6})$"></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-invoice-title"><?php echo esc_html__( 'Invoice Title', 'quick-quotes' ); ?></label></th>
							<td><input type="text" id="qq-invoice-title" name="invoice_title" class="regular-text" value="<?php echo esc_attr( $template['invoice_title'] ); ?>" required></td>
						</tr>
						<tr>
							<th scope="row"><label for="qq-footer-text"><?php echo esc_html__( 'Footer Text', 'quick-quotes' ); ?></label></th>
							<td><textarea id="qq-footer-text" name="footer_text" class="large-text" rows="2"><?php echo esc_textarea( $template['footer_text'] ); ?></textarea></td>
						</tr>
					</tbody>
				</table>
				<?php submit_button( __( 'Save Invoice Customizer', 'quick-quotes' ) ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render invoice page for a quote.
	 *
	 * @return void
	 */
	public function render_invoice_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'quick-quotes' ) );
		}

		$quote_id = isset( $_GET['quote_id'] ) ? absint( $_GET['quote_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$quote    = $quote_id ? $this->get_quote_by_id( $quote_id ) : null;
		if ( ! $quote ) {
			wp_die( esc_html__( 'Quote not found.', 'quick-quotes' ) );
		}

		$template   = $this->get_invoice_template_settings();
		$line_items = json_decode( $quote->line_items, true );
		if ( ! is_array( $line_items ) ) {
			$line_items = array();
		}
		$tax_amount      = round( (float) $quote->subtotal * ( (float) $quote->tax_percent / 100 ), 2 );
		$discount_amount = round( (float) $quote->subtotal * ( (float) $quote->discount_percent / 100 ), 2 );
		$payment_mode    = isset( $quote->payment_mode ) ? sanitize_key( (string) $quote->payment_mode ) : 'full';
		$due_today       = isset( $quote->due_today ) ? max( 0, (float) $quote->due_today ) : (float) $quote->total;
		$payment_percent = isset( $quote->payment_percent ) ? max( 0, min( 100, (float) $quote->payment_percent ) ) : 100;
		?>
		<div class="wrap qq-admin-wrap">
			<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=quick-quotes' ) ); ?>" class="button"><?php echo esc_html__( 'Back to Quotes', 'quick-quotes' ); ?></a> <button type="button" class="button button-primary" onclick="window.print();"><?php echo esc_html__( 'Print Invoice', 'quick-quotes' ); ?></button></p>
			<div class="qq-invoice" style="--qq-accent: <?php echo esc_attr( $template['accent_color'] ); ?>;">
				<div class="qq-invoice-header">
					<div>
						<?php if ( ! empty( $template['logo_url'] ) ) : ?>
							<p><img src="<?php echo esc_url( $template['logo_url'] ); ?>" alt="<?php echo esc_attr( $template['company_name'] ); ?>" class="qq-invoice-logo"></p>
						<?php endif; ?>
						<h1><?php echo esc_html( $template['invoice_title'] ); ?></h1>
						<p><?php echo esc_html( $template['company_name'] ); ?></p>
						<?php if ( ! empty( $template['company_address'] ) ) : ?>
							<p><?php echo nl2br( esc_html( $template['company_address'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
						<?php endif; ?>
						<?php if ( ! empty( $template['company_email'] ) ) : ?>
							<p><?php echo esc_html( $template['company_email'] ); ?></p>
						<?php endif; ?>
						<?php if ( ! empty( $template['company_phone'] ) ) : ?>
							<p><?php echo esc_html( $template['company_phone'] ); ?></p>
						<?php endif; ?>
					</div>
					<div class="qq-invoice-meta">
						<p><strong><?php echo esc_html__( 'Invoice #', 'quick-quotes' ); ?></strong> <?php echo esc_html( (string) $quote->id ); ?></p>
						<p><strong><?php echo esc_html__( 'Date', 'quick-quotes' ); ?></strong> <?php echo esc_html( $quote->created_at ); ?></p>
						<p><strong><?php echo esc_html__( 'Status', 'quick-quotes' ); ?></strong> <?php echo esc_html( ucfirst( $quote->status ) ); ?></p>
					</div>
				</div>

				<div class="qq-invoice-client">
					<h2><?php echo esc_html__( 'Bill To', 'quick-quotes' ); ?></h2>
					<p><?php echo esc_html( $quote->client_name ); ?></p>
					<p><?php echo esc_html( $quote->client_email ); ?></p>
					<p><?php echo esc_html( $quote->project_type ); ?></p>
				</div>

				<table class="widefat striped qq-invoice-table">
					<thead>
						<tr>
							<th><?php echo esc_html__( 'Description', 'quick-quotes' ); ?></th>
							<th><?php echo esc_html__( 'Amount', 'quick-quotes' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $line_items as $item ) : ?>
							<tr>
								<td><?php echo esc_html( isset( $item['description'] ) ? (string) $item['description'] : '' ); ?></td>
								<td><?php echo esc_html( number_format_i18n( isset( $item['price'] ) ? (float) $item['price'] : 0, 2 ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<div class="qq-invoice-totals">
					<p><strong><?php echo esc_html__( 'Subtotal:', 'quick-quotes' ); ?></strong> <?php echo esc_html( number_format_i18n( (float) $quote->subtotal, 2 ) ); ?></p>
					<p><strong><?php echo esc_html__( 'Tax:', 'quick-quotes' ); ?></strong> <?php echo esc_html( number_format_i18n( $tax_amount, 2 ) ); ?> (<?php echo esc_html( number_format_i18n( (float) $quote->tax_percent, 2 ) ); ?>%)</p>
					<p><strong><?php echo esc_html__( 'Discount:', 'quick-quotes' ); ?></strong> <?php echo esc_html( number_format_i18n( $discount_amount, 2 ) ); ?> (<?php echo esc_html( number_format_i18n( (float) $quote->discount_percent, 2 ) ); ?>%)</p>
					<p class="qq-invoice-total"><strong><?php echo esc_html__( 'Total:', 'quick-quotes' ); ?></strong> <?php echo esc_html( number_format_i18n( (float) $quote->total, 2 ) ); ?></p>
					<p><strong><?php echo esc_html__( 'Due Today:', 'quick-quotes' ); ?></strong> <?php echo esc_html( number_format_i18n( $due_today, 2 ) ); ?></p>
					<p><strong><?php echo esc_html__( 'Payment Mode:', 'quick-quotes' ); ?></strong> <?php echo esc_html( ucfirst( $payment_mode ) ); ?><?php echo 'percentage' === $payment_mode ? esc_html( ' (' . number_format_i18n( $payment_percent, 2 ) . '%)' ) : ''; ?></p>
				</div>

				<?php if ( ! empty( $quote->notes ) ) : ?>
					<div class="qq-invoice-notes">
						<h3><?php echo esc_html__( 'Notes', 'quick-quotes' ); ?></h3>
						<p><?php echo nl2br( esc_html( $quote->notes ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $template['footer_text'] ) ) : ?>
					<p class="qq-invoice-footer"><?php echo esc_html( $template['footer_text'] ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Handle quote save.
	 *
	 * @return void
	 */
	public function handle_save_quote() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
		}

		check_admin_referer( 'qquo_save_quote', 'qquo_save_quote_nonce' );

		$quote_id          = isset( $_POST['quote_id'] ) ? absint( $_POST['quote_id'] ) : 0;
		$client_name       = isset( $_POST['client_name'] ) ? sanitize_text_field( wp_unslash( $_POST['client_name'] ) ) : '';
		$client_email      = isset( $_POST['client_email'] ) ? sanitize_email( wp_unslash( $_POST['client_email'] ) ) : '';
		$project_type      = isset( $_POST['project_type'] ) ? sanitize_text_field( wp_unslash( $_POST['project_type'] ) ) : '';
		$tax_percent       = isset( $_POST['tax_percent'] ) ? $this->sanitize_percentage( wp_unslash( $_POST['tax_percent'] ) ) : 0;
		$discount_percent  = isset( $_POST['discount_percent'] ) ? $this->sanitize_percentage( wp_unslash( $_POST['discount_percent'] ) ) : 0;
		$notes             = isset( $_POST['notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['notes'] ) ) : '';
		$payment_mode      = isset( $_POST['payment_mode'] ) ? sanitize_key( wp_unslash( $_POST['payment_mode'] ) ) : 'full';
		$payment_percent   = isset( $_POST['payment_percent'] ) ? $this->sanitize_percentage( wp_unslash( $_POST['payment_percent'] ) ) : 0;
		$due_today_input   = isset( $_POST['due_today'] ) ? (float) wp_unslash( $_POST['due_today'] ) : 0;
		$stripe_payment_url = isset( $_POST['stripe_payment_url'] ) ? esc_url_raw( wp_unslash( $_POST['stripe_payment_url'] ) ) : '';
		$line_descriptions = isset( $_POST['line_description'] ) ? (array) wp_unslash( $_POST['line_description'] ) : array();
		$line_prices       = isset( $_POST['line_price'] ) ? (array) wp_unslash( $_POST['line_price'] ) : array();
		$premium_enabled   = qquo_is_premium_active();

		if ( empty( $client_name ) || empty( $client_email ) || empty( $project_type ) || ! is_email( $client_email ) ) {
			$this->redirect_with_message( 'quick-quotes-add-new', 'invalid', $quote_id );
		}

		$line_items = array();
		$subtotal   = 0.0;

		foreach ( $line_descriptions as $index => $description ) {
			$clean_description = sanitize_text_field( $description );
			$price             = isset( $line_prices[ $index ] ) ? (float) $line_prices[ $index ] : 0;
			$price             = max( 0, round( $price, 2 ) );

			if ( '' === $clean_description ) {
				continue;
			}

			$line_items[] = array(
				'description' => $clean_description,
				'price'       => $price,
			);
			$subtotal    += $price;
		}

		if ( empty( $line_items ) ) {
			$this->redirect_with_message( 'quick-quotes-add-new', 'invalid', $quote_id );
		}

		$totals   = $this->calculate_totals( $subtotal, $tax_percent, $discount_percent );
		if ( ! in_array( $payment_mode, array( 'full', 'percentage', 'consultation' ), true ) ) {
			$payment_mode = 'full';
		}
		if ( ! $premium_enabled ) {
			$payment_mode = 'full';
			$payment_percent = 100;
			$stripe_payment_url = '';
		}
		if ( 'full' === $payment_mode ) {
			$due_today = (float) $totals['final_total'];
		} elseif ( 'percentage' === $payment_mode ) {
			$due_today = round( (float) $totals['final_total'] * ( (float) $payment_percent / 100 ), 2 );
		} else {
			$due_today = max( 0, round( (float) $due_today_input, 2 ) );
		}
		$encoded  = wp_json_encode( $line_items );
		$now      = current_time( 'mysql' );
		$status   = 'pending';
		$redirect = 'quick-quotes-add-new';

		global $wpdb;
		$table_name = $this->get_table_name();

		if ( $quote_id > 0 ) {
			$existing = $this->get_quote_by_id( $quote_id );
			if ( ! $existing ) {
				$this->redirect_with_message( 'quick-quotes', 'error' );
			}

			$query = $wpdb->prepare(
				"UPDATE {$table_name}
				SET client_name = %s, client_email = %s, project_type = %s, line_items = %s, subtotal = %f, tax_percent = %f, discount_percent = %f, total = %f, due_today = %f, payment_mode = %s, payment_percent = %f, stripe_payment_url = %s, notes = %s
				WHERE id = %d",
				$client_name,
				$client_email,
				$project_type,
				$encoded,
				$subtotal,
				$tax_percent,
				$discount_percent,
				$totals['final_total'],
				$due_today,
				$payment_mode,
				$payment_percent,
				$stripe_payment_url,
				$notes,
				$quote_id
			);

			$wpdb->query( $query );
			$this->redirect_with_message( $redirect, 'updated', $quote_id );
		}

		$query = $wpdb->prepare(
			"INSERT INTO {$table_name}
			(client_name, client_email, project_type, line_items, subtotal, tax_percent, discount_percent, total, due_today, payment_mode, payment_percent, stripe_payment_url, notes, status, created_at)
			VALUES (%s, %s, %s, %s, %f, %f, %f, %f, %f, %s, %f, %s, %s, %s, %s)",
			$client_name,
			$client_email,
			$project_type,
			$encoded,
			$subtotal,
			$tax_percent,
			$discount_percent,
			$totals['final_total'],
			$due_today,
			$payment_mode,
			$payment_percent,
			$stripe_payment_url,
			$notes,
			$status,
			$now
		);

		$wpdb->query( $query );
		$this->redirect_with_message( 'quick-quotes', 'saved' );
	}

	/**
	 * Handle quote deletion.
	 *
	 * @return void
	 */
	public function handle_delete_quote() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
		}

		$quote_id = isset( $_GET['quote_id'] ) ? absint( $_GET['quote_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( ! $quote_id ) {
			$this->redirect_with_message( 'quick-quotes', 'error' );
		}

		check_admin_referer( 'qquo_delete_quote_' . $quote_id );

		global $wpdb;
		$table_name = $this->get_table_name();
		$query      = $wpdb->prepare( "DELETE FROM {$table_name} WHERE id = %d", $quote_id );
		$wpdb->query( $query );

		$this->redirect_with_message( 'quick-quotes', 'deleted' );
	}

	/**
	 * Handle status update.
	 *
	 * @return void
	 */
	public function handle_update_status() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
		}

		$quote_id = isset( $_GET['quote_id'] ) ? absint( $_GET['quote_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$status   = isset( $_GET['status'] ) ? sanitize_text_field( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$allowed  = array( 'pending', 'approved', 'rejected' );

		if ( ! $quote_id || ! in_array( $status, $allowed, true ) ) {
			$this->redirect_with_message( 'quick-quotes', 'error' );
		}

		check_admin_referer( 'qquo_update_status_' . $quote_id );

		global $wpdb;
		$table_name = $this->get_table_name();
		$query      = $wpdb->prepare( "UPDATE {$table_name} SET status = %s WHERE id = %d", $status, $quote_id );
		$wpdb->query( $query );

		$this->redirect_with_message( 'quick-quotes', 'status_updated' );
	}

	/**
	 * Handle settings save.
	 *
	 * @return void
	 */
	public function handle_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
		}

		check_admin_referer( 'qquo_save_settings', 'qquo_save_settings_nonce' );

		$settings = $this->get_settings();
		$premium_enabled = qquo_is_premium_active();
		$settings['default_tax_percent']      = isset( $_POST['default_tax_percent'] ) ? $this->sanitize_percentage( wp_unslash( $_POST['default_tax_percent'] ) ) : 0;
		$settings['default_discount_percent'] = isset( $_POST['default_discount_percent'] ) ? $this->sanitize_percentage( wp_unslash( $_POST['default_discount_percent'] ) ) : 0;
		$current_email_notifications          = isset( $settings['email_notifications'] ) && '1' === (string) $settings['email_notifications'] ? '1' : '0';
		$current_quick_schedule_url           = isset( $settings['quick_schedule_page_url'] ) ? esc_url_raw( (string) $settings['quick_schedule_page_url'] ) : '';
		$current_qf_to_quote_enabled          = isset( $settings['qf_to_quote_enabled'] ) && '1' === (string) $settings['qf_to_quote_enabled'] ? '1' : '0';
		$current_qs_integration_enabled       = isset( $settings['quick_schedule_integration_enabled'] ) && '1' === (string) $settings['quick_schedule_integration_enabled'] ? '1' : '0';
		$settings['email_notifications']      = $premium_enabled ? ( isset( $_POST['email_notifications'] ) ? '1' : '0' ) : $current_email_notifications;
		$settings['notification_email']       = isset( $_POST['notification_email'] ) ? sanitize_email( wp_unslash( $_POST['notification_email'] ) ) : '';
		$settings['quick_schedule_page_url']  = $premium_enabled && isset( $_POST['quick_schedule_page_url'] ) ? esc_url_raw( wp_unslash( $_POST['quick_schedule_page_url'] ) ) : $current_quick_schedule_url;
		$settings['qf_to_quote_enabled']      = $premium_enabled ? ( ( isset( $_POST['qf_to_quote_enabled'] ) && '1' === (string) wp_unslash( $_POST['qf_to_quote_enabled'] ) ) ? '1' : '0' ) : $current_qf_to_quote_enabled;
		$settings['qf_integration_enabled']   = $settings['qf_to_quote_enabled'];
		$settings['quick_schedule_integration_enabled'] = $premium_enabled ? ( ( isset( $_POST['quick_schedule_integration_enabled'] ) && '1' === (string) wp_unslash( $_POST['quick_schedule_integration_enabled'] ) ) ? '1' : '0' ) : $current_qs_integration_enabled;

		if ( ! is_email( $settings['notification_email'] ) ) {
			$settings['notification_email'] = get_option( 'admin_email', '' );
		}

		update_option( QQUO_OPTION_SETTINGS, $settings );
		$this->redirect_with_message( 'quick-quotes-settings', 'settings_saved' );
	}

	/**
	 * Handle style save.
	 *
	 * @return void
	 */
	public function handle_save_style() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
		}

		check_admin_referer( 'qquo_save_style', 'qquo_save_style_nonce' );
		$settings = $this->get_settings();
		$settings['custom_form_css'] = isset( $_POST['custom_form_css'] ) ? wp_kses_post( (string) wp_unslash( $_POST['custom_form_css'] ) ) : '';
		$settings['custom_invoice_css'] = isset( $_POST['custom_invoice_css'] ) ? wp_kses_post( (string) wp_unslash( $_POST['custom_invoice_css'] ) ) : '';
		update_option( QQUO_OPTION_SETTINGS, $settings );
		$this->redirect_with_message( 'quick-quotes-style', 'settings_saved' );
	}

	/**
	 * Handle license activation.
	 *
	 * @return void
	 */
	public function handle_activate_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
		}

		check_admin_referer( 'qquo_activate_license', 'qquo_activate_license_nonce' );

		$license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		$settings = $this->get_settings();

		if ( '' === $license_key ) {
			$settings['license_key'] = '';
			$settings['license_status'] = 'inactive';
			$settings['license_message'] = __( 'License key is required.', 'quick-quotes' );
			update_option( QQUO_OPTION_SETTINGS, $settings );
			$this->redirect_with_message( 'quick-quotes-settings', 'settings_saved' );
		}

		if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
			$settings['license_key'] = $license_key;
			$settings['license_status'] = 'invalid';
			$settings['license_message'] = __( 'Quick Woo License plugin is required for activation.', 'quick-quotes' );
			update_option( QQUO_OPTION_SETTINGS, $settings );
			$this->redirect_with_message( 'quick-quotes-settings', 'settings_saved' );
		}

		$result = qlic_activate_license_key_for_products(
			$license_key,
			array(
				'quick-quotes',
				'quick-quotes-one-site',
				'quick-quotes-five-sites',
				'quick-quotes-unlimited-sites',
				'quick-woo-bundle',
				'quick-woo-suite',
				'quick-bundle',
                    'quick-secretary',
                )
		);

		$settings['license_key'] = $license_key;
		$settings['license_status'] = isset( $result['status'] ) ? sanitize_key( (string) $result['status'] ) : 'invalid';
		$settings['license_message'] = isset( $result['message'] ) ? sanitize_text_field( (string) $result['message'] ) : __( 'License validation failed.', 'quick-quotes' );
		if ( ! empty( $result['valid'] ) ) {
			$settings['license_status'] = 'active';
		}

		update_option( QQUO_OPTION_SETTINGS, $settings );
		$this->redirect_with_message( 'quick-quotes-settings', 'settings_saved' );
	}

	/**
	 * Handle license deactivation.
	 *
	 * @return void
	 */
	public function handle_deactivate_license() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
		}

		check_admin_referer( 'qquo_deactivate_license', 'qquo_deactivate_license_nonce' );

		$settings = $this->get_settings();
		$license_key = isset( $settings['license_key'] ) ? sanitize_text_field( (string) $settings['license_key'] ) : '';
		if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
			$result = qlic_deactivate_license_key_for_products(
				$license_key,
				array(
					'quick-quotes',
					'quick-quotes-one-site',
					'quick-quotes-five-sites',
					'quick-quotes-unlimited-sites',
					'quick-woo-bundle',
					'quick-woo-suite',
					'quick-bundle',
                    'quick-secretary',
                )
			);
			$settings['license_status'] = 'inactive';
			$settings['license_message'] = isset( $result['message'] ) ? sanitize_text_field( (string) $result['message'] ) : __( 'License deactivated.', 'quick-quotes' );
		} else {
			$settings['license_status'] = 'inactive';
			$settings['license_message'] = __( 'License deactivated.', 'quick-quotes' );
		}

		update_option( QQUO_OPTION_SETTINGS, $settings );
		$this->redirect_with_message( 'quick-quotes-settings', 'settings_saved' );
	}

	/**
	 * Handle form builder save.
	 *
	 * @return void
	 */
	public function handle_save_form_builder() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
		}

		check_admin_referer( 'qquo_save_form_builder', 'qquo_save_form_builder_nonce' );
		if ( ! qquo_is_premium_active() ) {
			$this->redirect_with_message( 'quick-quotes-form-builder', 'error' );
		}

		$mode     = isset( $_POST['qquo_builder_mode'] ) ? sanitize_key( wp_unslash( $_POST['qquo_builder_mode'] ) ) : '';
		if ( 'qf_pricing' === $mode ) {
			$raw_pricing = isset( $_POST['qf_pricing'] ) && is_array( $_POST['qf_pricing'] ) ? wp_unslash( $_POST['qf_pricing'] ) : array();
			$raw_form_config = isset( $_POST['qf_form_config'] ) && is_array( $_POST['qf_form_config'] ) ? wp_unslash( $_POST['qf_form_config'] ) : array();
			$pricing_map = array();
			$form_config_map = array();
			$selected_form_id = isset( $_POST['qf_selected_form_id'] ) ? absint( wp_unslash( $_POST['qf_selected_form_id'] ) ) : 0;
			$current_map = $this->get_quick_forms_pricing_map();
			$current_form_config_map = $this->get_quick_forms_form_config_map();

			foreach ( $raw_pricing as $form_id => $fields ) {
				$form_id = absint( $form_id );
				if ( $form_id < 1 || ! is_array( $fields ) ) {
					continue;
				}

				$form_prices = array();
				foreach ( $fields as $field_name => $raw_field_config ) {
					$field_name = sanitize_key( $field_name );
					if ( '' === $field_name ) {
						continue;
					}

					$field_price = array(
						'amount'  => '',
						'options' => array(),
					);

					$raw_amount = '';
					if ( is_array( $raw_field_config ) ) {
						$raw_amount = isset( $raw_field_config['amount'] ) ? (string) $raw_field_config['amount'] : '';
					} else {
						$raw_amount = (string) $raw_field_config;
					}

					$normalized = preg_replace( '/[^0-9.\-]/', '', sanitize_text_field( $raw_amount ) );
					if ( '' !== $normalized && is_numeric( $normalized ) ) {
						$float_amount = max( 0, round( (float) $normalized, 2 ) );
						if ( $float_amount > 0 ) {
							$field_price['amount'] = number_format( $float_amount, 2, '.', '' );
						}
					}

					$raw_options = array();
					if ( is_array( $raw_field_config ) && isset( $raw_field_config['options'] ) && is_array( $raw_field_config['options'] ) ) {
						$raw_options = $raw_field_config['options'];
					}

					foreach ( $raw_options as $option_name => $raw_option_amount ) {
						$option_name = sanitize_text_field( (string) $option_name );
						if ( '' === $option_name ) {
							continue;
						}

						$normalized_option = preg_replace( '/[^0-9.\-]/', '', sanitize_text_field( (string) $raw_option_amount ) );
						if ( '' === $normalized_option || ! is_numeric( $normalized_option ) ) {
							continue;
						}

						$float_option = max( 0, round( (float) $normalized_option, 2 ) );
						if ( $float_option <= 0 ) {
							continue;
						}

						$field_price['options'][ $option_name ] = number_format( $float_option, 2, '.', '' );
					}

					if ( '' !== $field_price['amount'] || ! empty( $field_price['options'] ) ) {
						$form_prices[ $field_name ] = $field_price;
					}
				}

				$pricing_map[ $form_id ] = $form_prices;
			}

			foreach ( $raw_form_config as $form_id => $raw_config ) {
				$form_id = absint( $form_id );
				if ( $form_id < 1 || ! is_array( $raw_config ) ) {
					continue;
				}

				$due_percent = isset( $raw_config['due_percent'] ) ? max( 0, min( 100, round( (float) $raw_config['due_percent'], 2 ) ) ) : 100;
				$payment_action = isset( $raw_config['payment_action'] ) ? sanitize_key( (string) $raw_config['payment_action'] ) : 'pay_at_invoice';
				if ( ! in_array( $payment_action, array( 'pay_at_invoice', 'book_consultation' ), true ) ) {
					$payment_action = 'pay_at_invoice';
				}

				$form_config_map[ $form_id ] = array(
					'due_percent'    => number_format( (float) $due_percent, 2, '.', '' ),
					'payment_action' => $payment_action,
				);
			}

			if ( $selected_form_id > 0 ) {
				foreach ( $current_map as $form_id => $form_config ) {
					$form_id = absint( $form_id );
					if ( $form_id < 1 || $form_id === $selected_form_id ) {
						continue;
					}
					if ( ! isset( $pricing_map[ $form_id ] ) ) {
						$pricing_map[ $form_id ] = $form_config;
					}
				}
				foreach ( $current_form_config_map as $form_id => $form_config ) {
					$form_id = absint( $form_id );
					if ( $form_id < 1 || $form_id === $selected_form_id ) {
						continue;
					}
					if ( ! isset( $form_config_map[ $form_id ] ) ) {
						$form_config_map[ $form_id ] = $form_config;
					}
				}
			}

			update_option( QQUO_OPTION_QF_FIELD_PRICING, $pricing_map, false );
			update_option( QQUO_OPTION_QF_FORM_CONFIG, $form_config_map, false );
			$redirect_url = add_query_arg(
				array(
					'page'       => 'quick-quotes-form-builder',
					'message'    => 'form_builder_saved',
					'qf_form_id' => $selected_form_id,
				),
				admin_url( 'admin.php' )
			);
			wp_safe_redirect( $redirect_url );
			exit;
		}

		$raw_fields = isset( $_POST['custom_fields'] ) && is_array( $_POST['custom_fields'] ) ? wp_unslash( $_POST['custom_fields'] ) : array();
		$labels     = isset( $raw_fields['label'] ) ? (array) $raw_fields['label'] : array();
		$keys       = isset( $raw_fields['key'] ) ? (array) $raw_fields['key'] : array();
		$types      = isset( $raw_fields['type'] ) ? (array) $raw_fields['type'] : array();
		$options    = isset( $raw_fields['options'] ) ? (array) $raw_fields['options'] : array();
		$row_ids    = isset( $raw_fields['row_id'] ) ? (array) $raw_fields['row_id'] : array();
		$required_ids = isset( $raw_fields['required_ids'] ) ? (array) $raw_fields['required_ids'] : array();
		$required_ids = array_map( 'strval', $required_ids );

		$sanitized = array();
		foreach ( $labels as $index => $label ) {
			$clean_label = sanitize_text_field( $label );
			$clean_key   = isset( $keys[ $index ] ) ? $this->sanitize_field_key( $keys[ $index ] ) : '';
			$clean_type  = isset( $types[ $index ] ) ? $this->sanitize_custom_field_type( $types[ $index ] ) : 'text';
			$raw_options = isset( $options[ $index ] ) ? sanitize_text_field( $options[ $index ] ) : '';

			if ( '' === $clean_label || '' === $clean_key ) {
				continue;
			}

			$clean_options = array();
			if ( 'select' === $clean_type && '' !== $raw_options ) {
				$parts = array_map( 'trim', explode( ',', $raw_options ) );
				foreach ( $parts as $option ) {
					$option = sanitize_text_field( $option );
					if ( '' !== $option ) {
						$clean_options[] = $option;
					}
				}
			}

			$row_id      = isset( $row_ids[ $index ] ) ? (string) $row_ids[ $index ] : (string) $index;
			$is_required = in_array( $row_id, $required_ids, true );

			$sanitized[] = array(
				'label'    => $clean_label,
				'key'      => $clean_key,
				'type'     => $clean_type,
				'required' => $is_required,
				'options'  => $clean_options,
			);
		}

		if ( empty( $sanitized ) ) {
			$sanitized = $this->get_default_custom_fields();
		}

		update_option( QQUO_OPTION_CUSTOM_FIELDS, $sanitized );
		$this->redirect_with_message( 'quick-quotes-form-builder', 'form_builder_saved' );
	}

	/**
	 * Handle invoice customizer save.
	 *
	 * @return void
	 */
	public function handle_save_invoice_template() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
		}

		check_admin_referer( 'qquo_save_invoice_template', 'qquo_save_invoice_template_nonce' );

		$template = array(
			'company_name'    => isset( $_POST['company_name'] ) ? sanitize_text_field( wp_unslash( $_POST['company_name'] ) ) : '',
			'company_address' => isset( $_POST['company_address'] ) ? sanitize_textarea_field( wp_unslash( $_POST['company_address'] ) ) : '',
			'company_email'   => isset( $_POST['company_email'] ) ? sanitize_email( wp_unslash( $_POST['company_email'] ) ) : '',
			'company_phone'   => isset( $_POST['company_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['company_phone'] ) ) : '',
			'logo_url'        => isset( $_POST['logo_url'] ) ? esc_url_raw( wp_unslash( $_POST['logo_url'] ) ) : '',
			'accent_color'    => isset( $_POST['accent_color'] ) ? sanitize_hex_color( wp_unslash( $_POST['accent_color'] ) ) : '',
			'invoice_title'   => isset( $_POST['invoice_title'] ) ? sanitize_text_field( wp_unslash( $_POST['invoice_title'] ) ) : '',
			'footer_text'     => isset( $_POST['footer_text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['footer_text'] ) ) : '',
		);

		if ( '' === $template['company_name'] ) {
			$template['company_name'] = get_bloginfo( 'name' );
		}
		if ( ! is_email( $template['company_email'] ) ) {
			$template['company_email'] = '';
		}
		if ( '' === $template['accent_color'] ) {
			$template['accent_color'] = '#1d4ed8';
		}
		if ( '' === $template['invoice_title'] ) {
			$template['invoice_title'] = __( 'Quote Invoice', 'quick-quotes' );
		}

		update_option( QQUO_OPTION_INVOICE_TEMPLATE, $template );
		$this->redirect_with_message( 'quick-quotes-invoice-customizer', 'invoice_template_saved' );
	}

	/**
	 * Get table name.
	 *
	 * @return string
	 */
	private function get_table_name() {
		global $wpdb;
		return $wpdb->prefix . 'quick_quotes';
	}

	/**
	 * Get plugin settings with defaults.
	 *
	 * @return array<string,string>
	 */
	public function get_settings() {
		$defaults = array(
			'default_tax_percent'      => '0',
			'default_discount_percent' => '0',
			'email_notifications'      => '0',
			'notification_email'       => get_option( 'admin_email', '' ),
			'quick_schedule_page_url'  => '',
			'qf_to_quote_enabled'      => '1',
			'qf_integration_enabled'   => '1',
			'quick_schedule_integration_enabled' => '1',
			'custom_form_css'          => '',
			'custom_invoice_css'       => '',
			'license_key'              => '',
			'license_status'           => 'inactive',
			'license_message'          => '',
		);

		$settings = get_option( QQUO_OPTION_SETTINGS, array() );
		if ( ! is_array( $settings ) || ( ! isset( $settings['default_tax_percent'] ) && ! isset( $settings['qf_to_quote_enabled'] ) ) ) {
			$legacy = get_option( 'qquo_settings', array() );
			if ( is_array( $legacy ) && ( isset( $legacy['default_tax_percent'] ) || isset( $legacy['qf_to_quote_enabled'] ) ) ) {
				$settings = $legacy;
				update_option( QQUO_OPTION_SETTINGS, $settings );
			}
		}
		$settings = wp_parse_args( is_array( $settings ) ? $settings : array(), $defaults );
		if ( ! isset( $settings['qf_to_quote_enabled'] ) && isset( $settings['qf_integration_enabled'] ) ) {
			$settings['qf_to_quote_enabled'] = '1' === (string) $settings['qf_integration_enabled'] ? '1' : '0';
		}
		$settings['qf_integration_enabled'] = '1' === (string) $settings['qf_to_quote_enabled'] ? '1' : '0';

		return $settings;
	}

	/**
	 * Check if Quick Forms is active and available.
	 *
	 * @return bool
	 */
	private function is_quick_forms_available() {
		global $wpdb;

		$table_name = function_exists( 'qfrm_table_forms' ) ? qfrm_table_forms() : ( $wpdb->prefix . 'quick_forms' );
		$exists     = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) );

		return ! empty( $exists );
	}

	/**
	 * Get available active Quick Forms.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private function get_quick_forms_list() {
		if ( ! $this->is_quick_forms_available() ) {
			return array();
		}

		$builder = new QFRM_Builder();
		$forms   = $builder->get_forms();
		if ( ! is_array( $forms ) ) {
			return array();
		}

		$output = array();
		foreach ( $forms as $form ) {
			if ( ! is_array( $form ) ) {
				continue;
			}

			$form_id   = isset( $form['id'] ) ? absint( $form['id'] ) : 0;
			$form_name = isset( $form['name'] ) ? sanitize_text_field( $form['name'] ) : '';
			$status    = isset( $form['status'] ) ? sanitize_key( $form['status'] ) : 'inactive';

			if ( $form_id < 1 || '' === $form_name || 'active' !== $status ) {
				continue;
			}

			$output[] = array(
				'id'   => $form_id,
				'name' => $form_name,
			);
		}

		return $output;
	}

	/**
	 * Get Quick Forms with field configuration.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private function get_quick_forms_form_configs() {
		if ( ! $this->is_quick_forms_available() ) {
			return array();
		}

		$forms = array();
		if ( class_exists( 'QFRM_Builder' ) ) {
			$builder = new QFRM_Builder();
			$forms   = $builder->get_forms();
		} else {
			global $wpdb;
			$table_name = function_exists( 'qfrm_table_forms' ) ? qfrm_table_forms() : ( $wpdb->prefix . 'quick_forms' );
			$forms      = $wpdb->get_results( "SELECT id, name, status, fields_json FROM {$table_name} ORDER BY id DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		if ( ! is_array( $forms ) ) {
			return array();
		}

		$output = array();
		foreach ( $forms as $form ) {
			if ( ! is_array( $form ) ) {
				continue;
			}

			$form_id   = isset( $form['id'] ) ? absint( $form['id'] ) : 0;
			$form_name = isset( $form['name'] ) ? sanitize_text_field( $form['name'] ) : '';
			if ( $form_id < 1 || '' === $form_name ) {
				continue;
			}

			$fields = array();
			$raw_fields = isset( $form['fields_json'] ) ? qfrm_decode_json_array( $form['fields_json'] ) : array();
			if ( is_array( $raw_fields ) ) {
				foreach ( $raw_fields as $field ) {
					if ( ! is_array( $field ) ) {
						continue;
					}

					$field_name = isset( $field['name'] ) ? sanitize_key( $field['name'] ) : '';
					if ( '' === $field_name ) {
						continue;
					}

					$fields[] = array(
						'name'  => $field_name,
						'label' => isset( $field['label'] ) ? sanitize_text_field( $field['label'] ) : $field_name,
						'type'  => isset( $field['type'] ) ? sanitize_key( $field['type'] ) : 'text',
						'options' => isset( $field['options'] ) && is_array( $field['options'] ) ? array_map( 'sanitize_text_field', $field['options'] ) : array(),
					);
				}
			}

			$output[] = array(
				'id'     => $form_id,
				'name'   => $form_name,
				'fields' => $fields,
			);
		}

		return $output;
	}

	/**
	 * Get saved Quick Forms field pricing map.
	 *
	 * @return array<int,array<string,array<string,mixed>>>
	 */
	private function get_quick_forms_pricing_map() {
		$pricing = get_option( QQUO_OPTION_QF_FIELD_PRICING, array() );
		if ( ! is_array( $pricing ) || empty( $pricing ) ) {
			$legacy_pricing = get_option( 'qquo_qf_field_pricing', array() );
			if ( is_array( $legacy_pricing ) && ! empty( $legacy_pricing ) ) {
				$pricing = $legacy_pricing;
				update_option( QQUO_OPTION_QF_FIELD_PRICING, $pricing );
			}
		}
		if ( ! is_array( $pricing ) ) {
			return array();
		}

		$output = array();
		foreach ( $pricing as $form_id => $fields ) {
			$form_id = absint( $form_id );
			if ( $form_id < 1 || ! is_array( $fields ) ) {
				continue;
			}

			$output[ $form_id ] = array();
			foreach ( $fields as $field_name => $field_config ) {
				$field_name = sanitize_key( $field_name );
				if ( '' === $field_name ) {
					continue;
				}

				$amount  = '';
				$options = array();

				if ( is_array( $field_config ) ) {
					$amount = isset( $field_config['amount'] ) ? sanitize_text_field( (string) $field_config['amount'] ) : '';
					if ( isset( $field_config['options'] ) && is_array( $field_config['options'] ) ) {
						foreach ( $field_config['options'] as $option_name => $option_amount ) {
							$option_name   = sanitize_text_field( (string) $option_name );
							$option_amount = sanitize_text_field( (string) $option_amount );
							if ( '' === $option_name || '' === $option_amount ) {
								continue;
							}
							$options[ $option_name ] = $option_amount;
						}
					}
				} else {
					$amount = sanitize_text_field( (string) $field_config );
				}

				if ( '' === $amount && empty( $options ) ) {
					continue;
				}

				$output[ $form_id ][ $field_name ] = array(
					'amount'  => $amount,
					'options' => $options,
				);
			}
		}

		return $output;
	}

	/**
	 * Get saved Quick Forms form-level invoice config.
	 *
	 * @return array<int,array<string,string>>
	 */
	private function get_quick_forms_form_config_map() {
		$config_map = get_option( QQUO_OPTION_QF_FORM_CONFIG, array() );
		if ( ! is_array( $config_map ) || empty( $config_map ) ) {
			return array();
		}

		$output = array();
		foreach ( $config_map as $form_id => $config ) {
			$form_id = absint( $form_id );
			if ( $form_id < 1 || ! is_array( $config ) ) {
				continue;
			}

			$due_percent = isset( $config['due_percent'] ) ? max( 0, min( 100, round( (float) $config['due_percent'], 2 ) ) ) : 100;
			$payment_action = isset( $config['payment_action'] ) ? sanitize_key( (string) $config['payment_action'] ) : 'pay_at_invoice';
			if ( ! in_array( $payment_action, array( 'pay_at_invoice', 'book_consultation' ), true ) ) {
				$payment_action = 'pay_at_invoice';
			}

			$output[ $form_id ] = array(
				'due_percent'    => number_format( (float) $due_percent, 2, '.', '' ),
				'payment_action' => $payment_action,
			);
		}

		return $output;
	}

	/**
	 * Get additional custom fields config.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function get_custom_fields_config() {
		$fields = get_option( QQUO_OPTION_CUSTOM_FIELDS, array() );
		if ( ! is_array( $fields ) || empty( $fields ) ) {
			$legacy_fields = get_option( 'qquo_custom_fields', array() );
			if ( is_array( $legacy_fields ) && ! empty( $legacy_fields ) ) {
				$fields = $legacy_fields;
				update_option( QQUO_OPTION_CUSTOM_FIELDS, $fields );
			}
		}
		if ( empty( $fields ) || ! is_array( $fields ) ) {
			return $this->get_default_custom_fields();
		}

		$sanitized = array();
		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$key   = isset( $field['key'] ) ? $this->sanitize_field_key( $field['key'] ) : '';
			$label = isset( $field['label'] ) ? sanitize_text_field( $field['label'] ) : '';
			if ( '' === $key || '' === $label ) {
				continue;
			}

			$options = array();
			if ( isset( $field['options'] ) && is_array( $field['options'] ) ) {
				foreach ( $field['options'] as $option ) {
					$option = sanitize_text_field( $option );
					if ( '' !== $option ) {
						$options[] = $option;
					}
				}
			}

			$sanitized[] = array(
				'label'    => $label,
				'key'      => $key,
				'type'     => isset( $field['type'] ) ? $this->sanitize_custom_field_type( $field['type'] ) : 'text',
				'required' => ! empty( $field['required'] ),
				'options'  => $options,
			);
		}

		return empty( $sanitized ) ? $this->get_default_custom_fields() : $sanitized;
	}

	/**
	 * Get invoice template settings.
	 *
	 * @return array<string,string>
	 */
	private function get_invoice_template_settings() {
		$defaults = array(
			'company_name'    => get_bloginfo( 'name' ),
			'company_address' => '',
			'company_email'   => get_option( 'admin_email', '' ),
			'company_phone'   => '',
			'logo_url'        => '',
			'accent_color'    => '#1d4ed8',
			'invoice_title'   => __( 'Quote Invoice', 'quick-quotes' ),
			'footer_text'     => __( 'Thank you for your business.', 'quick-quotes' ),
		);

		$settings = get_option( QQUO_OPTION_INVOICE_TEMPLATE, array() );
		if ( ! is_array( $settings ) || empty( $settings ) ) {
			$legacy_template = get_option( 'qquo_invoice_template', array() );
			if ( is_array( $legacy_template ) && ! empty( $legacy_template ) ) {
				$settings = $legacy_template;
				update_option( QQUO_OPTION_INVOICE_TEMPLATE, $settings );
			}
		}
		$settings = wp_parse_args( $settings, $defaults );

		$settings['accent_color'] = sanitize_hex_color( $settings['accent_color'] );
		if ( '' === $settings['accent_color'] ) {
			$settings['accent_color'] = $defaults['accent_color'];
		}

		return array(
			'company_name'    => sanitize_text_field( $settings['company_name'] ),
			'company_address' => sanitize_textarea_field( $settings['company_address'] ),
			'company_email'   => sanitize_email( $settings['company_email'] ),
			'company_phone'   => sanitize_text_field( $settings['company_phone'] ),
			'logo_url'        => esc_url_raw( $settings['logo_url'] ),
			'accent_color'    => $settings['accent_color'],
			'invoice_title'   => sanitize_text_field( $settings['invoice_title'] ),
			'footer_text'     => sanitize_textarea_field( $settings['footer_text'] ),
		);
	}

	/**
	 * Get valid project types.
	 *
	 * @return array<int,string>
	 */
	private function get_project_types() {
		return array(
			'Website Design',
			'Ecommerce',
			'SEO',
			'Content Marketing',
			'Consulting',
			'Maintenance',
			'Custom',
		);
	}

	/**
	 * Get quote by ID.
	 *
	 * @param int $quote_id Quote ID.
	 * @return object|null
	 */
	private function get_quote_by_id( $quote_id ) {
		global $wpdb;
		$table_name = $this->get_table_name();
		$query      = $wpdb->prepare( "SELECT * FROM {$table_name} WHERE id = %d LIMIT 1", $quote_id );
		return $wpdb->get_row( $query );
	}

	/**
	 * Sanitize percentage value.
	 *
	 * @param mixed $value Raw input value.
	 * @return float
	 */
	private function sanitize_percentage( $value ) {
		$percent = (float) $value;
		$percent = max( 0, min( 100, $percent ) );
		return round( $percent, 2 );
	}

	/**
	 * Calculate totals.
	 *
	 * @param float $subtotal Subtotal.
	 * @param float $tax_percent Tax percent.
	 * @param float $discount_percent Discount percent.
	 * @return array<string,float>
	 */
	private function calculate_totals( $subtotal, $tax_percent, $discount_percent ) {
		$subtotal        = round( (float) $subtotal, 2 );
		$tax_amount      = round( $subtotal * ( (float) $tax_percent / 100 ), 2 );
		$discount_amount = round( $subtotal * ( (float) $discount_percent / 100 ), 2 );
		$final_total     = max( 0, round( $subtotal + $tax_amount - $discount_amount, 2 ) );

		return array(
			'subtotal'        => $subtotal,
			'tax_amount'      => $tax_amount,
			'discount_amount' => $discount_amount,
			'final_total'     => $final_total,
		);
	}

	/**
	 * Get supported custom field types.
	 *
	 * @return array<int,string>
	 */
	private function get_supported_custom_field_types() {
		return array( 'text', 'email', 'tel', 'textarea', 'select' );
	}

	/**
	 * Default custom fields.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private function get_default_custom_fields() {
		return array(
			array(
				'label'    => __( 'Phone Number', 'quick-quotes' ),
				'key'      => 'phone_number',
				'type'     => 'tel',
				'required' => false,
				'options'  => array(),
			),
		);
	}

	/**
	 * Sanitize field key.
	 *
	 * @param string $value Raw field key.
	 * @return string
	 */
	private function sanitize_field_key( $value ) {
		$sanitized = sanitize_key( $value );
		return '' === $sanitized ? '' : $sanitized;
	}

	/**
	 * Sanitize custom field type.
	 *
	 * @param string $value Raw field type.
	 * @return string
	 */
	private function sanitize_custom_field_type( $value ) {
		$value = sanitize_key( $value );
		return in_array( $value, $this->get_supported_custom_field_types(), true ) ? $value : 'text';
	}

	/**
	 * Build delete URL.
	 *
	 * @param int $quote_id Quote ID.
	 * @return string
	 */
	private function get_delete_url( $quote_id ) {
		$url = add_query_arg(
			array(
				'action'   => 'qquo_delete_quote',
				'quote_id' => absint( $quote_id ),
			),
			admin_url( 'admin-post.php' )
		);

		return wp_nonce_url( $url, 'qquo_delete_quote_' . absint( $quote_id ) );
	}

	/**
	 * Build status URL.
	 *
	 * @param int    $quote_id Quote ID.
	 * @param string $status Status.
	 * @return string
	 */
	private function get_status_url( $quote_id, $status ) {
		$url = add_query_arg(
			array(
				'action'   => 'qquo_update_status',
				'quote_id' => absint( $quote_id ),
				'status'   => sanitize_text_field( $status ),
			),
			admin_url( 'admin-post.php' )
		);

		return wp_nonce_url( $url, 'qquo_update_status_' . absint( $quote_id ) );
	}

	/**
	 * Redirect to admin page with message.
	 *
	 * @param string $page Page slug.
	 * @param string $message Message key.
	 * @param int    $quote_id Optional quote ID.
	 * @return void
	 */
	private function redirect_with_message( $page, $message, $quote_id = 0 ) {
		$args = array(
			'page'       => sanitize_text_field( $page ),
			'qquo_message' => sanitize_text_field( $message ),
		);

		if ( $quote_id > 0 ) {
			$args['quote_id'] = absint( $quote_id );
		}

		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Render admin notice from query arg.
	 *
	 * @return void
	 */
	private function render_admin_notice() {
		if ( ! isset( $_GET['qquo_message'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$message_key = sanitize_text_field( wp_unslash( $_GET['qquo_message'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$messages    = array(
			'saved'          => array( 'success', __( 'Quote saved successfully.', 'quick-quotes' ) ),
			'updated'        => array( 'success', __( 'Quote updated successfully.', 'quick-quotes' ) ),
			'deleted'        => array( 'success', __( 'Quote deleted successfully.', 'quick-quotes' ) ),
			'status_updated' => array( 'success', __( 'Quote status updated.', 'quick-quotes' ) ),
			'settings_saved' => array( 'success', __( 'Settings saved.', 'quick-quotes' ) ),
			'form_builder_saved' => array( 'success', __( 'Form builder saved.', 'quick-quotes' ) ),
			'invoice_template_saved' => array( 'success', __( 'Invoice customizer saved.', 'quick-quotes' ) ),
			'invalid'        => array( 'error', __( 'Please provide valid required fields and at least one line item.', 'quick-quotes' ) ),
			'error'          => array( 'error', __( 'An error occurred while processing your request.', 'quick-quotes' ) ),
		);

		if ( ! isset( $messages[ $message_key ] ) ) {
			return;
		}

		$notice_type = $messages[ $message_key ][0];
		$text        = $messages[ $message_key ][1];
		?>
		<div class="notice notice-<?php echo esc_attr( $notice_type ); ?> is-dismissible">
			<p><?php echo esc_html( $text ); ?></p>
		</div>
		<?php
	}
}
