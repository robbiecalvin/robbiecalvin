<?php
/**
 * Activator class.
 *
 * @package QuickQuotes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles plugin activation tasks.
 */
class QQUO_Activator {
	const SCHEMA_VERSION = '1.1.0';

	/**
	 * Create database table and default settings.
	 *
	 * @return void
	 */
	public static function activate() {
		global $wpdb;

		$table_name      = $wpdb->prefix . 'quick_quotes';
		$charset_collate = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "CREATE TABLE {$table_name} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			client_name VARCHAR(255) NOT NULL,
			client_email VARCHAR(255) NOT NULL,
			project_type VARCHAR(255) NOT NULL,
			line_items LONGTEXT NOT NULL,
			subtotal DECIMAL(10,2) NOT NULL DEFAULT 0.00,
			tax_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
			discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
			total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
			due_today DECIMAL(10,2) NOT NULL DEFAULT 0.00,
			payment_mode VARCHAR(32) NOT NULL DEFAULT 'full',
			payment_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
			stripe_payment_url TEXT NULL,
			notes TEXT NULL,
			status VARCHAR(50) NOT NULL DEFAULT 'pending',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id)
		) {$charset_collate};";

		dbDelta( $sql );

		$defaults = array(
			'default_tax_percent'      => '0',
			'default_discount_percent' => '0',
			'email_notifications'      => '0',
			'notification_email'       => get_option( 'admin_email', '' ),
			'qf_to_quote_enabled'      => '1',
			'quick_schedule_page_url'  => '',
		);

		$current_settings = get_option( QQUO_OPTION_SETTINGS, array() );
		if ( ! is_array( $current_settings ) || empty( $current_settings ) ) {
			$legacy_settings = get_option( 'qquo_settings', array() );
			if ( is_array( $legacy_settings ) && ( isset( $legacy_settings['default_tax_percent'] ) || isset( $legacy_settings['qf_to_quote_enabled'] ) ) ) {
				$current_settings = $legacy_settings;
			}
		}
		$settings         = wp_parse_args( $current_settings, $defaults );
		update_option( QQUO_OPTION_SETTINGS, $settings );

		$current_custom_fields = get_option( QQUO_OPTION_CUSTOM_FIELDS, array() );
		if ( empty( $current_custom_fields ) || ! is_array( $current_custom_fields ) ) {
			update_option(
				QQUO_OPTION_CUSTOM_FIELDS,
				array(
					array(
						'label'    => __( 'Phone Number', 'quick-quotes' ),
						'key'      => 'phone_number',
						'type'     => 'tel',
						'required' => false,
						'options'  => array(),
					),
				)
			);
		}

		$current_invoice_template = get_option( QQUO_OPTION_INVOICE_TEMPLATE, array() );
		$invoice_defaults         = array(
			'company_name'    => get_bloginfo( 'name' ),
			'company_address' => '',
			'company_email'   => get_option( 'admin_email', '' ),
			'company_phone'   => '',
			'logo_url'        => '',
			'accent_color'    => '#1d4ed8',
			'invoice_title'   => __( 'Quote Invoice', 'quick-quotes' ),
			'footer_text'     => __( 'Thank you for your business.', 'quick-quotes' ),
		);
		update_option( QQUO_OPTION_INVOICE_TEMPLATE, wp_parse_args( $current_invoice_template, $invoice_defaults ) );
		update_option( 'quick_woo_quotes_schema_version', self::SCHEMA_VERSION );
	}

	/**
	 * Ensure DB schema changes are applied without requiring manual re-activation.
	 *
	 * @return void
	 */
	public static function maybe_upgrade() {
		$current = get_option( 'quick_woo_quotes_schema_version', '' );
		if ( self::SCHEMA_VERSION !== (string) $current ) {
			self::activate();
		}
	}
}
