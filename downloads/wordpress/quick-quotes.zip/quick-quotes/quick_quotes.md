# Quick Quotes -- Visual To‑Do

## Main Screen

-   Change Remove + Add Line Item buttons to blue with white text

## Settings

-   Move Activate/Deactivate buttons below license input
-   Stack vertically
-   Make blue with white text

## Invoice Customizer

-   No changes required

## Style Page

-   Add left-side padding to both labels per container
