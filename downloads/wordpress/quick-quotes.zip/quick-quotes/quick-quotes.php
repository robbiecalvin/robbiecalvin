<?php
/**
 * Plugin Name: Quick Quotes
 * Description: Dynamic quote builder with admin management and frontend AJAX quote request form.
 * Version: 1.0.0
 * Author: QuickWoo by Robbie Calvin
 * Author URI: https://quickwoo.pro
 * Text Domain: quick-quotes
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/quick-core/bootstrap.php';
}

define( 'QQUO_PLUGIN_VERSION', '1.0.0' );
define( 'QQUO_PLUGIN_FILE', __FILE__ );
define( 'QQUO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'QQUO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'QQUO_OPTION_SETTINGS', 'quick_woo_quotes_settings' );
define( 'QQUO_OPTION_CUSTOM_FIELDS', 'quick_woo_quotes_custom_fields' );
define( 'QQUO_OPTION_INVOICE_TEMPLATE', 'quick_woo_quotes_invoice_template' );
define( 'QQUO_OPTION_QF_FIELD_PRICING', 'quick_woo_quotes_qf_field_pricing' );
define( 'QQUO_OPTION_QF_FORM_CONFIG', 'quick_woo_quotes_qf_form_config' );
define( 'QQUO_OPTION_QF_SUBMISSION_QUOTE_MAP', 'quick_woo_quotes_qf_submission_quote_map' );
define( 'QQUO_OPTION_INVOICE_TOKENS', 'quick_woo_quotes_invoice_tokens' );

function qquo_is_premium_active() {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

	if ( function_exists( 'qwoo_has_active_license' ) ) {
		return (bool) qwoo_has_active_license( array( 'quick-quotes' ) );
	}

	return false;
}

require_once QQUO_PLUGIN_DIR . 'includes/class-qq-activator.php';
require_once QQUO_PLUGIN_DIR . 'includes/class-qq-admin.php';
require_once QQUO_PLUGIN_DIR . 'includes/class-qq-ajax.php';
require_once QQUO_PLUGIN_DIR . 'includes/class-qq-shortcode.php';

register_activation_hook( QQUO_PLUGIN_FILE, array( 'QQUO_Activator', 'activate' ) );

/**
 * Initialize plugin classes.
 *
 * @return void
 */
function qquo_init_plugin() {
	new QQUO_Admin();
	new QQUO_Ajax();
	new QQUO_Shortcode();
}
add_action( 'plugins_loaded', 'qquo_init_plugin' );
add_action( 'plugins_loaded', array( 'QQUO_Activator', 'maybe_upgrade' ), 5 );

function qquo_create_quote_from_quick_forms_submission( $event ) {
	if ( ! class_exists( 'QQUO_Ajax' ) || ! method_exists( 'QQUO_Ajax', 'instance' ) ) {
		return array( 'quote_id' => 0, 'invoice_url' => '' );
	}

	$ajax = QQUO_Ajax::instance();
	if ( ! $ajax || ! method_exists( $ajax, 'create_quote_from_quick_forms_event' ) ) {
		return array( 'quote_id' => 0, 'invoice_url' => '' );
	}

	return $ajax->create_quote_from_quick_forms_event( $event );
}

function qquo_get_quote_id_for_form_submission( $submission_id ) {
	if ( ! class_exists( 'QQUO_Ajax' ) || ! method_exists( 'QQUO_Ajax', 'instance' ) ) {
		return 0;
	}

	$ajax = QQUO_Ajax::instance();
	if ( ! $ajax || ! method_exists( $ajax, 'get_quote_id_by_form_submission' ) ) {
		return 0;
	}

	return absint( $ajax->get_quote_id_by_form_submission( $submission_id ) );
}

function qquo_get_public_invoice_url( $quote_id ) {
	if ( ! class_exists( 'QQUO_Ajax' ) || ! method_exists( 'QQUO_Ajax', 'instance' ) ) {
		return '';
	}

	$ajax = QQUO_Ajax::instance();
	if ( ! $ajax || ! method_exists( $ajax, 'get_public_invoice_url' ) ) {
		return '';
	}

	return esc_url_raw( (string) $ajax->get_public_invoice_url( $quote_id ) );
}

function qquo_handle_woocommerce_payment_sync( $order_id ) {
	if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_order' ) ) {
		return;
	}

	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}

	global $wpdb;
	$quote_table = $wpdb->prefix . 'quick_quotes';
	$schedule_table = $wpdb->prefix . 'quick_schedule_appointments';
	$has_quick_payment_item = false;

	foreach ( $order->get_items() as $item ) {
		if ( ! is_object( $item ) || ! method_exists( $item, 'get_product_id' ) ) {
			continue;
		}

		$product_id = absint( $item->get_product_id() );
		if ( $product_id < 1 ) {
			continue;
		}

		$quote_id = absint( get_post_meta( $product_id, '_qwoo_quote_id', true ) );
		if ( $quote_id > 0 ) {
			$has_quick_payment_item = true;
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$quote_table} SET status = %s WHERE id = %d",
					'approved',
					$quote_id
				)
			);
		}

		$consultation_id = absint( get_post_meta( $product_id, '_qwoo_consultation_id', true ) );
		if ( $consultation_id > 0 ) {
			$has_quick_payment_item = true;
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$schedule_table} SET status = %s WHERE id = %d",
					'paid',
					$consultation_id
				)
			);
		}
	}

	if ( ! $has_quick_payment_item ) {
		return;
	}

	$current_status = $order->get_status();
	if ( 'completed' === $current_status ) {
		return;
	}

	$auto_completed = $order->get_meta( '_qwoo_auto_completed' );
	if ( '1' === (string) $auto_completed ) {
		return;
	}

	$order->update_meta_data( '_qwoo_auto_completed', '1' );
	$order->save();
	$order->update_status( 'completed', __( 'Auto-completed after Quick payment confirmation.', 'quick-quotes' ), true );
}
add_action( 'woocommerce_payment_complete', 'qquo_handle_woocommerce_payment_sync', 20, 1 );
add_action( 'woocommerce_order_status_processing', 'qquo_handle_woocommerce_payment_sync', 20, 1 );
add_action( 'woocommerce_order_status_completed', 'qquo_handle_woocommerce_payment_sync', 20, 1 );

add_action(
    'plugins_loaded',
    static function () {
        if (function_exists('qwoo_register_plugin')) {
            qwoo_register_plugin('quick-quotes', array(
                'name' => 'Quick Woo Quotes',
                'version' => QQUO_PLUGIN_VERSION,
                'file' => QQUO_PLUGIN_FILE,
                'features' => array('quote-builder', 'invoices', 'quick-forms-sync'),
            ));
        }

        if (function_exists('qwoo_event')) {
            qwoo_event('plugin_booted', array('plugin' => 'quick-quotes', 'version' => QQUO_PLUGIN_VERSION));
        }
    },
    20
);

if ( ! function_exists( 'qwoo_quick_quotes_license_bootstrap' ) ) {
    function qwoo_quick_quotes_license_bootstrap() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu', 'qwoo_quick_quotes_license_menu' );
        add_action( 'admin_post_qwoo_quick_quotes_activate_license', 'qwoo_quick_quotes_license_handle_activate' );
        add_action( 'admin_post_qwoo_quick_quotes_deactivate_license', 'qwoo_quick_quotes_license_handle_deactivate' );
    }
    add_action( 'plugins_loaded', 'qwoo_quick_quotes_license_bootstrap', 30 );

    function qwoo_quick_quotes_license_option_key() {
        return 'qwoo_quick_quotes_license';
    }

    function qwoo_quick_quotes_license_product_scope() {
        return array( 'quick-quotes' );
    }

    function qwoo_quick_quotes_license_get_data() {
        $defaults = array(
            'license_key' => '',
            'license_status' => 'inactive',
            'license_message' => '',
        );

        $saved = get_option( qwoo_quick_quotes_license_option_key(), array() );
        $saved = is_array( $saved ) ? $saved : array();

        return wp_parse_args( $saved, $defaults );
    }

    function qwoo_quick_quotes_license_save_data( $data ) {
        $data = is_array( $data ) ? $data : array();

        $clean = array(
            'license_key' => sanitize_text_field( (string) ( $data['license_key'] ?? '' ) ),
            'license_status' => sanitize_key( (string) ( $data['license_status'] ?? 'inactive' ) ),
            'license_message' => sanitize_text_field( (string) ( $data['license_message'] ?? '' ) ),
        );

        update_option( qwoo_quick_quotes_license_option_key(), $clean, false );
        return $clean;
    }

    function qwoo_quick_quotes_license_menu() {
        add_options_page(
            'Lquotes License',
            'Lquotes License',
            'manage_options',
            'qwoo-quick-quotes-license',
            'qwoo_quick_quotes_license_render_page'
        );
    }

    function qwoo_quick_quotes_license_render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = qwoo_quick_quotes_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );

        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $status = qlic_get_license_status_for_key_products( $license_key, qwoo_quick_quotes_license_product_scope() );
            if ( is_array( $status ) ) {
                $data['license_status'] = sanitize_key( (string) ( $status['status'] ?? $data['license_status'] ) );
                $data['license_message'] = sanitize_text_field( (string) ( $status['message'] ?? $data['license_message'] ) );
                if ( ! empty( $status['valid'] ) && ! empty( $status['domain_active'] ) ) {
                    $data['license_status'] = 'active';
                }
                qwoo_quick_quotes_license_save_data( $data );
            }
        }

        $notice = isset( $_GET['qwoo_license_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qwoo_license_notice'] ) ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Lquotes License', 'quick-quotes' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-quotes' ), (string) ( $data['license_status'] ?? 'inactive' ) ) ); ?></p>
            <?php if ( ! empty( $data['license_message'] ) ) : ?>
                <p><?php echo esc_html( (string) $data['license_message'] ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_quotes_activate_license" />
                <?php wp_nonce_field( 'qwoo_quick_quotes_activate_license', 'qwoo_quick_quotes_activate_license_nonce' ); ?>
                <p>
                    <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( (string) ( $data['license_key'] ?? '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button type="submit" class="button button-primary"><?php echo esc_html__( 'Activate License', 'quick-quotes' ); ?></button>
                </p>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_quotes_deactivate_license" />
                <?php wp_nonce_field( 'qwoo_quick_quotes_deactivate_license', 'qwoo_quick_quotes_deactivate_license_nonce' ); ?>
                <p><button type="submit" class="button"><?php echo esc_html__( 'Deactivate License', 'quick-quotes' ); ?></button></p>
            </form>
        </div>
        <?php
    }

    function qwoo_quick_quotes_license_redirect( $message ) {
        $url = add_query_arg(
            array(
                'page' => 'qwoo-quick-quotes-license',
                'qwoo_license_notice' => rawurlencode( (string) $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    function qwoo_quick_quotes_license_handle_activate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
        }

        check_admin_referer( 'qwoo_quick_quotes_activate_license', 'qwoo_quick_quotes_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        if ( '' === $license_key ) {
            qwoo_quick_quotes_license_save_data(
                array(
                    'license_key' => '',
                    'license_status' => 'inactive',
                    'license_message' => 'License key is required.',
                )
            );
            qwoo_quick_quotes_license_redirect( 'License key is required.' );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            qwoo_quick_quotes_license_save_data(
                array(
                    'license_key' => $license_key,
                    'license_status' => 'invalid',
                    'license_message' => 'Quick License plugin is required for activation.',
                )
            );
            qwoo_quick_quotes_license_redirect( 'Quick License plugin is required for activation.' );
        }

        $result = qlic_activate_license_key_for_products( $license_key, qwoo_quick_quotes_license_product_scope() );
        $data = array(
            'license_key' => $license_key,
            'license_status' => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'license_message' => sanitize_text_field( (string) ( $result['message'] ?? 'License validation failed.' ) ),
        );
        if ( ! empty( $result['valid'] ) ) {
            $data['license_status'] = 'active';
        }

        qwoo_quick_quotes_license_save_data( $data );
        qwoo_quick_quotes_license_redirect( (string) $data['license_message'] );
    }

    function qwoo_quick_quotes_license_handle_deactivate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-quotes' ) );
        }

        check_admin_referer( 'qwoo_quick_quotes_deactivate_license', 'qwoo_quick_quotes_deactivate_license_nonce' );

        $data = qwoo_quick_quotes_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );
        $message = 'License deactivated.';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products( $license_key, qwoo_quick_quotes_license_product_scope() );
            if ( is_array( $result ) && ! empty( $result['message'] ) ) {
                $message = sanitize_text_field( (string) $result['message'] );
            }
        }

        qwoo_quick_quotes_license_save_data(
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => $message,
            )
        );

        qwoo_quick_quotes_license_redirect( $message );
    }
}
