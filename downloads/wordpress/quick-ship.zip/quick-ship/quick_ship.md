# Quick Ship -- Visual To‑Do

## Overview

-   No changes required

## Shipping Wizard

-   Add left-side padding to:
    -   Step 1 header
    -   Description paragraph
    -   Continue button
