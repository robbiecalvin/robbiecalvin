(function($){
  'use strict';

  function notice(msg, type){
    var cls = type === 'error' ? 'notice notice-error' : 'notice notice-success';
    $('#qship-wizard-notice').html('<div class="' + cls + '"><p>' + msg + '</p></div>');
  }

  function getFormSerialized(){
    var $form = $('#qship-form');
    if (!$form.length) {
      return '';
    }
    return $form.serialize();
  }

  function saveStep(nextOverride){
    var step = parseInt($('#qship-wizard-step').data('step') || 0, 10);
    var payloadSerialized = getFormSerialized();
    $.post(QShipWizard.ajax_url, {
      action: 'qship_wizard_save_step',
      nonce: QShipWizard.nonce,
      step: step,
      payload_serialized: payloadSerialized
    }).done(function(resp){
      if (!resp || !resp.success) {
        notice((resp && resp.data && resp.data.message) ? resp.data.message : 'Failed to save step.', 'error');
        return;
      }

      var nextStep = typeof nextOverride === 'number' ? nextOverride : resp.data.next_step;
      window.location.href = QShipWizard.wizard_page + '&step=' + nextStep;
    }).fail(function(xhr){
      var msg = 'Failed to save wizard step.';
      if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
        msg = xhr.responseJSON.data.message;
      }
      notice(msg, 'error');
    });
  }

  $(document).on('click', '#qship-next-step', function(e){
    e.preventDefault();
    saveStep();
  });

  $(document).on('click', '#qship-customize-preset', function(e){
    e.preventDefault();
    saveStep(1);
  });

  $(document).on('click', '#qship-apply-rules', function(e){
    e.preventDefault();

    var serialized = getFormSerialized();
    $.post(QShipWizard.ajax_url, {
      action: 'qship_wizard_apply',
      nonce: QShipWizard.nonce,
      payload_serialized: serialized
    }).done(function(resp){
      if (!resp || !resp.success) {
        notice((resp && resp.data && resp.data.message) ? resp.data.message : 'Failed to apply rules.', 'error');
        return;
      }
      notice(resp.data.message + ' Inserted: ' + resp.data.inserted, 'success');
    }).fail(function(xhr){
      var msg = 'Failed to apply setup.';
      if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
        msg = xhr.responseJSON.data.message;
      }
      notice(msg, 'error');
    });
  });

  $(document).on('click', '#qship-reset-wizard', function(e){
    e.preventDefault();
    if (!window.confirm('Reset wizard state?')) {
      return;
    }

    $.post(QShipWizard.ajax_url, {
      action: 'qship_wizard_reset',
      nonce: QShipWizard.nonce
    }).done(function(resp){
      if (resp && resp.success) {
        window.location.href = QShipWizard.wizard_page + '&step=0';
      } else {
        notice('Failed to reset wizard.', 'error');
      }
    }).fail(function(){
      notice('Failed to reset wizard.', 'error');
    });
  });
})(jQuery);
