<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<form id="qship-form">
  <input type="hidden" name="step" value="5">
  <h2>Step 5 - Advanced Options</h2>

  <p><label>Rule Matching
    <select name="matching_mode">
      <option value="first_match" <?php selected( $fields['matching_mode'], 'first_match' ); ?>>First Match</option>
      <option value="stack" <?php selected( $fields['matching_mode'], 'stack' ); ?>>Stack Matches</option>
    </select>
  </label></p>

  <p><label>Fallback Rate <input type="number" step="0.01" name="fallback_rate" value="<?php echo esc_attr( $fields['fallback_rate'] ); ?>"></label></p>
  <p><label><input type="checkbox" name="taxable" value="1" <?php checked( ! empty( $fields['taxable'] ) ); ?>> Taxable shipping rates</label></p>
  <p><label><input type="checkbox" name="hide_other_methods" value="1" <?php checked( ! empty( $fields['hide_other_methods'] ) ); ?>> Hide other shipping methods (do not delete them)</label></p>
</form>
