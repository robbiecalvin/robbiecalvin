<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<form id="qship-form">
  <input type="hidden" name="step" value="3">
  <h2>Step 3 - International Shipping</h2>
  <p><label><input type="checkbox" name="intl_enabled" value="1" <?php checked( ! empty( $fields['intl_enabled'] ) ); ?>> Enable international shipping</label></p>
  <p><label>International Flat Rate <input type="number" step="0.01" name="intl_flat_rate" value="<?php echo esc_attr( $fields['intl_flat_rate'] ); ?>"></label></p>
</form>
