<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<form id="qship-form">
  <input type="hidden" name="step" value="2">
  <h2>Step 2 - Domestic Shipping Type</h2>
  <p><label>Domestic Type
    <select name="domestic_type">
      <option value="flat" <?php selected( $fields['domestic_type'], 'flat' ); ?>>Flat Rate</option>
      <option value="free_threshold" <?php selected( $fields['domestic_type'], 'free_threshold' ); ?>>Free Threshold</option>
      <option value="flat_plus_free" <?php selected( $fields['domestic_type'], 'flat_plus_free' ); ?>>Flat + Free Over Threshold</option>
      <option value="weight" <?php selected( $fields['domestic_type'], 'weight' ); ?>>Weight Brackets</option>
      <option value="item_count" <?php selected( $fields['domestic_type'], 'item_count' ); ?>>Item Count</option>
      <option value="pickup_only" <?php selected( $fields['domestic_type'], 'pickup_only' ); ?>>Pickup Only</option>
    </select>
  </label></p>

  <div class="qship-grid">
    <p><label>Flat Rate <input type="number" step="0.01" name="flat_rate" value="<?php echo esc_attr( $fields['flat_rate'] ); ?>"></label></p>
    <p><label>Free Shipping Threshold <input type="number" step="0.01" name="free_threshold" value="<?php echo esc_attr( $fields['free_threshold'] ); ?>"></label></p>
  </div>

  <h3>Weight Brackets (used when Weight selected)</h3>
  <?php foreach ( $fields['weight_brackets'] as $idx => $br ) : ?>
    <div class="qship-grid">
      <p><label>Max Weight #<?php echo esc_html( $idx + 1 ); ?> <input type="number" step="0.01" name="weight_brackets[<?php echo esc_attr( $idx ); ?>][max]" value="<?php echo esc_attr( $br['max'] ); ?>"></label></p>
      <p><label>Rate #<?php echo esc_html( $idx + 1 ); ?> <input type="number" step="0.01" name="weight_brackets[<?php echo esc_attr( $idx ); ?>][rate]" value="<?php echo esc_attr( $br['rate'] ); ?>"></label></p>
    </div>
  <?php endforeach; ?>
</form>
