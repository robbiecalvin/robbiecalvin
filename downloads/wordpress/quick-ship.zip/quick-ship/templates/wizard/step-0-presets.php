<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<form id="qship-form">
  <input type="hidden" name="step" value="0">

  <div class="qship-panel">
    <h2>Choose a setup style</h2>
    <label><input type="radio" name="setup_style" value="smart" <?php checked( $state['setup_style'] ?? 'smart', 'smart' ); ?>> Smart Presets (recommended)</label>
    <label><input type="radio" name="setup_style" value="manual" <?php checked( $state['setup_style'] ?? '', 'manual' ); ?>> Manual Setup</label>
  </div>

  <div class="qship-panel">
    <h3>Detected Store Summary</h3>
    <ul>
      <li><strong>Base:</strong> <?php echo esc_html( $ctx['base_country'] . ' ' . $ctx['base_state'] ); ?></li>
      <li><strong>Currency:</strong> <?php echo esc_html( $ctx['currency'] ); ?></li>
      <li><strong>Shipping zones:</strong> <?php echo esc_html( $ctx['existing_zone_count'] ); ?></li>
      <li><strong>Physical products detected:</strong> <?php echo ! empty( $ctx['physical_products'] ) ? 'Yes' : 'No'; ?></li>
      <li><strong>Weight usage:</strong> <?php echo esc_html( ucfirst( $ctx['weight_usage'] ) ); ?></li>
    </ul>
  </div>

  <div class="qship-preset-grid">
    <?php foreach ( $presets as $preset ) : ?>
      <div class="qship-preset-card <?php echo ! empty( $preset['premium'] ) && ! qship_is_premium() ? 'locked' : ''; ?>">
        <h4><?php echo esc_html( $preset['label'] ); ?></h4>
        <p><?php echo esc_html( $preset['description'] ); ?></p>
        <ul>
          <?php foreach ( (array) $preset['bullets'] as $bullet ) : ?>
            <li><?php echo esc_html( $bullet ); ?></li>
          <?php endforeach; ?>
        </ul>
        <?php if ( ! empty( $preset['premium'] ) && ! qship_is_premium() ) : ?>
          <p><em>Premium only</em></p>
        <?php else : ?>
          <label><input type="radio" name="preset_id" value="<?php echo esc_attr( $preset['id'] ); ?>" <?php checked( $state['preset_id'] ?? '', $preset['id'] ); ?>> Use This Preset</label>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <p><button type="button" class="button" id="qship-customize-preset">Customize</button></p>
</form>
