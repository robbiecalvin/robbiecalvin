<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<form id="qship-form">
  <input type="hidden" name="step" value="6">
  <h2>Step 6 - Review & Generate</h2>

  <p><label><input type="checkbox" name="confirm_apply" value="1"> Apply recommended settings and generate rules</label></p>

  <?php $existing_count = (new QSHIP_Rules())->count_rules(); ?>
  <?php if ( $existing_count > 0 ) : ?>
    <div class="qship-panel qship-warning">
      <h3>Existing Quick Ship Rules Detected (<?php echo esc_html( $existing_count ); ?>)</h3>
      <p>Choose how to handle existing Quick Ship rules:</p>
      <label><input type="radio" name="overwrite_mode" value="append" checked> Append new Quick Ship rules</label>
      <label><input type="radio" name="overwrite_mode" value="overwrite"> Overwrite Quick Ship rules only</label>
      <p>WooCommerce native shipping methods are never deleted.</p>
      <p><label><input type="checkbox" name="confirm_existing" value="1"> I confirm this apply action.</label></p>
    </div>
  <?php else : ?>
    <input type="hidden" name="overwrite_mode" value="append">
    <input type="hidden" name="confirm_existing" value="1">
  <?php endif; ?>

  <h3>Rule Preview</h3>
  <table class="widefat striped">
    <thead><tr><th>Priority</th><th>Name</th><th>Method</th><th>Amount</th><th>Conditions</th></tr></thead>
    <tbody>
      <?php if ( empty( $preview_rules ) ) : ?>
        <tr><td colspan="5">No preview rules yet. Continue through previous steps first.</td></tr>
      <?php else : ?>
        <?php foreach ( $preview_rules as $rule ) : ?>
          <tr>
            <td><?php echo esc_html( $rule['priority'] ); ?></td>
            <td><?php echo esc_html( $rule['name'] ); ?></td>
            <td><?php echo esc_html( $rule['method_type'] ); ?></td>
            <td><?php echo esc_html( wc_price( (float) $rule['amount'] ) ); ?></td>
            <td><code><?php echo esc_html( wp_json_encode( $rule['conditions'] ) ); ?></code></td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</form>
