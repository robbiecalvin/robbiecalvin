<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<form id="qship-form">
  <input type="hidden" name="step" value="4">
  <h2>Step 4 - Pickup / Local Delivery</h2>
  <p><label><input type="checkbox" name="pickup_enabled" value="1" <?php checked( ! empty( $fields['pickup_enabled'] ) ); ?>> Enable pickup option</label></p>
  <p><label>Pickup Label <input type="text" name="pickup_label" value="<?php echo esc_attr( $fields['pickup_label'] ); ?>"></label></p>

  <div class="qship-panel">
    <h3>Premium Local Delivery Presets</h3>
    <?php if ( qship_is_premium() ) : ?>
      <p>Distance-based local delivery can be configured from premium rule builder.</p>
    <?php else : ?>
      <p><em>Upgrade required for distance radius pricing and remote area surcharges.</em></p>
    <?php endif; ?>
  </div>
</form>
