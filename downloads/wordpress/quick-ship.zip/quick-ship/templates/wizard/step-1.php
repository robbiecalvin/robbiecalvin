<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<form id="qship-form">
  <input type="hidden" name="step" value="1">
  <h2>Step 1 - Store Base Configuration</h2>
  <div class="qship-grid">
    <p><label>Base Country <input type="text" name="base_country" value="<?php echo esc_attr( $fields['base_country'] ); ?>"></label></p>
    <p><label>Base State <input type="text" name="base_state" value="<?php echo esc_attr( $fields['base_state'] ); ?>"></label></p>
    <p><label>Postcode <input type="text" name="base_postcode" value="<?php echo esc_attr( $fields['base_postcode'] ); ?>"></label></p>
    <p><label>City <input type="text" name="base_city" value="<?php echo esc_attr( $fields['base_city'] ); ?>"></label></p>
  </div>
  <p><label>Shipping Scope
    <select name="shipping_scope">
      <option value="domestic" <?php selected( $fields['shipping_scope'], 'domestic' ); ?>>Domestic</option>
      <option value="domestic_intl" <?php selected( $fields['shipping_scope'], 'domestic_intl' ); ?>>Domestic + International</option>
      <option value="pickup_only" <?php selected( $fields['shipping_scope'], 'pickup_only' ); ?>>Pickup Only</option>
    </select>
  </label></p>
</form>
