<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QSHIP_Wizard {
    public function hooks() {
        add_action( 'admin_post_qship_wizard_save', array( $this, 'handle_save_step' ) );
        add_action( 'admin_post_qship_wizard_apply', array( $this, 'handle_apply' ) );
        add_action( 'admin_post_qship_wizard_reset', array( $this, 'handle_reset' ) );
    }

    public function get_state() {
        $base = wc_get_base_location();

        $defaults = array(
            'country'               => strtoupper( (string) ( $base['country'] ?? 'US' ) ),
            'domestic_enabled'      => 1,
            'international_enabled' => 0,
            'flat_rate'             => '9.99',
            'free_threshold'        => '',
            'local_pickup'          => 0,
        );

        $saved = qship_get_wizard_state();
        $saved = isset( $saved['fields'] ) && is_array( $saved['fields'] ) ? $saved['fields'] : array();

        return wp_parse_args( $saved, $defaults );
    }

    public function handle_save_step() {
        $this->assert_permissions();

        check_admin_referer( 'qship_wizard_save_step', 'qship_wizard_nonce' );

        $step   = isset( $_POST['step'] ) ? absint( $_POST['step'] ) : 1;
        $fields = $this->get_state();

        if ( 1 === $step ) {
            $fields['country']               = strtoupper( sanitize_text_field( wp_unslash( $_POST['country'] ?? 'US' ) ) );
            $fields['domestic_enabled']      = empty( $_POST['domestic_enabled'] ) ? 0 : 1;
            $fields['international_enabled'] = empty( $_POST['international_enabled'] ) ? 0 : 1;
        }

        if ( 2 === $step ) {
            $fields['flat_rate']      = wc_format_decimal( wp_unslash( $_POST['flat_rate'] ?? '0' ) );
            $fields['free_threshold'] = wc_format_decimal( wp_unslash( $_POST['free_threshold'] ?? '' ) );
            $fields['local_pickup']   = empty( $_POST['local_pickup'] ) ? 0 : 1;
        }

        qship_save_wizard_state(
            array(
                'fields'       => $fields,
                'current_step' => min( 3, $step + 1 ),
            )
        );

        wp_safe_redirect( admin_url( 'admin.php?page=quick-ship-wizard&step=' . min( 3, $step + 1 ) ) );
        exit;
    }

    public function handle_apply() {
        $this->assert_permissions();

        check_admin_referer( 'qship_wizard_apply', 'qship_wizard_nonce' );

        $fields = $this->get_state();
        $result = $this->apply_shipping_configuration( $fields );

        set_transient(
            'qship_flash_' . get_current_user_id(),
            array(
                'messages' => $result['messages'],
                'errors'   => $result['errors'],
            ),
            MINUTE_IN_SECONDS
        );

        if ( empty( $result['errors'] ) ) {
            update_option( 'quick_ship_wizard_completed', 1, false );
            update_option( 'quick_ship_wizard_needs_run', 0, false );
        }

        wp_safe_redirect( admin_url( 'admin.php?page=quick-ship-wizard&step=3' ) );
        exit;
    }

    public function handle_reset() {
        $this->assert_permissions();

        check_admin_referer( 'qship_wizard_reset', 'qship_wizard_nonce' );

        delete_option( 'quick_ship_wizard_state' );
        update_option( 'quick_ship_wizard_completed', 0, false );

        set_transient(
            'qship_flash_' . get_current_user_id(),
            array(
                'messages' => array( __( 'Wizard reset complete.', 'quick-ship' ) ),
                'errors'   => array(),
            ),
            MINUTE_IN_SECONDS
        );

        wp_safe_redirect( admin_url( 'admin.php?page=quick-ship-wizard&step=1' ) );
        exit;
    }

    public function apply_shipping_configuration( array $fields ): array {
        $messages = array();
        $errors   = array();

        if ( empty( $fields['domestic_enabled'] ) && empty( $fields['international_enabled'] ) ) {
            $errors[] = __( 'Enable at least one shipping scope (domestic or international).', 'quick-ship' );
            return array( 'messages' => $messages, 'errors' => $errors );
        }

        $flat_rate      = max( 0, (float) $fields['flat_rate'] );
        $free_threshold = (string) $fields['free_threshold'];
        $country        = sanitize_text_field( (string) $fields['country'] );

        if ( ! empty( $fields['domestic_enabled'] ) ) {
            $domestic_zone = $this->upsert_zone(
                'Quick Ship Domestic',
                array(
                    array(
                        'code' => $country,
                        'type' => 'country',
                    ),
                )
            );

            if ( is_wp_error( $domestic_zone ) ) {
                $errors[] = $domestic_zone->get_error_message();
            } else {
                $this->upsert_shipping_methods( $domestic_zone, $flat_rate, $free_threshold, ! empty( $fields['local_pickup'] ) );
                $messages[] = __( 'Domestic shipping zone updated.', 'quick-ship' );
            }
        }

        if ( ! empty( $fields['international_enabled'] ) ) {
            $international_zone = $this->upsert_zone(
                'Quick Ship International',
                array(
                    array( 'code' => 'AF', 'type' => 'continent' ),
                    array( 'code' => 'AN', 'type' => 'continent' ),
                    array( 'code' => 'AS', 'type' => 'continent' ),
                    array( 'code' => 'EU', 'type' => 'continent' ),
                    array( 'code' => 'NA', 'type' => 'continent' ),
                    array( 'code' => 'OC', 'type' => 'continent' ),
                    array( 'code' => 'SA', 'type' => 'continent' ),
                )
            );

            if ( is_wp_error( $international_zone ) ) {
                $errors[] = $international_zone->get_error_message();
            } else {
                $this->upsert_shipping_methods( $international_zone, $flat_rate, $free_threshold, false );
                $messages[] = __( 'International shipping zone updated.', 'quick-ship' );
            }
        }

        return array( 'messages' => $messages, 'errors' => $errors );
    }

    private function upsert_zone( string $zone_name, array $locations ) {
        $zone_id = 0;
        $zones   = WC_Shipping_Zones::get_zones();

        foreach ( $zones as $z ) {
            if ( isset( $z['zone_name'] ) && $zone_name === $z['zone_name'] ) {
                $zone_id = (int) $z['zone_id'];
                break;
            }
        }

        $zone = new WC_Shipping_Zone( $zone_id );
        $zone->set_zone_name( $zone_name );
        $zone->set_zone_locations( $locations );

        $saved_zone_id = $zone->save();
        if ( ! $saved_zone_id ) {
            return new WP_Error( 'qship_zone_save', sprintf( __( 'Could not save zone: %s', 'quick-ship' ), $zone_name ) );
        }

        return new WC_Shipping_Zone( (int) $saved_zone_id );
    }

    private function upsert_shipping_methods( WC_Shipping_Zone $zone, float $flat_rate, string $free_threshold, bool $local_pickup ): void {
        $flat_instance = $this->find_or_add_method_instance( $zone, 'flat_rate' );
        if ( $flat_instance > 0 ) {
            $settings = get_option( 'woocommerce_flat_rate_' . $flat_instance . '_settings', array() );
            $settings['title']   = 'Flat Rate';
            $settings['cost']    = wc_format_decimal( $flat_rate );
            $settings['tax_status'] = 'taxable';
            $settings['enabled'] = 'yes';
            update_option( 'woocommerce_flat_rate_' . $flat_instance . '_settings', $settings, false );
        }

        if ( '' !== $free_threshold && (float) $free_threshold > 0 ) {
            $free_instance = $this->find_or_add_method_instance( $zone, 'free_shipping' );
            if ( $free_instance > 0 ) {
                $settings = get_option( 'woocommerce_free_shipping_' . $free_instance . '_settings', array() );
                $settings['title']      = 'Free Shipping';
                $settings['requires']   = 'min_amount';
                $settings['min_amount'] = wc_format_decimal( $free_threshold );
                $settings['enabled']    = 'yes';
                update_option( 'woocommerce_free_shipping_' . $free_instance . '_settings', $settings, false );
            }
        }

        if ( $local_pickup ) {
            $pickup_instance = $this->find_or_add_method_instance( $zone, 'local_pickup' );
            if ( $pickup_instance > 0 ) {
                $settings = get_option( 'woocommerce_local_pickup_' . $pickup_instance . '_settings', array() );
                $settings['title']      = 'Local Pickup';
                $settings['tax_status'] = 'none';
                $settings['cost']       = '0';
                $settings['enabled']    = 'yes';
                update_option( 'woocommerce_local_pickup_' . $pickup_instance . '_settings', $settings, false );
            }
        }
    }

    private function find_or_add_method_instance( WC_Shipping_Zone $zone, string $method_id ): int {
        $methods = $zone->get_shipping_methods( true );
        foreach ( $methods as $method ) {
            if ( isset( $method->id ) && $method_id === $method->id ) {
                return (int) $method->instance_id;
            }
        }

        $new_id = $zone->add_shipping_method( $method_id );
        return absint( $new_id );
    }

    private function assert_permissions(): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-ship' ) );
        }
    }
}
