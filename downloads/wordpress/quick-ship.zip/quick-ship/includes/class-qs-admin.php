<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QSHIP_Admin {
    private $wizard;

    public function __construct( QSHIP_Wizard $wizard ) {
        $this->wizard = $wizard;
    }

    public function hooks() {
        add_action( 'admin_menu', array( $this, 'menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
    }

    public function menu() {
        add_submenu_page(
            'quickwoo',
            __( 'Quick Ship', 'quick-ship' ),
            __( 'Quick Ship', 'quick-ship' ),
            'manage_woocommerce',
            'quick-ship',
            array( $this, 'render_overview_page' )
        );

        add_menu_page(
            __( 'Quick Ship', 'quick-ship' ),
            __( 'Quick Ship', 'quick-ship' ),
            'manage_woocommerce',
            'quick-ship',
            array( $this, 'render_overview_page' ),
            'dashicons-location-alt',
            63
        );

        add_submenu_page(
            'quick-ship',
            __( 'Quick Ship Overview', 'quick-ship' ),
            __( 'Overview', 'quick-ship' ),
            'manage_woocommerce',
            'quick-ship',
            array( $this, 'render_overview_page' )
        );

        add_submenu_page(
            'quick-ship',
            __( 'Shipping Wizard', 'quick-ship' ),
            __( 'Setup Wizard', 'quick-ship' ),
            'manage_woocommerce',
            'quick-ship-wizard',
            array( $this, 'render_wizard_page' )
        );
    }

    public function enqueue( $hook ) {
        if ( false === strpos( (string) $hook, 'quick-ship' ) ) {
            return;
        }

        wp_enqueue_style( 'qship-wizard', QSHIP_URL . 'assets/css/wizard.css', array(), QSHIP_VERSION );
    }

    public function render_overview_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Not allowed', 'quick-ship' ) );
        }

        $zones = WC_Shipping_Zones::get_zones();

        echo '<div class="wrap qship-wizard-wrap">';
        echo '<h1>' . esc_html__( 'Quick Ship', 'quick-ship' ) . '</h1>';
        echo '<p>' . esc_html__( 'Use the setup wizard to configure domestic and international shipping with flat rate, free shipping, and local pickup.', 'quick-ship' ) . '</p>';
        echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=quick-ship-wizard&step=1' ) ) . '">' . esc_html__( 'Run Setup Wizard', 'quick-ship' ) . '</a></p>';

        echo '<h2>' . esc_html__( 'Existing Shipping Zones', 'quick-ship' ) . '</h2>';
        echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Zone', 'quick-ship' ) . '</th><th>' . esc_html__( 'Methods', 'quick-ship' ) . '</th></tr></thead><tbody>';

        if ( empty( $zones ) ) {
            echo '<tr><td colspan="2">' . esc_html__( 'No shipping zones found yet.', 'quick-ship' ) . '</td></tr>';
        } else {
            foreach ( $zones as $zone ) {
                $methods = array();
                if ( ! empty( $zone['shipping_methods'] ) && is_array( $zone['shipping_methods'] ) ) {
                    foreach ( $zone['shipping_methods'] as $method ) {
                        $methods[] = isset( $method->method_title ) ? (string) $method->method_title : (string) $method->id;
                    }
                }
                echo '<tr>';
                echo '<td>' . esc_html( (string) $zone['zone_name'] ) . '</td>';
                echo '<td>' . esc_html( implode( ', ', $methods ) ) . '</td>';
                echo '</tr>';
            }
        }

        echo '</tbody></table>';
        echo '</div>';
    }

    public function render_wizard_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'Not allowed', 'quick-ship' ) );
        }

        $step   = isset( $_GET['step'] ) ? max( 1, min( 3, absint( $_GET['step'] ) ) ) : 1;
        $fields = $this->wizard->get_state();
        $flash  = get_transient( 'qship_flash_' . get_current_user_id() );

        if ( is_array( $flash ) ) {
            delete_transient( 'qship_flash_' . get_current_user_id() );
        } else {
            $flash = array( 'messages' => array(), 'errors' => array() );
        }

        echo '<div class="wrap qship-wizard-wrap">';
        echo '<h1>' . esc_html__( 'Quick Ship Setup Wizard', 'quick-ship' ) . '</h1>';

        foreach ( (array) $flash['errors'] as $error ) {
            echo '<div class="notice notice-error"><p>' . esc_html( (string) $error ) . '</p></div>';
        }
        foreach ( (array) $flash['messages'] as $message ) {
            echo '<div class="notice notice-success"><p>' . esc_html( (string) $message ) . '</p></div>';
        }

        echo '<ol class="qship-steps">';
        echo '<li class="' . esc_attr( 1 === $step ? 'current' : ( $step > 1 ? 'done' : '' ) ) . '"><span>' . esc_html__( 'Store Scope', 'quick-ship' ) . '</span></li>';
        echo '<li class="' . esc_attr( 2 === $step ? 'current' : ( $step > 2 ? 'done' : '' ) ) . '"><span>' . esc_html__( 'Rates & Pickup', 'quick-ship' ) . '</span></li>';
        echo '<li class="' . esc_attr( 3 === $step ? 'current' : '' ) . '"><span>' . esc_html__( 'Review & Apply', 'quick-ship' ) . '</span></li>';
        echo '</ol>';

        if ( 1 === $step ) {
            $this->render_step_one( $fields );
        } elseif ( 2 === $step ) {
            $this->render_step_two( $fields );
        } else {
            $this->render_step_three( $fields );
        }

        echo '</div>';
    }

    private function render_step_one( array $fields ) {
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="qship-panel">';
        wp_nonce_field( 'qship_wizard_save_step', 'qship_wizard_nonce' );
        echo '<input type="hidden" name="action" value="qship_wizard_save" />';
        echo '<input type="hidden" name="step" value="1" />';

        echo '<h2>' . esc_html__( 'Step 1: Shipping Scope', 'quick-ship' ) . '</h2>';
        echo '<p>' . esc_html__( 'Set your base country and select whether domestic and international shipping should be configured.', 'quick-ship' ) . '</p>';

        echo '<table class="form-table">';
        echo '<tr><th><label for="country">' . esc_html__( 'Store Country', 'quick-ship' ) . '</label></th><td><input id="country" type="text" name="country" value="' . esc_attr( (string) $fields['country'] ) . '" class="regular-text" required /></td></tr>';
        echo '<tr><th>' . esc_html__( 'Domestic Shipping', 'quick-ship' ) . '</th><td><label><input type="checkbox" name="domestic_enabled" value="1" ' . checked( ! empty( $fields['domestic_enabled'] ), true, false ) . ' /> ' . esc_html__( 'Enable', 'quick-ship' ) . '</label></td></tr>';
        echo '<tr><th>' . esc_html__( 'International Shipping', 'quick-ship' ) . '</th><td><label><input type="checkbox" name="international_enabled" value="1" ' . checked( ! empty( $fields['international_enabled'] ), true, false ) . ' /> ' . esc_html__( 'Enable', 'quick-ship' ) . '</label></td></tr>';
        echo '</table>';

        echo '<p><button type="submit" class="button button-primary">' . esc_html__( 'Continue', 'quick-ship' ) . '</button></p>';
        echo '</form>';
    }

    private function render_step_two( array $fields ) {
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="qship-panel">';
        wp_nonce_field( 'qship_wizard_save_step', 'qship_wizard_nonce' );
        echo '<input type="hidden" name="action" value="qship_wizard_save" />';
        echo '<input type="hidden" name="step" value="2" />';

        echo '<h2>' . esc_html__( 'Step 2: Rates and Pickup', 'quick-ship' ) . '</h2>';
        echo '<table class="form-table">';
        echo '<tr><th><label for="flat_rate">' . esc_html__( 'Flat Rate Price', 'quick-ship' ) . '</label></th><td><input id="flat_rate" type="number" min="0" step="0.01" name="flat_rate" value="' . esc_attr( (string) $fields['flat_rate'] ) . '" /></td></tr>';
        echo '<tr><th><label for="free_threshold">' . esc_html__( 'Free Shipping Threshold', 'quick-ship' ) . '</label></th><td><input id="free_threshold" type="number" min="0" step="0.01" name="free_threshold" value="' . esc_attr( (string) $fields['free_threshold'] ) . '" /> <p class="description">' . esc_html__( 'Leave empty to disable free shipping.', 'quick-ship' ) . '</p></td></tr>';
        echo '<tr><th>' . esc_html__( 'Local Pickup', 'quick-ship' ) . '</th><td><label><input type="checkbox" name="local_pickup" value="1" ' . checked( ! empty( $fields['local_pickup'] ), true, false ) . ' /> ' . esc_html__( 'Enable local pickup', 'quick-ship' ) . '</label></td></tr>';
        echo '</table>';

        echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=quick-ship-wizard&step=1' ) ) . '">' . esc_html__( 'Back', 'quick-ship' ) . '</a> <button type="submit" class="button button-primary">' . esc_html__( 'Continue', 'quick-ship' ) . '</button></p>';
        echo '</form>';
    }

    private function render_step_three( array $fields ) {
        echo '<div class="qship-panel">';
        echo '<h2>' . esc_html__( 'Step 3: Review and Apply', 'quick-ship' ) . '</h2>';
        echo '<ul>';
        echo '<li><strong>' . esc_html__( 'Country:', 'quick-ship' ) . '</strong> ' . esc_html( (string) $fields['country'] ) . '</li>';
        echo '<li><strong>' . esc_html__( 'Domestic:', 'quick-ship' ) . '</strong> ' . esc_html( ! empty( $fields['domestic_enabled'] ) ? __( 'Enabled', 'quick-ship' ) : __( 'Disabled', 'quick-ship' ) ) . '</li>';
        echo '<li><strong>' . esc_html__( 'International:', 'quick-ship' ) . '</strong> ' . esc_html( ! empty( $fields['international_enabled'] ) ? __( 'Enabled', 'quick-ship' ) : __( 'Disabled', 'quick-ship' ) ) . '</li>';
        echo '<li><strong>' . esc_html__( 'Flat Rate:', 'quick-ship' ) . '</strong> ' . wp_kses_post( wc_price( (float) $fields['flat_rate'] ) ) . '</li>';
        echo '<li><strong>' . esc_html__( 'Free Shipping Threshold:', 'quick-ship' ) . '</strong> ' . ( '' !== (string) $fields['free_threshold'] ? wp_kses_post( wc_price( (float) $fields['free_threshold'] ) ) : esc_html__( 'Disabled', 'quick-ship' ) ) . '</li>';
        echo '<li><strong>' . esc_html__( 'Local Pickup:', 'quick-ship' ) . '</strong> ' . esc_html( ! empty( $fields['local_pickup'] ) ? __( 'Enabled', 'quick-ship' ) : __( 'Disabled', 'quick-ship' ) ) . '</li>';
        echo '</ul>';

        echo '<div class="qship-wizard-actions">';
        echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=quick-ship-wizard&step=2' ) ) . '">' . esc_html__( 'Back', 'quick-ship' ) . '</a>';

        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block; margin-left:10px;">';
        wp_nonce_field( 'qship_wizard_apply', 'qship_wizard_nonce' );
        echo '<input type="hidden" name="action" value="qship_wizard_apply" />';
        echo '<button type="submit" class="button button-primary">' . esc_html__( 'Apply Shipping Setup', 'quick-ship' ) . '</button>';
        echo '</form>';

        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block; margin-left:10px;">';
        wp_nonce_field( 'qship_wizard_reset', 'qship_wizard_nonce' );
        echo '<input type="hidden" name="action" value="qship_wizard_reset" />';
        echo '<button type="submit" class="button">' . esc_html__( 'Reset Wizard', 'quick-ship' ) . '</button>';
        echo '</form>';

        echo '</div>';
        echo '</div>';
    }
}
