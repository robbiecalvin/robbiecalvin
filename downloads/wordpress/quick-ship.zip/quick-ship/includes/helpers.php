<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function qship_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'quick_ship_rules';
}

function qship_default_settings() {
    return array(
        'matching_mode'       => 'first_match',
        'fallback_rate'       => '0',
        'taxable'             => 0,
        'hide_other_methods'  => 0,
        'wizard_completed'    => 0,
    );
}

function qship_get_settings() {
    $saved = get_option( 'quick_ship_settings', array() );
    if ( ! is_array( $saved ) ) {
        $saved = array();
    }
    return wp_parse_args( $saved, qship_default_settings() );
}

function qship_update_settings( $settings ) {
    $current = qship_get_settings();
    $new     = wp_parse_args( is_array( $settings ) ? $settings : array(), $current );

    $new['matching_mode']      = ( 'stack' === ( $new['matching_mode'] ?? '' ) ) ? 'stack' : 'first_match';
    $new['fallback_rate']      = wc_format_decimal( $new['fallback_rate'] ?? '0' );
    $new['taxable']            = empty( $new['taxable'] ) ? 0 : 1;
    $new['hide_other_methods'] = empty( $new['hide_other_methods'] ) ? 0 : 1;

    update_option( 'quick_ship_settings', $new );
    return $new;
}

function qship_is_premium() {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

    return (bool) apply_filters( 'quick_ship_is_premium', false );
}

function qship_is_admin_request() {
    return is_admin() && current_user_can( 'manage_woocommerce' );
}

function qship_get_wizard_state() {
    $state = get_option( 'quick_ship_wizard_state', array() );
    return is_array( $state ) ? $state : array();
}

function qship_save_wizard_state( $state ) {
    $state = is_array( $state ) ? $state : array();
    update_option( 'quick_ship_wizard_state', $state, false );
}

function qship_csv_to_array( $value ) {
    $parts = array_map( 'trim', explode( ',', (string) $value ) );
    return array_values( array_filter( $parts, static function( $v ) { return '' !== $v; } ) );
}
