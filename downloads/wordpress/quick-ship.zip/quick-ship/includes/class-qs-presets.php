<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QSHIP_Presets {
    private $rules;

    public function __construct( QSHIP_Rules $rules ) {
        $this->rules = $rules;
    }

    public function detect_store_context() {
        $base = wc_get_base_location();
        $currency = get_woocommerce_currency();

        $zone_count = 0;
        $methods_count = 0;
        $pickup_enabled = false;

        $zones = WC_Shipping_Zones::get_zones();
        $zone_count = count( $zones );

        foreach ( $zones as $zone ) {
            if ( empty( $zone['shipping_methods'] ) ) {
                continue;
            }

            foreach ( $zone['shipping_methods'] as $method ) {
                $methods_count++;
                if ( 'local_pickup' === $method->id && 'yes' === $method->enabled ) {
                    $pickup_enabled = true;
                }
            }
        }

        $product_ids = wc_get_products(
            array(
                'limit'  => 250,
                'status' => 'publish',
                'return' => 'ids',
            )
        );

        $physical = 0;
        $virtual = 0;
        $weight_count = 0;
        $price_values = array();

        foreach ( $product_ids as $pid ) {
            $product = wc_get_product( $pid );
            if ( ! $product ) {
                continue;
            }

            if ( $product->is_virtual() || $product->is_downloadable() ) {
                $virtual++;
            } else {
                $physical++;
            }

            if ( '' !== (string) $product->get_weight() ) {
                $weight_count++;
            }

            $price = (float) $product->get_price();
            if ( $price > 0 ) {
                $price_values[] = $price;
            }
        }

        sort( $price_values );
        $median = 30;
        $count = count( $price_values );
        if ( $count > 0 ) {
            $middle = (int) floor( $count / 2 );
            $median = ( $count % 2 ) ? $price_values[ $middle ] : ( ( $price_values[ $middle - 1 ] + $price_values[ $middle ] ) / 2 );
        }

        $weight_usage = 'low';
        if ( $count > 0 ) {
            $ratio = $weight_count / max( 1, $count );
            if ( $ratio >= 0.6 ) {
                $weight_usage = 'high';
            } elseif ( $ratio >= 0.3 ) {
                $weight_usage = 'medium';
            }
        }

        $shipping_classes = get_terms( array( 'taxonomy' => 'product_shipping_class', 'hide_empty' => false ) );
        $has_classes = is_array( $shipping_classes ) && ! is_wp_error( $shipping_classes ) && ! empty( $shipping_classes );

        $checkout_page_id = wc_get_page_id( 'checkout' );
        $cart_page_id = wc_get_page_id( 'cart' );

        return array(
            'locale'               => get_locale(),
            'timezone'             => wp_timezone_string(),
            'currency'             => $currency,
            'base_country'         => strtoupper( (string) ( $base['country'] ?? '' ) ),
            'base_state'           => strtoupper( (string) ( $base['state'] ?? '' ) ),
            'base_postcode'        => get_option( 'woocommerce_store_postcode', '' ),
            'base_city'            => get_option( 'woocommerce_store_city', '' ),
            'store_address_1'      => get_option( 'woocommerce_store_address', '' ),
            'store_address_2'      => get_option( 'woocommerce_store_address_2', '' ),
            'shipping_enabled'     => 'yes' === get_option( 'woocommerce_calc_shipping', 'yes' ),
            'ship_to_setting'      => get_option( 'woocommerce_ship_to_countries', '' ),
            'existing_zone_count'  => $zone_count,
            'existing_methods'     => $methods_count,
            'local_pickup_enabled' => $pickup_enabled,
            'physical_products'    => $physical,
            'virtual_products'     => $virtual,
            'weight_usage'         => $weight_usage,
            'has_shipping_classes' => $has_classes,
            'median_price'         => (float) $median,
            'taxes_enabled'        => wc_tax_enabled(),
            'cart_page_set'        => $cart_page_id > 0,
            'checkout_page_set'    => $checkout_page_id > 0,
            'has_subscriptions'    => class_exists( 'WC_Subscriptions' ),
        );
    }

    public function recommend_presets( $ctx ) {
        $ctx = is_array( $ctx ) ? $ctx : array();

        $median = max( 5, (float) ( $ctx['median_price'] ?? 30 ) );
        $threshold = min( 500, max( 25, round( $median * 3, 2 ) ) );
        $flat = min( 50, max( 4, round( $median * 0.15, 2 ) ) );
        $base_country = $ctx['base_country'] ?? 'US';

        $presets = array();

        $presets[] = array(
            'id' => 'simple_flat_free',
            'label' => 'Simple Domestic Flat Rate + Free Over ' . wc_price( $threshold ),
            'description' => 'Flat domestic shipping plus free shipping threshold and optional pickup.',
            'premium' => false,
            'data' => array(
                'base_country'   => $base_country,
                'shipping_scope' => 'domestic',
                'domestic_type'  => 'flat_plus_free',
                'flat_rate'      => $flat,
                'free_threshold' => $threshold,
                'intl_enabled'   => 0,
                'pickup_enabled' => ! empty( $ctx['local_pickup_enabled'] ) ? 1 : 0,
                'pickup_label'   => 'Local Pickup',
                'taxable'        => ! empty( $ctx['taxes_enabled'] ) ? 1 : 0,
            ),
            'bullets' => array(
                'Creates domestic free-over-threshold rule.',
                'Adds domestic flat rate fallback.',
                'Keeps existing WooCommerce methods intact.',
            ),
        );

        if ( in_array( $ctx['weight_usage'] ?? 'low', array( 'medium', 'high' ), true ) ) {
            $presets[] = array(
                'id' => 'weight_domestic',
                'label' => 'Weight-Based Domestic Brackets',
                'description' => 'Uses three domestic weight brackets (free version) with editable rates.',
                'premium' => false,
                'data' => array(
                    'base_country'    => $base_country,
                    'shipping_scope'  => 'domestic',
                    'domestic_type'   => 'weight',
                    'weight_brackets' => array(
                        array( 'max' => 2, 'rate' => max( 5, round( $flat * 0.8, 2 ) ) ),
                        array( 'max' => 5, 'rate' => max( 8, round( $flat * 1.2, 2 ) ) ),
                        array( 'max' => 99999, 'rate' => max( 12, round( $flat * 1.7, 2 ) ) ),
                    ),
                    'pickup_enabled'  => ! empty( $ctx['local_pickup_enabled'] ) ? 1 : 0,
                    'pickup_label'    => 'Local Pickup',
                    'taxable'         => ! empty( $ctx['taxes_enabled'] ) ? 1 : 0,
                ),
                'bullets' => array(
                    'Creates 3 domestic weight bracket rules.',
                    'Good when most products have weight.',
                    'Editable bracket breakpoints before apply.',
                ),
            );
        }

        if ( ! empty( $ctx['existing_zone_count'] ) || ! empty( $ctx['existing_methods'] ) ) {
            $presets[] = array(
                'id' => 'mirror_existing',
                'label' => 'Mirror Existing Shipping (Safe)',
                'description' => 'Builds Quick Ship equivalents from current Woo methods without deleting native methods.',
                'premium' => false,
                'data' => array(
                    'base_country'   => $base_country,
                    'shipping_scope' => 'domestic',
                    'domestic_type'  => 'flat_plus_free',
                    'flat_rate'      => $flat,
                    'free_threshold' => $threshold,
                    'mirror_rules'   => $this->build_mirror_rules(),
                ),
                'bullets' => array(
                    'Imports equivalent flat/free/pickup logic.',
                    'Assigns priorities by destination specificity.',
                    'Never touches Woo zone methods.',
                ),
            );
        }

        $presets[] = array(
            'id' => 'premium_distance_delivery',
            'label' => 'Distance-Based Local Delivery (Premium)',
            'description' => 'Uses local radius and distance pricing tiers.',
            'premium' => true,
            'data' => array(
                'base_country' => $base_country,
            ),
            'bullets' => array(
                'Requires premium license.',
                'Adds distance and postcode-aware delivery presets.',
            ),
        );

        return $presets;
    }

    public function build_mirror_rules() {
        $rules = array();
        $zones = WC_Shipping_Zones::get_zones();
        $priority = 10;

        foreach ( $zones as $zone ) {
            $locations = isset( $zone['zone_locations'] ) ? $zone['zone_locations'] : array();
            $conditions = $this->location_conditions( $locations );

            if ( empty( $zone['shipping_methods'] ) ) {
                continue;
            }

            foreach ( $zone['shipping_methods'] as $method ) {
                if ( 'yes' !== $method->enabled ) {
                    continue;
                }

                if ( ! in_array( $method->id, array( 'flat_rate', 'free_shipping', 'local_pickup' ), true ) ) {
                    continue;
                }

                $amount = 0;
                if ( 'flat_rate' === $method->id ) {
                    $amount = wc_format_decimal( $method->get_option( 'cost', 0 ) );
                }

                $rule = array(
                    'name'        => sanitize_text_field( $zone['zone_name'] . ' ' . $method->method_title ),
                    'enabled'     => 1,
                    'priority'    => $priority,
                    'method_type' => ( 'local_pickup' === $method->id ) ? 'pickup' : $method->id,
                    'amount'      => (float) $amount,
                    'taxable'     => 0,
                    'conditions'  => $conditions,
                );

                if ( 'free_shipping' === $method->id ) {
                    $min_amount = wc_format_decimal( $method->get_option( 'min_amount', 0 ) );
                    if ( $min_amount > 0 ) {
                        $rule['conditions']['subtotal_gte'] = (float) $min_amount;
                    }
                }

                $rules[] = $rule;
                $priority += 10;
            }
        }

        return $rules;
    }

    private function location_conditions( $locations ) {
        $conditions = array();
        $country = array();
        $state = array();
        $postcode = array();

        foreach ( (array) $locations as $loc ) {
            if ( empty( $loc->type ) || empty( $loc->code ) ) {
                continue;
            }

            if ( 'country' === $loc->type ) {
                $country[] = strtoupper( $loc->code );
            } elseif ( 'state' === $loc->type ) {
                $state[] = strtoupper( $loc->code );
            } elseif ( in_array( $loc->type, array( 'postcode', 'postcodes' ), true ) ) {
                $postcode[] = strtoupper( preg_replace( '/\*+$/', '', $loc->code ) );
            }
        }

        if ( ! empty( $country ) ) {
            $conditions['country_in'] = array_values( array_unique( $country ) );
        }
        if ( ! empty( $state ) ) {
            $conditions['state_in'] = array_values( array_unique( $state ) );
        }
        if ( ! empty( $postcode ) ) {
            $conditions['postcode_prefix'] = array_values( array_unique( $postcode ) );
        }

        return $conditions;
    }
}
