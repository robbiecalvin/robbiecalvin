<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QSHIP_Activator {
    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table = qship_table_name();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            enabled TINYINT(1) NOT NULL DEFAULT 1,
            priority INT NOT NULL DEFAULT 100,
            method_type VARCHAR(40) NOT NULL DEFAULT 'flat_rate',
            amount DECIMAL(12,4) NOT NULL DEFAULT 0,
            taxable TINYINT(1) NOT NULL DEFAULT 0,
            conditions LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY enabled (enabled),
            KEY priority (priority),
            KEY method_type (method_type)
        ) {$charset};";

        dbDelta( $sql );

        if ( false === get_option( 'quick_ship_settings', false ) ) {
            update_option( 'quick_ship_settings', qship_default_settings(), false );
        }

        if ( false === get_option( 'quick_ship_wizard_completed', false ) ) {
            update_option( 'quick_ship_wizard_completed', 0, false );
        }

        update_option( 'quick_ship_wizard_needs_run', 1, false );
    }
}
