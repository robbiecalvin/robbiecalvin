<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QSHIP_WC_Method extends WC_Shipping_Method {
    public static $rules_ref = null;

    public function __construct( $instance_id = 0 ) {
        $this->id                 = 'quick_ship';
        $this->instance_id        = absint( $instance_id );
        $this->method_title       = __( 'Quick Ship', 'quick-ship' );
        $this->method_description = __( 'Rule-based shipping by Quick Ship.', 'quick-ship' );
        $this->supports           = array( 'shipping-zones', 'instance-settings' );
        $this->enabled            = 'yes';
        $this->title              = __( 'Quick Shipping', 'quick-ship' );
    }

    public function calculate_shipping( $package = array() ) {
        if ( ! self::$rules_ref instanceof QSHIP_Rules ) {
            return;
        }

        $settings = qship_get_settings();
        $matched  = self::$rules_ref->evaluate_matching_rules( $package );

        if ( empty( $matched ) ) {
            $fallback = (float) $settings['fallback_rate'];
            if ( $fallback > 0 ) {
                $this->add_rate(
                    array(
                        'id'    => $this->id . '_fallback',
                        'label' => __( 'Shipping', 'quick-ship' ),
                        'cost'  => $fallback,
                    )
                );
            }
            return;
        }

        foreach ( $matched as $rule ) {
            $cost = ( 'free_shipping' === $rule['method_type'] || 'pickup' === $rule['method_type'] ) ? 0 : (float) $rule['amount'];
            $rate_id = $this->id . '_' . $rule['id'];
            $label = $rule['name'];

            if ( 'pickup' === $rule['method_type'] ) {
                $label = $rule['name'] ?: __( 'Local Pickup', 'quick-ship' );
            }

            $this->add_rate(
                array(
                    'id'      => $rate_id,
                    'label'   => $label,
                    'cost'    => $cost,
                    'package' => $package,
                    'taxes'   => ( ! empty( $rule['taxable'] ) || ! empty( $settings['taxable'] ) ) ? '' : false,
                )
            );
        }
    }
}

class QSHIP_Shipping_Method {
    private $rules;

    public function __construct( QSHIP_Rules $rules ) {
        $this->rules = $rules;
    }

    public function hooks() {
        add_filter( 'woocommerce_shipping_methods', array( $this, 'register_method' ) );
        add_filter( 'woocommerce_package_rates', array( $this, 'maybe_hide_other_methods' ), 99, 2 );
    }

    public function register_method( $methods ) {
        QSHIP_WC_Method::$rules_ref = $this->rules;
        $methods['quick_ship'] = 'QSHIP_WC_Method';
        return $methods;
    }

    public function maybe_hide_other_methods( $rates, $package ) {
        $settings = qship_get_settings();
        if ( empty( $settings['hide_other_methods'] ) ) {
            return $rates;
        }

        $filtered = array();
        foreach ( $rates as $key => $rate ) {
            if ( isset( $rate->method_id ) && 'quick_ship' === $rate->method_id ) {
                $filtered[ $key ] = $rate;
            }
        }

        return ! empty( $filtered ) ? $filtered : $rates;
    }
}
