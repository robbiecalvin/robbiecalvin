<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QSHIP_Rules {
    public function get_rules( $enabled_only = true ) {
        global $wpdb;

        $table = qship_table_name();
        if ( $enabled_only ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$table} WHERE enabled = 1 ORDER BY priority ASC, id ASC", ARRAY_A );
        } else {
            $rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY priority ASC, id ASC", ARRAY_A );
        }

        foreach ( $rows as &$row ) {
            $row['conditions'] = json_decode( (string) $row['conditions'], true );
            if ( ! is_array( $row['conditions'] ) ) {
                $row['conditions'] = array();
            }
        }

        return $rows;
    }

    public function count_rules() {
        global $wpdb;
        return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . qship_table_name() );
    }

    public function insert_rules( $rules, $mode = 'append' ) {
        global $wpdb;

        if ( ! in_array( $mode, array( 'append', 'overwrite' ), true ) ) {
            $mode = 'append';
        }

        if ( 'overwrite' === $mode ) {
            $wpdb->query( 'TRUNCATE TABLE ' . qship_table_name() );
        }

        $inserted = 0;
        foreach ( $rules as $rule ) {
            $ok = $wpdb->insert(
                qship_table_name(),
                array(
                    'name'       => sanitize_text_field( $rule['name'] ?? 'Quick Ship Rule' ),
                    'enabled'    => empty( $rule['enabled'] ) ? 0 : 1,
                    'priority'   => isset( $rule['priority'] ) ? (int) $rule['priority'] : 100,
                    'method_type'=> sanitize_key( $rule['method_type'] ?? 'flat_rate' ),
                    'amount'     => wc_format_decimal( $rule['amount'] ?? 0 ),
                    'taxable'    => empty( $rule['taxable'] ) ? 0 : 1,
                    'conditions' => wp_json_encode( $rule['conditions'] ?? array() ),
                    'created_at' => gmdate( 'Y-m-d H:i:s' ),
                    'updated_at' => gmdate( 'Y-m-d H:i:s' ),
                ),
                array( '%s', '%d', '%d', '%s', '%f', '%d', '%s', '%s', '%s' )
            );
            if ( false !== $ok ) {
                $inserted++;
            }
        }

        return $inserted;
    }

    public function generate_rules_from_wizard( $data ) {
        $data = is_array( $data ) ? $data : array();

        $base_country = sanitize_text_field( $data['base_country'] ?? wc_get_base_location()['country'] ?? '' );
        $shipping_type = sanitize_key( $data['domestic_type'] ?? 'flat_plus_free' );
        $free_threshold = wc_format_decimal( $data['free_threshold'] ?? 0 );
        $flat_rate = wc_format_decimal( $data['flat_rate'] ?? 0 );
        $priority = 10;

        $rules = array();

        if ( 'mirror_existing' === ( $data['preset_id'] ?? '' ) && ! empty( $data['mirror_rules'] ) && is_array( $data['mirror_rules'] ) ) {
            foreach ( $data['mirror_rules'] as $mirror_rule ) {
                $mirror_rule['priority'] = $priority;
                $priority += 10;
                $rules[] = $mirror_rule;
            }
            return $rules;
        }

        if ( in_array( $shipping_type, array( 'flat_plus_free', 'free_threshold' ), true ) && $free_threshold > 0 ) {
            $rules[] = array(
                'name'        => 'Domestic Free Shipping',
                'enabled'     => 1,
                'priority'    => $priority,
                'method_type' => 'free_shipping',
                'amount'      => 0,
                'taxable'     => 0,
                'conditions'  => array(
                    'country_in' => array( $base_country ),
                    'subtotal_gte' => (float) $free_threshold,
                ),
            );
            $priority += 10;
        }

        if ( 'weight' === $shipping_type ) {
            $brackets = isset( $data['weight_brackets'] ) && is_array( $data['weight_brackets'] ) ? $data['weight_brackets'] : array();
            if ( empty( $brackets ) ) {
                $brackets = array(
                    array( 'max' => 2, 'rate' => 8 ),
                    array( 'max' => 5, 'rate' => 12 ),
                    array( 'max' => 99999, 'rate' => 18 ),
                );
            }

            foreach ( $brackets as $i => $b ) {
                $max = isset( $b['max'] ) ? (float) $b['max'] : 99999;
                $rate = isset( $b['rate'] ) ? (float) $b['rate'] : 0;
                $rules[] = array(
                    'name'        => 'Domestic Weight Bracket ' . ( $i + 1 ),
                    'enabled'     => 1,
                    'priority'    => $priority,
                    'method_type' => 'flat_rate',
                    'amount'      => $rate,
                    'taxable'     => ! empty( $data['taxable'] ),
                    'conditions'  => array(
                        'country_in'  => array( $base_country ),
                        'weight_lte'  => $max,
                    ),
                );
                $priority += 10;
            }
        } elseif ( 'pickup_only' === $shipping_type ) {
            $rules[] = array(
                'name'        => sanitize_text_field( $data['pickup_label'] ?? 'Local Pickup' ),
                'enabled'     => 1,
                'priority'    => $priority,
                'method_type' => 'pickup',
                'amount'      => 0,
                'taxable'     => 0,
                'conditions'  => array(
                    'country_in' => array( $base_country ),
                ),
            );
            $priority += 10;
        } else {
            $rules[] = array(
                'name'        => 'Domestic Flat Rate',
                'enabled'     => 1,
                'priority'    => $priority,
                'method_type' => 'flat_rate',
                'amount'      => (float) $flat_rate,
                'taxable'     => ! empty( $data['taxable'] ),
                'conditions'  => array(
                    'country_in' => array( $base_country ),
                ),
            );
            $priority += 10;
        }

        if ( ! empty( $data['intl_enabled'] ) ) {
            $intl_rate = wc_format_decimal( $data['intl_flat_rate'] ?? 20 );
            $rules[] = array(
                'name'        => 'International Flat Rate',
                'enabled'     => 1,
                'priority'    => $priority,
                'method_type' => 'flat_rate',
                'amount'      => (float) $intl_rate,
                'taxable'     => ! empty( $data['taxable'] ),
                'conditions'  => array(
                    'country_not_in' => array( $base_country ),
                ),
            );
        }

        if ( ! empty( $data['pickup_enabled'] ) && 'pickup_only' !== $shipping_type ) {
            $rules[] = array(
                'name'        => sanitize_text_field( $data['pickup_label'] ?? 'Local Pickup' ),
                'enabled'     => 1,
                'priority'    => 999,
                'method_type' => 'pickup',
                'amount'      => 0,
                'taxable'     => 0,
                'conditions'  => array(
                    'country_in' => array( $base_country ),
                ),
            );
        }

        return $rules;
    }

    public function evaluate_matching_rules( $package ) {
        $settings = qship_get_settings();
        $rules = $this->get_rules( true );
        $matches = array();

        foreach ( $rules as $rule ) {
            if ( $this->rule_matches( $rule, $package ) ) {
                $matches[] = $rule;
                if ( 'first_match' === $settings['matching_mode'] ) {
                    break;
                }
            }
        }

        return $matches;
    }

    private function rule_matches( $rule, $package ) {
        $conditions = is_array( $rule['conditions'] ) ? $rule['conditions'] : array();
        $dest = $package['destination'] ?? array();
        $country = strtoupper( sanitize_text_field( $dest['country'] ?? '' ) );
        $state = strtoupper( sanitize_text_field( $dest['state'] ?? '' ) );
        $postcode = strtoupper( sanitize_text_field( $dest['postcode'] ?? '' ) );

        $subtotal = (float) ( $package['contents_cost'] ?? 0 );
        $weight = 0.0;
        $item_count = 0;

        if ( ! empty( $package['contents'] ) && is_array( $package['contents'] ) ) {
            foreach ( $package['contents'] as $item ) {
                $qty = (int) ( $item['quantity'] ?? 0 );
                $item_count += $qty;
                if ( isset( $item['data'] ) && is_object( $item['data'] ) ) {
                    $weight += (float) $item['data']->get_weight() * $qty;
                }
            }
        }

        if ( ! empty( $conditions['country_in'] ) && ! in_array( $country, array_map( 'strtoupper', (array) $conditions['country_in'] ), true ) ) {
            return false;
        }

        if ( ! empty( $conditions['country_not_in'] ) && in_array( $country, array_map( 'strtoupper', (array) $conditions['country_not_in'] ), true ) ) {
            return false;
        }

        if ( ! empty( $conditions['state_in'] ) && ! in_array( $state, array_map( 'strtoupper', (array) $conditions['state_in'] ), true ) ) {
            return false;
        }

        if ( ! empty( $conditions['postcode_prefix'] ) ) {
            $prefixes = array_map( 'strtoupper', (array) $conditions['postcode_prefix'] );
            $found = false;
            foreach ( $prefixes as $prefix ) {
                if ( 0 === strpos( $postcode, $prefix ) ) {
                    $found = true;
                    break;
                }
            }
            if ( ! $found ) {
                return false;
            }
        }

        if ( isset( $conditions['subtotal_gte'] ) && $subtotal < (float) $conditions['subtotal_gte'] ) {
            return false;
        }

        if ( isset( $conditions['subtotal_lte'] ) && $subtotal > (float) $conditions['subtotal_lte'] ) {
            return false;
        }

        if ( isset( $conditions['weight_lte'] ) && $weight > (float) $conditions['weight_lte'] ) {
            return false;
        }

        if ( isset( $conditions['weight_gte'] ) && $weight < (float) $conditions['weight_gte'] ) {
            return false;
        }

        if ( isset( $conditions['item_count_gte'] ) && $item_count < (int) $conditions['item_count_gte'] ) {
            return false;
        }

        if ( isset( $conditions['item_count_lte'] ) && $item_count > (int) $conditions['item_count_lte'] ) {
            return false;
        }

        return true;
    }
}
