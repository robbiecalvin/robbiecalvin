# Quick Code -- Visual To‑Do

## Global Snippets

-   Change background to branded sky blue

## Per-Page Snippets

-   Change Enable Test Mode Session to blue with white text

## Settings

-   Change Export JSON and Import JSON to blue with white text

## Integrations + History

-   No changes required
