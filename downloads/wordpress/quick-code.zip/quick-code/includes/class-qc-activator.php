<?php

if (!defined('ABSPATH')) {
    exit;
}

class QCOD_Activator
{
    public static function activate()
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $snippets_table = qcod_table_snippets();
        $map_table = qcod_table_map();
        $history_table = qcod_table_history();

        $sql_snippets = "CREATE TABLE {$snippets_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            scope VARCHAR(20) NOT NULL,
            title VARCHAR(255) NOT NULL,
            snippet_type VARCHAR(10) NOT NULL,
            location VARCHAR(20) NOT NULL,
            code LONGTEXT NOT NULL,
            conditions_json LONGTEXT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'enabled',
            priority INT NOT NULL DEFAULT 10,
            created_by BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY scope_status (scope, status),
            KEY location_status (location, status),
            KEY priority (priority)
        ) {$charset_collate};";

        $sql_map = "CREATE TABLE {$map_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            snippet_id BIGINT(20) UNSIGNED NOT NULL,
            object_type VARCHAR(20) NOT NULL,
            object_id BIGINT(20) UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY unique_mapping (snippet_id, object_type, object_id),
            KEY object_lookup (object_type, object_id),
            KEY snippet_lookup (snippet_id)
        ) {$charset_collate};";

        $sql_history = "CREATE TABLE {$history_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            snippet_id BIGINT(20) UNSIGNED NOT NULL,
            changed_by BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            changed_at DATETIME NOT NULL,
            old_values_json LONGTEXT NULL,
            new_values_json LONGTEXT NULL,
            PRIMARY KEY (id),
            KEY snippet_changed_at (snippet_id, changed_at)
        ) {$charset_collate};";

        dbDelta($sql_snippets);
        dbDelta($sql_map);
        dbDelta($sql_history);

        if (!get_option('qcod_settings')) {
            add_option('qcod_settings', qcod_default_settings());
        }
    }
}
