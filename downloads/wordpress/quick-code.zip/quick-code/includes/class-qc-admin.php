<?php

if (!defined('ABSPATH')) {
    exit;
}

class QCOD_Admin
{
    public static function init()
    {
        add_action('admin_menu', array(__CLASS__, 'register_menu'));
        add_action('admin_init', array(__CLASS__, 'handle_actions'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
        add_action('admin_notices', array(__CLASS__, 'render_license_debug_notice'));
    }

    public static function register_menu()
    {
        add_menu_page(
            __('Quick Code', 'quick-code'),
            __('Quick Code', 'quick-code'),
            'manage_options',
            'qc-global-snippets',
            array(__CLASS__, 'render_global_page'),
            'dashicons-editor-code',
            58
        );

        add_submenu_page(
            'qc-global-snippets',
            __('Global Snippets', 'quick-code'),
            __('Global Snippets', 'quick-code'),
            'manage_options',
            'qc-global-snippets',
            array(__CLASS__, 'render_global_page')
        );

        add_submenu_page(
            'qc-global-snippets',
            __('Per-Page Snippets', 'quick-code'),
            __('Per-Page Snippets', 'quick-code'),
            'manage_options',
            'qc-per-page-snippets',
            array(__CLASS__, 'render_per_page')
        );

        add_submenu_page(
            'qc-global-snippets',
            __('Settings', 'quick-code'),
            __('Settings', 'quick-code'),
            'manage_options',
            'qc-settings',
            array('QCOD_Settings', 'render_page')
        );

        add_submenu_page(
            'qc-global-snippets',
            __('Integrations', 'quick-code'),
            __('Integrations', 'quick-code'),
            'manage_options',
            'qc-integrations',
            array('QCOD_Integrations', 'render_page')
        );

        add_submenu_page(
            'qc-global-snippets',
            __('History', 'quick-code'),
            __('History', 'quick-code'),
            'manage_options',
            'qc-history',
            array(__CLASS__, 'render_history_page')
        );
    }

    public static function enqueue_assets($hook_suffix)
    {
        if (strpos($hook_suffix, 'qc-') === false && strpos($hook_suffix, 'post.php') === false && strpos($hook_suffix, 'post-new.php') === false) {
            return;
        }

        wp_enqueue_style('qc-admin', QUICK_CODE_URL . 'assets/css/admin.css', array(), QUICK_CODE_VERSION);
        wp_enqueue_script('qc-admin', QUICK_CODE_URL . 'assets/js/admin.js', array(), QUICK_CODE_VERSION, true);
    }

    public static function handle_actions()
    {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }

        if (!empty($_GET['qcod_action']) && $_GET['qcod_action'] === 'toggle_test_mode') {
            check_admin_referer('qcod_toggle_test_mode');
            $enabled = !qcod_is_test_mode_enabled_for_user(get_current_user_id());
            qcod_set_test_mode_for_user(get_current_user_id(), $enabled);
            $notice = $enabled ? 'test_mode_on' : 'test_mode_off';
            wp_safe_redirect(add_query_arg('qcod_notice', $notice, wp_get_referer() ?: admin_url('admin.php?page=qc-global-snippets')));
            exit;
        }

        if (!empty($_POST['qcod_action']) && $_POST['qcod_action'] === 'save_snippet') {
            check_admin_referer('qcod_save_snippet');
            qw_pro_require_license_or_error(array('quick-code'));
            self::save_snippet();
        }

        if (!empty($_GET['qcod_action']) && in_array($_GET['qcod_action'], array('delete_snippet', 'toggle_status'), true)) {
            check_admin_referer('qcod_row_action');
            qw_pro_require_license_or_error(array('quick-code'));

            $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
            if (!$id) {
                return;
            }

            $snippet = self::get_snippet($id);
            if (!$snippet) {
                return;
            }

            if ($_GET['qcod_action'] === 'delete_snippet') {
                self::delete_snippet($snippet);
            } else {
                self::toggle_snippet_status($snippet);
            }
        }
    }

    public static function render_global_page()
    {
        self::render_snippets_page('global');
    }

    public static function render_per_page()
    {
        self::render_snippets_page('per_page');
    }

    public static function render_history_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'quick-code'));
        }

        $rows = QCOD_History::get_rows(200);
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Quick Code History', 'quick-code'); ?></h1>
            <?php self::render_notice(); ?>
            <table class="widefat striped">
                <thead>
                <tr>
                    <th><?php esc_html_e('Changed At', 'quick-code'); ?></th>
                    <th><?php esc_html_e('Snippet', 'quick-code'); ?></th>
                    <th><?php esc_html_e('Changed By', 'quick-code'); ?></th>
                    <th><?php esc_html_e('Old Values', 'quick-code'); ?></th>
                    <th><?php esc_html_e('New Values', 'quick-code'); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php if (empty($rows)) : ?>
                    <tr><td colspan="5"><?php esc_html_e('No history found.', 'quick-code'); ?></td></tr>
                <?php else : ?>
                    <?php foreach ($rows as $row) : ?>
                        <?php $user = get_user_by('id', (int) $row['changed_by']); ?>
                        <tr>
                            <td><?php echo esc_html($row['changed_at']); ?></td>
                            <td><?php echo esc_html(!empty($row['snippet_title']) ? $row['snippet_title'] : ('#' . (int) $row['snippet_id'])); ?></td>
                            <td><?php echo esc_html($user ? $user->user_login : '#0'); ?></td>
                            <td><pre class="qc-history-json"><?php echo esc_html($row['old_values_json']); ?></pre></td>
                            <td><pre class="qc-history-json"><?php echo esc_html($row['new_values_json']); ?></pre></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    private static function render_snippets_page($scope)
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'quick-code'));
        }

        $scope = $scope === 'per_page' ? 'per_page' : 'global';
        $is_edit = !empty($_GET['qcod_form']) && in_array($_GET['qcod_form'], array('new', 'edit'), true);
        $license_valid = qcod_is_premium_active();

        echo '<div class="wrap">';
        echo '<h1>' . esc_html($scope === 'global' ? __('Global Snippets', 'quick-code') : __('Per-Page Snippets', 'quick-code')) . '</h1>';
        self::render_notice();
        self::render_test_mode_bar();
        if (!$license_valid) {
            echo '<div class="notice notice-warning"><p>' .
                esc_html__('Professional license is inactive. Snippet create, edit, toggle, and delete actions are locked.', 'quick-code') .
                ' <a class="button button-small" href="/pricing/">' .
                esc_html__('Upgrade to Professional', 'quick-code') .
            '</a></p></div>';
        }

        if ($is_edit) {
            if (!$license_valid) {
                echo '</div>';
                return;
            }
            $snippet = array();
            if ($_GET['qcod_form'] === 'edit' && !empty($_GET['id'])) {
                $snippet = self::get_snippet(absint($_GET['id']));
                if (!$snippet) {
                    echo '<p>' . esc_html__('Snippet not found.', 'quick-code') . '</p>';
                    echo '</div>';
                    return;
                }
            }
            self::render_form($scope, $snippet);
            echo '</div>';
            return;
        }

        $new_url = add_query_arg(
            array(
                'page' => $scope === 'global' ? 'qc-global-snippets' : 'qc-per-page-snippets',
                'qcod_form' => 'new',
            ),
            admin_url('admin.php')
        );

        if ($license_valid) {
            echo '<a href="' . esc_url($new_url) . '" class="page-title-action">' . esc_html__('Add New', 'quick-code') . '</a>';
        }

        $rows = self::get_snippets($scope);

        echo '<table class="widefat striped qc-snippets-table">';
        echo '<thead><tr>';
        echo '<th>' . esc_html__('ID', 'quick-code') . '</th>';
        echo '<th>' . esc_html__('Title', 'quick-code') . '</th>';
        echo '<th>' . esc_html__('Type', 'quick-code') . '</th>';
        echo '<th>' . esc_html__('Location', 'quick-code') . '</th>';
        echo '<th>' . esc_html__('Status', 'quick-code') . '</th>';
        echo '<th>' . esc_html__('Priority', 'quick-code') . '</th>';
        echo '<th>' . esc_html__('Updated', 'quick-code') . '</th>';
        echo '<th>' . esc_html__('Actions', 'quick-code') . '</th>';
        echo '</tr></thead><tbody>';

        if (empty($rows)) {
            echo '<tr><td colspan="8">' . esc_html__('No snippets found.', 'quick-code') . '</td></tr>';
        } else {
            foreach ($rows as $row) {
                $edit_url = add_query_arg(
                    array(
                        'page' => $scope === 'global' ? 'qc-global-snippets' : 'qc-per-page-snippets',
                        'qcod_form' => 'edit',
                        'id' => (int) $row['id'],
                    ),
                    admin_url('admin.php')
                );

                $toggle_url = wp_nonce_url(
                    add_query_arg(
                        array(
                            'page' => $scope === 'global' ? 'qc-global-snippets' : 'qc-per-page-snippets',
                            'qcod_action' => 'toggle_status',
                            'id' => (int) $row['id'],
                        ),
                        admin_url('admin.php')
                    ),
                    'qcod_row_action'
                );

                $delete_url = wp_nonce_url(
                    add_query_arg(
                        array(
                            'page' => $scope === 'global' ? 'qc-global-snippets' : 'qc-per-page-snippets',
                            'qcod_action' => 'delete_snippet',
                            'id' => (int) $row['id'],
                        ),
                        admin_url('admin.php')
                    ),
                    'qcod_row_action'
                );

                echo '<tr>';
                echo '<td>' . (int) $row['id'] . '</td>';
                echo '<td>' . esc_html($row['title']) . '</td>';
                echo '<td><code>' . esc_html($row['snippet_type']) . '</code></td>';
                echo '<td><code>' . esc_html($row['location']) . '</code></td>';
                echo '<td>' . esc_html($row['status']) . '</td>';
                echo '<td>' . (int) $row['priority'] . '</td>';
                echo '<td>' . esc_html($row['updated_at']) . '</td>';
                echo '<td>';
                if ($license_valid) {
                    echo '<a href="' . esc_url($edit_url) . '">' . esc_html__('Edit', 'quick-code') . '</a> | ';
                    echo '<a href="' . esc_url($toggle_url) . '">' . esc_html($row['status'] === 'enabled' ? __('Disable', 'quick-code') : __('Enable', 'quick-code')) . '</a> | ';
                    echo '<a href="' . esc_url($delete_url) . '" onclick="return confirm(\'' . esc_js(__('Delete this snippet?', 'quick-code')) . '\');">' . esc_html__('Delete', 'quick-code') . '</a>';
                } else {
                    echo '<span class="description">' . esc_html__('Locked: License required', 'quick-code') . '</span>';
                }
                echo '</td>';
                echo '</tr>';
            }
        }

        echo '</tbody></table>';
        echo '</div>';
    }

    private static function render_form($scope, $snippet)
    {
        $settings = qcod_get_settings();
        $snippet = wp_parse_args($snippet, array(
            'id' => 0,
            'title' => '',
            'snippet_type' => 'html',
            'location' => 'head',
            'code' => '',
            'conditions_json' => '',
            'status' => 'enabled',
            'priority' => 10,
        ));

        if (!$snippet['location']) {
            if ($snippet['snippet_type'] === 'css') {
                $snippet['location'] = $settings['default_css_location'];
            } elseif ($snippet['snippet_type'] === 'js') {
                $snippet['location'] = $settings['default_js_location'];
            }
        }

        $conditions = qcod_normalize_conditions($snippet['conditions_json']);
        $post_types = get_post_types(array('public' => true), 'objects');
        $roles = wp_roles()->roles;

        $mapped_ids = array();
        if (!empty($snippet['id'])) {
            $mapped_ids = self::get_mapped_object_ids($snippet['id']);
        }

        $back_url = add_query_arg('page', $scope === 'global' ? 'qc-global-snippets' : 'qc-per-page-snippets', admin_url('admin.php'));
        ?>
        <form method="post" action="" class="qc-form">
            <?php wp_nonce_field('qcod_save_snippet'); ?>
            <input type="hidden" name="qcod_action" value="save_snippet" />
            <input type="hidden" name="id" value="<?php echo (int) $snippet['id']; ?>" />
            <input type="hidden" name="scope" value="<?php echo esc_attr($scope); ?>" />

            <table class="form-table" role="presentation">
                <tr>
                    <th><label for="qc-title"><?php esc_html_e('Title', 'quick-code'); ?></label></th>
                    <td><input id="qc-title" class="regular-text" type="text" name="title" value="<?php echo esc_attr($snippet['title']); ?>" required /></td>
                </tr>
                <tr>
                    <th><label for="qc-snippet-type"><?php esc_html_e('Snippet Type', 'quick-code'); ?></label></th>
                    <td>
                        <select id="qc-snippet-type" name="snippet_type" required>
                            <option value="html" <?php selected($snippet['snippet_type'], 'html'); ?>><?php esc_html_e('HTML', 'quick-code'); ?></option>
                            <option value="css" <?php selected($snippet['snippet_type'], 'css'); ?>><?php esc_html_e('CSS', 'quick-code'); ?></option>
                            <option value="js" <?php selected($snippet['snippet_type'], 'js'); ?>><?php esc_html_e('JS', 'quick-code'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="qc-location"><?php esc_html_e('Location', 'quick-code'); ?></label></th>
                    <td>
                        <select id="qc-location" name="location" required>
                            <option value="head" <?php selected($snippet['location'], 'head'); ?>><?php esc_html_e('Head', 'quick-code'); ?></option>
                            <option value="body_open" <?php selected($snippet['location'], 'body_open'); ?>><?php esc_html_e('Body Open', 'quick-code'); ?></option>
                            <option value="body_close" <?php selected($snippet['location'], 'body_close'); ?>><?php esc_html_e('Body Close', 'quick-code'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="qc-status"><?php esc_html_e('Status', 'quick-code'); ?></label></th>
                    <td>
                        <select id="qc-status" name="status">
                            <option value="enabled" <?php selected($snippet['status'], 'enabled'); ?>><?php esc_html_e('Enabled', 'quick-code'); ?></option>
                            <option value="disabled" <?php selected($snippet['status'], 'disabled'); ?>><?php esc_html_e('Disabled', 'quick-code'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="qc-priority"><?php esc_html_e('Priority', 'quick-code'); ?></label></th>
                    <td><input id="qc-priority" type="number" name="priority" value="<?php echo (int) $snippet['priority']; ?>" min="-100" max="9999" /></td>
                </tr>
                <tr>
                    <th><label for="qc-code"><?php esc_html_e('Code', 'quick-code'); ?></label></th>
                    <td>
                        <textarea id="qc-code" class="large-text code qc-code-editor" name="code" rows="14" required><?php echo esc_textarea($snippet['code']); ?></textarea>
                        <p><strong><?php esc_html_e('Character count:', 'quick-code'); ?></strong> <span id="qc-char-count">0</span></p>
                        <p id="qc-large-warning" class="qc-warning" style="display:none;"><?php esc_html_e('Warning: this snippet is very large and may impact performance.', 'quick-code'); ?></p>
                    </td>
                </tr>
            </table>

            <h2><?php esc_html_e('Targeting Conditions', 'quick-code'); ?></h2>
            <table class="form-table" role="presentation">
                <tr>
                    <th><?php esc_html_e('Include Post Types', 'quick-code'); ?></th>
                    <td>
                        <?php foreach ($post_types as $pt) : ?>
                            <label class="qc-inline"><input type="checkbox" name="include_post_types[]" value="<?php echo esc_attr($pt->name); ?>" <?php checked(in_array($pt->name, $conditions['include_post_types'], true)); ?> /> <?php echo esc_html($pt->label); ?></label>
                        <?php endforeach; ?>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Exclude Post Types', 'quick-code'); ?></th>
                    <td>
                        <?php foreach ($post_types as $pt) : ?>
                            <label class="qc-inline"><input type="checkbox" name="exclude_post_types[]" value="<?php echo esc_attr($pt->name); ?>" <?php checked(in_array($pt->name, $conditions['exclude_post_types'], true)); ?> /> <?php echo esc_html($pt->label); ?></label>
                        <?php endforeach; ?>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Include IDs', 'quick-code'); ?></th>
                    <td><input class="regular-text" type="text" name="include_ids" value="<?php echo esc_attr(implode(',', $conditions['include_ids'])); ?>" /><p class="description"><?php esc_html_e('Comma-separated post IDs.', 'quick-code'); ?></p></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Exclude IDs', 'quick-code'); ?></th>
                    <td><input class="regular-text" type="text" name="exclude_ids" value="<?php echo esc_attr(implode(',', $conditions['exclude_ids'])); ?>" /><p class="description"><?php esc_html_e('Comma-separated post IDs.', 'quick-code'); ?></p></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Path Exact', 'quick-code'); ?></th>
                    <td><textarea name="path_exact" rows="3" class="large-text"><?php echo esc_textarea(implode("\n", $conditions['path_exact'])); ?></textarea><p class="description"><?php esc_html_e('One path per line, e.g. /pricing', 'quick-code'); ?></p></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Path Contains', 'quick-code'); ?></th>
                    <td><textarea name="path_contains" rows="3" class="large-text"><?php echo esc_textarea(implode("\n", $conditions['path_contains'])); ?></textarea><p class="description"><?php esc_html_e('One substring per line, e.g. /blog/', 'quick-code'); ?></p></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Login State', 'quick-code'); ?></th>
                    <td>
                        <label class="qc-inline"><input type="checkbox" name="logged_in_only" value="1" <?php checked(1, $conditions['logged_in_only']); ?> /> <?php esc_html_e('Logged-in only', 'quick-code'); ?></label>
                        <label class="qc-inline"><input type="checkbox" name="logged_out_only" value="1" <?php checked(1, $conditions['logged_out_only']); ?> /> <?php esc_html_e('Logged-out only', 'quick-code'); ?></label>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Roles', 'quick-code'); ?></th>
                    <td>
                        <?php foreach ($roles as $role_key => $role_data) : ?>
                            <label class="qc-inline"><input type="checkbox" name="roles[]" value="<?php echo esc_attr($role_key); ?>" <?php checked(in_array($role_key, $conditions['roles'], true)); ?> /> <?php echo esc_html($role_data['name']); ?></label>
                        <?php endforeach; ?>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Devices', 'quick-code'); ?></th>
                    <td>
                        <label class="qc-inline"><input type="checkbox" name="devices[]" value="desktop" <?php checked(in_array('desktop', $conditions['devices'], true)); ?> /> <?php esc_html_e('Desktop', 'quick-code'); ?></label>
                        <label class="qc-inline"><input type="checkbox" name="devices[]" value="mobile" <?php checked(in_array('mobile', $conditions['devices'], true)); ?> /> <?php esc_html_e('Mobile', 'quick-code'); ?></label>
                        <label class="qc-inline"><input type="checkbox" name="devices[]" value="tablet" <?php checked(in_array('tablet', $conditions['devices'], true)); ?> /> <?php esc_html_e('Tablet', 'quick-code'); ?></label>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Schedule Start', 'quick-code'); ?></th>
                    <td><input type="datetime-local" name="schedule_start" value="<?php echo esc_attr(self::for_datetime_local($conditions['schedule_start'])); ?>" /></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Schedule End', 'quick-code'); ?></th>
                    <td><input type="datetime-local" name="schedule_end" value="<?php echo esc_attr(self::for_datetime_local($conditions['schedule_end'])); ?>" /></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Special Flags', 'quick-code'); ?></th>
                    <td>
                        <label class="qc-inline"><input type="checkbox" name="preview_admin_only" value="1" <?php checked(1, $conditions['preview_admin_only']); ?> /> <?php esc_html_e('Preview mode (admins only)', 'quick-code'); ?></label>
                        <label class="qc-inline"><input type="checkbox" name="marketing_script" value="1" <?php checked(1, $conditions['marketing_script']); ?> /> <?php esc_html_e('Marketing script', 'quick-code'); ?></label>
                        <label class="qc-inline"><input type="checkbox" name="test_mode" value="1" <?php checked(1, $conditions['test_mode']); ?> /> <?php esc_html_e('Test mode (current admin session)', 'quick-code'); ?></label>
                    </td>
                </tr>
            </table>

            <?php if ($scope === 'per_page') : ?>
                <h2><?php esc_html_e('Per-Page Mapping', 'quick-code'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th><?php esc_html_e('Mapped Post IDs', 'quick-code'); ?></th>
                        <td>
                            <input type="text" name="mapped_ids" class="regular-text" value="<?php echo esc_attr(implode(',', $mapped_ids)); ?>" />
                            <p class="description"><?php esc_html_e('Comma-separated post IDs to attach this snippet.', 'quick-code'); ?></p>
                        </td>
                    </tr>
                </table>
            <?php endif; ?>

            <p class="submit">
                <button type="submit" class="button button-primary"><?php esc_html_e('Save Snippet', 'quick-code'); ?></button>
                <a href="<?php echo esc_url($back_url); ?>" class="button"><?php esc_html_e('Cancel', 'quick-code'); ?></a>
            </p>
        </form>
        <?php
    }

    private static function save_snippet()
    {
        qw_pro_require_license_or_error(array('quick-code'));
        global $wpdb;
        qcod_ensure_tables_exist();

        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        $scope = isset($_POST['scope']) && $_POST['scope'] === 'per_page' ? 'per_page' : 'global';
        $settings = qcod_get_settings();

        $snippet_type = isset($_POST['snippet_type']) ? sanitize_key(wp_unslash($_POST['snippet_type'])) : 'html';
        if (!in_array($snippet_type, array('html', 'css', 'js'), true)) {
            $snippet_type = 'html';
        }

        $location = isset($_POST['location']) ? sanitize_key(wp_unslash($_POST['location'])) : '';
        if (!in_array($location, array('head', 'body_open', 'body_close'), true)) {
            if ($snippet_type === 'css') {
                $location = $settings['default_css_location'];
            } elseif ($snippet_type === 'js') {
                $location = $settings['default_js_location'];
            } else {
                $location = 'head';
            }
        }

        $conditions = array(
            'include_post_types' => isset($_POST['include_post_types']) ? (array) wp_unslash($_POST['include_post_types']) : array(),
            'exclude_post_types' => isset($_POST['exclude_post_types']) ? (array) wp_unslash($_POST['exclude_post_types']) : array(),
            'include_ids' => self::csv_to_ints(isset($_POST['include_ids']) ? wp_unslash($_POST['include_ids']) : ''),
            'exclude_ids' => self::csv_to_ints(isset($_POST['exclude_ids']) ? wp_unslash($_POST['exclude_ids']) : ''),
            'path_exact' => self::lines_to_array(isset($_POST['path_exact']) ? wp_unslash($_POST['path_exact']) : ''),
            'path_contains' => self::lines_to_array(isset($_POST['path_contains']) ? wp_unslash($_POST['path_contains']) : ''),
            'logged_in_only' => empty($_POST['logged_in_only']) ? 0 : 1,
            'logged_out_only' => empty($_POST['logged_out_only']) ? 0 : 1,
            'roles' => isset($_POST['roles']) ? (array) wp_unslash($_POST['roles']) : array(),
            'devices' => isset($_POST['devices']) ? (array) wp_unslash($_POST['devices']) : array(),
            'schedule_start' => isset($_POST['schedule_start']) ? sanitize_text_field(wp_unslash($_POST['schedule_start'])) : '',
            'schedule_end' => isset($_POST['schedule_end']) ? sanitize_text_field(wp_unslash($_POST['schedule_end'])) : '',
            'preview_admin_only' => empty($_POST['preview_admin_only']) ? 0 : 1,
            'marketing_script' => empty($_POST['marketing_script']) ? 0 : 1,
            'test_mode' => empty($_POST['test_mode']) ? 0 : 1,
        );

        $conditions = qcod_normalize_conditions($conditions);

        $data = array(
            'scope' => $scope,
            'title' => isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : '',
            'snippet_type' => $snippet_type,
            'location' => $location,
            'code' => isset($_POST['code']) ? wp_unslash($_POST['code']) : '',
            'conditions_json' => wp_json_encode($conditions),
            'status' => isset($_POST['status']) && wp_unslash($_POST['status']) === 'disabled' ? 'disabled' : 'enabled',
            'priority' => isset($_POST['priority']) ? (int) $_POST['priority'] : 10,
            'updated_at' => qcod_now_mysql(),
        );

        $table = qcod_table_snippets();
        $old = array();

        if ($id) {
            $old = self::get_snippet($id);
            if (!$old) {
                wp_die(esc_html__('Snippet not found.', 'quick-code'));
            }

            $wpdb->update(
                $table,
                $data,
                array('id' => $id),
                array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s'),
                array('%d')
            );

            QCOD_History::log($id, $old, $data);
        } else {
            $data['created_by'] = get_current_user_id();
            $data['created_at'] = qcod_now_mysql();

            $wpdb->insert(
                $table,
                $data,
                array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s')
            );

            $id = (int) $wpdb->insert_id;
            QCOD_History::log($id, array(), $data);
        }

        if ($scope === 'per_page') {
            self::save_mappings($id, isset($_POST['mapped_ids']) ? wp_unslash($_POST['mapped_ids']) : '');
        }

        qcod_invalidate_cache();
        if (class_exists('QCOD_Integrations')) {
            QCOD_Integrations::emit_snippet_saved($id, $scope, $data['snippet_type'], $data['status']);
        }

        $page = $scope === 'per_page' ? 'qc-per-page-snippets' : 'qc-global-snippets';
        wp_safe_redirect(add_query_arg('qcod_notice', 'snippet_saved', admin_url('admin.php?page=' . $page)));
        exit;
    }

    private static function save_mappings($snippet_id, $mapped_ids_csv)
    {
        global $wpdb;

        $snippet_id = absint($snippet_id);
        if (!$snippet_id) {
            return;
        }

        $ids = self::csv_to_ints($mapped_ids_csv);
        $wpdb->delete(qcod_table_map(), array('snippet_id' => $snippet_id), array('%d'));

        foreach ($ids as $object_id) {
            $wpdb->insert(
                qcod_table_map(),
                array(
                    'snippet_id' => $snippet_id,
                    'object_type' => 'post',
                    'object_id' => $object_id,
                ),
                array('%d', '%s', '%d')
            );
        }
    }

    private static function toggle_snippet_status($snippet)
    {
        qw_pro_require_license_or_error(array('quick-code'));
        global $wpdb;

        $new_status = $snippet['status'] === 'enabled' ? 'disabled' : 'enabled';
        $wpdb->update(
            qcod_table_snippets(),
            array(
                'status' => $new_status,
                'updated_at' => qcod_now_mysql(),
            ),
            array('id' => (int) $snippet['id']),
            array('%s', '%s'),
            array('%d')
        );

        QCOD_History::log($snippet['id'], $snippet, array('status' => $new_status));
        qcod_invalidate_cache();

        $page = $snippet['scope'] === 'per_page' ? 'qc-per-page-snippets' : 'qc-global-snippets';
        wp_safe_redirect(add_query_arg('qcod_notice', 'snippet_toggled', admin_url('admin.php?page=' . $page)));
        exit;
    }

    private static function delete_snippet($snippet)
    {
        qw_pro_require_license_or_error(array('quick-code'));
        global $wpdb;

        $snippet_id = (int) $snippet['id'];
        $wpdb->delete(qcod_table_map(), array('snippet_id' => $snippet_id), array('%d'));
        $wpdb->delete(qcod_table_snippets(), array('id' => $snippet_id), array('%d'));

        QCOD_History::log($snippet_id, $snippet, array('deleted' => 1));
        qcod_invalidate_cache();

        $page = $snippet['scope'] === 'per_page' ? 'qc-per-page-snippets' : 'qc-global-snippets';
        wp_safe_redirect(add_query_arg('qcod_notice', 'snippet_deleted', admin_url('admin.php?page=' . $page)));
        exit;
    }

    private static function get_snippets($scope)
    {
        global $wpdb;

        $scope = $scope === 'per_page' ? 'per_page' : 'global';

        return $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM ' . qcod_table_snippets() . ' WHERE scope = %s ORDER BY priority ASC, id DESC',
                $scope
            ),
            ARRAY_A
        );
    }

    private static function get_snippet($id)
    {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare('SELECT * FROM ' . qcod_table_snippets() . ' WHERE id = %d LIMIT 1', absint($id)),
            ARRAY_A
        );
    }

    public static function get_mapped_object_ids($snippet_id)
    {
        global $wpdb;

        return array_map('absint', $wpdb->get_col(
            $wpdb->prepare('SELECT object_id FROM ' . qcod_table_map() . ' WHERE snippet_id = %d AND object_type = %s', absint($snippet_id), 'post')
        ));
    }

    public static function get_per_page_snippets_for_post($post_id)
    {
        global $wpdb;

        $post_id = absint($post_id);
        if (!$post_id) {
            return array();
        }

        return $wpdb->get_results(
            $wpdb->prepare(
                'SELECT s.* FROM ' . qcod_table_snippets() . ' s
                INNER JOIN ' . qcod_table_map() . ' m ON m.snippet_id = s.id
                WHERE m.object_type = %s AND m.object_id = %d AND s.scope = %s
                ORDER BY s.priority ASC, s.id ASC',
                'post',
                $post_id,
                'per_page'
            ),
            ARRAY_A
        );
    }

    public static function attach_snippet_to_post($snippet_id, $post_id)
    {
        global $wpdb;

        $snippet_id = absint($snippet_id);
        $post_id = absint($post_id);

        if (!$snippet_id || !$post_id) {
            return;
        }

        $wpdb->query(
            $wpdb->prepare(
                'INSERT IGNORE INTO ' . qcod_table_map() . ' (snippet_id, object_type, object_id) VALUES (%d, %s, %d)',
                $snippet_id,
                'post',
                $post_id
            )
        );

        qcod_invalidate_cache();
    }

    public static function remove_post_mappings($post_id)
    {
        global $wpdb;

        $post_id = absint($post_id);
        if (!$post_id) {
            return;
        }

        $wpdb->delete(qcod_table_map(), array('object_type' => 'post', 'object_id' => $post_id), array('%s', '%d'));
        qcod_invalidate_cache();
    }

    private static function csv_to_ints($raw)
    {
        if (!is_string($raw) || trim($raw) === '') {
            return array();
        }

        $parts = array_map('trim', explode(',', $raw));
        $ints = array();
        foreach ($parts as $part) {
            if ($part === '') {
                continue;
            }
            $value = absint($part);
            if ($value) {
                $ints[] = $value;
            }
        }

        return array_values(array_unique($ints));
    }

    private static function lines_to_array($raw)
    {
        if (!is_string($raw) || trim($raw) === '') {
            return array();
        }

        $lines = preg_split('/\r\n|\r|\n/', $raw);
        $lines = array_map('trim', $lines);
        $lines = array_filter($lines, static function ($line) {
            return $line !== '';
        });

        return array_values($lines);
    }

    private static function render_notice()
    {
        if (empty($_GET['qcod_notice'])) {
            return;
        }

        $key = sanitize_key(wp_unslash($_GET['qcod_notice']));
        $messages = array(
            'snippet_saved' => __('Snippet saved.', 'quick-code'),
            'snippet_deleted' => __('Snippet deleted.', 'quick-code'),
            'snippet_toggled' => __('Snippet status updated.', 'quick-code'),
            'settings_saved' => __('Settings saved.', 'quick-code'),
            'import_success' => __('Import completed successfully.', 'quick-code'),
            'import_error' => __('Import failed. Unable to read file.', 'quick-code'),
            'import_invalid' => __('Import failed. Invalid JSON schema.', 'quick-code'),
            'test_mode_on' => __('Test mode enabled for your current admin session.', 'quick-code'),
            'test_mode_off' => __('Test mode disabled for your session.', 'quick-code'),
        );

        if (!isset($messages[$key])) {
            return;
        }

        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($messages[$key]) . '</p></div>';
    }

    private static function render_test_mode_bar()
    {
        $enabled = qcod_is_test_mode_enabled_for_user(get_current_user_id());
        $label = $enabled ? __('Disable Test Mode Session', 'quick-code') : __('Enable Test Mode Session', 'quick-code');
        $url = wp_nonce_url(
            add_query_arg(
                array(
                    'qcod_action' => 'toggle_test_mode',
                )
            ),
            'qcod_toggle_test_mode'
        );

        echo '<p><strong>' . esc_html__('Session Test Mode:', 'quick-code') . '</strong> ' . esc_html($enabled ? __('Enabled', 'quick-code') : __('Disabled', 'quick-code')) . ' &nbsp; <a class="button button-secondary" href="' . esc_url($url) . '">' . esc_html($label) . '</a></p>';
    }

    private static function for_datetime_local($value)
    {
        if (empty($value)) {
            return '';
        }

        $ts = strtotime($value);
        if ($ts === false) {
            return '';
        }

        return gmdate('Y-m-d\TH:i', $ts);
    }

    public static function render_license_debug_notice()
    {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }
        if (empty($_GET['page']) || strpos((string) $_GET['page'], 'qc-') !== 0) {
            return;
        }

        $status = qw_pro_get_license_status(array('quick-code'));
        echo '<div class="notice notice-info"><p><strong>' .
            esc_html__('Quick Code License Status (Debug):', 'quick-code') .
            '</strong> ' . esc_html($status) . '</p></div>';
    }
}
