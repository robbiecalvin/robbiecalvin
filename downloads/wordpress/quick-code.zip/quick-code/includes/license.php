<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'qw_pro_is_license_valid' ) ) {
    function qw_pro_is_license_valid( $products = array() ) {
        // Promotional access is scoped to this owner-authored plugin only.
        if ( ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) && ! empty( $products ) && empty( array_diff( (array) $products, array( 'quick-code' ) ) ) ) {
            return true;
        }

        $products = (array) $products;
        if ( empty( $products ) ) {
            return false;
        }

        if ( function_exists( 'qwoo_has_active_license' ) ) {
            return (bool) qwoo_has_active_license( $products );
        }

        return false;
    }
}

if ( ! function_exists( 'qw_pro_get_license_status' ) ) {
    function qw_pro_get_license_status( $products = array() ) {
        return qw_pro_is_license_valid( $products ) ? 'active' : 'inactive';
    }
}

if ( ! function_exists( 'qw_pro_require_license_or_error' ) ) {
    function qw_pro_require_license_or_error( $products = array(), $context = 'web' ) {
        if ( qw_pro_is_license_valid( $products ) ) {
            return true;
        }

        $message = __( 'A valid Professional license is required to use this feature.', 'quick-code' );
        if ( $context === 'ajax' ) {
            wp_send_json_error(
                array(
                    'message' => $message . ' ' . __( 'Upgrade at /pricing/.', 'quick-code' ),
                ),
                403
            );
        }

        wp_die( esc_html( $message ) . ' <a href="/pricing/">' . esc_html__( 'Upgrade to Professional', 'quick-code' ) . '</a>' );
    }
}

if ( ! function_exists( 'qw_pro_activate_license' ) ) {
    function qw_pro_activate_license( $key, $products = array() ) {
        $key = sanitize_text_field( (string) $key );
        if ( '' === $key || empty( $products ) ) {
            return array(
                'status'  => 'invalid',
                'valid'   => false,
                'message' => __( 'License key is required.', 'quick-code' ),
            );
        }

        if ( function_exists( 'qlic_activate_license_key_for_products' ) ) {
            return qlic_activate_license_key_for_products( $key, (array) $products );
        }

        return array(
            'status'  => 'invalid',
            'valid'   => false,
            'message' => __( 'Quick Woo License plugin is required for activation.', 'quick-code' ),
        );
    }
}

