<?php

if (!defined('ABSPATH')) {
    exit;
}

class QCOD_Import_Export
{
    public static function init()
    {
        add_action('admin_post_qc_export_snippets', array(__CLASS__, 'export'));
        add_action('admin_post_qc_import_snippets', array(__CLASS__, 'import'));
    }

    public static function export()
    {
        qw_pro_require_license_or_error(array('quick-code'));
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'quick-code'));
        }

        check_admin_referer('qcod_export_snippets');

        global $wpdb;

        $snippets = $wpdb->get_results('SELECT * FROM ' . qcod_table_snippets() . ' ORDER BY id ASC', ARRAY_A);
        $maps = $wpdb->get_results('SELECT * FROM ' . qcod_table_map() . ' ORDER BY id ASC', ARRAY_A);

        $payload = array(
            'plugin' => 'quick-code',
            'version' => QUICK_CODE_VERSION,
            'exported_at' => gmdate('c'),
            'snippets' => $snippets,
            'mappings' => $maps,
        );

        $filename = 'quick-code-export-' . gmdate('Ymd-His') . '.json';

        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);

        echo wp_json_encode($payload, JSON_PRETTY_PRINT);
        exit;
    }

    public static function import()
    {
        qw_pro_require_license_or_error(array('quick-code'));
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'quick-code'));
        }

        check_admin_referer('qcod_import_snippets');

        if (empty($_FILES['qcod_import_file']['tmp_name'])) {
            self::redirect_with_notice('import_error');
        }

        $tmp_name = $_FILES['qcod_import_file']['tmp_name'];
        $content = file_get_contents($tmp_name); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

        if ($content === false || $content === '') {
            self::redirect_with_notice('import_error');
        }

        $json = json_decode($content, true);

        if (!self::validate_payload($json)) {
            self::redirect_with_notice('import_invalid');
        }

        self::insert_payload($json);
        qcod_invalidate_cache();

        self::redirect_with_notice('import_success');
    }

    private static function validate_payload($payload)
    {
        if (!is_array($payload)) {
            return false;
        }

        if (!isset($payload['snippets']) || !is_array($payload['snippets'])) {
            return false;
        }

        if (!isset($payload['mappings']) || !is_array($payload['mappings'])) {
            return false;
        }

        foreach ($payload['snippets'] as $snippet) {
            if (!is_array($snippet)) {
                return false;
            }

            $required = array('scope', 'title', 'snippet_type', 'location', 'code', 'status', 'priority');
            foreach ($required as $field) {
                if (!array_key_exists($field, $snippet)) {
                    return false;
                }
            }

            if (!in_array($snippet['scope'], array('global', 'per_page'), true)) {
                return false;
            }

            if (!in_array($snippet['snippet_type'], array('html', 'css', 'js'), true)) {
                return false;
            }

            if (!in_array($snippet['location'], array('head', 'body_open', 'body_close'), true)) {
                return false;
            }
        }

        return true;
    }

    private static function insert_payload($payload)
    {
        global $wpdb;

        $table_snippets = qcod_table_snippets();
        $table_map = qcod_table_map();

        $id_map = array();

        foreach ($payload['snippets'] as $snippet) {
            $conditions = isset($snippet['conditions_json']) ? $snippet['conditions_json'] : '';
            $conditions = qcod_normalize_conditions($conditions);

            $insert_data = array(
                'scope' => sanitize_key($snippet['scope']),
                'title' => sanitize_text_field($snippet['title']),
                'snippet_type' => sanitize_key($snippet['snippet_type']),
                'location' => sanitize_key($snippet['location']),
                'code' => (string) $snippet['code'],
                'conditions_json' => wp_json_encode($conditions),
                'status' => sanitize_key($snippet['status']) === 'disabled' ? 'disabled' : 'enabled',
                'priority' => isset($snippet['priority']) ? (int) $snippet['priority'] : 10,
                'created_by' => get_current_user_id(),
                'created_at' => qcod_now_mysql(),
                'updated_at' => qcod_now_mysql(),
            );

            $wpdb->insert(
                $table_snippets,
                $insert_data,
                array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s')
            );

            $new_id = (int) $wpdb->insert_id;

            if (!empty($snippet['id'])) {
                $id_map[(int) $snippet['id']] = $new_id;
            }

            QCOD_History::log($new_id, array(), $insert_data);
        }

        foreach ($payload['mappings'] as $mapping) {
            if (!is_array($mapping) || empty($mapping['snippet_id']) || empty($mapping['object_id'])) {
                continue;
            }

            $old_snippet_id = (int) $mapping['snippet_id'];
            if (empty($id_map[$old_snippet_id])) {
                continue;
            }

            $wpdb->insert(
                $table_map,
                array(
                    'snippet_id' => $id_map[$old_snippet_id],
                    'object_type' => !empty($mapping['object_type']) ? sanitize_key($mapping['object_type']) : 'post',
                    'object_id' => absint($mapping['object_id']),
                ),
                array('%d', '%s', '%d')
            );
        }
    }

    private static function redirect_with_notice($notice)
    {
        wp_safe_redirect(add_query_arg('qcod_notice', $notice, admin_url('admin.php?page=qc-settings')));
        exit;
    }
}
