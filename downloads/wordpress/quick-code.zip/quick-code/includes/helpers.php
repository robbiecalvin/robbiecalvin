<?php

if (!defined('ABSPATH')) {
    exit;
}

function qcod_table_snippets()
{
    global $wpdb;
    return $wpdb->prefix . 'quick_code_snippets';
}

function qcod_table_map()
{
    global $wpdb;
    return $wpdb->prefix . 'quick_code_snippet_map';
}

function qcod_table_history()
{
    global $wpdb;
    return $wpdb->prefix . 'quick_code_history';
}

function qcod_now_mysql()
{
    return current_time('mysql', true);
}

function qcod_default_settings()
{
    return array(
        'enable_global' => 1,
        'enable_per_page' => 1,
        'default_css_location' => 'head',
        'default_js_location' => 'body_close',
        'body_open_fallback' => 0,
        'disable_all' => 0,
        'exclude_admins' => 0,
        'respect_dnt' => 0,
        'disable_on_preview' => 1,
    );
}

function qcod_get_settings()
{
    $settings = get_option('qcod_settings', array());
    return wp_parse_args($settings, qcod_default_settings());
}

function qcod_invalidate_cache()
{
    delete_transient('qcod_active_snippets_global');
    delete_transient('qcod_active_snippets_all');

    global $wpdb;
    $prefix = '_transient_qc_active_snippets_post_';
    $like = $wpdb->esc_like($prefix) . '%';
    $options = $wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $like));

    if (!empty($options)) {
        foreach ($options as $option_name) {
            $transient_name = str_replace('_transient_', '', $option_name);
            delete_transient($transient_name);
        }
    }
}

function qcod_user_is_adminish()
{
    return is_user_logged_in() && current_user_can('manage_options');
}

function qcod_test_mode_transient_key($user_id)
{
    return 'qcod_test_mode_user_' . absint($user_id);
}

function qcod_is_test_mode_enabled_for_user($user_id = 0)
{
    $user_id = $user_id ? absint($user_id) : get_current_user_id();

    if (!$user_id) {
        return false;
    }

    return (bool) get_transient(qcod_test_mode_transient_key($user_id));
}

function qcod_set_test_mode_for_user($user_id, $enabled)
{
    $user_id = absint($user_id);

    if (!$user_id) {
        return;
    }

    $key = qcod_test_mode_transient_key($user_id);

    if ($enabled) {
        set_transient($key, 1, 2 * HOUR_IN_SECONDS);
    } else {
        delete_transient($key);
    }
}

function qcod_normalize_conditions($raw)
{
    $defaults = array(
        'include_post_types' => array(),
        'exclude_post_types' => array(),
        'include_ids' => array(),
        'exclude_ids' => array(),
        'path_exact' => array(),
        'path_contains' => array(),
        'logged_in_only' => 0,
        'logged_out_only' => 0,
        'roles' => array(),
        'devices' => array(),
        'schedule_start' => '',
        'schedule_end' => '',
        'preview_admin_only' => 0,
        'marketing_script' => 0,
        'test_mode' => 0,
    );

    $data = array();

    if (is_string($raw) && $raw !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) {
            $data = $decoded;
        }
    } elseif (is_array($raw)) {
        $data = $raw;
    }

    $data = wp_parse_args($data, $defaults);

    foreach (array('include_post_types', 'exclude_post_types', 'include_ids', 'exclude_ids', 'path_exact', 'path_contains', 'roles', 'devices') as $array_field) {
        if (!is_array($data[$array_field])) {
            $data[$array_field] = array();
        }
    }

    $data['include_post_types'] = array_values(array_filter(array_map('sanitize_key', $data['include_post_types'])));
    $data['exclude_post_types'] = array_values(array_filter(array_map('sanitize_key', $data['exclude_post_types'])));
    $data['include_ids'] = array_values(array_filter(array_map('absint', $data['include_ids'])));
    $data['exclude_ids'] = array_values(array_filter(array_map('absint', $data['exclude_ids'])));
    $data['path_exact'] = array_values(array_filter(array_map('sanitize_text_field', $data['path_exact'])));
    $data['path_contains'] = array_values(array_filter(array_map('sanitize_text_field', $data['path_contains'])));
    $data['roles'] = array_values(array_filter(array_map('sanitize_key', $data['roles'])));
    $data['devices'] = array_values(array_filter(array_map('sanitize_key', $data['devices'])));

    foreach (array('logged_in_only', 'logged_out_only', 'preview_admin_only', 'marketing_script', 'test_mode') as $bool_field) {
        $data[$bool_field] = empty($data[$bool_field]) ? 0 : 1;
    }

    $data['schedule_start'] = sanitize_text_field((string) $data['schedule_start']);
    $data['schedule_end'] = sanitize_text_field((string) $data['schedule_end']);

    return $data;
}

function qcod_page_test_mode_transient_key($post_id, $user_id)
{
    return 'qcod_page_test_mode_' . absint($post_id) . '_' . absint($user_id);
}

function qcod_is_page_test_mode_enabled_for_user($post_id, $user_id)
{
    $post_id = absint($post_id);
    $user_id = absint($user_id);

    if (!$post_id || !$user_id) {
        return false;
    }

    return (bool) get_transient(qcod_page_test_mode_transient_key($post_id, $user_id));
}

function qcod_set_page_test_mode_for_user($post_id, $user_id, $enabled)
{
    $post_id = absint($post_id);
    $user_id = absint($user_id);

    if (!$post_id || !$user_id) {
        return;
    }

    $key = qcod_page_test_mode_transient_key($post_id, $user_id);

    if ($enabled) {
        set_transient($key, 1, 2 * HOUR_IN_SECONDS);
    } else {
        delete_transient($key);
    }
}

function qcod_ensure_tables_exist()
{
    global $wpdb;

    static $checked = false;
    if ($checked) {
        return;
    }

    $checked = true;
    $table = qcod_table_snippets();
    $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));

    if ($exists !== $table) {
        require_once QUICK_CODE_DIR . 'includes/class-qc-activator.php';
        QCOD_Activator::activate();
    }
}
