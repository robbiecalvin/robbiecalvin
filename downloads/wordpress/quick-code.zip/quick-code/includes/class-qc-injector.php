<?php

if (!defined('ABSPATH')) {
    exit;
}

class QCOD_Injector
{
    private static $body_open_called = false;

    public static function init()
    {
        add_action('wp_head', array(__CLASS__, 'inject_head'), 1);
        add_action('wp_body_open', array(__CLASS__, 'inject_body_open'), 1);
        add_action('wp_footer', array(__CLASS__, 'inject_footer'), 999);
    }

    public static function inject_head()
    {
        self::inject_location('head');
    }

    public static function inject_body_open()
    {
        self::$body_open_called = true;
        self::inject_location('body_open');
    }

    public static function inject_footer()
    {
        self::inject_location('body_close');
        self::maybe_render_body_open_fallback();
    }

    private static function inject_location($location)
    {
        if (QCOD_Conditions::should_skip_runtime()) {
            return;
        }

        $snippets = self::get_matched_snippets_for_location($location);

        if (empty($snippets)) {
            return;
        }

        foreach ($snippets as $snippet) {
            self::render_snippet($snippet, $location);
        }
    }

    private static function get_matched_snippets_for_location($location)
    {
        $settings = qcod_get_settings();

        $context = array(
            'object_id' => is_singular() ? get_queried_object_id() : 0,
            'post_type' => is_singular() ? get_post_type() : '',
            'path' => QCOD_Conditions::current_path(),
        );

        $snippets = array();

        if (!empty($settings['enable_global'])) {
            $snippets = array_merge($snippets, self::get_global_snippets());
        }

        if (!empty($settings['enable_per_page']) && !empty($context['object_id'])) {
            $snippets = array_merge($snippets, self::get_per_page_snippets($context['object_id']));
        }

        if (empty($snippets)) {
            return array();
        }

        $matched = array();
        foreach ($snippets as $snippet) {
            $snippet = self::normalize_snippet_location($snippet);

            if ($snippet['status'] !== 'enabled') {
                continue;
            }

            if ($snippet['location'] !== $location) {
                continue;
            }

            if (!empty($context['object_id']) && $snippet['scope'] === 'per_page') {
                if (self::is_page_test_mode_only($snippet, $context['object_id'])) {
                    continue;
                }
            }

            if (QCOD_Conditions::matches($snippet, $context)) {
                $matched[] = $snippet;
            }
        }

        usort($matched, static function ($a, $b) {
            return (int) $a['priority'] <=> (int) $b['priority'];
        });

        return $matched;
    }

    private static function is_page_test_mode_only($snippet, $post_id)
    {
        $conditions = qcod_normalize_conditions($snippet['conditions_json']);

        if (empty($conditions['test_mode'])) {
            return false;
        }

        if (qcod_is_page_test_mode_enabled_for_user($post_id, get_current_user_id())) {
            return false;
        }

        return !qcod_is_test_mode_enabled_for_user(get_current_user_id());
    }

    private static function normalize_snippet_location($snippet)
    {
        $settings = qcod_get_settings();

        if (empty($snippet['location']) || !in_array($snippet['location'], array('head', 'body_open', 'body_close'), true)) {
            if ($snippet['snippet_type'] === 'css') {
                $snippet['location'] = $settings['default_css_location'];
            } elseif ($snippet['snippet_type'] === 'js') {
                $snippet['location'] = $settings['default_js_location'];
            } else {
                $snippet['location'] = 'head';
            }
        }

        return $snippet;
    }

    private static function render_snippet($snippet, $location)
    {
        if ($snippet['snippet_type'] === 'css') {
            echo "\n<style data-quick-code=\"" . esc_attr((string) $snippet['id']) . "\">\n";
            echo $snippet['code'];
            echo "\n</style>\n";
            return;
        }

        if ($snippet['snippet_type'] === 'js') {
            echo "\n<script data-quick-code=\"" . esc_attr((string) $snippet['id']) . "\">\n";
            echo $snippet['code'];
            echo "\n</script>\n";
            return;
        }

        echo "\n<!-- Quick Code #" . esc_html((string) $snippet['id']) . " " . esc_html($location) . " -->\n";
        echo $snippet['code'];
        echo "\n";
    }

    private static function maybe_render_body_open_fallback()
    {
        $settings = qcod_get_settings();

        if (QCOD_Conditions::should_skip_runtime()) {
            return;
        }

        if (empty($settings['body_open_fallback']) || self::$body_open_called) {
            return;
        }

        $snippets = self::get_matched_snippets_for_location('body_open');

        if (empty($snippets)) {
            return;
        }

        $html_blocks = array();

        foreach ($snippets as $snippet) {
            if ($snippet['snippet_type'] !== 'html') {
                continue;
            }
            $html_blocks[] = $snippet['code'];
        }

        if (empty($html_blocks)) {
            return;
        }

        echo "\n<script>\n";
        echo "(function(){";
        echo "if(!document.body){return;}";
        foreach ($html_blocks as $html) {
            echo 'document.body.insertAdjacentHTML("afterbegin",' . wp_json_encode($html) . ');';
        }
        echo "})();";
        echo "\n</script>\n";
    }

    private static function get_global_snippets()
    {
        $cached = get_transient('qcod_active_snippets_global');
        if (is_array($cached)) {
            return $cached;
        }

        global $wpdb;
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM ' . qcod_table_snippets() . ' WHERE scope = %s AND status = %s ORDER BY priority ASC, id ASC',
                'global',
                'enabled'
            ),
            ARRAY_A
        );

        set_transient('qcod_active_snippets_global', $rows, 5 * MINUTE_IN_SECONDS);
        return $rows;
    }

    private static function get_per_page_snippets($post_id)
    {
        $key = 'qcod_active_snippets_post_' . absint($post_id);
        $cached = get_transient($key);
        if (is_array($cached)) {
            return $cached;
        }

        global $wpdb;
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT s.* FROM ' . qcod_table_snippets() . ' s
                INNER JOIN ' . qcod_table_map() . ' m ON m.snippet_id = s.id
                WHERE s.scope = %s AND s.status = %s AND m.object_type = %s AND m.object_id = %d
                ORDER BY s.priority ASC, s.id ASC',
                'per_page',
                'enabled',
                'post',
                absint($post_id)
            ),
            ARRAY_A
        );

        set_transient($key, $rows, 5 * MINUTE_IN_SECONDS);
        return $rows;
    }
}
