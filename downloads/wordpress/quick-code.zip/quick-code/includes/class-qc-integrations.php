<?php

if (!defined('ABSPATH')) {
    exit;
}

class QCOD_Integrations
{
    private const OPTION_KEY = 'qcod_integrations';

    public static function init()
    {
        add_action('admin_post_qcod_save_integrations', array(__CLASS__, 'handle_save'));

        if (self::is_enabled('quick_audit')) {
            add_action('quickwoo_local/audit_completed', array(__CLASS__, 'handle_audit_completed'), 10, 2);
        }
    }

    public static function render_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'quick-code'));
        }
        $license_valid = qcod_is_premium_active();

        $settings = self::get_settings();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Quick Code Integrations', 'quick-code'); ?></h1>
            <p><?php esc_html_e('Optional integrations only. Quick Code remains fully standalone.', 'quick-code'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="qcod_save_integrations" />
                <?php wp_nonce_field('qcod_save_integrations', 'qcod_integrations_nonce'); ?>
                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row"><?php esc_html_e('Quick SEO', 'quick-code'); ?></th>
                            <td><label><input type="checkbox" name="quick_seo" value="1" <?php checked(1, (int) $settings['quick_seo']); ?> <?php disabled(!$license_valid); ?> /> <?php esc_html_e('Accept SEO update signals when Quick SEO is active.', 'quick-code'); ?></label></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Quick Audit', 'quick-code'); ?></th>
                            <td><label><input type="checkbox" name="quick_audit" value="1" <?php checked(1, (int) $settings['quick_audit']); ?> <?php disabled(!$license_valid); ?> /> <?php esc_html_e('Accept audit completion signals when Quick Audit is active.', 'quick-code'); ?></label></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Quick Traffic', 'quick-code'); ?></th>
                            <td><label><input type="checkbox" name="quick_traffic" value="1" <?php checked(1, (int) $settings['quick_traffic']); ?> <?php disabled(!$license_valid); ?> /> <?php esc_html_e('Accept traffic signals when Quick Traffic is active.', 'quick-code'); ?></label></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Quick Site', 'quick-code'); ?></th>
                            <td><label><input type="checkbox" name="quick_site" value="1" <?php checked(1, (int) $settings['quick_site']); ?> <?php disabled(!$license_valid); ?> /> <?php esc_html_e('Accept optimization signals when Quick Site is active.', 'quick-code'); ?></label></td>
                        </tr>
                    </tbody>
                </table>
                <?php if (!$license_valid) : ?>
                    <p class="description"><?php esc_html_e('Professional license is required to modify integrations.', 'quick-code'); ?> <a href="/pricing/"><?php esc_html_e('Upgrade to Professional', 'quick-code'); ?></a></p>
                <?php endif; ?>
                <?php submit_button(__('Save Integrations', 'quick-code')); ?>
            </form>
        </div>
        <?php
    }

    public static function handle_save()
    {
        qw_pro_require_license_or_error(array('quick-code'));
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'quick-code'));
        }

        check_admin_referer('qcod_save_integrations', 'qcod_integrations_nonce');

        $settings = array(
            'quick_seo' => !empty($_POST['quick_seo']) ? 1 : 0,
            'quick_audit' => !empty($_POST['quick_audit']) ? 1 : 0,
            'quick_traffic' => !empty($_POST['quick_traffic']) ? 1 : 0,
            'quick_site' => !empty($_POST['quick_site']) ? 1 : 0,
        );

        update_option(self::OPTION_KEY, $settings, false);
        wp_safe_redirect(admin_url('admin.php?page=qc-integrations'));
        exit;
    }

    public static function emit_snippet_saved($snippet_id, $scope, $snippet_type, $status)
    {
        do_action(
            'quickwoo_local/code_snippet_saved',
            array(
                'snippet_id' => absint($snippet_id),
                'scope' => sanitize_key((string) $scope),
                'snippet_type' => sanitize_key((string) $snippet_type),
                'status' => sanitize_key((string) $status),
            ),
            array(
                'source' => 'quick-code',
                'occurred_at' => current_time('mysql'),
            )
        );
    }

    public static function handle_audit_completed($payload, $context)
    {
        if (!self::is_enabled('quick_audit')) {
            return;
        }

        update_option('qcod_last_audit_event', array(
            'payload' => is_array($payload) ? $payload : array(),
            'context' => is_array($context) ? $context : array(),
            'stored_at' => current_time('mysql'),
        ), false);
    }

    private static function get_settings()
    {
        $defaults = array(
            'quick_seo' => 0,
            'quick_audit' => 0,
            'quick_traffic' => 0,
            'quick_site' => 0,
        );

        $saved = get_option(self::OPTION_KEY, array());
        if (!is_array($saved)) {
            $saved = array();
        }

        $settings = wp_parse_args($saved, $defaults);
        return array(
            'quick_seo' => !empty($settings['quick_seo']) ? 1 : 0,
            'quick_audit' => !empty($settings['quick_audit']) ? 1 : 0,
            'quick_traffic' => !empty($settings['quick_traffic']) ? 1 : 0,
            'quick_site' => !empty($settings['quick_site']) ? 1 : 0,
        );
    }

    private static function is_enabled($key)
    {
        $settings = self::get_settings();
        return !empty($settings[$key]);
    }
}
