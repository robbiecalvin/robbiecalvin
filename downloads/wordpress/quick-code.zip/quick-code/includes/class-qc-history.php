<?php

if (!defined('ABSPATH')) {
    exit;
}

class QCOD_History
{
    public static function log($snippet_id, $old_values, $new_values)
    {
        global $wpdb;

        $snippet_id = absint($snippet_id);
        if (!$snippet_id) {
            return;
        }

        $wpdb->insert(
            qcod_table_history(),
            array(
                'snippet_id' => $snippet_id,
                'changed_by' => get_current_user_id(),
                'changed_at' => qcod_now_mysql(),
                'old_values_json' => wp_json_encode($old_values),
                'new_values_json' => wp_json_encode($new_values),
            ),
            array('%d', '%d', '%s', '%s', '%s')
        );
    }

    public static function get_rows($limit = 100)
    {
        global $wpdb;

        $limit = max(1, absint($limit));
        $table = qcod_table_history();

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT h.*, s.title AS snippet_title
                FROM {$table} h
                LEFT JOIN " . qcod_table_snippets() . " s ON s.id = h.snippet_id
                ORDER BY h.changed_at DESC
                LIMIT %d",
                $limit
            ),
            ARRAY_A
        );
    }
}
