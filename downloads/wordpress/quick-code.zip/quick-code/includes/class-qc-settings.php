<?php

if (!defined('ABSPATH')) {
    exit;
}

class QCOD_Settings
{
    public static function init()
    {
        add_action('admin_init', array(__CLASS__, 'handle_save'));
    }

    public static function handle_save()
    {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }

        if (empty($_POST['qcod_action']) || $_POST['qcod_action'] !== 'save_settings') {
            return;
        }

        check_admin_referer('qcod_save_settings');

        $settings = qcod_get_settings();
        $settings['enable_global'] = empty($_POST['enable_global']) ? 0 : 1;
        $settings['enable_per_page'] = empty($_POST['enable_per_page']) ? 0 : 1;
        $settings['default_css_location'] = self::sanitize_location(isset($_POST['default_css_location']) ? wp_unslash($_POST['default_css_location']) : 'head', 'head');
        $settings['default_js_location'] = self::sanitize_location(isset($_POST['default_js_location']) ? wp_unslash($_POST['default_js_location']) : 'body_close', 'body_close');
        $settings['body_open_fallback'] = empty($_POST['body_open_fallback']) ? 0 : 1;
        $settings['disable_all'] = empty($_POST['disable_all']) ? 0 : 1;
        $settings['exclude_admins'] = empty($_POST['exclude_admins']) ? 0 : 1;
        $settings['respect_dnt'] = empty($_POST['respect_dnt']) ? 0 : 1;
        $settings['disable_on_preview'] = empty($_POST['disable_on_preview']) ? 0 : 1;

        update_option('qcod_settings', $settings);
        qcod_invalidate_cache();

        wp_safe_redirect(add_query_arg('qcod_notice', 'settings_saved', admin_url('admin.php?page=qc-settings')));
        exit;
    }

    public static function render_page()
    {
        $settings = qcod_get_settings();
        $notice = isset($_GET['qcod_notice']) ? sanitize_key(wp_unslash($_GET['qcod_notice'])) : '';
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Quick Code Settings', 'quick-code'); ?></h1>
            <?php if (in_array($notice, array('settings_saved', 'import_success', 'import_error', 'import_invalid'), true)) : ?>
                <div class="notice notice-<?php echo esc_attr(in_array($notice, array('import_error', 'import_invalid'), true) ? 'error' : 'success'); ?> is-dismissible">
                    <p>
                        <?php
                        if ($notice === 'settings_saved') {
                            esc_html_e('Settings saved.', 'quick-code');
                        } elseif ($notice === 'import_success') {
                            esc_html_e('Import completed successfully.', 'quick-code');
                        } elseif ($notice === 'import_error') {
                            esc_html_e('Import failed. Unable to read file.', 'quick-code');
                        } elseif ($notice === 'import_invalid') {
                            esc_html_e('Import failed. Invalid JSON schema.', 'quick-code');
                        }
                        ?>
                    </p>
                </div>
            <?php endif; ?>
            <form method="post" action="">
                <?php wp_nonce_field('qcod_save_settings'); ?>
                <input type="hidden" name="qcod_action" value="save_settings" />
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('Enable global injections', 'quick-code'); ?></th>
                        <td><label><input type="checkbox" name="enable_global" value="1" <?php checked(1, (int) $settings['enable_global']); ?> /> <?php esc_html_e('Enabled', 'quick-code'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Enable per-page injections', 'quick-code'); ?></th>
                        <td><label><input type="checkbox" name="enable_per_page" value="1" <?php checked(1, (int) $settings['enable_per_page']); ?> /> <?php esc_html_e('Enabled', 'quick-code'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Default CSS location', 'quick-code'); ?></th>
                        <td><?php self::render_location_select('default_css_location', $settings['default_css_location']); ?></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Default JS location', 'quick-code'); ?></th>
                        <td><?php self::render_location_select('default_js_location', $settings['default_js_location']); ?></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Fallback body_open injection', 'quick-code'); ?></th>
                        <td><label><input type="checkbox" name="body_open_fallback" value="1" <?php checked(1, (int) $settings['body_open_fallback']); ?> /> <?php esc_html_e('Enable JS fallback when wp_body_open is unavailable', 'quick-code'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Disable all snippets', 'quick-code'); ?></th>
                        <td><label><input type="checkbox" name="disable_all" value="1" <?php checked(1, (int) $settings['disable_all']); ?> /> <?php esc_html_e('Emergency switch (site-wide)', 'quick-code'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Exclude admins from snippets', 'quick-code'); ?></th>
                        <td><label><input type="checkbox" name="exclude_admins" value="1" <?php checked(1, (int) $settings['exclude_admins']); ?> /> <?php esc_html_e('Do not render snippets for users with manage_options', 'quick-code'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Respect Do Not Track', 'quick-code'); ?></th>
                        <td><label><input type="checkbox" name="respect_dnt" value="1" <?php checked(1, (int) $settings['respect_dnt']); ?> /> <?php esc_html_e('Skip snippets marked as marketing when DNT=1', 'quick-code'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><?php esc_html_e('Disable on preview', 'quick-code'); ?></th>
                        <td><label><input type="checkbox" name="disable_on_preview" value="1" <?php checked(1, (int) $settings['disable_on_preview']); ?> /> <?php esc_html_e('Do not inject snippets on post preview screens', 'quick-code'); ?></label></td>
                    </tr>
                </table>
                <?php submit_button(__('Save Settings', 'quick-code')); ?>
            </form>

            <hr />
            <h2><?php esc_html_e('Export Snippets', 'quick-code'); ?></h2>
            <p><?php esc_html_e('Download all snippets and mappings as JSON.', 'quick-code'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('qcod_export_snippets'); ?>
                <input type="hidden" name="action" value="qcod_export_snippets" />
                <?php submit_button(__('Export JSON', 'quick-code'), 'secondary', 'submit', false); ?>
            </form>

            <hr />
            <h2><?php esc_html_e('Import Snippets', 'quick-code'); ?></h2>
            <p><?php esc_html_e('Import snippets from a Quick Code JSON file.', 'quick-code'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
                <?php wp_nonce_field('qcod_import_snippets'); ?>
                <input type="hidden" name="action" value="qcod_import_snippets" />
                <input type="file" name="qcod_import_file" accept="application/json,.json" required />
                <?php submit_button(__('Import JSON', 'quick-code'), 'secondary', 'submit', false); ?>
            </form>
        </div>
        <?php
    }

    private static function sanitize_location($value, $default)
    {
        $value = sanitize_key($value);
        $allowed = array('head', 'body_open', 'body_close');
        return in_array($value, $allowed, true) ? $value : $default;
    }

    private static function render_location_select($name, $selected)
    {
        $options = array(
            'head' => __('Head', 'quick-code'),
            'body_open' => __('Body Open', 'quick-code'),
            'body_close' => __('Body Close', 'quick-code'),
        );

        echo '<select name="' . esc_attr($name) . '">';
        foreach ($options as $value => $label) {
            echo '<option value="' . esc_attr($value) . '" ' . selected($selected, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
    }
}
