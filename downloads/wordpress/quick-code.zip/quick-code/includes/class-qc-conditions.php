<?php

if (!defined('ABSPATH')) {
    exit;
}

class QCOD_Conditions
{
    public static function should_skip_runtime()
    {
        $settings = qcod_get_settings();

        if (defined('QUICK_CODE_SAFE_MODE') && QUICK_CODE_SAFE_MODE) {
            return true;
        }

        if (!empty($settings['disable_all'])) {
            return true;
        }

        if (is_admin()) {
            return true;
        }

        if (self::is_login_request()) {
            return true;
        }

        if (self::is_rest_request()) {
            return true;
        }

        if (is_feed()) {
            return true;
        }

        if (!empty($settings['disable_on_preview']) && is_preview()) {
            return true;
        }

        return false;
    }

    public static function matches($snippet, $context = array())
    {
        $settings = qcod_get_settings();
        $conditions = qcod_normalize_conditions($snippet['conditions_json']);

        if (!empty($settings['exclude_admins']) && qcod_user_is_adminish()) {
            return false;
        }

        if (!empty($conditions['marketing_script']) && !empty($settings['respect_dnt']) && self::has_dnt_enabled()) {
            return false;
        }

        if (!empty($conditions['preview_admin_only']) && !qcod_user_is_adminish()) {
            return false;
        }

        if (!empty($conditions['test_mode']) && !qcod_is_test_mode_enabled_for_user()) {
            return false;
        }

        if (!self::matches_auth($conditions)) {
            return false;
        }

        if (!self::matches_roles($conditions)) {
            return false;
        }

        if (!self::matches_schedule($conditions)) {
            return false;
        }

        if (!self::matches_device($conditions)) {
            return false;
        }

        if (!self::matches_post_type($conditions, $context)) {
            return false;
        }

        if (!self::matches_ids($conditions, $context)) {
            return false;
        }

        if (!self::matches_path($conditions, $context)) {
            return false;
        }

        return true;
    }

    public static function detect_device()
    {
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';

        if ($ua === '') {
            return 'desktop';
        }

        if (strpos($ua, 'ipad') !== false || strpos($ua, 'tablet') !== false || strpos($ua, 'kindle') !== false) {
            return 'tablet';
        }

        if (strpos($ua, 'mobi') !== false || strpos($ua, 'android') !== false || strpos($ua, 'iphone') !== false) {
            return 'mobile';
        }

        return 'desktop';
    }

    public static function current_path()
    {
        $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
        $path = wp_parse_url($request_uri, PHP_URL_PATH);
        $path = is_string($path) ? $path : '/';

        if ($path === '') {
            $path = '/';
        }

        return untrailingslashit($path) ?: '/';
    }

    private static function has_dnt_enabled()
    {
        if (!isset($_SERVER['HTTP_DNT'])) {
            return false;
        }

        return trim((string) wp_unslash($_SERVER['HTTP_DNT'])) === '1';
    }

    private static function matches_auth($conditions)
    {
        if (!empty($conditions['logged_in_only']) && !is_user_logged_in()) {
            return false;
        }

        if (!empty($conditions['logged_out_only']) && is_user_logged_in()) {
            return false;
        }

        return true;
    }

    private static function matches_roles($conditions)
    {
        if (empty($conditions['roles'])) {
            return true;
        }

        if (!is_user_logged_in()) {
            return false;
        }

        $user = wp_get_current_user();
        if (!$user || empty($user->roles)) {
            return false;
        }

        return (bool) array_intersect($conditions['roles'], $user->roles);
    }

    private static function matches_schedule($conditions)
    {
        $now_ts = current_time('timestamp');

        if (!empty($conditions['schedule_start'])) {
            $start_ts = strtotime($conditions['schedule_start']);
            if ($start_ts !== false && $now_ts < $start_ts) {
                return false;
            }
        }

        if (!empty($conditions['schedule_end'])) {
            $end_ts = strtotime($conditions['schedule_end']);
            if ($end_ts !== false && $now_ts > $end_ts) {
                return false;
            }
        }

        return true;
    }

    private static function matches_device($conditions)
    {
        if (empty($conditions['devices'])) {
            return true;
        }

        return in_array(self::detect_device(), $conditions['devices'], true);
    }

    private static function matches_post_type($conditions, $context)
    {
        $post_type = '';

        if (!empty($context['post_type'])) {
            $post_type = sanitize_key($context['post_type']);
        } elseif (is_singular()) {
            $post_type = get_post_type() ?: '';
        }

        if (!empty($conditions['include_post_types'])) {
            if ($post_type === '' || !in_array($post_type, $conditions['include_post_types'], true)) {
                return false;
            }
        }

        if (!empty($conditions['exclude_post_types']) && $post_type !== '') {
            if (in_array($post_type, $conditions['exclude_post_types'], true)) {
                return false;
            }
        }

        return true;
    }

    private static function matches_ids($conditions, $context)
    {
        $object_id = 0;

        if (!empty($context['object_id'])) {
            $object_id = absint($context['object_id']);
        } elseif (is_singular()) {
            $object_id = get_queried_object_id();
        }

        if (!empty($conditions['include_ids'])) {
            if (!$object_id || !in_array($object_id, $conditions['include_ids'], true)) {
                return false;
            }
        }

        if (!empty($conditions['exclude_ids']) && $object_id) {
            if (in_array($object_id, $conditions['exclude_ids'], true)) {
                return false;
            }
        }

        return true;
    }

    private static function matches_path($conditions, $context)
    {
        $path = !empty($context['path']) ? (string) $context['path'] : self::current_path();
        $path = untrailingslashit($path) ?: '/';

        if (!empty($conditions['path_exact'])) {
            $matched = false;
            foreach ($conditions['path_exact'] as $exact) {
                $normalized = untrailingslashit($exact) ?: '/';
                if ($normalized === $path) {
                    $matched = true;
                    break;
                }
            }
            if (!$matched) {
                return false;
            }
        }

        if (!empty($conditions['path_contains'])) {
            $matched = false;
            foreach ($conditions['path_contains'] as $contains) {
                if ($contains !== '' && strpos($path, $contains) !== false) {
                    $matched = true;
                    break;
                }
            }
            if (!$matched) {
                return false;
            }
        }

        return true;
    }

    private static function is_login_request()
    {
        global $pagenow;
        return isset($pagenow) && $pagenow === 'wp-login.php';
    }

    private static function is_rest_request()
    {
        if (defined('REST_REQUEST') && REST_REQUEST) {
            return true;
        }

        if (function_exists('wp_is_json_request') && wp_is_json_request()) {
            return true;
        }

        if (function_exists('rest_get_url_prefix')) {
            $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';
            if (strpos($request_uri, rest_get_url_prefix()) !== false) {
                return true;
            }
        }

        return false;
    }
}
