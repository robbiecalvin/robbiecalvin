<?php

if (!defined('ABSPATH')) {
    exit;
}

class QCOD_Metabox
{
    public static function init()
    {
        add_action('add_meta_boxes', array(__CLASS__, 'register_metabox'));
        add_action('save_post', array(__CLASS__, 'save_metabox'), 10, 2);
    }

    public static function register_metabox()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $post_types = get_post_types(array('public' => true), 'names');
        foreach ($post_types as $post_type) {
            add_meta_box(
                'qc-metabox',
                __('Quick Code', 'quick-code'),
                array(__CLASS__, 'render_metabox'),
                $post_type,
                'side',
                'default'
            );
        }
    }

    public static function render_metabox($post)
    {
        wp_nonce_field('qcod_metabox_save', 'qcod_metabox_nonce');
        $license_valid = qcod_is_premium_active();
        if (!$license_valid) {
            echo '<p>' . esc_html__('Professional license is required for per-page snippet management.', 'quick-code') . '</p>';
            echo '<p><a class="button button-primary" href="/pricing/">' . esc_html__('Upgrade to Professional', 'quick-code') . '</a></p>';
            return;
        }

        $snippets = self::get_all_per_page_snippets();
        $attached = self::get_attached_ids($post->ID);
        $page_test_mode_enabled = qcod_is_page_test_mode_enabled_for_user($post->ID, get_current_user_id());
        ?>
        <p><strong><?php esc_html_e('Attach Existing Per-Page Snippets', 'quick-code'); ?></strong></p>
        <div class="qc-metabox-list">
            <?php if (empty($snippets)) : ?>
                <p><?php esc_html_e('No per-page snippets found.', 'quick-code'); ?></p>
            <?php else : ?>
                <?php foreach ($snippets as $snippet) : ?>
                    <label class="qc-metabox-item">
                        <input type="checkbox" name="qcod_attached_snippets[]" value="<?php echo (int) $snippet['id']; ?>" <?php checked(in_array((int) $snippet['id'], $attached, true)); ?> />
                        <?php echo esc_html($snippet['title']); ?>
                    </label>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <hr />
        <p><strong><?php esc_html_e('Quick Create Snippet', 'quick-code'); ?></strong></p>
        <p><input type="text" class="widefat" name="qcod_quick_title" placeholder="<?php esc_attr_e('Snippet title', 'quick-code'); ?>" /></p>
        <p>
            <select name="qcod_quick_type" class="widefat">
                <option value="html"><?php esc_html_e('HTML', 'quick-code'); ?></option>
                <option value="css"><?php esc_html_e('CSS', 'quick-code'); ?></option>
                <option value="js"><?php esc_html_e('JS', 'quick-code'); ?></option>
            </select>
        </p>
        <p>
            <select name="qcod_quick_location" class="widefat">
                <option value="head"><?php esc_html_e('Head', 'quick-code'); ?></option>
                <option value="body_open"><?php esc_html_e('Body Open', 'quick-code'); ?></option>
                <option value="body_close"><?php esc_html_e('Body Close', 'quick-code'); ?></option>
            </select>
        </p>
        <p><textarea class="widefat" rows="6" name="qcod_quick_code" placeholder="<?php esc_attr_e('Code snippet', 'quick-code'); ?>"></textarea></p>
        <p>
            <label>
                <input type="checkbox" name="qcod_page_test_mode" value="1" <?php checked($page_test_mode_enabled); ?> />
                <?php esc_html_e('Enable test mode for this page (current admin session)', 'quick-code'); ?>
            </label>
        </p>
        <?php
    }

    public static function save_metabox($post_id, $post)
    {
        if (!qcod_is_premium_active()) {
            return;
        }
        if (!current_user_can('manage_options')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!isset($_POST['qcod_metabox_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['qcod_metabox_nonce'])), 'qcod_metabox_save')) {
            return;
        }

        if (!in_array($post->post_status, array('publish', 'draft', 'pending', 'future', 'private'), true)) {
            return;
        }

        QCOD_Admin::remove_post_mappings($post_id);

        $attached_ids = array();
        if (!empty($_POST['qcod_attached_snippets']) && is_array($_POST['qcod_attached_snippets'])) {
            foreach ($_POST['qcod_attached_snippets'] as $snippet_id) {
                $attached_ids[] = absint($snippet_id);
            }
            $attached_ids = array_values(array_unique(array_filter($attached_ids)));
        }

        foreach ($attached_ids as $snippet_id) {
            QCOD_Admin::attach_snippet_to_post($snippet_id, $post_id);
        }

        $quick_title = isset($_POST['qcod_quick_title']) ? sanitize_text_field(wp_unslash($_POST['qcod_quick_title'])) : '';
        $quick_code = isset($_POST['qcod_quick_code']) ? wp_unslash($_POST['qcod_quick_code']) : '';

        if ($quick_title !== '' && trim($quick_code) !== '') {
            $new_id = self::create_quick_snippet(
                $quick_title,
                isset($_POST['qcod_quick_type']) ? sanitize_key(wp_unslash($_POST['qcod_quick_type'])) : 'html',
                isset($_POST['qcod_quick_location']) ? sanitize_key(wp_unslash($_POST['qcod_quick_location'])) : 'head',
                $quick_code
            );

            if ($new_id) {
                QCOD_Admin::attach_snippet_to_post($new_id, $post_id);
            }
        }

        $user_id = get_current_user_id();
        if (!empty($_POST['qcod_page_test_mode'])) {
            qcod_set_page_test_mode_for_user($post_id, $user_id, true);
        } else {
            qcod_set_page_test_mode_for_user($post_id, $user_id, false);
        }
    }

    private static function get_all_per_page_snippets()
    {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, title FROM ' . qcod_table_snippets() . ' WHERE scope = %s ORDER BY priority ASC, title ASC',
                'per_page'
            ),
            ARRAY_A
        );
    }

    private static function get_attached_ids($post_id)
    {
        global $wpdb;

        return array_map('absint', $wpdb->get_col(
            $wpdb->prepare(
                'SELECT snippet_id FROM ' . qcod_table_map() . ' WHERE object_type = %s AND object_id = %d',
                'post',
                absint($post_id)
            )
        ));
    }

    private static function create_quick_snippet($title, $type, $location, $code)
    {
        global $wpdb;

        if (!in_array($type, array('html', 'css', 'js'), true)) {
            $type = 'html';
        }

        if (!in_array($location, array('head', 'body_open', 'body_close'), true)) {
            $location = 'head';
        }

        $data = array(
            'scope' => 'per_page',
            'title' => $title,
            'snippet_type' => $type,
            'location' => $location,
            'code' => $code,
            'conditions_json' => wp_json_encode(qcod_normalize_conditions(array())),
            'status' => 'enabled',
            'priority' => 10,
            'created_by' => get_current_user_id(),
            'created_at' => qcod_now_mysql(),
            'updated_at' => qcod_now_mysql(),
        );

        $wpdb->insert(
            qcod_table_snippets(),
            $data,
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s')
        );

        $new_id = (int) $wpdb->insert_id;

        if ($new_id) {
            QCOD_History::log($new_id, array(), $data);
            qcod_invalidate_cache();
        }

        return $new_id;
    }
}
