(function () {
    function updateCharCount() {
        var textarea = document.getElementById('qc-code');
        var counter = document.getElementById('qc-char-count');
        var warning = document.getElementById('qc-large-warning');

        if (!textarea || !counter || !warning) {
            return;
        }

        var length = textarea.value.length;
        counter.textContent = String(length);

        if (length > 50000) {
            warning.style.display = 'block';
        } else {
            warning.style.display = 'none';
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        var textarea = document.getElementById('qc-code');
        if (!textarea) {
            return;
        }

        updateCharCount();
        textarea.addEventListener('input', updateCharCount);
    });
})();
