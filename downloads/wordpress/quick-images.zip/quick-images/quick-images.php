<?php
/**
 * Plugin Name: Quick Images
 * Plugin URI: https://quickwoo.pro
 * Description: Bulk product image processor for logo and watermark overlays with WordPress media integration.
 * Version: 1.1.0
 * Author: QuickWoo by Robbie Calvin
 * Author URI: https://quickwoo.pro
 * License: GPL-2.0-or-later
 * Text Domain: quick-images
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class QIMG_Processor {
    public const OPTION_WATERMARK_ID = 'qimg_watermark_id';
    public const OPTION_LOGO_ID = 'qimg_logo_id';

    public function process_batch( array $files, array $names, bool $is_premium ): array {
        $results = array(
            'success' => array(),
            'errors'  => array(),
        );

        if ( ! function_exists( 'wp_handle_upload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $normalized = $this->normalize_multi_upload( $files );
        if ( empty( $normalized ) ) {
            $results['errors'][] = __( 'No image files were provided.', 'quick-images' );
            return $results;
        }

        if ( count( $normalized ) !== count( $names ) ) {
            $results['errors'][] = __( 'Uploaded image count must match product name count.', 'quick-images' );
            return $results;
        }

        if ( ! $is_premium && count( $normalized ) > 2 ) {
            $results['errors'][] = __( 'Free version allows processing up to 2 images per submission.', 'quick-images' );
            return $results;
        }

        $watermark_id = (int) get_option( self::OPTION_WATERMARK_ID, 0 );
        $logo_id      = (int) get_option( self::OPTION_LOGO_ID, 0 );

        $watermark_path = $watermark_id ? (string) get_attached_file( $watermark_id ) : '';
        $logo_path      = $logo_id ? (string) get_attached_file( $logo_id ) : '';

        if ( '' === $watermark_path || ! file_exists( $watermark_path ) ) {
            $results['errors'][] = __( 'A valid watermark image is required.', 'quick-images' );
            return $results;
        }

        if ( '' === $logo_path || ! file_exists( $logo_path ) ) {
            $results['errors'][] = __( 'A valid company logo is required.', 'quick-images' );
            return $results;
        }

        foreach ( $normalized as $index => $file ) {
            try {
                $name = sanitize_text_field( $names[ $index ] ?? '' );
                if ( '' === $name ) {
                    $results['errors'][] = sprintf( __( 'Image %d skipped because name is empty.', 'quick-images' ), ( $index + 1 ) );
                    continue;
                }

                if ( ! empty( $file['error'] ) ) {
                    $results['errors'][] = sprintf( __( 'Upload failed for %1$s (error %2$d).', 'quick-images' ), esc_html( (string) $file['name'] ), (int) $file['error'] );
                    continue;
                }

                $uploaded = wp_handle_upload(
                    $file,
                    array(
                        'test_form' => false,
                        'mimes'     => array(
                            'jpg|jpeg|jpe' => 'image/jpeg',
                            'png'          => 'image/png',
                            'gif'          => 'image/gif',
                            'webp'         => 'image/webp',
                        ),
                    )
                );

                if ( ! is_array( $uploaded ) || isset( $uploaded['error'] ) ) {
                    $results['errors'][] = sprintf( __( 'Could not upload %1$s: %2$s', 'quick-images' ), esc_html( (string) $file['name'] ), esc_html( (string) ( $uploaded['error'] ?? 'unknown' ) ) );
                    continue;
                }

                $source_path = (string) $uploaded['file'];
                $source_path = $this->resize_if_needed( $source_path, 2200 );

                $composed = $this->compose_image( $source_path, $watermark_path, $logo_path );
                if ( is_wp_error( $composed ) ) {
                    $results['errors'][] = sprintf( __( 'Processing failed for %1$s: %2$s', 'quick-images' ), esc_html( $name ), esc_html( $composed->get_error_message() ) );
                    wp_delete_file( $source_path );
                    continue;
                }

                $target = $this->make_target_path( $name, $source_path );
                if ( is_wp_error( $target ) ) {
                    $results['errors'][] = sprintf( __( 'Could not prepare file for %1$s.', 'quick-images' ), esc_html( $name ) );
                    wp_delete_file( $source_path );
                    continue;
                }

                $saved = $this->save_image_resource( $composed['resource'], $target['path'], $target['ext'] );
                imagedestroy( $composed['resource'] );

                if ( ! $saved ) {
                    $results['errors'][] = sprintf( __( 'Could not save processed image for %1$s.', 'quick-images' ), esc_html( $name ) );
                    wp_delete_file( $source_path );
                    continue;
                }

                $attachment_id = $this->insert_attachment( $target['path'], $name );
                if ( is_wp_error( $attachment_id ) ) {
                    $results['errors'][] = sprintf( __( 'Image created but Media Library insert failed for %1$s.', 'quick-images' ), esc_html( $name ) );
                    wp_delete_file( $source_path );
                    continue;
                }

                wp_delete_file( $source_path );

                $results['success'][] = array(
                    'name'     => $name,
                    'media_id' => (int) $attachment_id,
                );
            } catch ( Throwable $e ) {
                $results['errors'][] = sprintf( __( 'Unexpected failure on image %1$d: %2$s', 'quick-images' ), ( $index + 1 ), esc_html( $e->getMessage() ) );
            }
        }

        return $results;
    }

    private function resize_if_needed( string $source_path, int $max_size ): string {
        $editor = wp_get_image_editor( $source_path );
        if ( is_wp_error( $editor ) ) {
            return $source_path;
        }

        $size = $editor->get_size();
        $width  = isset( $size['width'] ) ? (int) $size['width'] : 0;
        $height = isset( $size['height'] ) ? (int) $size['height'] : 0;

        if ( $width <= $max_size && $height <= $max_size ) {
            return $source_path;
        }

        $editor->resize( $max_size, $max_size, false );
        $saved = $editor->save( $source_path );
        if ( is_wp_error( $saved ) || empty( $saved['path'] ) ) {
            return $source_path;
        }

        return (string) $saved['path'];
    }

    private function compose_image( string $base_path, string $watermark_path, string $logo_path ) {
        $base      = $this->load_image_resource( $base_path );
        $watermark = $this->load_image_resource( $watermark_path );
        $logo      = $this->load_image_resource( $logo_path );

        if ( ! $base || ! $watermark || ! $logo ) {
            if ( $base ) {
                imagedestroy( $base );
            }
            if ( $watermark ) {
                imagedestroy( $watermark );
            }
            if ( $logo ) {
                imagedestroy( $logo );
            }
            return new WP_Error( 'qimg_invalid_resource', __( 'Unable to load image resources.', 'quick-images' ) );
        }

        $base_w = imagesx( $base );
        $base_h = imagesy( $base );

        // Watermark centered with scaled overlay footprint.
        $wm_scale = 0.72;
        $wm_w = max( 1, (int) floor( $base_w * $wm_scale ) );
        $wm_h = max( 1, (int) floor( $base_h * $wm_scale ) );
        $wm_x = (int) floor( ( $base_w - $wm_w ) / 2 );
        $wm_y = (int) floor( ( $base_h - $wm_h ) / 2 );
        $this->overlay_image( $base, $watermark, $wm_x, $wm_y, $wm_w, $wm_h, 45 );

        // Company logo in bottom-left with 20px margin.
        $margin = 20;
        $logo_w = max( 1, (int) floor( $base_w * 0.20 ) );
        $logo_h = max( 1, (int) floor( $logo_w * ( imagesy( $logo ) / max( imagesx( $logo ), 1 ) ) ) );
        $logo_x = $margin;
        $logo_y = max( 0, $base_h - $logo_h - $margin );
        $this->overlay_image( $base, $logo, $logo_x, $logo_y, $logo_w, $logo_h, 100 );

        imagedestroy( $watermark );
        imagedestroy( $logo );

        return array(
            'resource' => $base,
        );
    }

    private function overlay_image( $base, $overlay, int $dst_x, int $dst_y, int $new_w, int $new_h, int $opacity = 100 ): void {
        $temp = imagecreatetruecolor( $new_w, $new_h );
        imagealphablending( $temp, false );
        imagesavealpha( $temp, true );
        $transparent = imagecolorallocatealpha( $temp, 0, 0, 0, 127 );
        imagefilledrectangle( $temp, 0, 0, $new_w, $new_h, $transparent );

        imagecopyresampled( $temp, $overlay, 0, 0, 0, 0, $new_w, $new_h, imagesx( $overlay ), imagesy( $overlay ) );

        if ( $opacity >= 100 ) {
            imagecopy( $base, $temp, $dst_x, $dst_y, 0, 0, $new_w, $new_h );
        } else {
            imagecopymerge( $base, $temp, $dst_x, $dst_y, 0, 0, $new_w, $new_h, $opacity );
        }

        imagedestroy( $temp );
    }

    private function load_image_resource( string $path ) {
        if ( ! file_exists( $path ) ) {
            return null;
        }

        $mime = wp_get_image_mime( $path );
        if ( ! $mime ) {
            return null;
        }

        switch ( $mime ) {
            case 'image/jpeg':
                $img = imagecreatefromjpeg( $path );
                break;
            case 'image/png':
                $img = imagecreatefrompng( $path );
                break;
            case 'image/gif':
                $img = imagecreatefromgif( $path );
                break;
            case 'image/webp':
                if ( ! function_exists( 'imagecreatefromwebp' ) ) {
                    return null;
                }
                $img = imagecreatefromwebp( $path );
                break;
            default:
                return null;
        }

        if ( ! is_resource( $img ) && ! is_object( $img ) ) {
            return null;
        }

        imagealphablending( $img, true );
        imagesavealpha( $img, true );

        return $img;
    }

    private function make_target_path( string $name, string $source_path ) {
        $upload_dir = wp_upload_dir();
        if ( ! empty( $upload_dir['error'] ) ) {
            return new WP_Error( 'qimg_upload_dir', (string) $upload_dir['error'] );
        }

        $base_name = sanitize_file_name( remove_accents( $name ) );
        if ( '' === $base_name ) {
            $base_name = 'quick-image';
        }

        $ext = strtolower( (string) pathinfo( $source_path, PATHINFO_EXTENSION ) );
        if ( ! in_array( $ext, array( 'jpg', 'jpeg', 'png', 'gif', 'webp' ), true ) ) {
            $ext = 'jpg';
        }

        $filename = wp_unique_filename( $upload_dir['path'], $base_name . '.' . $ext );

        return array(
            'path' => trailingslashit( $upload_dir['path'] ) . $filename,
            'ext'  => $ext,
        );
    }

    private function save_image_resource( $resource, string $path, string $ext ): bool {
        switch ( $ext ) {
            case 'jpg':
            case 'jpeg':
                return imagejpeg( $resource, $path, 90 );
            case 'png':
                return imagepng( $resource, $path, 6 );
            case 'gif':
                return imagegif( $resource, $path );
            case 'webp':
                if ( function_exists( 'imagewebp' ) ) {
                    return imagewebp( $resource, $path, 90 );
                }
                return imagejpeg( $resource, $path, 90 );
            default:
                return imagejpeg( $resource, $path, 90 );
        }
    }

    private function insert_attachment( string $path, string $name ) {
        $filetype   = wp_check_filetype( $path );
        $slug       = sanitize_title( $name );
        $attachment = array(
            'post_mime_type' => (string) ( $filetype['type'] ?? 'image/jpeg' ),
            'post_title'     => sanitize_text_field( $name ),
            'post_name'      => $slug,
            'post_content'   => '',
            'post_status'    => 'inherit',
        );

        $attachment_id = wp_insert_attachment( $attachment, $path );
        if ( is_wp_error( $attachment_id ) ) {
            return $attachment_id;
        }

        $metadata = wp_generate_attachment_metadata( $attachment_id, $path );
        if ( ! is_wp_error( $metadata ) ) {
            wp_update_attachment_metadata( $attachment_id, $metadata );
        }

        update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $name ) );

        return (int) $attachment_id;
    }

    private function normalize_multi_upload( array $files ): array {
        $normalized = array();

        if ( empty( $files['name'] ) || ! is_array( $files['name'] ) ) {
            return $normalized;
        }

        foreach ( $files['name'] as $i => $name ) {
            $tmp = $files['tmp_name'][ $i ] ?? '';
            if ( '' === $tmp ) {
                continue;
            }

            $normalized[] = array(
                'name'     => (string) $name,
                'type'     => (string) ( $files['type'][ $i ] ?? '' ),
                'tmp_name' => (string) $tmp,
                'error'    => (int) ( $files['error'][ $i ] ?? 0 ),
                'size'     => (int) ( $files['size'][ $i ] ?? 0 ),
            );
        }

        return $normalized;
    }
}

final class QIMG_Admin {
    private $processor;

    public function __construct( QIMG_Processor $processor ) {
        $this->processor = $processor;
    }

    public function hooks(): void {
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
        add_action( 'admin_post_qimg_save_assets', array( $this, 'handle_save_assets' ) );
        add_action( 'admin_post_qimg_process_batch', array( $this, 'handle_process_batch' ) );
    }

    public function register_menu(): void {
        add_submenu_page(
            'quickwoo',
            __( 'Quick Images', 'quick-images' ),
            __( 'Quick Images', 'quick-images' ),
            'upload_files',
            'quick-images',
            array( $this, 'render_page' )
        );

        add_menu_page(
            __( 'Quick Images', 'quick-images' ),
            __( 'Quick Images', 'quick-images' ),
            'upload_files',
            'quick-images',
            array( $this, 'render_page' ),
            'dashicons-format-gallery',
            27
        );
    }

    public function enqueue( string $hook ): void {
        if ( 'toplevel_page_quick-images' !== $hook ) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style( 'qimg-admin', plugin_dir_url( __FILE__ ) . 'assets/admin.css', array(), '1.1.0' );
        wp_enqueue_script( 'qimg-admin', plugin_dir_url( __FILE__ ) . 'assets/admin.js', array( 'jquery' ), '1.1.0', true );
    }

    public function handle_save_assets(): void {
        if ( ! current_user_can( 'upload_files' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-images' ) );
        }

        check_admin_referer( 'qimg_save_assets', 'qimg_nonce' );

        $watermark_id = absint( $_POST['qimg_watermark_id'] ?? 0 );
        $logo_id      = absint( $_POST['qimg_logo_id'] ?? 0 );

        if ( $watermark_id > 0 && ! wp_attachment_is_image( $watermark_id ) ) {
            $this->set_flash( array(), array( __( 'Watermark must be an image.', 'quick-images' ) ) );
            wp_safe_redirect( admin_url( 'admin.php?page=quick-images' ) );
            exit;
        }

        if ( $logo_id > 0 && ! wp_attachment_is_image( $logo_id ) ) {
            $this->set_flash( array(), array( __( 'Logo must be an image.', 'quick-images' ) ) );
            wp_safe_redirect( admin_url( 'admin.php?page=quick-images' ) );
            exit;
        }

        update_option( QIMG_Processor::OPTION_WATERMARK_ID, $watermark_id );
        update_option( QIMG_Processor::OPTION_LOGO_ID, $logo_id );

        $this->set_flash( array( __( 'Brand assets saved.', 'quick-images' ) ), array() );
        wp_safe_redirect( admin_url( 'admin.php?page=quick-images' ) );
        exit;
    }

    public function handle_process_batch(): void {
        if ( ! current_user_can( 'upload_files' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-images' ) );
        }

        check_admin_referer( 'qimg_process_batch', 'qimg_nonce' );

        $names_raw = isset( $_POST['qimg_product_names'] ) ? (string) wp_unslash( $_POST['qimg_product_names'] ) : '';
        $names     = array_values( array_filter( array_map( 'sanitize_text_field', preg_split( '/\r\n|\r|\n/', $names_raw ) ) ) );

        $result = $this->processor->process_batch( $_FILES['qimg_images'] ?? array(), $names, qimg_is_premium() );

        $messages = array();
        if ( ! empty( $result['success'] ) ) {
            $messages[] = sprintf( __( 'Processed %d image(s) successfully.', 'quick-images' ), count( $result['success'] ) );
            foreach ( $result['success'] as $item ) {
                $messages[] = sprintf( __( '%1$s saved (Media ID: %2$d).', 'quick-images' ), (string) $item['name'], (int) $item['media_id'] );
            }
        }

        $this->set_flash( $messages, $result['errors'] ?? array() );
        wp_safe_redirect( admin_url( 'admin.php?page=quick-images' ) );
        exit;
    }

    public function render_page(): void {
        if ( ! current_user_can( 'upload_files' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'quick-images' ) );
        }

        $watermark_id = (int) get_option( QIMG_Processor::OPTION_WATERMARK_ID, 0 );
        $logo_id      = (int) get_option( QIMG_Processor::OPTION_LOGO_ID, 0 );

        $watermark_url = $watermark_id ? wp_get_attachment_url( $watermark_id ) : '';
        $logo_url      = $logo_id ? wp_get_attachment_url( $logo_id ) : '';

        $flash = get_transient( 'qimg_flash_' . get_current_user_id() );
        if ( is_array( $flash ) ) {
            delete_transient( 'qimg_flash_' . get_current_user_id() );
        } else {
            $flash = array( 'messages' => array(), 'errors' => array() );
        }

        echo '<div class="wrap wqpsp-wrap">';
        echo '<h1>' . esc_html__( 'Quick Images', 'quick-images' ) . '</h1>';
        echo '<p>' . esc_html__( 'Batch process product images with watermark and logo overlays, then save to Media Library.', 'quick-images' ) . '</p>';

        if ( ! qimg_is_premium() ) {
            echo '<div class="notice notice-info"><p>';
            echo esc_html__( 'Free version supports up to 2 images per batch.', 'quick-images' );
            echo ' <a href="' . esc_url( 'https://quickwoo.pro/pricing/' ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Upgrade to Pro', 'quick-images' ) . '</a>';
            echo '</p></div>';
        }

        foreach ( (array) $flash['errors'] as $error ) {
            echo '<div class="notice notice-error"><p>' . esc_html( (string) $error ) . '</p></div>';
        }

        foreach ( (array) $flash['messages'] as $message ) {
            echo '<div class="notice notice-success"><p>' . esc_html( (string) $message ) . '</p></div>';
        }

        echo '<div class="wqpsp-grid">';

        echo '<div class="wqpsp-card">';
        echo '<h2>' . esc_html__( 'Brand Assets', 'quick-images' ) . '</h2>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        wp_nonce_field( 'qimg_save_assets', 'qimg_nonce' );
        echo '<input type="hidden" name="action" value="qimg_save_assets" />';

        $this->render_media_field( 'qimg_watermark_id', __( 'Watermark Image', 'quick-images' ), $watermark_id, (string) $watermark_url );
        $this->render_media_field( 'qimg_logo_id', __( 'Company Logo', 'quick-images' ), $logo_id, (string) $logo_url );

        submit_button( __( 'Save Assets', 'quick-images' ) );
        echo '</form>';
        echo '</div>';

        echo '<div class="wqpsp-card">';
        echo '<h2>' . esc_html__( 'Batch Processing', 'quick-images' ) . '</h2>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" enctype="multipart/form-data">';
        wp_nonce_field( 'qimg_process_batch', 'qimg_nonce' );
        echo '<input type="hidden" name="action" value="qimg_process_batch" />';

        echo '<label for="qimg_images"><strong>' . esc_html__( 'Upload Product Images', 'quick-images' ) . '</strong></label>';
        echo '<input type="file" id="qimg_images" name="qimg_images[]" accept="image/*" multiple required />';

        echo '<label for="qimg_product_names"><strong>' . esc_html__( 'Product Names (one per line)', 'quick-images' ) . '</strong></label>';
        echo '<textarea id="qimg_product_names" name="qimg_product_names" rows="8" placeholder="Product A&#10;Product B" required></textarea>';

        echo '<p class="description">' . esc_html__( 'Image count must match name count exactly.', 'quick-images' ) . '</p>';
        submit_button( __( 'Process Images', 'quick-images' ), 'primary', 'submit', false );

        echo '</form>';
        echo '</div>';

        echo '</div>';
        echo '</div>';
    }

    private function render_media_field( string $field_name, string $label, int $attachment_id, string $preview_url ): void {
        echo '<div class="wqpsp-field">';
        echo '<label><strong>' . esc_html( $label ) . '</strong></label>';
        echo '<input type="hidden" id="' . esc_attr( $field_name ) . '" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( (string) $attachment_id ) . '" />';
        echo '<button type="button" class="button wqpsp-media-button" data-target="' . esc_attr( $field_name ) . '" data-library-type="image">' . esc_html__( 'Select From Media Library', 'quick-images' ) . '</button> ';
        echo '<button type="button" class="button wqpsp-clear-button" data-target="' . esc_attr( $field_name ) . '">' . esc_html__( 'Clear', 'quick-images' ) . '</button>';

        if ( '' !== $preview_url ) {
            echo '<img class="wqpsp-preview" src="' . esc_url( $preview_url ) . '" alt="" />';
        } else {
            echo '<img class="wqpsp-preview" src="" alt="" style="display:none;" />';
        }

        echo '</div>';
    }

    private function set_flash( array $messages, array $errors ): void {
        set_transient(
            'qimg_flash_' . get_current_user_id(),
            array(
                'messages' => array_map( 'sanitize_text_field', $messages ),
                'errors'   => array_map( 'sanitize_text_field', $errors ),
            ),
            MINUTE_IN_SECONDS
        );
    }
}

function qimg_is_premium(): bool {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

    return (bool) apply_filters( 'quick_images_is_premium', false );
}

add_action(
    'plugins_loaded',
    static function() {
        $processor = new QIMG_Processor();
        $admin = new QIMG_Admin( $processor );
        $admin->hooks();
    }
);

if ( ! function_exists( 'qwoo_quick_images_license_bootstrap' ) ) {
    function qwoo_quick_images_license_bootstrap() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu', 'qwoo_quick_images_license_menu' );
        add_action( 'admin_post_qwoo_quick_images_activate_license', 'qwoo_quick_images_license_handle_activate' );
        add_action( 'admin_post_qwoo_quick_images_deactivate_license', 'qwoo_quick_images_license_handle_deactivate' );
    }
    add_action( 'plugins_loaded', 'qwoo_quick_images_license_bootstrap', 30 );

    function qwoo_quick_images_license_option_key() {
        return 'qwoo_quick_images_license';
    }

    function qwoo_quick_images_license_product_scope() {
        return array( 'quick-images' );
    }

    function qwoo_quick_images_license_get_data() {
        $defaults = array(
            'license_key' => '',
            'license_status' => 'inactive',
            'license_message' => '',
        );

        $saved = get_option( qwoo_quick_images_license_option_key(), array() );
        $saved = is_array( $saved ) ? $saved : array();

        return wp_parse_args( $saved, $defaults );
    }

    function qwoo_quick_images_license_save_data( $data ) {
        $data = is_array( $data ) ? $data : array();

        $clean = array(
            'license_key' => sanitize_text_field( (string) ( $data['license_key'] ?? '' ) ),
            'license_status' => sanitize_key( (string) ( $data['license_status'] ?? 'inactive' ) ),
            'license_message' => sanitize_text_field( (string) ( $data['license_message'] ?? '' ) ),
        );

        update_option( qwoo_quick_images_license_option_key(), $clean, false );
        return $clean;
    }

    function qwoo_quick_images_license_menu() {
        add_options_page(
            'Limages License',
            'Limages License',
            'manage_options',
            'qwoo-quick-images-license',
            'qwoo_quick_images_license_render_page'
        );
    }

    function qwoo_quick_images_license_render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = qwoo_quick_images_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );

        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $status = qlic_get_license_status_for_key_products( $license_key, qwoo_quick_images_license_product_scope() );
            if ( is_array( $status ) ) {
                $data['license_status'] = sanitize_key( (string) ( $status['status'] ?? $data['license_status'] ) );
                $data['license_message'] = sanitize_text_field( (string) ( $status['message'] ?? $data['license_message'] ) );
                if ( ! empty( $status['valid'] ) && ! empty( $status['domain_active'] ) ) {
                    $data['license_status'] = 'active';
                }
                qwoo_quick_images_license_save_data( $data );
            }
        }

        $notice = isset( $_GET['qwoo_license_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qwoo_license_notice'] ) ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Limages License', 'quick-images' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-images' ), (string) ( $data['license_status'] ?? 'inactive' ) ) ); ?></p>
            <?php if ( ! empty( $data['license_message'] ) ) : ?>
                <p><?php echo esc_html( (string) $data['license_message'] ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_images_activate_license" />
                <?php wp_nonce_field( 'qwoo_quick_images_activate_license', 'qwoo_quick_images_activate_license_nonce' ); ?>
                <p>
                    <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( (string) ( $data['license_key'] ?? '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button type="submit" class="button button-primary"><?php echo esc_html__( 'Activate License', 'quick-images' ); ?></button>
                </p>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_images_deactivate_license" />
                <?php wp_nonce_field( 'qwoo_quick_images_deactivate_license', 'qwoo_quick_images_deactivate_license_nonce' ); ?>
                <p><button type="submit" class="button"><?php echo esc_html__( 'Deactivate License', 'quick-images' ); ?></button></p>
            </form>
        </div>
        <?php
    }

    function qwoo_quick_images_license_redirect( $message ) {
        $url = add_query_arg(
            array(
                'page' => 'qwoo-quick-images-license',
                'qwoo_license_notice' => rawurlencode( (string) $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    function qwoo_quick_images_license_handle_activate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-images' ) );
        }

        check_admin_referer( 'qwoo_quick_images_activate_license', 'qwoo_quick_images_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        if ( '' === $license_key ) {
            qwoo_quick_images_license_save_data(
                array(
                    'license_key' => '',
                    'license_status' => 'inactive',
                    'license_message' => 'License key is required.',
                )
            );
            qwoo_quick_images_license_redirect( 'License key is required.' );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            qwoo_quick_images_license_save_data(
                array(
                    'license_key' => $license_key,
                    'license_status' => 'invalid',
                    'license_message' => 'Quick License plugin is required for activation.',
                )
            );
            qwoo_quick_images_license_redirect( 'Quick License plugin is required for activation.' );
        }

        $result = qlic_activate_license_key_for_products( $license_key, qwoo_quick_images_license_product_scope() );
        $data = array(
            'license_key' => $license_key,
            'license_status' => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'license_message' => sanitize_text_field( (string) ( $result['message'] ?? 'License validation failed.' ) ),
        );
        if ( ! empty( $result['valid'] ) ) {
            $data['license_status'] = 'active';
        }

        qwoo_quick_images_license_save_data( $data );
        qwoo_quick_images_license_redirect( (string) $data['license_message'] );
    }

    function qwoo_quick_images_license_handle_deactivate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-images' ) );
        }

        check_admin_referer( 'qwoo_quick_images_deactivate_license', 'qwoo_quick_images_deactivate_license_nonce' );

        $data = qwoo_quick_images_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );
        $message = 'License deactivated.';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products( $license_key, qwoo_quick_images_license_product_scope() );
            if ( is_array( $result ) && ! empty( $result['message'] ) ) {
                $message = sanitize_text_field( (string) $result['message'] );
            }
        }

        qwoo_quick_images_license_save_data(
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => $message,
            )
        );

        qwoo_quick_images_license_redirect( $message );
    }
}
