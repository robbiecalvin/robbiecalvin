# Quick Images -- Visual To‑Do

-   Add margin between labels and:
    -   Select from Media Library
    -   Clear (watermark + logo)
-   Change those buttons to blue with white text
