# Strain Photo Batch Processor (WordPress Plugin)

## What it does
- Upload multiple raw photos in one batch.
- Apply a saved watermark image stretched over the entire photo.
- Apply a saved company logo at the bottom-right, scaled to 50% of photo width.
- Draw strain name text in the top-left in all-caps black using preset Montserrat ExtraBold.
- Save final processed images into the WordPress Media Library.
- Use strain names as output filenames (sanitized for safe file naming).

## Install
1. Zip the `strain-photo-batch-processor` folder.
2. In WordPress Admin, go to `Plugins -> Add New -> Upload Plugin`.
3. Upload and activate.

## Use
1. Open `WordPress Admin -> Strain Photos`.
2. In `Branding Assets`, select:
   - Watermark image
   - Company logo image
3. Click `Save Assets`.
4. In `Batch Processor`:
   - Upload your raw photos (multiple at once)
   - Enter one strain name per line in the same order as the uploaded files
5. Click `Process & Save to Media Library`.

## Notes
- Server must have GD + FreeType enabled for text rendering.
- Supports input/output image types: JPG, PNG, GIF, WEBP.
- Duplicate strain names will receive unique suffixes automatically when needed.
