(function ($) {
  'use strict';

  function openMediaFrame(targetFieldId, libraryType) {
    var frame = wp.media({
      title: 'Select image',
      button: { text: 'Use image' },
      multiple: false,
      library: { type: libraryType }
    });

    frame.on('select', function () {
      var attachment = frame.state().get('selection').first().toJSON();
      var $field = $('#' + targetFieldId);
      var $wrapper = $field.closest('.wqpsp-field');
      var $preview = $wrapper.find('.wqpsp-preview');

      $field.val(attachment.id);

      if (attachment.type === 'image' && attachment.url) {
        $preview.attr('src', attachment.url).show();
      } else {
        $preview.attr('src', '').hide();
      }
    });

    frame.open();
  }

  function stripExtension(fileName) {
    return fileName.replace(/\.[^/.]+$/, '');
  }

  $(document).on('click', '.wqpsp-media-button', function () {
    var target = $(this).data('target');
    var libraryType = $(this).data('library-type') || 'image';
    openMediaFrame(target, libraryType);
  });

  $(document).on('click', '.wqpsp-clear-button', function () {
    var target = $(this).data('target');
    var $field = $('#' + target);
    var $wrapper = $field.closest('.wqpsp-field');

    $field.val('');
    $wrapper.find('.wqpsp-preview').attr('src', '').hide();
  });

  $('#qimg_images').on('change', function (event) {
    var files = event.target.files || [];
    var $textarea = $('#qimg_product_names');

    if (!$textarea.length || $textarea.val().trim() !== '') {
      return;
    }

    var names = [];
    for (var i = 0; i < files.length; i += 1) {
      names.push(stripExtension(files[i].name));
    }

    $textarea.val(names.join('\n'));
  });
})(jQuery);
