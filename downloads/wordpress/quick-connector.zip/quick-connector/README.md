# Quick Connector (WordPress Plugin)

Quick Connector is the server-side control plane for QuickWoo Desktop.

## Install
1. Zip the `quick-connector` folder.
2. In WordPress admin, go to `Plugins > Add New Plugin > Upload Plugin`.
3. Upload the zip and activate `Quick Connector`.

## Required auth model
- Use a WordPress user with `manage_options` capability.
- Connect from QuickWoo Desktop using WordPress username + Application Password.
- HTTPS is required in production.

## REST endpoints
- `GET /wp-json/quick/v1/health` (public)
- `GET /wp-json/quick/v1/auth` (authenticated)
- `GET /wp-json/quick/v1/modules` (authenticated)
- `GET /wp-json/quick/v1/modules/catalog` (authenticated)
- `POST /wp-json/quick/v1/modules/<module>/<action>` (authenticated)
- `GET /wp-json/quick/v1/site/content` (authenticated)
- `GET /wp-json/quick/v1/store/dashboard` (authenticated)
- `GET /wp-json/quick/v1/store/orders` (authenticated)
- `GET /wp-json/quick/v1/plugins` (authenticated)
- `POST /wp-json/quick/v1/plugins/install` (authenticated)
- `POST /wp-json/quick/v1/plugins/status` (authenticated)
- `POST /wp-json/quick/v1/plugins/update` (authenticated)
- `POST /wp-json/quick/v1/plugins/delete` (authenticated)

## Module system
Current built-in modules:
- `wp-content`
- `woo-operations`
- `quick-stack`

This plugin is intentionally scoped as a single connection/control surface for all Quick-managed capabilities.

## Implemented module actions
- `quick-importer/open` returns importer workspace data.
- `quick-importer/save-settings` saves importer defaults and runtime toggles.
- `quick-importer/save-template` saves import/export template payloads by name.
- `quick-importer/delete-template` deletes a saved template by group and name.
- `quick-importer/clear-logs` clears importer run logs.
- `quick-importer/export-csv` exports posts/pages/products CSV (base64 payload).
- `quick-importer/import-csv` imports posts/pages/products CSV (base64 payload).
- `quick-site/open` returns page/post summary and recently modified pages.
- `quick-site/create-draft-page` creates a draft page and returns refreshed workspace data.
- `quick-site/save-settings` saves cache/optimization/database settings.
- `quick-site/purge-all-cache` purges all Quick Site cache files.
- `quick-site/purge-cache-url` purges cache entries for a single URL.
- `quick-site/install-dropin` installs or reinstalls the `advanced-cache.php` drop-in.
- `quick-site/db-preview` previews database cleanup impact.
- `quick-site/db-cleanup` runs database cleanup and optional table optimization.
- `quick-site/save-integrations` saves integration toggles (`quick_seo`, `quick_audit`, `quick_code`, `quick_traffic`).
- `quick-site/export-settings` exports settings/integrations JSON (base64 payload).
- `quick-site/import-settings` imports settings/integrations JSON (base64 payload).
- `quick-points/open` returns points summary and top users by balance.
- `quick-points/award` adds points to a user and returns refreshed workspace data.
- `quick-points/redeem` redeems points from a user (capped at available balance) and returns refreshed workspace data.
- `quick-points/list-transactions` returns paged/filterable transaction rows.
- `quick-points/save-settings` saves Quick Points settings (rates, redemption, expiry, and premium toggles).
- `quick-points/save-tier` creates or updates a tier and optional perks.
- `quick-points/delete-tier` deletes a tier by ID.
- `quick-points/run-expiry` processes due expirations and updates last-run stats.
- `quick-points/export-csv` exports transactions/tiers/balances as CSV (base64 payload).
- `quick-add/open` returns product summary and recent products.
- `quick-add/create-product` creates a draft WooCommerce product and returns refreshed workspace data.
- `quick-edit/open` returns editable products summary and recent products.
- `quick-edit/list-products` loads paged/filtered products for spreadsheet editing.
- `quick-edit/bulk-update-products` applies bulk edits to selected product IDs.
- `quick-edit/update-product` updates a WooCommerce product and returns refreshed workspace data.
- `quick-variations/open` returns variation summary and recent variations.
- `quick-variations/list-variable-products` returns variable products for generator targeting.
- `quick-variations/generate-combinations` builds combination rows from attribute definitions.
- `quick-variations/create-variations` creates variation batches with duplicate-combo checks.
- `quick-variations/update-variation` updates a WooCommerce variation and returns refreshed workspace data.
- `quick-accountant/open` returns financial summary and recent manual entries.
- `quick-accountant/record-entry` records a manual ledger entry and returns refreshed workspace data.
- `quick-accountant/save-category` saves a manual accounting category and returns refreshed workspace data.
- `quick-accountant/save-budget` saves a monthly budget target and returns refreshed workspace data.
- `quick-accountant/report-range` computes WooCommerce financial totals for a date range.
- `quick-accountant/export-csv` exports entries/categories/budgets as CSV (base64 payload).
- `quick-forms/open` returns form summary and saved forms.
- `quick-forms/save-form` saves a form config and returns refreshed workspace data.
- `quick-forms/update-form` updates an existing form config by `formId`.
- `quick-forms/set-form-status` sets form status (`active|inactive|publish|draft`).
- `quick-forms/duplicate-form` duplicates a form with copied fields/settings.
- `quick-forms/delete-form` deletes a form and related submissions.
- `quick-forms/record-submission` records a submission entry for a form.
- `quick-forms/list-submissions` returns paged submissions with filters.
- `quick-forms/set-submission-status` marks submissions as `new` or `read`.
- `quick-forms/delete-submission` deletes a submission.
- `quick-forms/export-submissions-csv` exports submissions CSV (base64 payload).
- `quick-quotes/open` returns quote summary and quote requests.
- `quick-quotes/create-quote` creates a quote request and returns refreshed workspace data.
- `quick-quotes/save-settings` saves default tax/discount and notification settings.
- `quick-quotes/update-quote` updates an existing quote (line items/totals/status fields).
- `quick-quotes/set-status` sets quote status (`open|pending|approved|rejected`).
- `quick-quotes/delete-quote` deletes a quote by ID.
- `quick-quotes/export-csv` exports quote rows as CSV (base64 payload).
- `quick-schedule/open` returns schedule summary and saved jobs.
- `quick-schedule/save-job` saves a scheduled job and returns refreshed workspace data.
- `quick-schedule/save-settings` saves consultation/processor fee and integration settings.
- `quick-schedule/set-job-status` updates a job status (`active|paused`).
- `quick-schedule/delete-job` deletes a saved job by ID.
- `quick-schedule/run-job` records an on-demand run result for a job.
- `quick-schedule/record-appointment` saves appointment intake rows (quote/client/totals/status).
- `quick-schedule/list-appointments` returns paged appointments with status filters.
- `quick-schedule/set-appointment-status` updates appointment status.
- `quick-schedule/delete-appointment` deletes an appointment by ID.
- `quick-schedule/export-csv` exports jobs/runs/appointments CSV (base64 payload).
- `quick-images/open` returns image summary and recent media items.
- `quick-images/set-brand-assets` saves watermark/logo media attachment IDs.
- `quick-images/process-batch` processes image rows (`attachmentId|name`) with watermark/logo overlays and strain label text.
- `quick-images/optimize-image` updates/generates image alt text and returns refreshed workspace data.
- `quick-ship/open` returns shipping summary with pending orders and shipments.
- `quick-ship/create-shipment` records shipment tracking for an order and returns refreshed workspace data.
- `quick-ship/save-settings` saves matching/fallback/tax display settings.
- `quick-ship/save-rule` creates or updates a shipping rule.
- `quick-ship/delete-rule` deletes a shipping rule by ID.
- `quick-ship/apply-preset` applies a wizard preset and generates rule rows.
- `quick-ship/set-shipment-status` updates a shipment status.
- `quick-ship/delete-shipment` deletes a shipment by ID.
- `quick-ship/export-csv` exports shipments or rules CSV (base64 payload).
- `quick-course-builder/open` returns course summary and recent courses.
- `quick-course-builder/create-course` creates a draft course and returns refreshed workspace data.
- `quick-course-builder/create-module` creates a draft module linked to a course.
- `quick-course-builder/create-test` creates a draft test with question rows.
- `quick-course-builder/set-course-status` updates a course status (`draft|publish|private|pending`).
- `quick-course-builder/delete-course` permanently deletes a course by ID.
- `quick-course-builder/export-csv` exports courses/modules/tests CSV (base64 payload).
- `quick-code/open` returns snippet summary and recent snippets.
- `quick-code/save-settings` saves runtime settings and returns refreshed workspace data.
- `quick-code/save-snippet` saves a snippet and returns refreshed workspace data.
- `quick-code/update-snippet` updates snippet content/settings and returns refreshed workspace data.
- `quick-code/set-snippet-enabled` toggles snippet enabled state and returns refreshed workspace data.
- `quick-code/delete-snippet` deletes a snippet and returns refreshed workspace data.
- `quick-code/save-conditions` saves condition rules for a snippet.
- `quick-code/list-history` returns Quick Code history rows.
- `quick-code/export-csv` exports snippets/history CSV (base64 payload).
- `quick-seo/open` returns SEO summary, content recommendations, and image-alt coverage.
- `quick-seo/generate-meta-description` generates and stores a meta description for a content item.
- `quick-seo/save-meta` saves meta description/canonical/focus keyword/noindex values for a content item.
- `quick-seo/run-link-scan` scans published content for broken internal links.
- `quick-seo/add-redirect` adds a redirect rule (`from` -> `to`).
- `quick-seo/remove-redirect` removes a redirect rule by `from` path.
- `quick-seo/save-robots` writes `robots.txt` content at site root.
- `quick-seo/generate-sitemap` generates `sitemap.xml` from published posts/pages/products.
- `quick-seo/export-csv` exports content/recommendations/redirects/broken-links CSV (base64 payload).
- `quick-audit/open` returns audit summary (risk score, update counts, plugin posture) and findings.
- `quick-audit/run-scan` reruns the same audit checks and returns fresh findings.
- `quick-audit/save-integrations` saves integration toggles (`quick_seo`, `quick_code`, `quick_traffic`, `quick_site`).
- `quick-audit/export-csv` exports findings/top-issues/pages CSV (base64 payload).
- `quick-mail/open` returns mail workspace summary and last test delivery status.
- `quick-mail/save-settings` saves provider/from/smtp/api settings.
- `quick-mail/queue-email` appends an email to the connector queue.
- `quick-mail/run-queue` processes queued emails and writes delivery logs.
- `quick-mail/clear-queue` clears queued emails.
- `quick-mail/clear-logs` clears delivery logs.
- `quick-mail/save-template` creates or updates a mail template.
- `quick-mail/delete-template` deletes a mail template by ID.
- `quick-mail/duplicate-template` duplicates a mail template.
- `quick-mail/save-mappings` saves event-to-template mappings.
- `quick-mail/test-provider` validates provider configuration presence.
- `quick-mail/export-logs-csv` exports delivery logs CSV (base64 payload).
- `quick-mail/send-test-email` sends a WordPress test email and returns refreshed workspace data.
- `quick-traffic/open` returns traffic content summary and recent tracked campaigns.
- `quick-traffic/generate-utm-url` builds a UTM campaign URL, stores it, and returns refreshed workspace data.
- `quick-traffic/report-range` returns range-based traffic totals, daily series, top pages, and top referrers.
- `quick-traffic/save-settings` saves tracking/privacy/retention settings.
- `quick-traffic/export-csv` exports campaigns, daily-series, top-pages, or top-referrers CSV (base64 payload).
