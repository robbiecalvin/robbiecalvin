<?php
/**
 * Plugin Name: Quick Connector
 * Description: Secure control plane for QuickWoo Desktop features on WordPress and WooCommerce.
 * Version: 0.1.0
 * Requires at least: 6.5
 * Requires PHP: 8.1
 * Author: QuickWoo
 * License: GPL-2.0-or-later
 * Text Domain: quick-connector
 */

if (!defined('ABSPATH')) {
    exit;
}

define('QUICK_CONNECTOR_VERSION', '0.1.0');
define('QUICK_CONNECTOR_FILE', __FILE__);
define('QUICK_CONNECTOR_PATH', plugin_dir_path(__FILE__));
define('QUICK_CONNECTOR_URL', plugin_dir_url(__FILE__));

require_once QUICK_CONNECTOR_PATH . 'includes/interfaces/interface-quick-connector-module.php';
require_once QUICK_CONNECTOR_PATH . 'includes/class-quick-connector-modules.php';
require_once QUICK_CONNECTOR_PATH . 'includes/class-quick-connector-auth.php';
require_once QUICK_CONNECTOR_PATH . 'includes/modules/class-quick-connector-module-wp-content.php';
require_once QUICK_CONNECTOR_PATH . 'includes/modules/class-quick-connector-module-woo-operations.php';
require_once QUICK_CONNECTOR_PATH . 'includes/modules/class-quick-connector-module-quick-stack.php';
require_once QUICK_CONNECTOR_PATH . 'includes/class-quick-connector.php';

function quick_connector_bootstrap(): void
{
    $plugin = new Quick_Connector();
    $plugin->register_hooks();
}

quick_connector_bootstrap();
