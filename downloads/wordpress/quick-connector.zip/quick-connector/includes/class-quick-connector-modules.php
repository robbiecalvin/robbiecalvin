<?php

if (!defined('ABSPATH')) {
    exit;
}

class Quick_Connector_Modules
{
    /**
     * @var array<string, Quick_Connector_Module>
     */
    private array $modules = [];

    public function register_module(Quick_Connector_Module $module): void
    {
        $this->modules[$module->get_slug()] = $module;
    }

    /**
     * @return array<string, Quick_Connector_Module>
     */
    public function all(): array
    {
        return $this->modules;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function as_rest_payload(): array
    {
        $payload = [];

        foreach ($this->modules as $module) {
            $payload[] = $module->to_array();
        }

        return $payload;
    }
}
