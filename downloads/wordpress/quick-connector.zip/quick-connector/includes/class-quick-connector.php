<?php

if (!defined('ABSPATH')) {
    exit;
}

class Quick_Connector
{
    private const QUICK_AUDIT_USER_AGENT = 'QuickAuditConnector/1.0';
    private const QUICK_AUDIT_MAX_LINKS_PER_PAGE = 120;
    private const MODULE_ACTION_SCHEMA_VERSION = '2026-02-20';
    private const AUDIT_LOG_OPTION = 'quick_connector_audit_log';
    private const AUDIT_LOG_MAX = 250;

    private Quick_Connector_Auth $auth;

    private Quick_Connector_Modules $modules;

    public function __construct()
    {
        $this->auth = new Quick_Connector_Auth();
        $this->modules = new Quick_Connector_Modules();
        $this->register_default_modules();
    }

    public function register_hooks(): void
    {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function register_routes(): void
    {
        register_rest_route('quick/v1', '/health', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'health_endpoint'],
            'permission_callback' => [$this->auth, 'allow_public_health'],
        ]);

        register_rest_route('quick/v1', '/auth', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'auth_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/modules', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'modules_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/modules/catalog', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'module_catalog_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/modules/(?P<module>[a-z0-9-]+)/(?P<action>[a-z0-9-]+)', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'module_action_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/site/content', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'site_content_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/store/dashboard', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'store_dashboard_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/store/orders', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'store_orders_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/plugins', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'plugins_list_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/plugins/install', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'plugins_install_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/plugins/status', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'plugins_status_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/plugins/update', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'plugins_update_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/plugins/delete', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [$this, 'plugins_delete_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);

        register_rest_route('quick/v1', '/audit/recent', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [$this, 'audit_recent_endpoint'],
            'permission_callback' => [$this->auth, 'require_operator'],
        ]);
    }

    public function health_endpoint(WP_REST_Request $request): WP_REST_Response
    {
        unset($request);

        $payload = [
            'ok' => true,
            'plugin' => 'quick-connector',
            'version' => QUICK_CONNECTOR_VERSION,
            'wordpressVersion' => get_bloginfo('version'),
            'phpVersion' => PHP_VERSION,
            'siteUrl' => get_site_url(),
            'wooActive' => class_exists('WooCommerce'),
            'timestamp' => gmdate('c'),
        ];

        return new WP_REST_Response($payload, 200);
    }

    public function auth_endpoint(WP_REST_Request $request): WP_REST_Response
    {
        unset($request);

        $user = wp_get_current_user();

        $payload = [
            'ok' => true,
            'user' => [
                'id' => $user->ID,
                'login' => $user->user_login,
                'email' => $user->user_email,
                'displayName' => $user->display_name,
            ],
            'capabilities' => [
                'manageOptions' => user_can($user, 'manage_options'),
                'activatePlugins' => user_can($user, 'activate_plugins'),
                'installPlugins' => user_can($user, 'install_plugins'),
                'updatePlugins' => user_can($user, 'update_plugins'),
            ],
        ];

        return new WP_REST_Response($payload, 200);
    }

    public function modules_endpoint(WP_REST_Request $request): WP_REST_Response
    {
        unset($request);

        $payload = [
            'ok' => true,
            'count' => count($this->modules->all()),
            'modules' => $this->modules->as_rest_payload(),
        ];

        return new WP_REST_Response($payload, 200);
    }

    public function module_catalog_endpoint(WP_REST_Request $request): WP_REST_Response
    {
        unset($request);

        $site_modules = [
            ['slug' => 'quick-importer', 'name' => 'Quick Importer', 'enabled' => true],
            ['slug' => 'quick-mail', 'name' => 'Mail', 'enabled' => true],
            ['slug' => 'quick-site', 'name' => 'Site', 'enabled' => true],
            ['slug' => 'quick-course-builder', 'name' => 'Course Builder', 'enabled' => true],
            ['slug' => 'quick-audit', 'name' => 'Audit', 'enabled' => true],
            ['slug' => 'quick-seo', 'name' => 'SEO', 'enabled' => true],
            ['slug' => 'quick-code', 'name' => 'Code', 'enabled' => true],
            ['slug' => 'quick-traffic', 'name' => 'Traffic', 'enabled' => true],
        ];

        $store_modules = [
            ['slug' => 'quick-add', 'name' => 'Quick Add', 'enabled' => true],
            ['slug' => 'quick-edit', 'name' => 'Edit', 'enabled' => true],
            ['slug' => 'quick-variations', 'name' => 'Variations', 'enabled' => true],
            ['slug' => 'quick-accountant', 'name' => 'Accountant', 'enabled' => true],
            ['slug' => 'quick-forms', 'name' => 'Forms', 'enabled' => true],
            ['slug' => 'quick-quotes', 'name' => 'Quote', 'enabled' => true],
            ['slug' => 'quick-schedule', 'name' => 'Schedule', 'enabled' => true],
            ['slug' => 'quick-images', 'name' => 'Images', 'enabled' => true],
            ['slug' => 'quick-ship', 'name' => 'Ship', 'enabled' => true],
            ['slug' => 'quick-points', 'name' => 'Points', 'enabled' => true],
        ];

        return new WP_REST_Response([
            'ok' => true,
            'siteModules' => $site_modules,
            'storeModules' => $store_modules,
        ], 200);
    }

    public function audit_recent_endpoint(WP_REST_Request $request): WP_REST_Response
    {
        unset($request);
        $events = get_option(self::AUDIT_LOG_OPTION, []);
        if (!is_array($events)) {
            $events = [];
        }

        return new WP_REST_Response([
            'ok' => true,
            'count' => count($events),
            'events' => array_values($events),
        ], 200);
    }

    /**
     * @return WP_REST_Response|WP_Error
     */
    public function module_action_endpoint(WP_REST_Request $request)
    {
        $module = sanitize_text_field((string) $request->get_param('module'));
        $action = sanitize_text_field((string) $request->get_param('action'));
        $input_payload = $request->get_json_params();
        if (!is_array($input_payload)) {
            $input_payload = [];
        }

        if ($module === '' || $action === '') {
            return new WP_Error(
                'quick_connector_module_invalid',
                'Module and action are required.',
                ['status' => 400]
            );
        }

        $catalog = $this->module_catalog_endpoint(new WP_REST_Request())->get_data();
        $allowed = [];
        if (isset($catalog['siteModules']) && is_array($catalog['siteModules'])) {
            $allowed = array_merge($allowed, $catalog['siteModules']);
        }
        if (isset($catalog['storeModules']) && is_array($catalog['storeModules'])) {
            $allowed = array_merge($allowed, $catalog['storeModules']);
        }

        $known = false;
        foreach ($allowed as $entry) {
            if (is_array($entry) && isset($entry['slug']) && $entry['slug'] === $module) {
                $known = true;
                break;
            }
        }

        if (!$known) {
            $this->record_audit_event('module-action', 'denied', [
                'module' => $module,
                'action' => $action,
                'reason' => 'unknown-module',
            ]);
            return new WP_Error(
                'quick_connector_module_unknown',
                'Unknown module.',
                ['status' => 404]
            );
        }

        $capability_error = $this->assert_module_action_capability($module, $action);
        if ($capability_error instanceof WP_Error) {
            $error_data = $capability_error->get_error_data();
            $this->record_audit_event('module-action', 'denied', [
                'module' => $module,
                'action' => $action,
                'reason' => 'capability',
                'requiredCapability' => is_array($error_data) && isset($error_data['requiredCapability']) ? (string) $error_data['requiredCapability'] : 'unknown',
            ]);
            return $capability_error;
        }

        $payload = [];
        $default_message = sprintf('Module %s received action %s.', $module, $action);
        $message = $default_message;

        if ($module === 'quick-importer') {
            if ($action === 'open') {
                $payload = $this->quick_importer_open_payload();
                $message = 'Quick Importer workspace loaded.';
            } elseif ($action === 'save-settings') {
                $payload = $this->quick_importer_save_settings_payload($input_payload);
                $message = 'Quick Importer settings saved.';
            } elseif ($action === 'save-template') {
                $result = $this->quick_importer_save_template_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Importer template saved.';
            } elseif ($action === 'delete-template') {
                $result = $this->quick_importer_delete_template_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Importer template deleted.';
            } elseif ($action === 'clear-logs') {
                $payload = $this->quick_importer_clear_logs_payload();
                $message = 'Quick Importer logs cleared.';
            } elseif ($action === 'export-csv') {
                $result = $this->quick_importer_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Quick Importer exported %s CSV with %d rows.',
                    (string) $payload['entity'],
                    (int) $payload['rowCount']
                );
            } elseif ($action === 'import-csv') {
                $result = $this->quick_importer_import_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Quick Importer imported %s CSV: inserted %d, updated %d, errors %d.',
                    (string) $payload['entity'],
                    (int) $payload['inserted'],
                    (int) $payload['updated'],
                    is_array($payload['errors']) ? count($payload['errors']) : 0
                );
            }
        } elseif ($module === 'quick-site') {
            if ($action === 'open') {
                $payload = $this->quick_site_open_payload();
                $message = 'Quick Site workspace loaded.';
            } elseif ($action === 'create-draft-page') {
                $result = $this->quick_site_create_draft_page_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Quick Site created draft page #%d.', (int) $payload['pageId']);
            } elseif ($action === 'save-settings') {
                $result = $this->quick_site_save_settings_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Site settings saved.';
            } elseif ($action === 'purge-all-cache') {
                $payload = $this->quick_site_purge_all_cache_payload();
                $message = !empty($payload['ok'])
                    ? 'Quick Site cache purged.'
                    : 'Quick Site cache purge completed with errors.';
            } elseif ($action === 'purge-cache-url') {
                $result = $this->quick_site_purge_cache_url_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Purged %d cache files for URL.', (int) ($payload['deleted'] ?? 0));
            } elseif ($action === 'install-dropin') {
                $payload = $this->quick_site_install_dropin_payload();
                $message = !empty($payload['installed'])
                    ? 'Quick Site drop-in installed.'
                    : 'Quick Site drop-in could not be installed.';
            } elseif ($action === 'db-preview') {
                $payload = $this->quick_site_db_preview_payload();
                $message = 'Quick Site database cleanup preview loaded.';
            } elseif ($action === 'db-cleanup') {
                $payload = $this->quick_site_db_cleanup_payload();
                $message = 'Quick Site database cleanup completed.';
            } elseif ($action === 'save-integrations') {
                $result = $this->quick_site_save_integrations_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Site integrations saved.';
            } elseif ($action === 'export-settings') {
                $payload = $this->quick_site_export_settings_payload();
                $message = 'Quick Site settings export generated.';
            } elseif ($action === 'import-settings') {
                $result = $this->quick_site_import_settings_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Site settings imported.';
            }
        } elseif ($module === 'quick-points') {
            if ($action === 'open') {
                $payload = $this->quick_points_open_payload();
                $message = 'Quick Points workspace loaded.';
            } elseif ($action === 'award') {
                $result = $this->quick_points_adjust_payload($input_payload, 'award');
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Awarded %d points to user #%d.', (int) $payload['delta'], (int) $payload['userId']);
            } elseif ($action === 'redeem') {
                $result = $this->quick_points_adjust_payload($input_payload, 'redeem');
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Redeemed %d points from user #%d.', (int) $payload['delta'], (int) $payload['userId']);
            } elseif ($action === 'list-transactions') {
                $payload = $this->quick_points_list_transactions_payload($input_payload);
                $message = sprintf('Loaded %d points transactions.', isset($payload['transactions']) && is_array($payload['transactions']) ? count($payload['transactions']) : 0);
            } elseif ($action === 'save-settings') {
                $result = $this->quick_points_save_settings_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Points settings saved.';
            } elseif ($action === 'save-tier') {
                $result = $this->quick_points_save_tier_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Saved points tier #%d.', (int) $payload['tierId']);
            } elseif ($action === 'delete-tier') {
                $result = $this->quick_points_delete_tier_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Deleted points tier #%d.', (int) $payload['tierId']);
            } elseif ($action === 'run-expiry') {
                $payload = $this->quick_points_run_expiry_payload();
                $message = sprintf(
                    'Quick Points expiry run complete: expired %d points across %d rows.',
                    (int) $payload['expiredPoints'],
                    (int) $payload['rowsProcessed']
                );
            } elseif ($action === 'export-csv') {
                $result = $this->quick_points_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Quick Points exported %s CSV with %d rows.',
                    (string) $payload['entity'],
                    (int) $payload['rowCount']
                );
            }
        } elseif ($module === 'quick-seo') {
            if ($action === 'open') {
                $payload = $this->quick_seo_open_payload();
                $message = 'Quick SEO workspace loaded.';
            } elseif ($action === 'save-bulk') {
                $result = $this->quick_seo_save_bulk_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Quick SEO saved %d rows.', (int) ($payload['savedCount'] ?? 0));
            } elseif ($action === 'generate-meta-description') {
                $result = $this->quick_seo_generate_meta_description_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Generated meta description for content #%d.', (int) $payload['postId']);
            } elseif ($action === 'save-meta') {
                $result = $this->quick_seo_save_meta_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Saved SEO metadata for content #%d.', (int) $payload['postId']);
            } elseif ($action === 'run-link-scan') {
                $payload = $this->quick_seo_run_link_scan_payload();
                $message = sprintf('Quick SEO scanned links and found %d broken URLs.', isset($payload['brokenCount']) ? (int) $payload['brokenCount'] : 0);
            } elseif ($action === 'add-redirect') {
                $result = $this->quick_seo_add_redirect_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = 'Quick SEO redirect added.';
            } elseif ($action === 'remove-redirect') {
                $result = $this->quick_seo_remove_redirect_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = 'Quick SEO redirect removed.';
            } elseif ($action === 'save-robots') {
                $result = $this->quick_seo_save_robots_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = 'Quick SEO robots.txt updated.';
            } elseif ($action === 'generate-sitemap') {
                $result = $this->quick_seo_generate_sitemap_payload();
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Quick SEO generated sitemap with %d URLs.', (int) $payload['urlCount']);
            } elseif ($action === 'export-csv') {
                $result = $this->quick_seo_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Quick SEO exported %s CSV with %d rows.', (string) $payload['entity'], (int) $payload['rowCount']);
            } elseif ($action === 'load-schema-template') {
                $result = $this->quick_seo_load_schema_template_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Quick SEO loaded %s schema template.', (string) ($payload['schemaType'] ?? ''));
            } elseif ($action === 'save-schema-template') {
                $result = $this->quick_seo_save_schema_template_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Quick SEO saved %s schema template.', (string) ($payload['schemaType'] ?? ''));
            } elseif ($action === 'save-canonical-mode') {
                $result = $this->quick_seo_save_canonical_mode_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Quick SEO canonical mode set to %s.', (string) ($payload['canonicalMode'] ?? 'default'));
            }
        } elseif ($module === 'quick-audit') {
            if ($action === 'open') {
                $payload = $this->quick_audit_open_payload();
                $message = 'Quick Audit workspace loaded.';
            } elseif ($action === 'run-scan') {
                $payload = $this->quick_audit_run_scan_payload($input_payload);
                $message = 'Quick Audit scan completed.';
            } elseif ($action === 'run-crawl') {
                $crawl_payload = $input_payload;
                $crawl_payload['scanMode'] = 'crawl';
                $payload = $this->quick_audit_run_scan_payload($crawl_payload);
                $message = 'Quick Audit crawl completed.';
            } elseif ($action === 'save-integrations') {
                $payload = $this->quick_audit_save_integrations_payload($input_payload);
                $message = 'Quick Audit integrations saved.';
            } elseif ($action === 'export-csv') {
                $result = $this->quick_audit_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Quick Audit exported %s CSV with %d rows.', (string) $payload['entity'], (int) $payload['rowCount']);
            }
        } elseif ($module === 'quick-course-builder') {
            if ($action === 'open') {
                $payload = $this->quick_course_builder_open_payload();
                $message = 'Quick Course Builder workspace loaded.';
            } elseif ($action === 'create-course') {
                $result = $this->quick_course_builder_create_course_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Created course #%d.', (int) $payload['courseId']);
            } elseif ($action === 'create-module') {
                $result = $this->quick_course_builder_create_module_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Created module #%d.', (int) $payload['moduleId']);
            } elseif ($action === 'create-test') {
                $result = $this->quick_course_builder_create_test_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Created test #%d.', (int) $payload['testId']);
            } elseif ($action === 'set-course-status') {
                $result = $this->quick_course_builder_set_course_status_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Course #%d status updated to %s.', (int) $payload['courseId'], (string) $payload['status']);
            } elseif ($action === 'delete-course') {
                $result = $this->quick_course_builder_delete_course_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Deleted course #%d.', (int) $payload['courseId']);
            } elseif ($action === 'export-csv') {
                $result = $this->quick_course_builder_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = sprintf('Quick Course Builder exported %s CSV with %d rows.', (string) $payload['entity'], (int) $payload['rowCount']);
            }
        } elseif ($module === 'quick-code') {
            if ($action === 'open') {
                $payload = $this->quick_code_open_payload();
                $message = 'Quick Code workspace loaded.';
            } elseif ($action === 'save-settings') {
                $result = $this->quick_code_save_settings_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Code settings saved.';
            } elseif ($action === 'save-snippet') {
                $result = $this->quick_code_save_snippet_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Saved code snippet #%d.', (int) $payload['snippetId']);
            } elseif ($action === 'update-snippet') {
                $result = $this->quick_code_update_snippet_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Updated code snippet #%d.', (int) $payload['snippetId']);
            } elseif ($action === 'set-snippet-enabled') {
                $result = $this->quick_code_set_enabled_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Snippet #%d is now %s.',
                    (int) $payload['snippetId'],
                    !empty($payload['enabled']) ? 'enabled' : 'disabled'
                );
            } elseif ($action === 'delete-snippet') {
                $result = $this->quick_code_delete_snippet_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Deleted code snippet #%d.', (int) $payload['snippetId']);
            } elseif ($action === 'save-conditions') {
                $result = $this->quick_code_save_conditions_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Saved conditions for snippet #%d.', (int) $payload['snippetId']);
            } elseif ($action === 'list-history') {
                $payload = $this->quick_code_history_payload($input_payload);
                $message = sprintf(
                    'Loaded %d Quick Code history rows.',
                    isset($payload['history']) && is_array($payload['history']) ? count($payload['history']) : 0
                );
            } elseif ($action === 'export-csv') {
                $result = $this->quick_code_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Quick Code exported %s CSV with %d rows.',
                    (string) $payload['entity'],
                    (int) $payload['rowCount']
                );
            }
        } elseif ($module === 'quick-add') {
            if ($action === 'open') {
                $result = $this->quick_add_open_payload();
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Add workspace loaded.';
            } elseif ($action === 'create-product') {
                $result = $this->quick_add_create_product_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Created product #%d.', (int) $payload['productId']);
            }
        } elseif ($module === 'quick-edit') {
            if ($action === 'open') {
                $result = $this->quick_edit_open_payload();
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Edit workspace loaded.';
            } elseif ($action === 'list-products') {
                $result = $this->quick_edit_list_products_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Loaded %d products (page %d).',
                    isset($payload['recentProducts']) && is_array($payload['recentProducts']) ? count($payload['recentProducts']) : 0,
                    isset($payload['page']) ? (int) $payload['page'] : 1
                );
            } elseif ($action === 'bulk-update-products') {
                $result = $this->quick_edit_bulk_update_products_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Bulk updated %d product(s).', (int) ($payload['updatedCount'] ?? 0));
            } elseif ($action === 'update-product') {
                $result = $this->quick_edit_update_product_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Updated product #%d.', (int) $payload['productId']);
            }
        } elseif ($module === 'quick-variations') {
            if ($action === 'open') {
                $result = $this->quick_variations_open_payload();
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Variations workspace loaded.';
            } elseif ($action === 'list-variable-products') {
                $result = $this->quick_variations_list_variable_products_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Loaded %d variable product(s).',
                    isset($payload['variableProducts']) && is_array($payload['variableProducts']) ? count($payload['variableProducts']) : 0
                );
            } elseif ($action === 'generate-combinations') {
                $result = $this->quick_variations_generate_combinations_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Generated %d combination(s).',
                    isset($payload['generatedRows']) && is_array($payload['generatedRows']) ? count($payload['generatedRows']) : 0
                );
            } elseif ($action === 'create-variations') {
                $result = $this->quick_variations_create_variations_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Created %d, skipped %d, failed %d variation(s).',
                    (int) ($payload['created'] ?? 0),
                    (int) ($payload['skipped'] ?? 0),
                    (int) ($payload['failed'] ?? 0)
                );
            } elseif ($action === 'update-variation') {
                $result = $this->quick_variations_update_variation_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Updated variation #%d.', (int) $payload['variationId']);
            }
        } elseif ($module === 'quick-accountant') {
            if ($action === 'open') {
                $result = $this->quick_accountant_open_payload();
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Accountant workspace loaded.';
            } elseif ($action === 'save-category') {
                $result = $this->quick_accountant_save_category_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Saved category #%d.', (int) $payload['categoryId']);
            } elseif ($action === 'save-budget') {
                $result = $this->quick_accountant_save_budget_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Saved budget #%d.', (int) $payload['budgetId']);
            } elseif ($action === 'report-range') {
                $result = $this->quick_accountant_report_range_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Generated accountant range report.';
            } elseif ($action === 'export-csv') {
                $result = $this->quick_accountant_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Quick Accountant exported CSV (%d rows).', (int) $payload['rowCount']);
            } elseif ($action === 'record-entry') {
                $result = $this->quick_accountant_record_entry_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Recorded %s entry #%d.', (string) $payload['type'], (int) $payload['entryId']);
            }
        } elseif ($module === 'quick-forms') {
            if ($action === 'open') {
                $payload = $this->quick_forms_open_payload();
                $message = 'Quick Forms workspace loaded.';
            } elseif ($action === 'save-form') {
                $result = $this->quick_forms_save_form_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Saved form #%d.', (int) $payload['formId']);
            } elseif ($action === 'update-form') {
                $result = $this->quick_forms_update_form_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Updated form #%d.', (int) $payload['formId']);
            } elseif ($action === 'set-form-status') {
                $result = $this->quick_forms_set_form_status_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Form #%d is now %s.', (int) $payload['formId'], (string) $payload['status']);
            } elseif ($action === 'duplicate-form') {
                $result = $this->quick_forms_duplicate_form_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Duplicated form as #%d.', (int) $payload['formId']);
            } elseif ($action === 'delete-form') {
                $result = $this->quick_forms_delete_form_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Deleted form #%d.', (int) $payload['formId']);
            } elseif ($action === 'record-submission') {
                $result = $this->quick_forms_record_submission_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Recorded submission #%d.', (int) $payload['submissionId']);
            } elseif ($action === 'list-submissions') {
                $result = $this->quick_forms_list_submissions_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Loaded %d submission(s) (page %d).',
                    isset($payload['submissions']) && is_array($payload['submissions']) ? count($payload['submissions']) : 0,
                    isset($payload['page']) ? (int) $payload['page'] : 1
                );
            } elseif ($action === 'set-submission-status') {
                $result = $this->quick_forms_set_submission_status_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Submission #%d marked as %s.',
                    (int) $payload['submissionId'],
                    (string) $payload['status']
                );
            } elseif ($action === 'delete-submission') {
                $result = $this->quick_forms_delete_submission_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Deleted submission #%d.', (int) $payload['submissionId']);
            } elseif ($action === 'export-submissions-csv') {
                $result = $this->quick_forms_export_submissions_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Exported %d submission row(s).', (int) ($payload['rowCount'] ?? 0));
            }
        } elseif ($module === 'quick-quotes') {
            if ($action === 'open') {
                $payload = $this->quick_quotes_open_payload();
                $message = 'Quick Quotes workspace loaded.';
            } elseif ($action === 'save-settings') {
                $result = $this->quick_quotes_save_settings_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Quotes settings saved.';
            } elseif ($action === 'create-quote') {
                $result = $this->quick_quotes_create_quote_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Created quote request #%d.', (int) $payload['quoteId']);
            } elseif ($action === 'update-quote') {
                $result = $this->quick_quotes_update_quote_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Updated quote #%d.', (int) $payload['quoteId']);
            } elseif ($action === 'set-status') {
                $result = $this->quick_quotes_set_status_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Quote #%d marked %s.', (int) $payload['quoteId'], (string) $payload['status']);
            } elseif ($action === 'delete-quote') {
                $result = $this->quick_quotes_delete_quote_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Deleted quote #%d.', (int) $payload['quoteId']);
            } elseif ($action === 'export-csv') {
                $result = $this->quick_quotes_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Exported %d quote row(s).', (int) ($payload['rowCount'] ?? 0));
            }
        } elseif ($module === 'quick-schedule') {
            if ($action === 'open') {
                $payload = $this->quick_schedule_open_payload();
                $message = 'Quick Schedule workspace loaded.';
            } elseif ($action === 'save-settings') {
                $result = $this->quick_schedule_save_settings_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Schedule settings saved.';
            } elseif ($action === 'save-job') {
                $result = $this->quick_schedule_save_job_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Saved schedule job #%d.', (int) $payload['jobId']);
            } elseif ($action === 'set-job-status') {
                $result = $this->quick_schedule_set_job_status_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Job #%d is now %s.', (int) $payload['jobId'], (string) $payload['status']);
            } elseif ($action === 'delete-job') {
                $result = $this->quick_schedule_delete_job_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Deleted schedule job #%d.', (int) $payload['jobId']);
            } elseif ($action === 'run-job') {
                $result = $this->quick_schedule_run_job_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Ran job #%d.', (int) $payload['jobId']);
            } elseif ($action === 'record-appointment') {
                $result = $this->quick_schedule_record_appointment_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Recorded appointment #%d.', (int) $payload['appointmentId']);
            } elseif ($action === 'list-appointments') {
                $result = $this->quick_schedule_list_appointments_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Loaded %d appointment(s) (page %d).',
                    isset($payload['appointments']) && is_array($payload['appointments']) ? count($payload['appointments']) : 0,
                    isset($payload['page']) ? (int) $payload['page'] : 1
                );
            } elseif ($action === 'set-appointment-status') {
                $result = $this->quick_schedule_set_appointment_status_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Appointment #%d marked %s.',
                    (int) $payload['appointmentId'],
                    (string) $payload['status']
                );
            } elseif ($action === 'delete-appointment') {
                $result = $this->quick_schedule_delete_appointment_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Deleted appointment #%d.', (int) $payload['appointmentId']);
            } elseif ($action === 'export-csv') {
                $result = $this->quick_schedule_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Exported %d %s row(s).',
                    (int) ($payload['rowCount'] ?? 0),
                    isset($payload['entity']) ? (string) $payload['entity'] : 'schedule'
                );
            }
        } elseif ($module === 'quick-ship') {
            if ($action === 'open') {
                $result = $this->quick_ship_open_payload();
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Ship workspace loaded.';
            } elseif ($action === 'save-settings') {
                $result = $this->quick_ship_save_settings_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Ship settings saved.';
            } elseif ($action === 'save-rule') {
                $result = $this->quick_ship_save_rule_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Saved shipping rule #%d.', (int) $payload['ruleId']);
            } elseif ($action === 'delete-rule') {
                $result = $this->quick_ship_delete_rule_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Deleted shipping rule #%d.', (int) $payload['ruleId']);
            } elseif ($action === 'apply-preset') {
                $result = $this->quick_ship_apply_preset_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Applied Quick Ship preset %s.', (string) $payload['presetId']);
            } elseif ($action === 'create-shipment') {
                $result = $this->quick_ship_create_shipment_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Created shipment #%d for order #%d.', (int) $payload['shipmentId'], (int) $payload['orderId']);
            } elseif ($action === 'set-shipment-status') {
                $result = $this->quick_ship_set_shipment_status_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Shipment #%d status set to %s.', (int) $payload['shipmentId'], (string) $payload['status']);
            } elseif ($action === 'delete-shipment') {
                $result = $this->quick_ship_delete_shipment_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Deleted shipment #%d.', (int) $payload['shipmentId']);
            } elseif ($action === 'export-csv') {
                $result = $this->quick_ship_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Exported %d %s row(s).',
                    (int) ($payload['rowCount'] ?? 0),
                    isset($payload['entity']) ? (string) $payload['entity'] : 'ship'
                );
            }
        } elseif ($module === 'quick-images') {
            if ($action === 'open') {
                $payload = $this->quick_images_open_payload();
                $message = 'Quick Images workspace loaded.';
            } elseif ($action === 'set-brand-assets') {
                $result = $this->quick_images_set_brand_assets_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Images brand assets saved.';
            } elseif ($action === 'process-batch') {
                $result = $this->quick_images_process_batch_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Quick Images processed %d image(s) with %d error(s).',
                    isset($result['processed']) && is_array($result['processed']) ? count($result['processed']) : 0,
                    isset($result['errors']) && is_array($result['errors']) ? count($result['errors']) : 0
                );
            } elseif ($action === 'optimize-image') {
                $result = $this->quick_images_optimize_image_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Optimized image #%d.', (int) $payload['attachmentId']);
            }
        } elseif ($module === 'quick-mail') {
            if ($action === 'open') {
                $payload = $this->quick_mail_open_payload();
                $message = 'Quick Mail workspace loaded.';
            } elseif ($action === 'save-settings') {
                $result = $this->quick_mail_save_settings_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Mail settings saved.';
            } elseif ($action === 'queue-email') {
                $result = $this->quick_mail_queue_email_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Queued email #%d.', (int) $payload['queueId']);
            } elseif ($action === 'run-queue') {
                $payload = $this->quick_mail_run_queue_payload();
                $message = 'Quick Mail queue run completed.';
            } elseif ($action === 'clear-queue') {
                $payload = $this->quick_mail_clear_queue_payload();
                $message = 'Quick Mail queue cleared.';
            } elseif ($action === 'clear-logs') {
                $payload = $this->quick_mail_clear_logs_payload();
                $message = 'Quick Mail logs cleared.';
            } elseif ($action === 'save-template') {
                $result = $this->quick_mail_save_template_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Saved template #%d.', (int) $payload['templateId']);
            } elseif ($action === 'delete-template') {
                $result = $this->quick_mail_delete_template_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Deleted template #%d.', (int) $payload['templateId']);
            } elseif ($action === 'duplicate-template') {
                $result = $this->quick_mail_duplicate_template_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Duplicated template as #%d.', (int) $payload['templateId']);
            } elseif ($action === 'save-mappings') {
                $result = $this->quick_mail_save_mappings_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Mail mappings saved.';
            } elseif ($action === 'test-provider') {
                $payload = $this->quick_mail_test_provider_payload();
                $message = isset($payload['testMessage']) ? (string) $payload['testMessage'] : 'Provider test completed.';
            } elseif ($action === 'export-logs-csv') {
                $result = $this->quick_mail_export_logs_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Exported %d mail log row(s).', (int) ($payload['rowCount'] ?? 0));
            } elseif ($action === 'send-test-email') {
                $result = $this->quick_mail_send_test_email_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf('Quick Mail sent test email to %s.', (string) $payload['to']);
            }
        } elseif ($module === 'quick-traffic') {
            if ($action === 'open') {
                $payload = $this->quick_traffic_open_payload();
                $message = 'Quick Traffic workspace loaded.';
            } elseif ($action === 'generate-utm-url') {
                $result = $this->quick_traffic_generate_utm_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = 'Quick Traffic generated campaign URL.';
            } elseif ($action === 'report-range') {
                $payload = $this->quick_traffic_report_range_payload($input_payload);
                $message = sprintf(
                    'Quick Traffic report loaded: %s to %s.',
                    isset($payload['range']['start']) ? (string) $payload['range']['start'] : '',
                    isset($payload['range']['end']) ? (string) $payload['range']['end'] : ''
                );
            } elseif ($action === 'save-settings') {
                $payload = $this->quick_traffic_save_settings_payload($input_payload);
                $message = 'Quick Traffic settings saved.';
            } elseif ($action === 'save-integrations') {
                $payload = $this->quick_traffic_save_integrations_payload($input_payload);
                $message = 'Quick Traffic integrations saved.';
            } elseif ($action === 'reset-data') {
                $result = $this->quick_traffic_reset_data_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }
                $payload = $result;
                $message = 'Quick Traffic data reset completed.';
            } elseif ($action === 'export-csv') {
                $result = $this->quick_traffic_export_csv_payload($input_payload);
                if ($result instanceof WP_Error) {
                    return $result;
                }

                $payload = $result;
                $message = sprintf(
                    'Quick Traffic exported %s CSV with %d rows.',
                    (string) $payload['entity'],
                    (int) $payload['rowCount']
                );
            }
        }

        if ($message === $default_message && $payload === []) {
            $this->record_audit_event('module-action', 'denied', [
                'module' => $module,
                'action' => $action,
                'reason' => 'unknown-action',
            ]);
            return new WP_Error(
                'quick_connector_action_unknown',
                'Unknown action for module.',
                [
                    'status' => 404,
                    'module' => $module,
                    'action' => $action,
                    'schemaVersion' => self::MODULE_ACTION_SCHEMA_VERSION,
                ]
            );
        }

        if (is_array($payload) && !isset($payload['serverTimeUtc'])) {
            $payload['serverTimeUtc'] = gmdate('c');
        }

        $this->record_audit_event('module-action', 'success', [
            'module' => $module,
            'action' => $action,
            'message' => $message,
        ]);

        return new WP_REST_Response([
            'ok' => true,
            'schemaVersion' => self::MODULE_ACTION_SCHEMA_VERSION,
            'module' => $module,
            'action' => $action,
            'message' => $message,
            'payload' => $payload,
        ], 200);
    }

    public function site_content_endpoint(WP_REST_Request $request): WP_REST_Response
    {
        unset($request);

        $post_counts = wp_count_posts('post');
        $page_counts = wp_count_posts('page');
        $media_counts = wp_count_attachments();
        $recent_posts = $this->get_recent_posts_payload();
        $recent_pages = $this->get_recent_pages_payload();
        $recent_media = $this->get_recent_media_payload();

        $last_edited_candidates = [];
        foreach ([$recent_posts, $recent_pages, $recent_media] as $collection) {
            if (!is_array($collection)) {
                continue;
            }
            foreach ($collection as $entry) {
                if (is_array($entry) && isset($entry['date']) && is_string($entry['date']) && $entry['date'] !== '') {
                    $last_edited_candidates[] = $entry['date'];
                }
            }
        }

        $payload = [
            'recentPosts' => $recent_posts,
            'recentPages' => $recent_pages,
            'recentMedia' => $recent_media,
            'summary' => [
                'totalPosts' => (int) ($post_counts->publish ?? 0) + (int) ($post_counts->draft ?? 0) + (int) ($post_counts->private ?? 0) + (int) ($post_counts->pending ?? 0),
                'publishedPosts' => (int) ($post_counts->publish ?? 0),
                'draftPosts' => (int) ($post_counts->draft ?? 0),
                'totalPages' => (int) ($page_counts->publish ?? 0) + (int) ($page_counts->draft ?? 0) + (int) ($page_counts->private ?? 0) + (int) ($page_counts->pending ?? 0),
                'publishedPages' => (int) ($page_counts->publish ?? 0),
                'draftPages' => (int) ($page_counts->draft ?? 0),
                'totalMedia' => (int) ($media_counts->inherit ?? 0),
                'lastEditedUtc' => count($last_edited_candidates) > 0 ? max($last_edited_candidates) : gmdate('c'),
            ],
        ];

        return new WP_REST_Response($payload, 200);
    }

    /**
     * @return WP_REST_Response|WP_Error
     */
    public function store_dashboard_endpoint(WP_REST_Request $request)
    {
        unset($request);

        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_connector_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $payload = [
            'openOrders' => $this->count_orders_by_status('on-hold'),
            'processingOrders' => $this->count_orders_by_status('processing'),
            'totalProducts' => $this->count_products(),
            'lowStockProducts' => $this->count_low_stock_products(),
            'revenueToday' => 0.0,
            'revenue7d' => 0.0,
            'ordersToday' => 0,
            'orders7d' => 0,
            'averageOrderValue7d' => 0.0,
            'refundRate7d' => 0.0,
            'currency' => get_woocommerce_currency(),
            'customerInsights' => $this->calculate_customer_insights_payload(),
        ];

        $today_metrics = $this->calculate_order_window_metrics(new DateTimeImmutable('today', wp_timezone()));
        $week_metrics = $this->calculate_order_window_metrics((new DateTimeImmutable('today', wp_timezone()))->modify('-6 days'));

        $payload['revenueToday'] = $today_metrics['revenue'];
        $payload['ordersToday'] = $today_metrics['orders'];
        $payload['revenue7d'] = $week_metrics['revenue'];
        $payload['orders7d'] = $week_metrics['orders'];
        $payload['averageOrderValue7d'] = $week_metrics['orders'] > 0 ? round($week_metrics['revenue'] / $week_metrics['orders'], 2) : 0.0;
        $payload['refundRate7d'] = $week_metrics['ordersTotal'] > 0 ? round(($week_metrics['refundedOrders'] / $week_metrics['ordersTotal']) * 100, 2) : 0.0;

        return new WP_REST_Response($payload, 200);
    }

    /**
     * @return WP_REST_Response|WP_Error
     */
    public function store_orders_endpoint(WP_REST_Request $request)
    {
        unset($request);

        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_connector_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $orders = wc_get_orders([
            'limit' => 20,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => array_keys(wc_get_order_statuses()),
        ]);

        $payload = [];

        foreach ($orders as $order) {
            if (!$order instanceof WC_Order) {
                continue;
            }

            $payload[] = [
                'id' => $order->get_id(),
                'status' => $order->get_status(),
                'date_created' => $order->get_date_created() ? $order->get_date_created()->date('c') : '',
                'total' => wc_format_decimal($order->get_total(), wc_get_price_decimals()),
                'currency' => $order->get_currency(),
                'billing' => [
                    'first_name' => $order->get_billing_first_name(),
                    'last_name' => $order->get_billing_last_name(),
                ],
            ];
        }

        return new WP_REST_Response($payload, 200);
    }

    /**
     * @return WP_REST_Response|WP_Error
     */
    public function plugins_list_endpoint(WP_REST_Request $request)
    {
        unset($request);

        $proxy = $this->proxy_wp_plugins_request('GET', '/wp/v2/plugins');
        if ($proxy instanceof WP_Error) {
            return $proxy;
        }

        if ($proxy->get_status() === 404) {
            return new WP_REST_Response([
                'supported' => false,
                'message' => 'This site does not expose /wp/v2/plugins for the authenticated user.',
                'plugins' => [],
            ], 200);
        }

        if ($proxy->get_status() >= 400) {
            return new WP_Error(
                'quick_connector_plugins_list_failed',
                'Failed to load plugin list.',
                ['status' => $proxy->get_status(), 'details' => $proxy->get_data()]
            );
        }

        $data = $proxy->get_data();
        if (!is_array($data)) {
            return new WP_Error(
                'quick_connector_plugins_invalid',
                'Plugin list response shape is invalid.',
                ['status' => 500]
            );
        }

        $plugins = [];
        foreach ($data as $item) {
            if (!is_array($item)) {
                continue;
            }
            $plugins[] = $this->map_plugin_payload($item);
        }

        return new WP_REST_Response([
            'supported' => true,
            'message' => 'Plugin list loaded.',
            'plugins' => $plugins,
        ], 200);
    }

    /**
     * @return WP_REST_Response|WP_Error
     */
    public function plugins_install_endpoint(WP_REST_Request $request)
    {
        if (!current_user_can('install_plugins')) {
            $this->record_audit_event('plugin-install', 'denied', [
                'reason' => 'capability',
                'requiredCapability' => 'install_plugins',
            ]);
            return new WP_Error('quick_connector_forbidden', 'User cannot install plugins.', ['status' => 403]);
        }

        $slug = sanitize_text_field((string) $request->get_param('slug'));
        $status = sanitize_text_field((string) ($request->get_param('status') ?: 'inactive'));

        if ($slug === '' || !preg_match('/^[a-zA-Z0-9-]+$/', $slug)) {
            return new WP_Error(
                'quick_connector_invalid_slug',
                'Plugin slug is required and may include letters, numbers, and hyphens only.',
                ['status' => 400]
            );
        }

        if ($status !== 'active' && $status !== 'inactive') {
            return new WP_Error(
                'quick_connector_invalid_status',
                'Plugin status must be active or inactive.',
                ['status' => 400]
            );
        }

        $proxy = $this->proxy_wp_plugins_request('POST', '/wp/v2/plugins', [
            'slug' => $slug,
            'status' => $status,
        ]);
        if ($proxy instanceof WP_Error) {
            return $proxy;
        }

        if ($proxy->get_status() >= 400) {
            return new WP_Error(
                'quick_connector_plugins_install_failed',
                'Plugin install request failed.',
                ['status' => $proxy->get_status(), 'details' => $proxy->get_data()]
            );
        }

        $data = $proxy->get_data();
        if (!is_array($data)) {
            return new WP_Error(
                'quick_connector_plugins_invalid',
                'Plugin install response shape is invalid.',
                ['status' => 500]
            );
        }

        $mapped = $this->map_plugin_payload($data);
        $this->record_audit_event('plugin-install', 'success', [
            'plugin' => isset($mapped['plugin']) ? (string) $mapped['plugin'] : $slug,
            'status' => isset($mapped['status']) ? (string) $mapped['status'] : $status,
        ]);
        return new WP_REST_Response($mapped, 200);
    }

    /**
     * @return WP_REST_Response|WP_Error
     */
    public function plugins_status_endpoint(WP_REST_Request $request)
    {
        if (!current_user_can('activate_plugins')) {
            $this->record_audit_event('plugin-status', 'denied', [
                'reason' => 'capability',
                'requiredCapability' => 'activate_plugins',
            ]);
            return new WP_Error('quick_connector_forbidden', 'User cannot change plugin status.', ['status' => 403]);
        }

        $plugin = sanitize_text_field((string) $request->get_param('plugin'));
        $status = sanitize_text_field((string) $request->get_param('status'));

        if ($plugin === '') {
            return new WP_Error('quick_connector_invalid_plugin', 'Plugin key is required.', ['status' => 400]);
        }

        if ($status !== 'active' && $status !== 'inactive') {
            return new WP_Error(
                'quick_connector_invalid_status',
                'Plugin status must be active or inactive.',
                ['status' => 400]
            );
        }

        $candidates = $this->build_plugin_key_candidates($plugin);
        $last_proxy = null;

        foreach ($candidates as $candidate) {
            $proxy = $this->proxy_wp_plugins_request('POST', '/wp/v2/plugins/' . $candidate, [
                'status' => $status,
            ]);
            if ($proxy instanceof WP_Error) {
                return $proxy;
            }

            if ($proxy->get_status() >= 200 && $proxy->get_status() < 300) {
                $data = $proxy->get_data();
                if (!is_array($data)) {
                    return new WP_Error(
                        'quick_connector_plugins_invalid',
                        'Plugin status response shape is invalid.',
                        ['status' => 500]
                    );
                }

                $mapped = $this->map_plugin_payload($data);
                $this->record_audit_event('plugin-status', 'success', [
                    'plugin' => isset($mapped['plugin']) ? (string) $mapped['plugin'] : $plugin,
                    'status' => isset($mapped['status']) ? (string) $mapped['status'] : $status,
                ]);
                return new WP_REST_Response($mapped, 200);
            }

            $last_proxy = $proxy;
        }

        return new WP_Error(
            'quick_connector_plugins_status_failed',
            'Plugin status request failed.',
            [
                'status' => $last_proxy instanceof WP_REST_Response ? $last_proxy->get_status() : 404,
                'details' => $last_proxy instanceof WP_REST_Response ? $last_proxy->get_data() : null,
            ]
        );
    }

    /**
     * @return WP_REST_Response|WP_Error
     */
    public function plugins_update_endpoint(WP_REST_Request $request)
    {
        if (!current_user_can('update_plugins')) {
            $this->record_audit_event('plugin-update', 'denied', [
                'reason' => 'capability',
                'requiredCapability' => 'update_plugins',
            ]);
            return new WP_Error('quick_connector_forbidden', 'User cannot update plugins.', ['status' => 403]);
        }

        $plugin = sanitize_text_field((string) $request->get_param('plugin'));
        if ($plugin === '') {
            return new WP_Error('quick_connector_invalid_plugin', 'Plugin key is required.', ['status' => 400]);
        }

        $resolved = $this->resolve_installed_plugin_file($plugin);
        if ($resolved === null) {
            return new WP_Error('quick_connector_plugin_not_found', 'Plugin not found.', ['status' => 404]);
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

        wp_update_plugins();

        $skin = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        $result = $upgrader->upgrade($resolved);

        if (is_wp_error($result)) {
            return new WP_Error(
                'quick_connector_plugins_update_failed',
                'Plugin update failed.',
                ['status' => 500, 'details' => $result->get_error_message()]
            );
        }

        if ($result === false) {
            return new WP_Error(
                'quick_connector_plugins_update_failed',
                'Plugin update failed or no update was available.',
                ['status' => 400]
            );
        }

        $plugin_data = $this->get_installed_plugin_data($resolved);
        if ($plugin_data === null) {
            return new WP_Error(
                'quick_connector_plugins_invalid',
                'Plugin updated but could not load plugin metadata.',
                ['status' => 500]
            );
        }

        $mapped = $this->map_plugin_payload($plugin_data);
        $this->record_audit_event('plugin-update', 'success', [
            'plugin' => isset($mapped['plugin']) ? (string) $mapped['plugin'] : $resolved,
            'status' => isset($mapped['status']) ? (string) $mapped['status'] : '',
        ]);
        return new WP_REST_Response($mapped, 200);
    }

    /**
     * @return WP_REST_Response|WP_Error
     */
    public function plugins_delete_endpoint(WP_REST_Request $request)
    {
        if (!current_user_can('delete_plugins')) {
            $this->record_audit_event('plugin-delete', 'denied', [
                'reason' => 'capability',
                'requiredCapability' => 'delete_plugins',
            ]);
            return new WP_Error('quick_connector_forbidden', 'User cannot delete plugins.', ['status' => 403]);
        }

        $plugin = sanitize_text_field((string) $request->get_param('plugin'));
        if ($plugin === '') {
            return new WP_Error('quick_connector_invalid_plugin', 'Plugin key is required.', ['status' => 400]);
        }

        $resolved = $this->resolve_installed_plugin_file($plugin);
        if ($resolved === null) {
            return new WP_Error('quick_connector_plugin_not_found', 'Plugin not found.', ['status' => 404]);
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

        if (is_plugin_active($resolved)) {
            deactivate_plugins($resolved, true);
        }

        $result = delete_plugins([$resolved]);
        if (is_wp_error($result)) {
            return new WP_Error(
                'quick_connector_plugins_delete_failed',
                'Plugin delete failed.',
                ['status' => 500, 'details' => $result->get_error_message()]
            );
        }

        if ($result === false) {
            return new WP_Error(
                'quick_connector_plugins_delete_failed',
                'Plugin delete failed.',
                ['status' => 500]
            );
        }

        $this->record_audit_event('plugin-delete', 'success', [
            'plugin' => $resolved,
        ]);

        return new WP_REST_Response([
            'ok' => true,
            'message' => 'Plugin deleted.',
            'plugin' => $resolved,
        ], 200);
    }

    /**
     * @return true|WP_Error
     */
    private function assert_module_action_capability(string $module, string $action)
    {
        $required_capability = $this->required_module_action_capability($module, $action);
        if ($required_capability === null) {
            return true;
        }

        if (!current_user_can($required_capability)) {
            return new WP_Error(
                'quick_connector_forbidden_action',
                sprintf('User cannot run %s:%s.', $module, $action),
                [
                    'status' => 403,
                    'requiredCapability' => $required_capability,
                ]
            );
        }

        return true;
    }

    private function required_module_action_capability(string $module, string $action): ?string
    {
        if ($action === 'open' || str_starts_with($action, 'export-') || str_starts_with($action, 'list-')) {
            return 'manage_options';
        }

        if ($module === 'quick-add' || $module === 'quick-edit' || $module === 'quick-variations' || $module === 'quick-ship') {
            if ($action !== 'open') {
                return 'manage_woocommerce';
            }
        }

        if ($action === 'save-snippet' || $action === 'update-snippet' || $action === 'save-conditions') {
            return 'edit_theme_options';
        }

        if (
            str_starts_with($action, 'save-')
            || str_starts_with($action, 'create-')
            || str_starts_with($action, 'update-')
            || str_starts_with($action, 'set-')
            || str_starts_with($action, 'delete-')
            || str_starts_with($action, 'run-')
            || str_starts_with($action, 'purge-')
            || str_starts_with($action, 'import-')
            || $action === 'install-dropin'
            || $action === 'db-cleanup'
            || $action === 'reset-data'
        ) {
            return 'manage_options';
        }

        return 'manage_options';
    }

    private function record_audit_event(string $scope, string $outcome, array $context = []): void
    {
        $events = get_option(self::AUDIT_LOG_OPTION, []);
        if (!is_array($events)) {
            $events = [];
        }

        $user = wp_get_current_user();
        $event = [
            'timestamp' => gmdate('c'),
            'scope' => sanitize_key($scope),
            'outcome' => sanitize_key($outcome),
            'userId' => (int) ($user instanceof WP_User ? $user->ID : 0),
            'userLogin' => $user instanceof WP_User ? sanitize_user((string) $user->user_login, true) : '',
            'ip' => $this->resolve_client_ip(),
            'context' => $this->sanitize_audit_context($context),
        ];

        array_unshift($events, $event);
        if (count($events) > self::AUDIT_LOG_MAX) {
            $events = array_slice($events, 0, self::AUDIT_LOG_MAX);
        }
        update_option(self::AUDIT_LOG_OPTION, array_values($events), false);
    }

    /**
     * @return array<string, scalar|null>
     */
    private function sanitize_audit_context(array $context): array
    {
        $safe = [];
        foreach ($context as $key => $value) {
            $safe_key = sanitize_key((string) $key);
            if ($safe_key === '') {
                continue;
            }

            if (is_scalar($value) || $value === null) {
                if (is_string($value)) {
                    $safe[$safe_key] = sanitize_text_field($value);
                } else {
                    $safe[$safe_key] = $value;
                }
            }
        }

        return $safe;
    }

    private function resolve_client_ip(): string
    {
        $remote_addr = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
        if ($remote_addr !== '' && filter_var($remote_addr, FILTER_VALIDATE_IP)) {
            return $remote_addr;
        }

        return '';
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function get_recent_posts_payload(): array
    {
        $posts = get_posts([
            'post_type' => 'post',
            'post_status' => ['publish', 'draft', 'pending', 'private'],
            'numberposts' => 10,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        $payload = [];

        foreach ($posts as $post) {
            $payload[] = [
                'id' => $post->ID,
                'date' => get_post_time('c', true, $post),
                'status' => $post->post_status,
                'link' => get_permalink($post) ?: '',
                'title' => ['rendered' => get_the_title($post)],
            ];
        }

        return $payload;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function get_recent_pages_payload(): array
    {
        $pages = get_posts([
            'post_type' => 'page',
            'post_status' => ['publish', 'draft', 'pending', 'private'],
            'numberposts' => 10,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        $payload = [];

        foreach ($pages as $page) {
            $payload[] = [
                'id' => $page->ID,
                'date' => get_post_time('c', true, $page),
                'status' => $page->post_status,
                'link' => get_permalink($page) ?: '',
                'title' => ['rendered' => get_the_title($page)],
            ];
        }

        return $payload;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function get_recent_media_payload(): array
    {
        $media = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'numberposts' => 10,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        $payload = [];

        foreach ($media as $item) {
            $mime = get_post_mime_type($item);
            $media_type = is_string($mime) && str_contains($mime, '/') ? explode('/', $mime)[0] : 'file';

            $payload[] = [
                'id' => $item->ID,
                'date' => get_post_time('c', true, $item),
                'media_type' => $media_type,
                'source_url' => wp_get_attachment_url($item->ID) ?: '',
                'title' => ['rendered' => get_the_title($item)],
            ];
        }

        return $payload;
    }

    private function count_orders_by_status(string $status): int
    {
        if (!function_exists('wc_orders_count')) {
            return 0;
        }

        return (int) wc_orders_count($status);
    }

    private function count_products(): int
    {
        $counts = wp_count_posts('product');
        if (!$counts instanceof stdClass) {
            return 0;
        }

        return isset($counts->publish) ? (int) $counts->publish : 0;
    }

    private function count_low_stock_products(): int
    {
        if (!function_exists('wc_get_products')) {
            return 0;
        }

        $products = wc_get_products([
            'status' => 'publish',
            'stock_status' => 'instock',
            'limit' => -1,
            'return' => 'objects',
        ]);

        $count = 0;

        foreach ($products as $product) {
            if (!$product instanceof WC_Product) {
                continue;
            }

            if (!$product->managing_stock()) {
                continue;
            }

            $stock_quantity = $product->get_stock_quantity();
            if (!is_numeric($stock_quantity)) {
                continue;
            }

            $threshold = wc_get_low_stock_amount($product);
            if ($threshold === '' || $threshold === null) {
                continue;
            }

            if ((int) $stock_quantity <= (int) $threshold) {
                $count++;
            }
        }

        return $count;
    }

    /**
     * @return array{revenue: float, orders: int, refundedOrders: int, ordersTotal: int}
     */
    private function calculate_order_window_metrics(DateTimeImmutable $start): array
    {
        if (!class_exists('WooCommerce') || !function_exists('wc_get_orders')) {
            return [
                'revenue' => 0.0,
                'orders' => 0,
                'refundedOrders' => 0,
                'ordersTotal' => 0,
            ];
        }

        $paid_statuses = function_exists('wc_get_is_paid_statuses') ? wc_get_is_paid_statuses() : ['processing', 'completed'];
        if (!is_array($paid_statuses) || count($paid_statuses) === 0) {
            $paid_statuses = ['processing', 'completed'];
        }

        $window_statuses = array_values(array_unique(array_merge($paid_statuses, ['refunded'])));
        $date_query = '>=' . $start->format('Y-m-d H:i:s');
        $orders = wc_get_orders([
            'limit' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => $window_statuses,
            'date_created' => $date_query,
        ]);

        $revenue = 0.0;
        $paid_count = 0;
        $refunded_count = 0;
        $total_count = 0;

        foreach ($orders as $order) {
            if (!$order instanceof WC_Order) {
                continue;
            }

            $total_count++;
            $status = $order->get_status();
            if (in_array($status, $paid_statuses, true)) {
                $paid_count++;
                $revenue += (float) $order->get_total();
                continue;
            }

            if ($status === 'refunded') {
                $refunded_count++;
            }
        }

        return [
            'revenue' => round($revenue, 2),
            'orders' => $paid_count,
            'refundedOrders' => $refunded_count,
            'ordersTotal' => $total_count,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function calculate_customer_insights_payload(): array
    {
        if (!class_exists('WooCommerce') || !function_exists('wc_get_orders')) {
            return [
                'newCustomers30d' => 0,
                'returningCustomers30d' => 0,
                'highLtvCustomers' => [],
                'churnRiskCustomers' => [],
                'anomalies7d' => [],
            ];
        }

        $now = new DateTimeImmutable('now', wp_timezone());
        $start_365 = $now->modify('-365 days');
        $start_30 = $now->modify('-30 days');
        $start_60 = $now->modify('-60 days');
        $start_7 = $now->modify('-7 days');

        $paid_statuses = function_exists('wc_get_is_paid_statuses') ? wc_get_is_paid_statuses() : ['processing', 'completed'];
        if (!is_array($paid_statuses) || count($paid_statuses) === 0) {
            $paid_statuses = ['processing', 'completed'];
        }

        $all_statuses = array_values(array_unique(array_merge($paid_statuses, ['cancelled', 'failed', 'refunded'])));
        $orders_365 = wc_get_orders([
            'limit' => 800,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => $all_statuses,
            'date_created' => '>=' . $start_365->format('Y-m-d H:i:s'),
        ]);

        $customers = [];
        $orders_7d_total = 0;
        $orders_7d_cancelled = 0;
        $orders_7d_failed = 0;
        $orders_7d_refunded = 0;

        foreach ($orders_365 as $order) {
            if (!$order instanceof WC_Order) {
                continue;
            }

            $email = strtolower(trim((string) $order->get_billing_email()));
            if ($email === '') {
                continue;
            }

            $created = $order->get_date_created();
            if (!$created) {
                continue;
            }
            $created_at = DateTimeImmutable::createFromInterface($created);
            $status = (string) $order->get_status();

            if (!isset($customers[$email])) {
                $customers[$email] = [
                    'email' => $email,
                    'name' => trim((string) $order->get_billing_first_name() . ' ' . (string) $order->get_billing_last_name()),
                    'firstPaidAt' => null,
                    'lastPaidAt' => null,
                    'paidOrderCount' => 0,
                    'paidOrderCount30d' => 0,
                    'paidSpend' => 0.0,
                ];
            }

            if ($created_at >= $start_7) {
                $orders_7d_total++;
                if ($status === 'cancelled') {
                    $orders_7d_cancelled++;
                } elseif ($status === 'failed') {
                    $orders_7d_failed++;
                } elseif ($status === 'refunded') {
                    $orders_7d_refunded++;
                }
            }

            if (!in_array($status, $paid_statuses, true)) {
                continue;
            }

            $customers[$email]['paidOrderCount']++;
            $customers[$email]['paidSpend'] += (float) $order->get_total();
            if ($created_at >= $start_30) {
                $customers[$email]['paidOrderCount30d']++;
            }

            if ($customers[$email]['firstPaidAt'] === null || $created_at < $customers[$email]['firstPaidAt']) {
                $customers[$email]['firstPaidAt'] = $created_at;
            }
            if ($customers[$email]['lastPaidAt'] === null || $created_at > $customers[$email]['lastPaidAt']) {
                $customers[$email]['lastPaidAt'] = $created_at;
            }
        }

        $new_customers_30d = 0;
        $returning_customers_30d = 0;
        $high_ltv = [];
        $churn_risk = [];

        foreach ($customers as $customer) {
            if ($customer['paidOrderCount30d'] > 0) {
                if ($customer['firstPaidAt'] instanceof DateTimeImmutable && $customer['firstPaidAt'] >= $start_30) {
                    $new_customers_30d++;
                } else {
                    $returning_customers_30d++;
                }
            }

            if ($customer['paidOrderCount'] >= 1) {
                $high_ltv[] = [
                    'email' => $customer['email'],
                    'name' => $customer['name'] !== '' ? $customer['name'] : $customer['email'],
                    'totalSpend' => round((float) $customer['paidSpend'], 2),
                    'orders' => (int) $customer['paidOrderCount'],
                ];
            }

            if (
                $customer['paidOrderCount'] >= 2
                && $customer['lastPaidAt'] instanceof DateTimeImmutable
                && $customer['lastPaidAt'] < $start_60
            ) {
                $churn_risk[] = [
                    'email' => $customer['email'],
                    'name' => $customer['name'] !== '' ? $customer['name'] : $customer['email'],
                    'daysSinceLastOrder' => (int) floor(($now->getTimestamp() - $customer['lastPaidAt']->getTimestamp()) / DAY_IN_SECONDS),
                    'orders' => (int) $customer['paidOrderCount'],
                    'totalSpend' => round((float) $customer['paidSpend'], 2),
                ];
            }
        }

        usort($high_ltv, static function (array $a, array $b): int {
            return ((float) $b['totalSpend'] <=> (float) $a['totalSpend']);
        });
        usort($churn_risk, static function (array $a, array $b): int {
            return ((int) $b['daysSinceLastOrder'] <=> (int) $a['daysSinceLastOrder']);
        });

        $anomalies = [];
        if ($orders_7d_total > 0) {
            $cancel_rate = ($orders_7d_cancelled / $orders_7d_total) * 100;
            $refund_rate = ($orders_7d_refunded / $orders_7d_total) * 100;
            $failed_rate = ($orders_7d_failed / $orders_7d_total) * 100;

            if ($cancel_rate >= 5) {
                $anomalies[] = [
                    'type' => 'cancellation_spike',
                    'count' => $orders_7d_cancelled,
                    'ratePercent' => round($cancel_rate, 2),
                    'severity' => $cancel_rate >= 10 ? 'high' : 'medium',
                    'detail' => 'Cancelled orders rate in last 7 days is elevated.',
                ];
            }
            if ($refund_rate >= 4) {
                $anomalies[] = [
                    'type' => 'refund_spike',
                    'count' => $orders_7d_refunded,
                    'ratePercent' => round($refund_rate, 2),
                    'severity' => $refund_rate >= 8 ? 'high' : 'medium',
                    'detail' => 'Refunded orders rate in last 7 days is elevated.',
                ];
            }
            if ($failed_rate >= 3) {
                $anomalies[] = [
                    'type' => 'payment_failure_spike',
                    'count' => $orders_7d_failed,
                    'ratePercent' => round($failed_rate, 2),
                    'severity' => $failed_rate >= 6 ? 'high' : 'medium',
                    'detail' => 'Failed orders rate in last 7 days is elevated.',
                ];
            }
        }

        return [
            'newCustomers30d' => $new_customers_30d,
            'returningCustomers30d' => $returning_customers_30d,
            'highLtvCustomers' => array_slice($high_ltv, 0, 5),
            'churnRiskCustomers' => array_slice($churn_risk, 0, 5),
            'anomalies7d' => $anomalies,
        ];
    }

    /**
     * @param array<string, mixed> $item
     * @return array<string, mixed>
     */
    private function map_plugin_payload(array $item): array
    {
        return [
            'plugin' => isset($item['plugin']) ? (string) $item['plugin'] : '',
            'name' => isset($item['name']) ? (string) $item['name'] : '',
            'version' => isset($item['version']) ? (string) $item['version'] : '',
            'status' => (isset($item['status']) && $item['status'] === 'active') ? 'active' : 'inactive',
        ];
    }

    /**
     * @return array<int, string>
     */
    private function build_plugin_key_candidates(string $plugin): array
    {
        $decoded = rawurldecode($plugin);
        $normalized = trim($decoded);
        $candidates = [];

        if ($normalized !== '') {
            $candidates[] = $normalized;
        }

        // Some sites report keys without ".php" while wp/v2/plugins routes expect file keys.
        if (!str_ends_with($normalized, '.php') && str_contains($normalized, '/')) {
            $parts = explode('/', $normalized);
            $last = array_pop($parts);
            $parts[] = $last . '.php';
            $candidates[] = implode('/', $parts);
        }

        // Deduplicate while preserving order.
        return array_values(array_unique($candidates));
    }

    private function resolve_installed_plugin_file(string $plugin): ?string
    {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $installed = get_plugins();
        $candidates = $this->build_plugin_key_candidates($plugin);

        foreach ($candidates as $candidate) {
            if (isset($installed[$candidate])) {
                return $candidate;
            }
        }

        foreach (array_keys($installed) as $plugin_file) {
            foreach ($candidates as $candidate) {
                if ($plugin_file === $candidate || str_starts_with($plugin_file, $candidate . '/')) {
                    return $plugin_file;
                }
            }
        }

        return null;
    }

    /**
     * @return array<string, mixed>|null
     */
    private function get_installed_plugin_data(string $plugin_file): ?array
    {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $installed = get_plugins();
        if (!isset($installed[$plugin_file])) {
            return null;
        }

        $plugin = $installed[$plugin_file];

        return [
            'plugin' => $plugin_file,
            'name' => isset($plugin['Name']) ? (string) $plugin['Name'] : '',
            'version' => isset($plugin['Version']) ? (string) $plugin['Version'] : '',
            'status' => is_plugin_active($plugin_file) ? 'active' : 'inactive',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_importer_open_payload(): array
    {
        $settings = $this->quick_importer_get_settings();
        $logs = $this->quick_importer_get_logs();
        $templates = $this->quick_importer_get_templates();
        $post_counts = wp_count_posts('post');
        $page_counts = wp_count_posts('page');
        $product_counts = class_exists('WooCommerce') ? wp_count_posts('product') : null;
        $media_counts = wp_count_posts('attachment');

        $posts = ($post_counts instanceof stdClass && isset($post_counts->publish)) ? (int) $post_counts->publish : 0;
        $pages = ($page_counts instanceof stdClass && isset($page_counts->publish)) ? (int) $page_counts->publish : 0;
        $products = ($product_counts instanceof stdClass && isset($product_counts->publish)) ? (int) $product_counts->publish : 0;
        $media = ($media_counts instanceof stdClass && isset($media_counts->inherit)) ? (int) $media_counts->inherit : 0;
        $users = (int) count_users()['total_users'];

        return [
            'summary' => [
                'posts' => $posts,
                'pages' => $pages,
                'products' => $products,
                'media' => $media,
                'users' => $users,
            ],
            'connectorVersion' => QUICK_CONNECTOR_VERSION,
            'siteUrl' => get_site_url(),
            'settings' => $settings,
            'logs' => $logs,
            'templates' => $templates,
            'serverTimeUtc' => gmdate('c'),
            'lastImportRunUtc' => get_option('quick_importer_last_run_utc', null),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_importer_default_settings(): array
    {
        return [
            'max_upload_mb' => 10,
            'batch_size' => 50,
            'auto_create_terms' => 1,
            'default_import_mode' => 'update_create',
            'default_matching_key' => 'id',
            'default_delimiter' => ',',
            'utf8_bom' => 0,
            'debug_mode' => 0,
            'scheduled_exports_enabled' => 0,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_importer_get_settings(): array
    {
        $saved = get_option('qiim_settings', []);
        if (!is_array($saved)) {
            $saved = [];
        }
        $settings = wp_parse_args($saved, $this->quick_importer_default_settings());
        $settings['max_upload_mb'] = max(1, absint($settings['max_upload_mb']));
        $settings['batch_size'] = max(1, absint($settings['batch_size']));
        $settings['auto_create_terms'] = $this->quick_site_bool_to_int($settings['auto_create_terms']);
        $settings['utf8_bom'] = $this->quick_site_bool_to_int($settings['utf8_bom']);
        $settings['debug_mode'] = $this->quick_site_bool_to_int($settings['debug_mode']);
        $settings['scheduled_exports_enabled'] = $this->quick_site_bool_to_int($settings['scheduled_exports_enabled']);
        $settings['default_import_mode'] = in_array((string) $settings['default_import_mode'], ['update_create', 'update_only', 'create_only'], true)
            ? (string) $settings['default_import_mode']
            : 'update_create';
        $settings['default_matching_key'] = in_array((string) $settings['default_matching_key'], ['id', 'slug', 'title', 'sku', 'meta'], true)
            ? (string) $settings['default_matching_key']
            : 'id';
        $delimiter = (string) $settings['default_delimiter'];
        $settings['default_delimiter'] = strlen($delimiter) > 0 ? substr($delimiter, 0, 1) : ',';
        return $settings;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_importer_get_logs(): array
    {
        $logs = get_option('qiim_logs', []);
        if (!is_array($logs)) {
            return [];
        }
        $rows = [];
        foreach ($logs as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $rows[] = [
                'date' => isset($entry['date']) ? sanitize_text_field((string) $entry['date']) : '',
                'type' => isset($entry['type']) ? sanitize_key((string) $entry['type']) : '',
                'contentType' => isset($entry['content_type']) ? sanitize_text_field((string) $entry['content_type']) : '',
                'totalRows' => isset($entry['total_rows']) ? (int) $entry['total_rows'] : 0,
                'success' => isset($entry['success']) ? (int) $entry['success'] : 0,
                'failed' => isset($entry['failed']) ? (int) $entry['failed'] : 0,
                'duration' => isset($entry['duration']) ? (float) $entry['duration'] : 0.0,
                'details' => isset($entry['details']) && is_array($entry['details']) ? $entry['details'] : [],
            ];
        }
        return $rows;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function quick_importer_get_templates(): array
    {
        $templates = get_option('qiim_templates', ['import' => [], 'export' => []]);
        if (!is_array($templates)) {
            $templates = ['import' => [], 'export' => []];
        }
        $import_templates = isset($templates['import']) && is_array($templates['import']) ? $templates['import'] : [];
        $export_templates = isset($templates['export']) && is_array($templates['export']) ? $templates['export'] : [];

        return [
            'import' => $import_templates,
            'export' => $export_templates,
        ];
    }

    private function quick_importer_add_log(string $type, string $content_type, int $total_rows, int $success, int $failed, float $duration, array $details = []): void
    {
        $logs = get_option('qiim_logs', []);
        if (!is_array($logs)) {
            $logs = [];
        }
        $logs[] = [
            'date' => current_time('mysql'),
            'type' => sanitize_key($type),
            'content_type' => sanitize_text_field($content_type),
            'total_rows' => max(0, $total_rows),
            'success' => max(0, $success),
            'failed' => max(0, $failed),
            'duration' => max(0.0, $duration),
            'details' => $details,
        ];
        if (count($logs) > 20) {
            $logs = array_slice($logs, -20);
        }
        update_option('qiim_logs', $logs, false);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function quick_importer_save_settings_payload(array $payload): array
    {
        $settings = $this->quick_importer_get_settings();
        if (isset($payload['max_upload_mb'])) {
            $settings['max_upload_mb'] = max(1, absint($payload['max_upload_mb']));
        }
        if (isset($payload['batch_size'])) {
            $settings['batch_size'] = max(1, absint($payload['batch_size']));
        }
        foreach (['auto_create_terms', 'utf8_bom', 'debug_mode', 'scheduled_exports_enabled'] as $flag) {
            if (array_key_exists($flag, $payload)) {
                $settings[$flag] = $this->quick_site_bool_to_int($payload[$flag]);
            }
        }
        if (isset($payload['default_import_mode'])) {
            $mode = sanitize_key((string) $payload['default_import_mode']);
            if (in_array($mode, ['update_create', 'update_only', 'create_only'], true)) {
                $settings['default_import_mode'] = $mode;
            }
        }
        if (isset($payload['default_matching_key'])) {
            $key = sanitize_key((string) $payload['default_matching_key']);
            if (in_array($key, ['id', 'slug', 'title', 'sku', 'meta'], true)) {
                $settings['default_matching_key'] = $key;
            }
        }
        if (isset($payload['default_delimiter'])) {
            $delimiter = (string) $payload['default_delimiter'];
            $settings['default_delimiter'] = strlen($delimiter) > 0 ? substr($delimiter, 0, 1) : ',';
        }

        update_option('qiim_settings', $settings, false);
        $workspace = $this->quick_importer_open_payload();

        return [
            'settings' => $settings,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_importer_save_template_payload(array $payload)
    {
        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : '';
        $group = isset($payload['group']) ? sanitize_key((string) $payload['group']) : 'import';
        $template_payload = isset($payload['template']) && is_array($payload['template']) ? $payload['template'] : [];
        if ($name === '') {
            return new WP_Error('quick_importer_template_name_required', 'Template name is required.', ['status' => 400]);
        }
        if (!in_array($group, ['import', 'export'], true)) {
            return new WP_Error('quick_importer_template_group_invalid', 'Template group must be import or export.', ['status' => 400]);
        }

        $templates = $this->quick_importer_get_templates();
        $templates[$group][$name] = $template_payload;
        update_option('qiim_templates', $templates, false);
        $workspace = $this->quick_importer_open_payload();

        return [
            'group' => $group,
            'name' => $name,
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : $templates,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_importer_delete_template_payload(array $payload)
    {
        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : '';
        $group = isset($payload['group']) ? sanitize_key((string) $payload['group']) : '';
        if ($name === '' || !in_array($group, ['import', 'export'], true)) {
            return new WP_Error('quick_importer_template_invalid', 'Template name and valid group are required.', ['status' => 400]);
        }
        $templates = $this->quick_importer_get_templates();
        if (isset($templates[$group][$name])) {
            unset($templates[$group][$name]);
            update_option('qiim_templates', $templates, false);
        }
        $workspace = $this->quick_importer_open_payload();
        return [
            'group' => $group,
            'name' => $name,
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : $templates,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_importer_clear_logs_payload(): array
    {
        update_option('qiim_logs', [], false);
        $workspace = $this->quick_importer_open_payload();
        return [
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_site_open_payload(): array
    {
        $settings = $this->quick_site_get_settings();
        $integrations = $this->quick_site_get_integrations();
        $cache_dir = $this->quick_site_cache_pages_dir();
        $page_counts = wp_count_posts('page');
        $post_counts = wp_count_posts('post');

        $total_pages = ($page_counts instanceof stdClass && isset($page_counts->publish)) ? (int) $page_counts->publish : 0;
        $draft_pages = ($page_counts instanceof stdClass && isset($page_counts->draft)) ? (int) $page_counts->draft : 0;
        $total_posts = ($post_counts instanceof stdClass && isset($post_counts->publish)) ? (int) $post_counts->publish : 0;

        $latest_pages = get_posts([
            'post_type' => 'page',
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'numberposts' => 5,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);

        $latest = [];
        foreach ($latest_pages as $page) {
            $latest[] = [
                'id' => $page->ID,
                'title' => (string) $page->post_title,
                'status' => (string) $page->post_status,
                'modified' => get_post_modified_time('c', true, $page),
            ];
        }

        $latest_posts = get_posts([
            'post_type' => 'post',
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'numberposts' => 5,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);
        $posts = [];
        foreach ($latest_posts as $post) {
            if (!$post instanceof WP_Post) {
                continue;
            }
            $posts[] = [
                'id' => $post->ID,
                'title' => (string) $post->post_title,
                'status' => (string) $post->post_status,
                'modified' => get_post_modified_time('c', true, $post),
            ];
        }

        $db_last_run = get_option('quick_site_db_last_run', '');
        return [
            'summary' => [
                'totalPages' => $total_pages,
                'draftPages' => $draft_pages,
                'totalPosts' => $total_posts,
                'safeMode' => !empty($settings['safe_mode']) ? 1 : 0,
                'pageCacheEnabled' => !empty($settings['page_cache_enabled']) ? 1 : 0,
                'dropinInstalled' => $this->quick_site_is_dropin_installed() ? 1 : 0,
                'cacheTtl' => (int) $settings['cache_ttl'],
                'cacheFiles' => $this->quick_site_cache_file_count(),
                'cacheSizeBytes' => $this->quick_site_get_cache_size_bytes(),
                'cacheHits' => $this->quick_site_get_cache_stat('hits'),
                'cacheMisses' => $this->quick_site_get_cache_stat('misses'),
            ],
            'settings' => $settings,
            'integrations' => $integrations,
            'latestPages' => $latest,
            'latestPosts' => $posts,
            'cache' => [
                'pagesDir' => $cache_dir,
                'files' => $this->quick_site_cache_file_count(),
                'sizeBytes' => $this->quick_site_get_cache_size_bytes(),
                'stats' => [
                    'hits' => $this->quick_site_get_cache_stat('hits'),
                    'misses' => $this->quick_site_get_cache_stat('misses'),
                ],
                'dropinInstalled' => $this->quick_site_is_dropin_installed(),
            ],
            'database' => [
                'lastRun' => is_string($db_last_run) ? $db_last_run : '',
            ],
            'diagnostics' => $this->quick_site_get_diagnostics(),
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_site_default_settings(): array
    {
        return [
            'page_cache_enabled' => 1,
            'cache_ttl' => 600,
            'cache_search' => 0,
            'query_whitelist' => "gclid\nfbclid",
            'ignore_query_prefixes' => "utm_",
            'split_device' => 0,
            'split_language' => 0,
            'exclude_urls' => "/cart\n/checkout\n/my-account\n/wp-json/",
            'exclude_cookies' => "woocommerce_items_in_cart\nwoocommerce_cart_hash\nwp_woocommerce_session_\nwordpress_logged_in_\ncomment_author_",
            'exclude_user_agents' => '',
            'safe_mode' => 0,
            'debug_log' => 0,
            'disable_emojis' => 1,
            'disable_embeds' => 1,
            'heartbeat_admin' => 60,
            'heartbeat_editor' => 60,
            'heartbeat_front' => 120,
            'remove_asset_query_strings' => 0,
            'preload_assets' => '',
            'lazyload_images' => 0,
            'defer_js' => 0,
            'defer_excludes' => "jquery\njquery-core\njquery-migrate",
            'minify_assets' => 0,
            'minify_excludes' => '',
            'db_cleanup_enabled' => 0,
            'db_delete_revisions_days' => 30,
            'db_delete_autodraft_days' => 14,
            'db_delete_trash_days' => 14,
            'db_optimize_tables' => 0,
            'purge_on_comment_change' => 0,
            'add_cache_headers' => 0,
            'disable_etag_header' => 0,
            'dropin_enabled' => 1,
        ];
    }

    private function quick_site_bool_to_int($value): int
    {
        if (is_bool($value)) {
            return $value ? 1 : 0;
        }
        if (is_numeric($value)) {
            return ((int) $value) > 0 ? 1 : 0;
        }
        $normalized = strtolower(trim((string) $value));
        return in_array($normalized, ['1', 'true', 'yes', 'on'], true) ? 1 : 0;
    }

    private function quick_site_sanitize_lines($value): string
    {
        $lines = preg_split('/\r\n|\r|\n/', (string) $value);
        if (!is_array($lines)) {
            return '';
        }
        $clean = [];
        foreach ($lines as $line) {
            $line = trim(wp_strip_all_tags((string) $line));
            if ($line !== '') {
                $clean[] = $line;
            }
        }
        return implode("\n", $clean);
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_site_get_settings(): array
    {
        $saved = get_option('quick_site_settings', []);
        if (!is_array($saved)) {
            $saved = [];
        }
        $settings = wp_parse_args($saved, $this->quick_site_default_settings());

        foreach ([
            'page_cache_enabled', 'cache_search', 'split_device', 'split_language', 'safe_mode', 'debug_log',
            'disable_emojis', 'disable_embeds', 'remove_asset_query_strings', 'lazyload_images', 'defer_js',
            'minify_assets', 'db_cleanup_enabled', 'db_optimize_tables', 'purge_on_comment_change',
            'add_cache_headers', 'disable_etag_header', 'dropin_enabled',
        ] as $flag) {
            $settings[$flag] = $this->quick_site_bool_to_int($settings[$flag]);
        }

        $settings['cache_ttl'] = max(60, (int) $settings['cache_ttl']);
        $settings['heartbeat_admin'] = max(15, (int) $settings['heartbeat_admin']);
        $settings['heartbeat_editor'] = max(15, (int) $settings['heartbeat_editor']);
        $settings['heartbeat_front'] = max(15, (int) $settings['heartbeat_front']);
        $settings['db_delete_revisions_days'] = max(1, (int) $settings['db_delete_revisions_days']);
        $settings['db_delete_autodraft_days'] = max(1, (int) $settings['db_delete_autodraft_days']);
        $settings['db_delete_trash_days'] = max(1, (int) $settings['db_delete_trash_days']);

        foreach ([
            'query_whitelist', 'ignore_query_prefixes', 'exclude_urls', 'exclude_cookies', 'exclude_user_agents',
            'preload_assets', 'defer_excludes', 'minify_excludes',
        ] as $text_key) {
            $settings[$text_key] = $this->quick_site_sanitize_lines($settings[$text_key]);
        }

        return $settings;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_site_get_integrations(): array
    {
        $saved = get_option('qsit_integrations', []);
        if (!is_array($saved)) {
            $saved = [];
        }
        return [
            'quick_seo' => $this->quick_site_bool_to_int($saved['quick_seo'] ?? 0),
            'quick_audit' => $this->quick_site_bool_to_int($saved['quick_audit'] ?? 0),
            'quick_code' => $this->quick_site_bool_to_int($saved['quick_code'] ?? 0),
            'quick_traffic' => $this->quick_site_bool_to_int($saved['quick_traffic'] ?? 0),
        ];
    }

    private function quick_site_cache_base_dir(): string
    {
        return trailingslashit(WP_CONTENT_DIR) . 'cache/quick-site/';
    }

    private function quick_site_cache_pages_dir(): string
    {
        return $this->quick_site_cache_base_dir() . 'pages/';
    }

    private function quick_site_cache_stats_dir(): string
    {
        return $this->quick_site_cache_base_dir() . 'stats/';
    }

    private function quick_site_ensure_cache_dirs(): bool
    {
        $dirs = [$this->quick_site_cache_base_dir(), $this->quick_site_cache_pages_dir(), $this->quick_site_cache_stats_dir()];
        foreach ($dirs as $dir) {
            if (!file_exists($dir) && !wp_mkdir_p($dir)) {
                return false;
            }
        }
        return true;
    }

    private function quick_site_get_cache_size_bytes(): int
    {
        $total = 0;
        foreach (glob($this->quick_site_cache_pages_dir() . '*.html') ?: [] as $file) {
            $size = @filesize($file);
            if ($size !== false) {
                $total += (int) $size;
            }
        }
        return $total;
    }

    private function quick_site_cache_file_count(): int
    {
        return count(glob($this->quick_site_cache_pages_dir() . '*.html') ?: []);
    }

    private function quick_site_get_cache_stat(string $name): int
    {
        $path = $this->quick_site_cache_stats_dir() . sanitize_key($name) . '.count';
        if (!file_exists($path)) {
            return 0;
        }
        $raw = @file_get_contents($path);
        if ($raw === false) {
            return 0;
        }
        return is_numeric(trim($raw)) ? (int) trim($raw) : 0;
    }

    private function quick_site_is_dropin_installed(): bool
    {
        $target = trailingslashit(WP_CONTENT_DIR) . 'advanced-cache.php';
        if (!file_exists($target)) {
            return false;
        }
        $content = @file_get_contents($target);
        return is_string($content) && strpos($content, 'Quick Site advanced-cache drop-in') !== false;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_site_get_diagnostics(): array
    {
        $cache_dir = $this->quick_site_cache_pages_dir();
        $cache_writable = file_exists($cache_dir) ? is_writable($cache_dir) : $this->quick_site_ensure_cache_dirs();
        $conflicts = [];
        foreach (['w3-total-cache/w3-total-cache.php', 'wp-super-cache/wp-cache.php', 'litespeed-cache/litespeed-cache.php'] as $plugin_file) {
            if (is_plugin_active($plugin_file)) {
                $conflicts[] = $plugin_file;
            }
        }

        $settings = $this->quick_site_get_settings();
        $woo_patterns = ['/cart', '/checkout', '/my-account'];
        $woo_excluded = true;
        foreach ($woo_patterns as $pattern) {
            if (strpos((string) $settings['exclude_urls'], $pattern) === false) {
                $woo_excluded = false;
                break;
            }
        }

        return [
            'cache_writable' => $cache_writable ? 1 : 0,
            'conflicts' => empty($conflicts) ? 'none' : implode(', ', $conflicts),
            'woo_excluded' => $woo_excluded ? 1 : 0,
            'dropin_installed' => $this->quick_site_is_dropin_installed() ? 1 : 0,
            'wp_cache_defined' => (defined('WP_CACHE') && WP_CACHE) ? 1 : 0,
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_site_save_settings_payload(array $payload)
    {
        $settings = $this->quick_site_get_settings();
        foreach ([
            'page_cache_enabled', 'cache_search', 'split_device', 'split_language', 'safe_mode', 'debug_log',
            'disable_emojis', 'disable_embeds', 'remove_asset_query_strings', 'lazyload_images', 'defer_js',
            'minify_assets', 'db_cleanup_enabled', 'db_optimize_tables', 'purge_on_comment_change',
            'add_cache_headers', 'disable_etag_header', 'dropin_enabled',
        ] as $flag) {
            if (array_key_exists($flag, $payload)) {
                $settings[$flag] = $this->quick_site_bool_to_int($payload[$flag]);
            }
        }
        foreach ([
            'cache_ttl', 'heartbeat_admin', 'heartbeat_editor', 'heartbeat_front',
            'db_delete_revisions_days', 'db_delete_autodraft_days', 'db_delete_trash_days',
        ] as $int_key) {
            if (array_key_exists($int_key, $payload)) {
                $settings[$int_key] = (int) $payload[$int_key];
            }
        }
        $settings['cache_ttl'] = max(60, (int) $settings['cache_ttl']);
        $settings['heartbeat_admin'] = max(15, (int) $settings['heartbeat_admin']);
        $settings['heartbeat_editor'] = max(15, (int) $settings['heartbeat_editor']);
        $settings['heartbeat_front'] = max(15, (int) $settings['heartbeat_front']);
        $settings['db_delete_revisions_days'] = max(1, (int) $settings['db_delete_revisions_days']);
        $settings['db_delete_autodraft_days'] = max(1, (int) $settings['db_delete_autodraft_days']);
        $settings['db_delete_trash_days'] = max(1, (int) $settings['db_delete_trash_days']);
        foreach ([
            'query_whitelist', 'ignore_query_prefixes', 'exclude_urls', 'exclude_cookies', 'exclude_user_agents',
            'preload_assets', 'defer_excludes', 'minify_excludes',
        ] as $text_key) {
            if (array_key_exists($text_key, $payload)) {
                $settings[$text_key] = $this->quick_site_sanitize_lines($payload[$text_key]);
            }
        }

        update_option('quick_site_settings', $settings, false);
        $workspace = $this->quick_site_open_payload();
        return [
            'settings' => $settings,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'latestPages' => isset($workspace['latestPages']) && is_array($workspace['latestPages']) ? $workspace['latestPages'] : [],
            'latestPosts' => isset($workspace['latestPosts']) && is_array($workspace['latestPosts']) ? $workspace['latestPosts'] : [],
            'cache' => isset($workspace['cache']) && is_array($workspace['cache']) ? $workspace['cache'] : [],
            'database' => isset($workspace['database']) && is_array($workspace['database']) ? $workspace['database'] : [],
            'diagnostics' => isset($workspace['diagnostics']) && is_array($workspace['diagnostics']) ? $workspace['diagnostics'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_site_purge_all_cache_payload(): array
    {
        $ok = true;
        if (class_exists('QSIT_Cache') && method_exists('QSIT_Cache', 'purge_all')) {
            $ok = (bool) QSIT_Cache::purge_all();
        } else {
            foreach (glob($this->quick_site_cache_pages_dir() . '*.html') ?: [] as $file) {
                if (!@unlink($file)) {
                    $ok = false;
                }
            }
        }
        $workspace = $this->quick_site_open_payload();
        return [
            'ok' => $ok,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'cache' => isset($workspace['cache']) && is_array($workspace['cache']) ? $workspace['cache'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_site_purge_cache_url_payload(array $payload)
    {
        $url = isset($payload['url']) ? esc_url_raw((string) $payload['url']) : '';
        if ($url === '') {
            return new WP_Error('quick_site_url_required', 'A URL is required.', ['status' => 400]);
        }

        $deleted = 0;
        if (class_exists('QSIT_Cache') && method_exists('QSIT_Cache', 'purge_url')) {
            $deleted = (int) QSIT_Cache::purge_url($url);
        } else {
            $hash = md5($url);
            foreach (glob($this->quick_site_cache_pages_dir() . $hash . '--*.html') ?: [] as $file) {
                if (@unlink($file)) {
                    $deleted++;
                }
            }
        }

        $workspace = $this->quick_site_open_payload();
        return [
            'url' => $url,
            'deleted' => $deleted,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'cache' => isset($workspace['cache']) && is_array($workspace['cache']) ? $workspace['cache'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_site_install_dropin_payload(): array
    {
        $installed = false;
        $target = trailingslashit(WP_CONTENT_DIR) . 'advanced-cache.php';
        if (class_exists('QSIT_Dropin') && method_exists('QSIT_Dropin', 'install_dropin')) {
            $installed = (bool) QSIT_Dropin::install_dropin();
        } else {
            $this->quick_site_ensure_cache_dirs();
            $dropin_code = "<?php\n"
                . "/** Quick Site advanced-cache drop-in */\n"
                . "if (!defined('ABSPATH')) { exit; }\n"
                . '$configPath = WP_CONTENT_DIR . "/cache/quick-site/config.php";' . "\n"
                . "if (!file_exists(\$configPath)) { return; }\n"
                . '$cfg = include $configPath;' . "\n"
                . "if (!is_array(\$cfg) || empty(\$cfg['enabled'])) { return; }\n"
                . '$ttl = isset($cfg["ttl"]) ? (int) $cfg["ttl"] : 600;' . "\n"
                . '$uri = isset($_SERVER["REQUEST_URI"]) ? (string) $_SERVER["REQUEST_URI"] : "/";' . "\n"
                . '$parts = wp_parse_url($uri);' . "\n"
                . '$path = isset($parts["path"]) ? (string) $parts["path"] : "/";' . "\n"
                . '$base = home_url($path);' . "\n"
                . '$hash = md5($base);' . "\n"
                . '$pattern = WP_CONTENT_DIR . "/cache/quick-site/pages/" . $hash . "--*.html";' . "\n"
                . '$files = glob($pattern);' . "\n"
                . "if (!empty(\$files)) {\n"
                . "  \$file = \$files[0];\n"
                . "  \$mtime = @filemtime(\$file);\n"
                . "  if (\$mtime !== false && (time() - \$mtime) <= \$ttl) {\n"
                . "    @header('X-Quick-Site-Cache: HIT');\n"
                . "    @header('Cache-Control: public, max-age=' . \$ttl);\n"
                . "    readfile(\$file);\n"
                . "    exit;\n"
                . "  }\n"
                . "}\n";
            $installed = (bool) @file_put_contents($target, $dropin_code, LOCK_EX);
        }

        $workspace = $this->quick_site_open_payload();
        return [
            'installed' => $installed,
            'dropinPath' => $target,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'cache' => isset($workspace['cache']) && is_array($workspace['cache']) ? $workspace['cache'] : [],
            'diagnostics' => isset($workspace['diagnostics']) && is_array($workspace['diagnostics']) ? $workspace['diagnostics'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_site_db_preview_payload(): array
    {
        global $wpdb;
        $settings = $this->quick_site_get_settings();
        $preview = [
            'expired_transients' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_%' AND option_value < UNIX_TIMESTAMP()"
            ),
            'old_revisions' => (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                    max(1, (int) $settings['db_delete_revisions_days'])
                )
            ),
            'old_autodrafts' => (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'auto-draft' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                    max(1, (int) $settings['db_delete_autodraft_days'])
                )
            ),
            'old_trash_posts' => (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status = 'trash' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                    max(1, (int) $settings['db_delete_trash_days'])
                )
            ),
        ];
        $tables = $wpdb->get_col('SHOW TABLES');
        $preview['tablesCount'] = is_array($tables) ? count($tables) : 0;
        set_transient('quick_connector_quick_site_db_preview', $preview, 15 * MINUTE_IN_SECONDS);

        $workspace = $this->quick_site_open_payload();
        return [
            'preview' => $preview,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'database' => isset($workspace['database']) && is_array($workspace['database']) ? $workspace['database'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_site_db_cleanup_payload(): array
    {
        global $wpdb;
        $settings = $this->quick_site_get_settings();
        $report = [
            'expired_transients' => 0,
            'old_revisions' => 0,
            'old_autodrafts' => 0,
            'old_trash_posts' => 0,
            'optimized_tables' => 0,
            'errors' => [],
        ];

        $expired = $wpdb->get_results(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_%' AND option_value < UNIX_TIMESTAMP()"
        );
        if (is_array($expired)) {
            foreach ($expired as $row) {
                if (!isset($row->option_name)) {
                    continue;
                }
                $timeout_name = (string) $row->option_name;
                delete_option($timeout_name);
                delete_option(str_replace('_transient_timeout_', '_transient_', $timeout_name));
                $report['expired_transients']++;
            }
        }

        $revision_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'revision' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                max(1, (int) $settings['db_delete_revisions_days'])
            )
        );
        if (is_array($revision_ids)) {
            foreach ($revision_ids as $id) {
                if (wp_delete_post((int) $id, true)) {
                    $report['old_revisions']++;
                }
            }
        }

        $auto_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'auto-draft' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                max(1, (int) $settings['db_delete_autodraft_days'])
            )
        );
        if (is_array($auto_ids)) {
            foreach ($auto_ids as $id) {
                if (wp_delete_post((int) $id, true)) {
                    $report['old_autodrafts']++;
                }
            }
        }

        $trash_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'trash' AND post_modified_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
                max(1, (int) $settings['db_delete_trash_days'])
            )
        );
        if (is_array($trash_ids)) {
            foreach ($trash_ids as $id) {
                if (wp_delete_post((int) $id, true)) {
                    $report['old_trash_posts']++;
                }
            }
        }

        if (!empty($settings['db_optimize_tables'])) {
            $tables = $wpdb->get_col('SHOW TABLES');
            if (is_array($tables)) {
                foreach ($tables as $table) {
                    $table = preg_replace('/[^a-zA-Z0-9_]/', '', (string) $table);
                    if (!$table) {
                        continue;
                    }
                    $ok = $wpdb->query("OPTIMIZE TABLE `{$table}`");
                    if ($ok === false) {
                        $report['errors'][] = 'Failed optimizing table: ' . $table;
                    } else {
                        $report['optimized_tables']++;
                    }
                }
            }
        }

        update_option('quick_site_db_last_run', current_time('mysql'), false);
        $workspace = $this->quick_site_open_payload();
        return [
            'report' => $report,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'database' => isset($workspace['database']) && is_array($workspace['database']) ? $workspace['database'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_site_save_integrations_payload(array $payload)
    {
        $settings = [
            'quick_seo' => $this->quick_site_bool_to_int($payload['quick_seo'] ?? $payload['quickSeo'] ?? 0),
            'quick_audit' => $this->quick_site_bool_to_int($payload['quick_audit'] ?? $payload['quickAudit'] ?? 0),
            'quick_code' => $this->quick_site_bool_to_int($payload['quick_code'] ?? $payload['quickCode'] ?? 0),
            'quick_traffic' => $this->quick_site_bool_to_int($payload['quick_traffic'] ?? $payload['quickTraffic'] ?? 0),
        ];
        update_option('qsit_integrations', $settings, false);
        $workspace = $this->quick_site_open_payload();
        return [
            'integrations' => $settings,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_site_export_settings_payload(): array
    {
        $payload = [
            'plugin' => 'quick-site',
            'version' => QUICK_CONNECTOR_VERSION,
            'exportedAt' => gmdate('c'),
            'settings' => $this->quick_site_get_settings(),
            'integrations' => $this->quick_site_get_integrations(),
        ];
        $json = wp_json_encode($payload, JSON_PRETTY_PRINT);
        if (!is_string($json)) {
            $json = '{}';
        }
        return [
            'filename' => 'quick-site-settings-' . gmdate('Ymd-His') . '.json',
            'jsonBase64' => base64_encode($json),
            'settings' => $this->quick_site_get_settings(),
            'integrations' => $this->quick_site_get_integrations(),
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_site_import_settings_payload(array $payload)
    {
        $json_base64 = isset($payload['jsonBase64']) ? (string) $payload['jsonBase64'] : '';
        if ($json_base64 === '') {
            return new WP_Error('quick_site_import_payload_required', 'jsonBase64 is required.', ['status' => 400]);
        }

        $decoded = base64_decode($json_base64, true);
        if (!is_string($decoded) || trim($decoded) === '') {
            return new WP_Error('quick_site_import_invalid_payload', 'jsonBase64 could not be decoded.', ['status' => 400]);
        }

        $json = json_decode($decoded, true);
        if (!is_array($json)) {
            return new WP_Error('quick_site_import_invalid_json', 'Decoded payload is not valid JSON.', ['status' => 400]);
        }

        $incoming_settings = isset($json['settings']) && is_array($json['settings']) ? $json['settings'] : [];
        $result = $this->quick_site_save_settings_payload($incoming_settings);
        if ($result instanceof WP_Error) {
            return $result;
        }

        if (isset($json['integrations']) && is_array($json['integrations'])) {
            update_option('qsit_integrations', [
                'quick_seo' => $this->quick_site_bool_to_int($json['integrations']['quick_seo'] ?? 0),
                'quick_audit' => $this->quick_site_bool_to_int($json['integrations']['quick_audit'] ?? 0),
                'quick_code' => $this->quick_site_bool_to_int($json['integrations']['quick_code'] ?? 0),
                'quick_traffic' => $this->quick_site_bool_to_int($json['integrations']['quick_traffic'] ?? 0),
            ], false);
        }

        $workspace = $this->quick_site_open_payload();
        return [
            'imported' => true,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'integrations' => isset($workspace['integrations']) && is_array($workspace['integrations']) ? $workspace['integrations'] : [],
            'cache' => isset($workspace['cache']) && is_array($workspace['cache']) ? $workspace['cache'] : [],
            'database' => isset($workspace['database']) && is_array($workspace['database']) ? $workspace['database'] : [],
            'diagnostics' => isset($workspace['diagnostics']) && is_array($workspace['diagnostics']) ? $workspace['diagnostics'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_site_create_draft_page_payload(array $payload)
    {
        $title = isset($payload['title']) ? sanitize_text_field((string) $payload['title']) : '';
        $content = isset($payload['content']) ? wp_kses_post((string) $payload['content']) : '';

        if ($title === '') {
            return new WP_Error('quick_site_title_required', 'Page title is required.', ['status' => 400]);
        }

        $result = wp_insert_post([
            'post_type' => 'page',
            'post_status' => 'draft',
            'post_title' => $title,
            'post_content' => $content,
        ], true);

        if (is_wp_error($result)) {
            return new WP_Error(
                'quick_site_create_failed',
                'Could not create draft page.',
                ['status' => 500, 'details' => $result->get_error_message()]
            );
        }

        $page_id = (int) $result;
        $workspace = $this->quick_site_open_payload();

        return [
            'pageId' => $page_id,
            'status' => 'draft',
            'link' => get_edit_post_link($page_id, ''),
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'integrations' => isset($workspace['integrations']) && is_array($workspace['integrations']) ? $workspace['integrations'] : [],
            'latestPages' => isset($workspace['latestPages']) && is_array($workspace['latestPages']) ? $workspace['latestPages'] : [],
            'latestPosts' => isset($workspace['latestPosts']) && is_array($workspace['latestPosts']) ? $workspace['latestPosts'] : [],
            'cache' => isset($workspace['cache']) && is_array($workspace['cache']) ? $workspace['cache'] : [],
            'database' => isset($workspace['database']) && is_array($workspace['database']) ? $workspace['database'] : [],
            'diagnostics' => isset($workspace['diagnostics']) && is_array($workspace['diagnostics']) ? $workspace['diagnostics'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_points_open_payload(array $input_payload = []): array
    {
        $settings = $this->quick_points_get_settings();
        $balances = $this->quick_points_get_balances(400);
        $tiers = $this->quick_points_get_tiers();
        $tx_totals = $this->quick_points_get_transaction_totals();
        $users_with_points = 0;
        $outstanding_points = 0;

        foreach ($balances as $balance) {
            if (!is_array($balance)) {
                continue;
            }

            $points = isset($balance['balance']) ? (int) $balance['balance'] : 0;
            if ($points > 0) {
                $users_with_points++;
            }
            $outstanding_points += $points;
        }

        usort($balances, static function (array $a, array $b): int {
            return (int) ($b['balance'] ?? 0) <=> (int) ($a['balance'] ?? 0);
        });
        $top_users = array_slice($balances, 0, 8);

        $liability = 0.0;
        $redemption_points = isset($settings['redemption_points']) ? (float) $settings['redemption_points'] : 100.0;
        $redemption_value = isset($settings['redemption_value']) ? (float) $settings['redemption_value'] : 1.0;
        if ($redemption_points > 0) {
            $liability = ($outstanding_points / $redemption_points) * $redemption_value;
        }

        $tx_filters = [
            'userId' => isset($input_payload['userId']) ? absint($input_payload['userId']) : 0,
            'type' => isset($input_payload['type']) ? sanitize_key((string) $input_payload['type']) : '',
            'dateFrom' => isset($input_payload['dateFrom']) ? sanitize_text_field((string) $input_payload['dateFrom']) : '',
            'dateTo' => isset($input_payload['dateTo']) ? sanitize_text_field((string) $input_payload['dateTo']) : '',
            'page' => isset($input_payload['page']) ? max(1, absint($input_payload['page'])) : 1,
            'perPage' => isset($input_payload['perPage']) ? max(1, min(100, absint($input_payload['perPage']))) : 20,
        ];
        $tx_listing = $this->quick_points_get_transactions($tx_filters);
        $last_expiry_run = get_option('qpnt_last_expiry_run', []);
        if (!is_array($last_expiry_run)) {
            $last_expiry_run = [];
        }

        return [
            'summary' => [
                'usersWithPoints' => $users_with_points,
                'outstandingPoints' => $outstanding_points,
                'totalPointsIssued' => (int) $tx_totals['issued'],
                'totalPointsRedeemed' => (int) $tx_totals['redeemed'],
                'liability' => round($liability, 2),
                'tiersCount' => count($tiers),
            ],
            'settings' => $settings,
            'tiers' => $tiers,
            'topUsers' => $top_users,
            'balances' => array_slice($balances, 0, 40),
            'transactions' => isset($tx_listing['rows']) && is_array($tx_listing['rows']) ? $tx_listing['rows'] : [],
            'page' => isset($tx_listing['page']) ? (int) $tx_listing['page'] : 1,
            'perPage' => isset($tx_listing['perPage']) ? (int) $tx_listing['perPage'] : 20,
            'total' => isset($tx_listing['total']) ? (int) $tx_listing['total'] : 0,
            'filters' => [
                'userId' => $tx_filters['userId'],
                'type' => $tx_filters['type'],
                'dateFrom' => $tx_filters['dateFrom'],
                'dateTo' => $tx_filters['dateTo'],
            ],
            'lastExpiryRun' => $last_expiry_run,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_points_adjust_payload(array $payload, string $direction)
    {
        $user_id = isset($payload['userId']) ? absint($payload['userId']) : 0;
        $amount = isset($payload['amount']) ? absint($payload['amount']) : 0;
        $reason = isset($payload['reason']) ? sanitize_text_field((string) $payload['reason']) : '';

        if ($user_id <= 0) {
            return new WP_Error('quick_points_user_required', 'Valid userId is required.', ['status' => 400]);
        }
        if ($amount <= 0) {
            return new WP_Error('quick_points_amount_required', 'Amount must be greater than 0.', ['status' => 400]);
        }

        $user = get_user_by('id', $user_id);
        if (!$user instanceof WP_User) {
            return new WP_Error('quick_points_user_not_found', 'User not found.', ['status' => 404]);
        }

        $result = $this->quick_points_apply_adjustment($user_id, $direction, $amount, $reason);
        if ($result instanceof WP_Error) {
            return $result;
        }

        $workspace = $this->quick_points_open_payload();

        return [
            'userId' => $user_id,
            'displayName' => $user->display_name,
            'delta' => isset($result['delta']) ? (int) $result['delta'] : 0,
            'signedDelta' => isset($result['signedDelta']) ? (int) $result['signedDelta'] : 0,
            'newBalance' => isset($result['newBalance']) ? (int) $result['newBalance'] : 0,
            'lifetimePoints' => isset($result['lifetimePoints']) ? (int) $result['lifetimePoints'] : 0,
            'transactionId' => isset($result['transactionId']) ? (int) $result['transactionId'] : 0,
            'reason' => $reason,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'tiers' => isset($workspace['tiers']) && is_array($workspace['tiers']) ? $workspace['tiers'] : [],
            'topUsers' => isset($workspace['topUsers']) && is_array($workspace['topUsers']) ? $workspace['topUsers'] : [],
            'balances' => isset($workspace['balances']) && is_array($workspace['balances']) ? $workspace['balances'] : [],
            'transactions' => isset($workspace['transactions']) && is_array($workspace['transactions']) ? $workspace['transactions'] : [],
            'page' => isset($workspace['page']) ? (int) $workspace['page'] : 1,
            'perPage' => isset($workspace['perPage']) ? (int) $workspace['perPage'] : 20,
            'total' => isset($workspace['total']) ? (int) $workspace['total'] : 0,
            'lastExpiryRun' => isset($workspace['lastExpiryRun']) && is_array($workspace['lastExpiryRun']) ? $workspace['lastExpiryRun'] : [],
            'filters' => isset($workspace['filters']) && is_array($workspace['filters']) ? $workspace['filters'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function quick_points_list_transactions_payload(array $payload): array
    {
        $listing = $this->quick_points_get_transactions([
            'userId' => isset($payload['userId']) ? absint($payload['userId']) : 0,
            'type' => isset($payload['type']) ? sanitize_key((string) $payload['type']) : '',
            'dateFrom' => isset($payload['dateFrom']) ? sanitize_text_field((string) $payload['dateFrom']) : '',
            'dateTo' => isset($payload['dateTo']) ? sanitize_text_field((string) $payload['dateTo']) : '',
            'page' => isset($payload['page']) ? max(1, absint($payload['page'])) : 1,
            'perPage' => isset($payload['perPage']) ? max(1, min(100, absint($payload['perPage']))) : 20,
        ]);
        $workspace = $this->quick_points_open_payload($payload);

        return [
            'transactions' => isset($listing['rows']) && is_array($listing['rows']) ? $listing['rows'] : [],
            'page' => isset($listing['page']) ? (int) $listing['page'] : 1,
            'perPage' => isset($listing['perPage']) ? (int) $listing['perPage'] : 20,
            'total' => isset($listing['total']) ? (int) $listing['total'] : 0,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'tiers' => isset($workspace['tiers']) && is_array($workspace['tiers']) ? $workspace['tiers'] : [],
            'topUsers' => isset($workspace['topUsers']) && is_array($workspace['topUsers']) ? $workspace['topUsers'] : [],
            'balances' => isset($workspace['balances']) && is_array($workspace['balances']) ? $workspace['balances'] : [],
            'lastExpiryRun' => isset($workspace['lastExpiryRun']) && is_array($workspace['lastExpiryRun']) ? $workspace['lastExpiryRun'] : [],
            'filters' => isset($workspace['filters']) && is_array($workspace['filters']) ? $workspace['filters'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_points_save_settings_payload(array $payload)
    {
        $current = $this->quick_points_get_settings();

        $out = $current;
        $out['points_per_currency'] = isset($payload['pointsPerCurrency']) ? max(0.01, (float) $payload['pointsPerCurrency']) : (float) $current['points_per_currency'];
        $out['redemption_enabled'] = isset($payload['redemptionEnabled']) ? $this->quick_points_bool_to_int($payload['redemptionEnabled']) : (int) $current['redemption_enabled'];
        $out['redemption_points'] = isset($payload['redemptionPoints']) ? max(1, absint($payload['redemptionPoints'])) : (int) $current['redemption_points'];
        $out['redemption_value'] = isset($payload['redemptionValue']) ? max(0.01, (float) $payload['redemptionValue']) : (float) $current['redemption_value'];
        $out['expiry_enabled'] = isset($payload['expiryEnabled']) ? $this->quick_points_bool_to_int($payload['expiryEnabled']) : (int) $current['expiry_enabled'];
        $out['expiry_days'] = isset($payload['expiryDays']) ? max(1, absint($payload['expiryDays'])) : (int) $current['expiry_days'];
        $out['max_redeem_per_order'] = isset($payload['maxRedeemPerOrder']) ? max(0.0, (float) $payload['maxRedeemPerOrder']) : (float) $current['max_redeem_per_order'];
        $out['min_cart_total_for_redeem'] = isset($payload['minCartTotalForRedeem']) ? max(0.0, (float) $payload['minCartTotalForRedeem']) : (float) $current['min_cart_total_for_redeem'];
        $out['order_status_trigger'] = isset($payload['orderStatusTrigger']) ? sanitize_key((string) $payload['orderStatusTrigger']) : (string) $current['order_status_trigger'];
        if (!in_array($out['order_status_trigger'], ['completed', 'processing'], true)) {
            $out['order_status_trigger'] = 'completed';
        }
        $out['liability_warning_display'] = isset($payload['liabilityWarningDisplay']) ? $this->quick_points_bool_to_int($payload['liabilityWarningDisplay']) : (int) $current['liability_warning_display'];

        $out['enable_referrals'] = isset($payload['enableReferrals']) ? $this->quick_points_bool_to_int($payload['enableReferrals']) : (int) $current['enable_referrals'];
        $out['enable_tiers'] = isset($payload['enableTiers']) ? $this->quick_points_bool_to_int($payload['enableTiers']) : (int) $current['enable_tiers'];
        $out['enable_activity_rewards'] = isset($payload['enableActivityRewards']) ? $this->quick_points_bool_to_int($payload['enableActivityRewards']) : (int) $current['enable_activity_rewards'];
        $out['activity_registration'] = isset($payload['activityRegistration']) ? max(0, absint($payload['activityRegistration'])) : (int) $current['activity_registration'];
        $out['activity_review'] = isset($payload['activityReview']) ? max(0, absint($payload['activityReview'])) : (int) $current['activity_review'];
        $out['activity_anniversary'] = isset($payload['activityAnniversary']) ? max(0, absint($payload['activityAnniversary'])) : (int) $current['activity_anniversary'];
        $out['activity_referral'] = isset($payload['activityReferral']) ? max(0, absint($payload['activityReferral'])) : (int) $current['activity_referral'];
        $out['tier_rule_mode'] = isset($payload['tierRuleMode']) ? sanitize_key((string) $payload['tierRuleMode']) : (string) $current['tier_rule_mode'];
        if (!in_array($out['tier_rule_mode'], ['lifetime_points', 'annual_spend', 'rolling_12_months'], true)) {
            $out['tier_rule_mode'] = 'lifetime_points';
        }
        $out['points_only_checkout'] = isset($payload['pointsOnlyCheckout']) ? $this->quick_points_bool_to_int($payload['pointsOnlyCheckout']) : (int) $current['points_only_checkout'];
        $out['points_cash_partial'] = isset($payload['pointsCashPartial']) ? $this->quick_points_bool_to_int($payload['pointsCashPartial']) : (int) $current['points_cash_partial'];

        update_option('qpnt_settings', $out, false);
        $workspace = $this->quick_points_open_payload();

        return [
            'saved' => true,
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'tiers' => isset($workspace['tiers']) && is_array($workspace['tiers']) ? $workspace['tiers'] : [],
            'topUsers' => isset($workspace['topUsers']) && is_array($workspace['topUsers']) ? $workspace['topUsers'] : [],
            'balances' => isset($workspace['balances']) && is_array($workspace['balances']) ? $workspace['balances'] : [],
            'transactions' => isset($workspace['transactions']) && is_array($workspace['transactions']) ? $workspace['transactions'] : [],
            'lastExpiryRun' => isset($workspace['lastExpiryRun']) && is_array($workspace['lastExpiryRun']) ? $workspace['lastExpiryRun'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_points_save_tier_payload(array $payload)
    {
        global $wpdb;

        $tier_id = isset($payload['tierId']) ? absint($payload['tierId']) : 0;
        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : '';
        $threshold = isset($payload['threshold']) ? max(0, (int) $payload['threshold']) : 0;
        $multiplier = isset($payload['multiplier']) ? max(0.1, (float) $payload['multiplier']) : 1.0;
        if ($name === '') {
            return new WP_Error('quick_points_tier_name_required', 'Tier name is required.', ['status' => 400]);
        }

        $tiers_table = $this->quick_points_table('quick_points_tiers');
        if ($this->quick_points_table_exists('quick_points_tiers')) {
            if ($tier_id > 0) {
                $updated = $wpdb->update(
                    $tiers_table,
                    [
                        'name' => $name,
                        'threshold' => $threshold,
                        'multiplier' => $multiplier,
                    ],
                    ['id' => $tier_id],
                    ['%s', '%d', '%f'],
                    ['%d']
                );
                if ($updated === false) {
                    return new WP_Error('quick_points_tier_save_failed', 'Could not update tier.', ['status' => 500]);
                }
            } else {
                $inserted = $wpdb->insert(
                    $tiers_table,
                    [
                        'name' => $name,
                        'threshold' => $threshold,
                        'multiplier' => $multiplier,
                    ],
                    ['%s', '%d', '%f']
                );
                if ($inserted === false) {
                    return new WP_Error('quick_points_tier_create_failed', 'Could not create tier.', ['status' => 500]);
                }
                $tier_id = (int) $wpdb->insert_id;
            }
        } else {
            $tiers = get_option('quick_points_connector_tiers', []);
            if (!is_array($tiers)) {
                $tiers = [];
            }
            if ($tier_id > 0) {
                $found = false;
                foreach ($tiers as &$tier) {
                    if (!is_array($tier) || (int) ($tier['id'] ?? 0) !== $tier_id) {
                        continue;
                    }
                    $tier['name'] = $name;
                    $tier['threshold'] = $threshold;
                    $tier['multiplier'] = $multiplier;
                    $found = true;
                    break;
                }
                unset($tier);
                if (!$found) {
                    $tier_id = 0;
                }
            }
            if ($tier_id <= 0) {
                $tier_id = $this->quick_ship_next_id($tiers);
                $tiers[] = [
                    'id' => $tier_id,
                    'name' => $name,
                    'threshold' => $threshold,
                    'multiplier' => $multiplier,
                ];
            }
            update_option('quick_points_connector_tiers', array_values($tiers), false);
        }

        $perks_all = get_option('qpnt_tier_perks', []);
        if (!is_array($perks_all)) {
            $perks_all = [];
        }
        $existing_perks = isset($perks_all[(string) $tier_id]) && is_array($perks_all[(string) $tier_id])
            ? $perks_all[(string) $tier_id]
            : [];
        $perks_all[(string) $tier_id] = [
            'exclusive_discount_percent' => isset($payload['exclusiveDiscountPercent'])
                ? max(0.0, (float) $payload['exclusiveDiscountPercent'])
                : (float) ($existing_perks['exclusive_discount_percent'] ?? 0),
            'free_shipping' => isset($payload['freeShipping'])
                ? $this->quick_points_bool_to_int($payload['freeShipping'])
                : (int) ($existing_perks['free_shipping'] ?? 0),
            'early_sale_access' => isset($payload['earlySaleAccess'])
                ? $this->quick_points_bool_to_int($payload['earlySaleAccess'])
                : (int) ($existing_perks['early_sale_access'] ?? 0),
            'redemption_bonus_percent' => isset($payload['redemptionBonusPercent'])
                ? max(0.0, (float) $payload['redemptionBonusPercent'])
                : (float) ($existing_perks['redemption_bonus_percent'] ?? 0),
        ];
        update_option('qpnt_tier_perks', $perks_all, false);

        $workspace = $this->quick_points_open_payload();
        return [
            'tierId' => $tier_id,
            'saved' => true,
            'tiers' => isset($workspace['tiers']) && is_array($workspace['tiers']) ? $workspace['tiers'] : [],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_points_delete_tier_payload(array $payload)
    {
        global $wpdb;

        $tier_id = isset($payload['tierId']) ? absint($payload['tierId']) : 0;
        if ($tier_id <= 0) {
            return new WP_Error('quick_points_tier_required', 'Valid tierId is required.', ['status' => 400]);
        }

        if ($this->quick_points_table_exists('quick_points_tiers')) {
            $deleted = $wpdb->delete($this->quick_points_table('quick_points_tiers'), ['id' => $tier_id], ['%d']);
            if ($deleted === false) {
                return new WP_Error('quick_points_tier_delete_failed', 'Could not delete tier.', ['status' => 500]);
            }
        } else {
            $tiers = get_option('quick_points_connector_tiers', []);
            if (!is_array($tiers)) {
                $tiers = [];
            }
            $tiers = array_values(array_filter($tiers, static function ($tier) use ($tier_id): bool {
                return !is_array($tier) || (int) ($tier['id'] ?? 0) !== $tier_id;
            }));
            update_option('quick_points_connector_tiers', $tiers, false);
        }

        $perks_all = get_option('qpnt_tier_perks', []);
        if (is_array($perks_all)) {
            unset($perks_all[(string) $tier_id]);
            update_option('qpnt_tier_perks', $perks_all, false);
        }

        $workspace = $this->quick_points_open_payload();
        return [
            'tierId' => $tier_id,
            'deleted' => true,
            'tiers' => isset($workspace['tiers']) && is_array($workspace['tiers']) ? $workspace['tiers'] : [],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_points_run_expiry_payload(): array
    {
        $settings = $this->quick_points_get_settings();
        if (empty($settings['expiry_enabled'])) {
            $result = [
                'ran_at' => current_time('mysql'),
                'expired' => 0,
                'rows' => 0,
                'status' => 'skipped',
            ];
            update_option('qpnt_last_expiry_run', $result, false);
            $workspace = $this->quick_points_open_payload();

            return [
                'expiredPoints' => 0,
                'rowsProcessed' => 0,
                'lastExpiryRun' => $result,
                'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
                'transactions' => isset($workspace['transactions']) && is_array($workspace['transactions']) ? $workspace['transactions'] : [],
                'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
            ];
        }

        $expiry = $this->quick_points_expire_due_points();
        $result = [
            'ran_at' => current_time('mysql'),
            'expired' => (int) $expiry['expired'],
            'rows' => (int) $expiry['rows'],
            'status' => 'completed',
        ];
        update_option('qpnt_last_expiry_run', $result, false);
        $workspace = $this->quick_points_open_payload();

        return [
            'expiredPoints' => (int) $expiry['expired'],
            'rowsProcessed' => (int) $expiry['rows'],
            'lastExpiryRun' => $result,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'transactions' => isset($workspace['transactions']) && is_array($workspace['transactions']) ? $workspace['transactions'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_points_export_csv_payload(array $payload)
    {
        $entity = isset($payload['entity']) ? sanitize_key((string) $payload['entity']) : 'transactions';
        if (!in_array($entity, ['transactions', 'tiers', 'balances'], true)) {
            return new WP_Error('quick_points_export_entity_invalid', 'entity must be one of transactions, tiers, balances.', ['status' => 400]);
        }

        $rows = [];
        if ($entity === 'transactions') {
            $listing = $this->quick_points_get_transactions([
                'userId' => isset($payload['userId']) ? absint($payload['userId']) : 0,
                'type' => isset($payload['type']) ? sanitize_key((string) $payload['type']) : '',
                'dateFrom' => isset($payload['dateFrom']) ? sanitize_text_field((string) $payload['dateFrom']) : '',
                'dateTo' => isset($payload['dateTo']) ? sanitize_text_field((string) $payload['dateTo']) : '',
                'page' => 1,
                'perPage' => 5000,
            ]);
            $rows[] = ['id', 'user_id', 'display_name', 'points_change', 'type', 'reference_id', 'description', 'created_at'];
            foreach ($listing['rows'] as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $rows[] = [
                    (string) ($row['id'] ?? 0),
                    (string) ($row['userId'] ?? 0),
                    (string) ($row['displayName'] ?? ''),
                    (string) ($row['pointsChange'] ?? 0),
                    (string) ($row['type'] ?? ''),
                    (string) ($row['referenceId'] ?? 0),
                    (string) ($row['description'] ?? ''),
                    (string) ($row['createdAt'] ?? ''),
                ];
            }
        } elseif ($entity === 'tiers') {
            $tiers = $this->quick_points_get_tiers();
            $rows[] = ['id', 'name', 'threshold', 'multiplier', 'exclusive_discount_percent', 'free_shipping', 'early_sale_access', 'redemption_bonus_percent'];
            foreach ($tiers as $tier) {
                if (!is_array($tier)) {
                    continue;
                }
                $rows[] = [
                    (string) ($tier['id'] ?? 0),
                    (string) ($tier['name'] ?? ''),
                    (string) ($tier['threshold'] ?? 0),
                    (string) ($tier['multiplier'] ?? 1),
                    (string) ($tier['exclusiveDiscountPercent'] ?? 0),
                    (string) ($tier['freeShipping'] ?? 0),
                    (string) ($tier['earlySaleAccess'] ?? 0),
                    (string) ($tier['redemptionBonusPercent'] ?? 0),
                ];
            }
        } else {
            $balances = $this->quick_points_get_balances(2000);
            $rows[] = ['user_id', 'display_name', 'balance', 'lifetime_points'];
            foreach ($balances as $balance) {
                if (!is_array($balance)) {
                    continue;
                }
                $rows[] = [
                    (string) ($balance['userId'] ?? 0),
                    (string) ($balance['displayName'] ?? ''),
                    (string) ($balance['balance'] ?? 0),
                    (string) ($balance['lifetimePoints'] ?? 0),
                ];
            }
        }

        $csv = $this->quick_importer_rows_to_csv($rows);
        if ($csv instanceof WP_Error) {
            return $csv;
        }

        return [
            'entity' => $entity,
            'filename' => sprintf('quick-points-%s-%s.csv', $entity, gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    private function quick_points_table(string $suffix): string
    {
        global $wpdb;
        return $wpdb->prefix . $suffix;
    }

    private function quick_points_table_exists(string $suffix): bool
    {
        global $wpdb;
        $table = $this->quick_points_table($suffix);
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        return is_string($found) && $found === $table;
    }

    private function quick_points_bool_to_int($value): int
    {
        if (is_bool($value)) {
            return $value ? 1 : 0;
        }
        if (is_numeric($value)) {
            return ((int) $value) > 0 ? 1 : 0;
        }
        $normalized = strtolower(trim((string) $value));
        return in_array($normalized, ['1', 'true', 'yes', 'on'], true) ? 1 : 0;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_points_get_settings(): array
    {
        $defaults = [
            'points_per_currency' => 1.0,
            'redemption_enabled' => 1,
            'redemption_points' => 100,
            'redemption_value' => 1.0,
            'expiry_enabled' => 0,
            'expiry_days' => 365,
            'max_redeem_per_order' => 0.0,
            'order_status_trigger' => 'completed',
            'liability_warning_display' => 1,
            'enable_referrals' => 0,
            'enable_tiers' => 0,
            'enable_activity_rewards' => 0,
            'activity_registration' => 25,
            'activity_review' => 10,
            'activity_anniversary' => 50,
            'activity_referral' => 100,
            'tier_rule_mode' => 'lifetime_points',
            'points_only_checkout' => 0,
            'points_cash_partial' => 1,
            'min_cart_total_for_redeem' => 0.0,
        ];

        $saved = get_option('qpnt_settings', []);
        if (!is_array($saved)) {
            $saved = [];
        }

        $raw = wp_parse_args($saved, $defaults);
        return [
            'points_per_currency' => max(0.01, (float) $raw['points_per_currency']),
            'redemption_enabled' => $this->quick_points_bool_to_int($raw['redemption_enabled']),
            'redemption_points' => max(1, absint($raw['redemption_points'])),
            'redemption_value' => max(0.01, (float) $raw['redemption_value']),
            'expiry_enabled' => $this->quick_points_bool_to_int($raw['expiry_enabled']),
            'expiry_days' => max(1, absint($raw['expiry_days'])),
            'max_redeem_per_order' => max(0.0, (float) $raw['max_redeem_per_order']),
            'order_status_trigger' => in_array((string) $raw['order_status_trigger'], ['completed', 'processing'], true) ? (string) $raw['order_status_trigger'] : 'completed',
            'liability_warning_display' => $this->quick_points_bool_to_int($raw['liability_warning_display']),
            'enable_referrals' => $this->quick_points_bool_to_int($raw['enable_referrals']),
            'enable_tiers' => $this->quick_points_bool_to_int($raw['enable_tiers']),
            'enable_activity_rewards' => $this->quick_points_bool_to_int($raw['enable_activity_rewards']),
            'activity_registration' => max(0, absint($raw['activity_registration'])),
            'activity_review' => max(0, absint($raw['activity_review'])),
            'activity_anniversary' => max(0, absint($raw['activity_anniversary'])),
            'activity_referral' => max(0, absint($raw['activity_referral'])),
            'tier_rule_mode' => in_array((string) $raw['tier_rule_mode'], ['lifetime_points', 'annual_spend', 'rolling_12_months'], true)
                ? (string) $raw['tier_rule_mode']
                : 'lifetime_points',
            'points_only_checkout' => $this->quick_points_bool_to_int($raw['points_only_checkout']),
            'points_cash_partial' => $this->quick_points_bool_to_int($raw['points_cash_partial']),
            'min_cart_total_for_redeem' => max(0.0, (float) $raw['min_cart_total_for_redeem']),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_points_get_tiers(): array
    {
        global $wpdb;
        $rows = [];

        if ($this->quick_points_table_exists('quick_points_tiers')) {
            $rows = $wpdb->get_results(
                "SELECT id, name, threshold, multiplier FROM {$this->quick_points_table('quick_points_tiers')} ORDER BY threshold ASC",
                ARRAY_A
            );
            if (!is_array($rows)) {
                $rows = [];
            }
        } else {
            $saved = get_option('quick_points_connector_tiers', []);
            if (is_array($saved)) {
                $rows = $saved;
            }
        }

        $perks_all = get_option('qpnt_tier_perks', []);
        if (!is_array($perks_all)) {
            $perks_all = [];
        }

        $tiers = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $id = isset($row['id']) ? absint($row['id']) : 0;
            if ($id <= 0) {
                continue;
            }
            $perks = isset($perks_all[(string) $id]) && is_array($perks_all[(string) $id]) ? $perks_all[(string) $id] : [];
            $tiers[] = [
                'id' => $id,
                'name' => isset($row['name']) ? sanitize_text_field((string) $row['name']) : '',
                'threshold' => isset($row['threshold']) ? (int) $row['threshold'] : 0,
                'multiplier' => isset($row['multiplier']) ? (float) $row['multiplier'] : 1.0,
                'exclusiveDiscountPercent' => isset($perks['exclusive_discount_percent']) ? (float) $perks['exclusive_discount_percent'] : 0.0,
                'freeShipping' => isset($perks['free_shipping']) ? $this->quick_points_bool_to_int($perks['free_shipping']) : 0,
                'earlySaleAccess' => isset($perks['early_sale_access']) ? $this->quick_points_bool_to_int($perks['early_sale_access']) : 0,
                'redemptionBonusPercent' => isset($perks['redemption_bonus_percent']) ? (float) $perks['redemption_bonus_percent'] : 0.0,
            ];
        }

        usort($tiers, static function (array $a, array $b): int {
            return (int) ($a['threshold'] ?? 0) <=> (int) ($b['threshold'] ?? 0);
        });
        return $tiers;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_points_get_balances(int $limit = 250): array
    {
        global $wpdb;
        $rows = [];

        if ($this->quick_points_table_exists('quick_points_balances')) {
            $raw_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT user_id, total_points, lifetime_points FROM {$this->quick_points_table('quick_points_balances')} ORDER BY total_points DESC LIMIT %d",
                    max(1, $limit)
                ),
                ARRAY_A
            );
            if (is_array($raw_rows)) {
                foreach ($raw_rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $user_id = isset($row['user_id']) ? absint($row['user_id']) : 0;
                    if ($user_id <= 0) {
                        continue;
                    }
                    $user = get_userdata($user_id);
                    $rows[] = [
                        'userId' => $user_id,
                        'displayName' => $user instanceof WP_User ? (string) $user->display_name : sprintf('User #%d', $user_id),
                        'balance' => isset($row['total_points']) ? (int) $row['total_points'] : 0,
                        'lifetimePoints' => isset($row['lifetime_points']) ? (int) $row['lifetime_points'] : 0,
                    ];
                }
            }
        } else {
            $users = get_users(['fields' => ['ID', 'display_name'], 'number' => max(1, $limit)]);
            foreach ($users as $user) {
                if (!$user instanceof WP_User) {
                    continue;
                }
                $balance = (int) get_user_meta($user->ID, 'quickwoo_points_balance', true);
                if ($balance === 0) {
                    $balance = (int) get_user_meta($user->ID, 'quick_points_balance', true);
                }
                if ($balance <= 0) {
                    continue;
                }

                $rows[] = [
                    'userId' => $user->ID,
                    'displayName' => $user->display_name,
                    'balance' => $balance,
                    'lifetimePoints' => $balance,
                ];
            }
        }

        return $rows;
    }

    /**
     * @return array<string, int|array<int, array<string, mixed>>>
     */
    private function quick_points_get_transactions(array $filters): array
    {
        global $wpdb;

        $user_id = isset($filters['userId']) ? absint($filters['userId']) : 0;
        $type = isset($filters['type']) ? sanitize_key((string) $filters['type']) : '';
        $date_from = isset($filters['dateFrom']) ? sanitize_text_field((string) $filters['dateFrom']) : '';
        $date_to = isset($filters['dateTo']) ? sanitize_text_field((string) $filters['dateTo']) : '';
        $page = isset($filters['page']) ? max(1, absint($filters['page'])) : 1;
        $per_page = isset($filters['perPage']) ? max(1, min(100, absint($filters['perPage']))) : 20;
        $offset = ($page - 1) * $per_page;
        $rows = [];
        $total = 0;

        if ($this->quick_points_table_exists('quick_points_transactions')) {
            $table = $this->quick_points_table('quick_points_transactions');
            $where = ['1=1'];
            $params = [];

            if ($user_id > 0) {
                $where[] = 'user_id = %d';
                $params[] = $user_id;
            }
            if ($type !== '') {
                $where[] = 'type = %s';
                $params[] = $type;
            }
            if ($date_from !== '') {
                $where[] = 'created_at >= %s';
                $params[] = $date_from . ' 00:00:00';
            }
            if ($date_to !== '') {
                $where[] = 'created_at <= %s';
                $params[] = $date_to . ' 23:59:59';
            }

            $count_sql = "SELECT COUNT(*) FROM {$table} WHERE " . implode(' AND ', $where);
            if (count($params) > 0) {
                $total = (int) $wpdb->get_var($wpdb->prepare($count_sql, $params));
            } else {
                $total = (int) $wpdb->get_var($count_sql);
            }

            $query_sql = "SELECT id, user_id, points_change, type, reference_id, description, created_at FROM {$table} WHERE "
                . implode(' AND ', $where)
                . ' ORDER BY id DESC LIMIT %d OFFSET %d';
            $query_params = $params;
            $query_params[] = $per_page;
            $query_params[] = $offset;
            $query_rows = $wpdb->get_results($wpdb->prepare($query_sql, $query_params), ARRAY_A);
            if (is_array($query_rows)) {
                foreach ($query_rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $row_user_id = isset($row['user_id']) ? absint($row['user_id']) : 0;
                    $user = $row_user_id > 0 ? get_userdata($row_user_id) : null;
                    $rows[] = [
                        'id' => isset($row['id']) ? (int) $row['id'] : 0,
                        'userId' => $row_user_id,
                        'displayName' => $user instanceof WP_User ? (string) $user->display_name : sprintf('User #%d', $row_user_id),
                        'pointsChange' => isset($row['points_change']) ? (int) $row['points_change'] : 0,
                        'type' => isset($row['type']) ? (string) $row['type'] : '',
                        'referenceId' => isset($row['reference_id']) ? (int) $row['reference_id'] : 0,
                        'description' => isset($row['description']) ? (string) $row['description'] : '',
                        'createdAt' => isset($row['created_at']) ? (string) $row['created_at'] : '',
                    ];
                }
            }
        } else {
            $saved = get_option('quick_points_connector_transactions', []);
            if (!is_array($saved)) {
                $saved = [];
            }
            $filtered = [];
            foreach ($saved as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $row_user_id = isset($row['user_id']) ? absint($row['user_id']) : 0;
                $row_type = isset($row['type']) ? sanitize_key((string) $row['type']) : '';
                $row_date = isset($row['created_at']) ? (string) $row['created_at'] : '';
                if ($user_id > 0 && $row_user_id !== $user_id) {
                    continue;
                }
                if ($type !== '' && $row_type !== $type) {
                    continue;
                }
                if ($date_from !== '' && strcmp($row_date, $date_from . ' 00:00:00') < 0) {
                    continue;
                }
                if ($date_to !== '' && strcmp($row_date, $date_to . ' 23:59:59') > 0) {
                    continue;
                }
                $filtered[] = $row;
            }
            usort($filtered, static function (array $a, array $b): int {
                return (int) ($b['id'] ?? 0) <=> (int) ($a['id'] ?? 0);
            });
            $total = count($filtered);
            $paged = array_slice($filtered, $offset, $per_page);
            foreach ($paged as $row) {
                $row_user_id = isset($row['user_id']) ? absint($row['user_id']) : 0;
                $user = $row_user_id > 0 ? get_userdata($row_user_id) : null;
                $rows[] = [
                    'id' => isset($row['id']) ? (int) $row['id'] : 0,
                    'userId' => $row_user_id,
                    'displayName' => $user instanceof WP_User ? (string) $user->display_name : sprintf('User #%d', $row_user_id),
                    'pointsChange' => isset($row['points_change']) ? (int) $row['points_change'] : 0,
                    'type' => isset($row['type']) ? (string) $row['type'] : '',
                    'referenceId' => isset($row['reference_id']) ? (int) $row['reference_id'] : 0,
                    'description' => isset($row['description']) ? (string) $row['description'] : '',
                    'createdAt' => isset($row['created_at']) ? (string) $row['created_at'] : '',
                ];
            }
        }

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $per_page,
        ];
    }

    /**
     * @return array<string, int>
     */
    private function quick_points_get_transaction_totals(): array
    {
        global $wpdb;
        $issued = 0;
        $redeemed = 0;

        if ($this->quick_points_table_exists('quick_points_transactions')) {
            $table = $this->quick_points_table('quick_points_transactions');
            $issued = (int) $wpdb->get_var("SELECT COALESCE(SUM(points_change), 0) FROM {$table} WHERE points_change > 0");
            $redeemed = (int) abs((int) $wpdb->get_var("SELECT COALESCE(SUM(points_change), 0) FROM {$table} WHERE points_change < 0"));
        } else {
            $saved = get_option('quick_points_connector_transactions', []);
            if (!is_array($saved)) {
                $saved = [];
            }
            foreach ($saved as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $change = isset($row['points_change']) ? (int) $row['points_change'] : 0;
                if ($change > 0) {
                    $issued += $change;
                } elseif ($change < 0) {
                    $redeemed += abs($change);
                }
            }
        }

        return [
            'issued' => $issued,
            'redeemed' => $redeemed,
        ];
    }

    /**
     * @return array<string, int>|WP_Error
     */
    private function quick_points_apply_adjustment(
        int $user_id,
        string $direction,
        int $amount,
        string $reason,
        string $tx_type = '',
        int $reference_id = 0,
        bool $track_lifetime = true
    )
    {
        global $wpdb;

        $current_balance = 0;
        $current_lifetime = 0;
        if ($this->quick_points_table_exists('quick_points_balances')) {
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT total_points, lifetime_points FROM {$this->quick_points_table('quick_points_balances')} WHERE user_id = %d",
                    $user_id
                ),
                ARRAY_A
            );
            if (is_array($row)) {
                $current_balance = isset($row['total_points']) ? (int) $row['total_points'] : 0;
                $current_lifetime = isset($row['lifetime_points']) ? (int) $row['lifetime_points'] : 0;
            }
        } else {
            $current_balance = (int) get_user_meta($user_id, 'quickwoo_points_balance', true);
            if ($current_balance === 0) {
                $current_balance = (int) get_user_meta($user_id, 'quick_points_balance', true);
            }
            $current_lifetime = (int) get_user_meta($user_id, 'quick_points_lifetime', true);
            if ($current_lifetime <= 0) {
                $current_lifetime = $current_balance;
            }
        }

        $applied = $direction === 'redeem' ? min($amount, $current_balance) : $amount;
        $signed_delta = $direction === 'redeem' ? (-1 * $applied) : $applied;
        $next_balance = max(0, $current_balance + $signed_delta);
        $next_lifetime = $current_lifetime;
        if ($track_lifetime && $signed_delta > 0) {
            $next_lifetime += $signed_delta;
        }

        if ($this->quick_points_table_exists('quick_points_balances')) {
            $balances_table = $this->quick_points_table('quick_points_balances');
            $exists = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$balances_table} WHERE user_id = %d", $user_id));
            if ($exists > 0) {
                $ok = $wpdb->update(
                    $balances_table,
                    [
                        'total_points' => $next_balance,
                        'lifetime_points' => $next_lifetime,
                        'updated_at' => current_time('mysql'),
                    ],
                    ['user_id' => $user_id],
                    ['%d', '%d', '%s'],
                    ['%d']
                );
                if ($ok === false) {
                    return new WP_Error('quick_points_balance_update_failed', 'Could not update points balance.', ['status' => 500]);
                }
            } else {
                $ok = $wpdb->insert(
                    $balances_table,
                    [
                        'user_id' => $user_id,
                        'total_points' => $next_balance,
                        'lifetime_points' => $next_lifetime,
                        'updated_at' => current_time('mysql'),
                    ],
                    ['%d', '%d', '%d', '%s']
                );
                if ($ok === false) {
                    return new WP_Error('quick_points_balance_create_failed', 'Could not create points balance.', ['status' => 500]);
                }
            }
        }

        update_user_meta($user_id, 'quickwoo_points_balance', $next_balance);
        update_user_meta($user_id, 'quick_points_balance', $next_balance);
        update_user_meta($user_id, 'quick_points_lifetime', $next_lifetime);
        update_user_meta($user_id, 'quick_points_last_reason', $reason);
        update_user_meta($user_id, 'quick_points_last_updated_utc', gmdate('c'));

        $resolved_tx_type = $tx_type !== '' ? sanitize_key($tx_type) : ($direction === 'redeem' ? 'redeem' : 'award');
        $transaction_id = $this->quick_points_record_transaction(
            $user_id,
            $signed_delta,
            $resolved_tx_type,
            $reference_id,
            $reason
        );

        return [
            'delta' => $applied,
            'signedDelta' => $signed_delta,
            'newBalance' => $next_balance,
            'lifetimePoints' => $next_lifetime,
            'transactionId' => $transaction_id,
        ];
    }

    private function quick_points_record_transaction(
        int $user_id,
        int $points_change,
        string $type,
        int $reference_id,
        string $description
    ): int {
        global $wpdb;

        if ($this->quick_points_table_exists('quick_points_transactions')) {
            $wpdb->insert(
                $this->quick_points_table('quick_points_transactions'),
                [
                    'user_id' => $user_id,
                    'points_change' => $points_change,
                    'type' => sanitize_key($type),
                    'reference_id' => $reference_id,
                    'description' => $description,
                    'created_at' => current_time('mysql'),
                ],
                ['%d', '%d', '%s', '%d', '%s', '%s']
            );
            return (int) $wpdb->insert_id;
        }

        $rows = get_option('quick_points_connector_transactions', []);
        if (!is_array($rows)) {
            $rows = [];
        }
        $next_id = $this->quick_ship_next_id($rows);
        array_unshift($rows, [
            'id' => $next_id,
            'user_id' => $user_id,
            'points_change' => $points_change,
            'type' => sanitize_key($type),
            'reference_id' => $reference_id,
            'description' => $description,
            'created_at' => current_time('mysql'),
        ]);
        $rows = array_slice($rows, 0, 5000);
        update_option('quick_points_connector_transactions', $rows, false);

        return $next_id;
    }

    /**
     * @return array<string, int>
     */
    private function quick_points_expire_due_points(): array
    {
        global $wpdb;

        if (!$this->quick_points_table_exists('quick_points_expirations')) {
            return ['expired' => 0, 'rows' => 0];
        }

        $exp_table = $this->quick_points_table('quick_points_expirations');
        $due_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, user_id, points FROM {$exp_table} WHERE points > 0 AND expires_at <= %s ORDER BY expires_at ASC",
                current_time('mysql')
            ),
            ARRAY_A
        );
        if (!is_array($due_rows) || count($due_rows) === 0) {
            return ['expired' => 0, 'rows' => 0];
        }

        $expired_total = 0;
        $processed_rows = 0;
        foreach ($due_rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $exp_id = isset($row['id']) ? absint($row['id']) : 0;
            $user_id = isset($row['user_id']) ? absint($row['user_id']) : 0;
            $points = isset($row['points']) ? absint($row['points']) : 0;
            if ($exp_id <= 0 || $user_id <= 0 || $points <= 0) {
                continue;
            }

            $apply = $this->quick_points_apply_adjustment(
                $user_id,
                'redeem',
                $points,
                'Points expired by rule.',
                'expire',
                $exp_id,
                false
            );
            if ($apply instanceof WP_Error) {
                continue;
            }

            $used = isset($apply['delta']) ? (int) $apply['delta'] : 0;
            if ($used <= 0) {
                continue;
            }

            $wpdb->update(
                $exp_table,
                ['points' => max(0, $points - $used)],
                ['id' => $exp_id],
                ['%d'],
                ['%d']
            );
            $expired_total += $used;
            $processed_rows++;
        }

        return [
            'expired' => $expired_total,
            'rows' => $processed_rows,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_seo_open_payload(): array
    {
        $post_types = ['post', 'page'];
        if (post_type_exists('product')) {
            $post_types[] = 'product';
        }

        $items = get_posts([
            'post_type' => $post_types,
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'numberposts' => 200,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);

        $missing_title = 0;
        $short_title = 0;
        $long_title = 0;
        $missing_meta_description = 0;
        $recommendations = [];
        $content_rows = [];

        foreach ($items as $item) {
            if (!$item instanceof WP_Post) {
                continue;
            }

            $row = $this->quick_seo_content_row_from_post($item);
            $content_rows[] = $row;

            $title = trim((string) $row['title']);
            $title_length = function_exists('mb_strlen') ? mb_strlen($title) : strlen($title);
            $meta_description = trim((string) ($row['metaDescription'] ?? ''));

            if ($title === '') {
                $missing_title++;
                if (count($recommendations) < 20) {
                    $recommendations[] = [
                        'postId' => (int) $row['postId'],
                        'postType' => (string) $row['postType'],
                        'title' => '(Untitled)',
                        'issue' => 'missing_title',
                    ];
                }
            } elseif ($title_length < 30) {
                $short_title++;
                if (count($recommendations) < 20) {
                    $recommendations[] = [
                        'postId' => (int) $row['postId'],
                        'postType' => (string) $row['postType'],
                        'title' => $title,
                        'issue' => 'title_too_short',
                    ];
                }
            } elseif ($title_length > 60) {
                $long_title++;
                if (count($recommendations) < 20) {
                    $recommendations[] = [
                        'postId' => (int) $row['postId'],
                        'postType' => (string) $row['postType'],
                        'title' => $title,
                        'issue' => 'title_too_long',
                    ];
                }
            }

            if ($meta_description === '') {
                $missing_meta_description++;
                if (count($recommendations) < 20) {
                    $recommendations[] = [
                        'postId' => (int) $row['postId'],
                        'postType' => (string) $row['postType'],
                        'title' => $title !== '' ? $title : '(Untitled)',
                        'issue' => 'missing_meta_description',
                    ];
                }
            }
        }

        $recent_images = get_posts([
            'post_type' => 'attachment',
            'post_mime_type' => 'image',
            'post_status' => 'inherit',
            'numberposts' => 60,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);
        $missing_alt_images = 0;
        foreach ($recent_images as $image) {
            if (!$image instanceof WP_Post) {
                continue;
            }
            $alt = trim((string) get_post_meta($image->ID, '_wp_attachment_image_alt', true));
            if ($alt === '') {
                $missing_alt_images++;
            }
        }

        $redirects = get_option('quickseo_redirects', []);
        if (!is_array($redirects)) {
            $redirects = [];
        }

        $broken_links = get_option('quick_seo_broken_links', []);
        if (!is_array($broken_links)) {
            $broken_links = [];
        }

        $robots_path = ABSPATH . 'robots.txt';
        $robots_content = file_exists($robots_path) ? file_get_contents($robots_path) : "User-agent: *\nDisallow:\n";
        if (!is_string($robots_content)) {
            $robots_content = "User-agent: *\nDisallow:\n";
        }

        $sitemap_path = ABSPATH . 'sitemap.xml';
        $sitemap_exists = file_exists($sitemap_path);
        $sitemap_size = $sitemap_exists ? (int) filesize($sitemap_path) : 0;
        $sitemap_modified = $sitemap_exists ? gmdate('c', (int) filemtime($sitemap_path)) : null;

        $schema_types = $this->quick_seo_schema_types();
        $schema_templates = [];
        foreach ($schema_types as $schema_type) {
            $schema_templates[(string) $schema_type] = (string) get_option('quickseo_schema_' . strtolower((string) $schema_type), '');
        }

        $term_rows = [];
        $taxonomy_configs = [
            ['taxonomy' => 'category', 'label' => 'Post Category'],
            ['taxonomy' => 'post_tag', 'label' => 'Post Tag'],
            ['taxonomy' => 'product_cat', 'label' => 'Product Category'],
            ['taxonomy' => 'product_tag', 'label' => 'Product Tag'],
        ];
        foreach ($taxonomy_configs as $taxonomy_config) {
            $taxonomy = (string) ($taxonomy_config['taxonomy'] ?? '');
            if ($taxonomy === '' || !taxonomy_exists($taxonomy)) {
                continue;
            }
            $label = (string) ($taxonomy_config['label'] ?? $taxonomy);
            $term_rows = array_merge($term_rows, $this->quick_seo_term_rows($taxonomy, $label));
        }

        $summary = [
            'scannedItems' => count($content_rows),
            'missingTitle' => $missing_title,
            'shortTitle' => $short_title,
            'longTitle' => $long_title,
            'missingMetaDescription' => $missing_meta_description,
            'missingAltOnRecentImages' => $missing_alt_images,
            'redirectCount' => count($redirects),
            'brokenLinkCount' => count($broken_links),
            'schemaTemplateCount' => count(array_filter($schema_templates, static function ($template) {
                return is_string($template) && trim($template) !== '';
            })),
            'termRows' => count($term_rows),
            'sitemapExists' => $sitemap_exists,
        ];

        $workspace = [
            'summary' => $summary,
            'contentRows' => array_slice($content_rows, 0, 200),
            'termRows' => array_slice($term_rows, 0, 400),
            'recommendations' => $recommendations,
            'redirects' => $this->quick_seo_normalize_redirects($redirects),
            'brokenLinks' => array_slice($broken_links, 0, 250),
            'robots' => [
                'content' => $robots_content,
                'writable' => is_writable(ABSPATH),
            ],
            'sitemap' => [
                'exists' => $sitemap_exists,
                'sizeBytes' => $sitemap_size,
                'modifiedUtc' => $sitemap_modified,
            ],
            'canonical' => [
                'mode' => (string) get_option('quickseo_global_canonical', 'default'),
            ],
            'schema' => [
                'types' => $schema_types,
                'templates' => $schema_templates,
            ],
            'serverTimeUtc' => gmdate('c'),
        ];

        $workspace['content'] = array_map([$this, 'quick_seo_legacy_content_row'], (array) $workspace['contentRows']);

        return $workspace;
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_generate_meta_description_payload(array $payload)
    {
        $post_id = isset($payload['postId']) ? absint($payload['postId']) : 0;
        $max_length = isset($payload['maxLength']) ? absint($payload['maxLength']) : 155;
        if ($max_length <= 0) {
            $max_length = 155;
        }
        if ($max_length > 300) {
            $max_length = 300;
        }

        if ($post_id <= 0) {
            return new WP_Error('quick_seo_post_required', 'Valid postId is required.', ['status' => 400]);
        }

        $post = get_post($post_id);
        if (!$post instanceof WP_Post) {
            return new WP_Error('quick_seo_post_not_found', 'Post not found.', ['status' => 404]);
        }

        $raw_text = trim(wp_strip_all_tags((string) $post->post_excerpt));
        if ($raw_text === '') {
            $raw_text = trim(wp_strip_all_tags((string) $post->post_content));
        }
        if ($raw_text === '') {
            $raw_text = trim((string) $post->post_title);
        }
        if ($raw_text === '') {
            return new WP_Error('quick_seo_no_text', 'No content available to generate a description.', ['status' => 400]);
        }

        if (function_exists('mb_substr') && function_exists('mb_strlen')) {
            $description = mb_substr($raw_text, 0, $max_length);
            if (mb_strlen($raw_text) > $max_length) {
                $description = rtrim($description) . '...';
            }
        } else {
            $description = substr($raw_text, 0, $max_length);
            if (strlen($raw_text) > $max_length) {
                $description = rtrim($description) . '...';
            }
        }

        update_post_meta($post_id, 'quick_seo_meta_description', $description);
        update_post_meta($post_id, '_quickseo_meta_description', $description);
        return $this->quick_seo_workspace_response([
            'postId' => $post_id,
            'postType' => $post->post_type,
            'title' => (string) $post->post_title,
            'metaDescription' => $description,
        ]);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_save_meta_payload(array $payload)
    {
        $post_id = isset($payload['postId']) ? absint($payload['postId']) : 0;
        if ($post_id <= 0) {
            return new WP_Error('quick_seo_post_required', 'Valid postId is required.', ['status' => 400]);
        }
        $post = get_post($post_id);
        if (!$post instanceof WP_Post) {
            return new WP_Error('quick_seo_post_not_found', 'Post not found.', ['status' => 404]);
        }

        $meta_description = isset($payload['metaDescription']) ? sanitize_textarea_field((string) $payload['metaDescription']) : '';
        $canonical_url = isset($payload['canonicalUrl']) ? esc_url_raw((string) $payload['canonicalUrl']) : '';
        $focus_keyword = isset($payload['focusKeyword']) ? sanitize_text_field((string) $payload['focusKeyword']) : '';
        $secondary_keyword = isset($payload['secondaryKeyword']) ? sanitize_text_field((string) $payload['secondaryKeyword']) : '';
        $seo_title = isset($payload['seoTitle']) ? sanitize_text_field((string) $payload['seoTitle']) : '';
        $og_title = isset($payload['ogTitle']) ? sanitize_text_field((string) $payload['ogTitle']) : '';
        $og_description = isset($payload['ogDescription']) ? sanitize_textarea_field((string) $payload['ogDescription']) : '';
        $og_type = isset($payload['ogType']) ? sanitize_text_field((string) $payload['ogType']) : '';
        $og_image = isset($payload['ogImage']) ? esc_url_raw((string) $payload['ogImage']) : '';
        $twitter_title = isset($payload['twitterTitle']) ? sanitize_text_field((string) $payload['twitterTitle']) : '';
        $twitter_description = isset($payload['twitterDescription']) ? sanitize_textarea_field((string) $payload['twitterDescription']) : '';
        $twitter_image = isset($payload['twitterImage']) ? esc_url_raw((string) $payload['twitterImage']) : '';
        $schema_type = isset($payload['schemaType']) ? sanitize_text_field((string) $payload['schemaType']) : '';
        $longtail_keyword = isset($payload['longtailKeyword']) ? sanitize_text_field((string) $payload['longtailKeyword']) : '';
        $robots = isset($payload['robots']) ? sanitize_text_field((string) $payload['robots']) : '';
        $sitemap = isset($payload['sitemap']) ? sanitize_text_field((string) $payload['sitemap']) : '';
        $noindex = isset($payload['noindex']) ? ($this->quick_points_bool_to_int($payload['noindex']) > 0 ? '1' : '0') : '0';

        update_post_meta($post_id, 'quick_seo_meta_description', $meta_description);
        update_post_meta($post_id, '_quickseo_meta_description', $meta_description);
        update_post_meta($post_id, 'quick_seo_canonical', $canonical_url);
        update_post_meta($post_id, '_quickseo_canonical_override', $canonical_url);
        update_post_meta($post_id, 'quick_seo_focus_keyword', $focus_keyword);
        update_post_meta($post_id, '_quickseo_focus_keyword', $focus_keyword);
        update_post_meta($post_id, 'quick_seo_noindex', $noindex);
        update_post_meta($post_id, '_quickseo_secondary_keyword', $secondary_keyword);
        update_post_meta($post_id, '_quickseo_seo_title', $seo_title);
        update_post_meta($post_id, '_quickseo_og_title', $og_title);
        update_post_meta($post_id, '_quickseo_og_description', $og_description);
        update_post_meta($post_id, '_quickseo_og_type', $og_type);
        update_post_meta($post_id, '_quickseo_og_image', $og_image);
        update_post_meta($post_id, '_quickseo_twitter_title', $twitter_title);
        update_post_meta($post_id, '_quickseo_twitter_description', $twitter_description);
        update_post_meta($post_id, '_quickseo_twitter_image', $twitter_image);
        update_post_meta($post_id, '_quickseo_schema', $schema_type);
        update_post_meta($post_id, '_quickseo_longtail_keyword', $longtail_keyword);
        update_post_meta($post_id, '_quickseo_robots', $robots);
        update_post_meta($post_id, '_quickseo_sitemap', $sitemap === 'yes' ? 'yes' : 'no');

        return $this->quick_seo_workspace_response([
            'postId' => $post_id,
            'saved' => true,
            'metaDescription' => $meta_description,
            'canonicalUrl' => $canonical_url,
            'focusKeyword' => $focus_keyword,
            'noindex' => $noindex === '1',
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_seo_run_link_scan_payload(): array
    {
        global $wpdb;

        $rows = $wpdb->get_results(
            "SELECT ID, post_content FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_content <> '' LIMIT 500",
            ARRAY_A
        );

        $broken = [];
        if (is_array($rows)) {
            foreach ($rows as $row) {
                if (!is_array($row) || !isset($row['ID'], $row['post_content'])) {
                    continue;
                }
                $post_id = (int) $row['ID'];
                $doc = new DOMDocument();
                @$doc->loadHTML((string) $row['post_content']);
                $links = $doc->getElementsByTagName('a');
                foreach ($links as $link) {
                    $href = trim((string) $link->getAttribute('href'));
                    if ($href === '') {
                        continue;
                    }
                    if (strpos($href, home_url()) === 0 || strpos($href, '/') === 0) {
                        $path = parse_url($href, PHP_URL_PATH);
                        if (!is_string($path) || $path === '') {
                            continue;
                        }
                        $exists = $this->quick_seo_url_exists($path);
                        if (!$exists) {
                            $broken[$path] = get_permalink($post_id);
                        }
                    }
                }
            }
        }

        $broken_rows = [];
        foreach ($broken as $path => $source_url) {
            $broken_rows[] = [
                'path' => (string) $path,
                'sourceUrl' => (string) $source_url,
            ];
        }
        update_option('quick_seo_broken_links', $broken_rows, false);
        return $this->quick_seo_workspace_response([
            'brokenCount' => count($broken_rows),
            'brokenLinks' => array_slice($broken_rows, 0, 250),
        ]);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_add_redirect_payload(array $payload)
    {
        $from = isset($payload['from']) ? sanitize_text_field((string) $payload['from']) : '';
        $to = isset($payload['to']) ? sanitize_text_field((string) $payload['to']) : '';
        if ($from === '' || $to === '') {
            return new WP_Error('quick_seo_redirect_fields_required', 'Both from and to are required.', ['status' => 400]);
        }

        $redirects = get_option('quickseo_redirects', []);
        if (!is_array($redirects)) {
            $redirects = [];
        }
        $redirects[$from] = $to;
        update_option('quickseo_redirects', $redirects, false);
        return $this->quick_seo_workspace_response([
            'from' => $from,
            'to' => $to,
        ]);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_remove_redirect_payload(array $payload)
    {
        $from = isset($payload['from']) ? sanitize_text_field((string) $payload['from']) : '';
        if ($from === '') {
            return new WP_Error('quick_seo_redirect_from_required', 'from is required.', ['status' => 400]);
        }

        $redirects = get_option('quickseo_redirects', []);
        if (!is_array($redirects)) {
            $redirects = [];
        }
        unset($redirects[$from]);
        update_option('quickseo_redirects', $redirects, false);
        return $this->quick_seo_workspace_response([
            'from' => $from,
        ]);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_save_robots_payload(array $payload)
    {
        $content = isset($payload['content']) ? (string) $payload['content'] : '';
        if (!is_writable(ABSPATH)) {
            return new WP_Error('quick_seo_robots_not_writable', 'Site root is not writable.', ['status' => 400]);
        }

        $path = ABSPATH . 'robots.txt';
        $written = file_put_contents($path, $content);
        if ($written === false) {
            return new WP_Error('quick_seo_robots_write_failed', 'Failed to write robots.txt.', ['status' => 500]);
        }

        return $this->quick_seo_workspace_response([
            'saved' => true,
        ]);
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_generate_sitemap_payload()
    {
        if (!is_writable(ABSPATH)) {
            return new WP_Error('quick_seo_sitemap_not_writable', 'Site root is not writable.', ['status' => 400]);
        }

        $post_types = ['page', 'post'];
        if (class_exists('WooCommerce')) {
            $post_types[] = 'product';
        }
        $urls = [];
        foreach ($post_types as $type) {
            $query = new WP_Query([
                'post_type' => $type,
                'post_status' => 'publish',
                'posts_per_page' => -1,
                'fields' => 'ids',
            ]);
            if ($query->have_posts()) {
                foreach ($query->posts as $post_id) {
                    $url = get_permalink((int) $post_id);
                    if (is_string($url) && $url !== '') {
                        $urls[] = $url;
                    }
                }
            }
            wp_reset_postdata();
        }

        $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        $xml .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
        foreach ($urls as $url) {
            $xml .= "  <url>\n";
            $xml .= "    <loc>" . htmlspecialchars($url, ENT_XML1, 'UTF-8') . "</loc>\n";
            $xml .= "    <lastmod>" . gmdate('c') . "</lastmod>\n";
            $xml .= "    <changefreq>weekly</changefreq>\n";
            $xml .= "    <priority>0.8</priority>\n";
            $xml .= "  </url>\n";
        }
        $xml .= "</urlset>";

        $path = ABSPATH . 'sitemap.xml';
        $written = file_put_contents($path, $xml);
        if ($written === false) {
            return new WP_Error('quick_seo_sitemap_write_failed', 'Failed to write sitemap.xml.', ['status' => 500]);
        }

        return $this->quick_seo_workspace_response([
            'urlCount' => count($urls),
        ]);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_export_csv_payload(array $payload)
    {
        $entity = isset($payload['entity']) ? sanitize_key((string) $payload['entity']) : 'content';
        if (!in_array($entity, ['content', 'content-rows', 'terms', 'recommendations', 'redirects', 'broken-links'], true)) {
            return new WP_Error('quick_seo_export_entity_invalid', 'entity must be one of content, content-rows, terms, recommendations, redirects, broken-links.', ['status' => 400]);
        }

        $workspace = $this->quick_seo_open_payload();
        $rows = [];
        if ($entity === 'content') {
            $rows[] = ['post_id', 'post_type', 'title', 'status', 'modified_utc', 'meta_description', 'canonical_url', 'focus_keyword', 'noindex'];
            $content = isset($workspace['content']) && is_array($workspace['content']) ? $workspace['content'] : [];
            foreach ($content as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $rows[] = [
                    (string) ($item['postId'] ?? 0),
                    (string) ($item['postType'] ?? ''),
                    (string) ($item['title'] ?? ''),
                    (string) ($item['status'] ?? ''),
                    (string) ($item['modified'] ?? ''),
                    (string) ($item['metaDescription'] ?? ''),
                    (string) ($item['canonicalUrl'] ?? ''),
                    (string) ($item['focusKeyword'] ?? ''),
                    !empty($item['noindex']) ? '1' : '0',
                ];
            }
        } elseif ($entity === 'content-rows') {
            $rows[] = [
                'post_id',
                'post_type',
                'title',
                'status',
                'modified_utc',
                'focus_keyword',
                'secondary_keyword',
                'seo_title',
                'meta_description',
                'og_title',
                'og_description',
                'og_type',
                'og_image',
                'twitter_title',
                'twitter_description',
                'twitter_image',
                'schema_type',
                'longtail_keyword',
                'robots',
                'sitemap',
                'canonical_url'
            ];
            $content_rows = isset($workspace['contentRows']) && is_array($workspace['contentRows']) ? $workspace['contentRows'] : [];
            foreach ($content_rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $rows[] = [
                    (string) ($row['postId'] ?? 0),
                    (string) ($row['postType'] ?? ''),
                    (string) ($row['title'] ?? ''),
                    (string) ($row['status'] ?? ''),
                    (string) ($row['modified'] ?? ''),
                    (string) ($row['focusKeyword'] ?? ''),
                    (string) ($row['secondaryKeyword'] ?? ''),
                    (string) ($row['seoTitle'] ?? ''),
                    (string) ($row['metaDescription'] ?? ''),
                    (string) ($row['ogTitle'] ?? ''),
                    (string) ($row['ogDescription'] ?? ''),
                    (string) ($row['ogType'] ?? ''),
                    (string) ($row['ogImage'] ?? ''),
                    (string) ($row['twitterTitle'] ?? ''),
                    (string) ($row['twitterDescription'] ?? ''),
                    (string) ($row['twitterImage'] ?? ''),
                    (string) ($row['schemaType'] ?? ''),
                    (string) ($row['longtailKeyword'] ?? ''),
                    (string) ($row['robots'] ?? ''),
                    (string) ($row['sitemap'] ?? ''),
                    (string) ($row['canonicalUrl'] ?? ''),
                ];
            }
        } elseif ($entity === 'terms') {
            $rows[] = [
                'term_id',
                'taxonomy',
                'taxonomy_label',
                'name',
                'count',
                'focus_keyword',
                'secondary_keyword',
                'seo_title',
                'meta_description',
                'og_title',
                'og_description',
                'og_type',
                'og_image',
                'twitter_title',
                'twitter_description',
                'twitter_image',
                'schema_type',
                'longtail_keyword',
                'robots',
                'sitemap'
            ];
            $term_rows = isset($workspace['termRows']) && is_array($workspace['termRows']) ? $workspace['termRows'] : [];
            foreach ($term_rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $rows[] = [
                    (string) ($row['termId'] ?? 0),
                    (string) ($row['taxonomy'] ?? ''),
                    (string) ($row['taxonomyLabel'] ?? ''),
                    (string) ($row['name'] ?? ''),
                    (string) ($row['count'] ?? 0),
                    (string) ($row['focusKeyword'] ?? ''),
                    (string) ($row['secondaryKeyword'] ?? ''),
                    (string) ($row['seoTitle'] ?? ''),
                    (string) ($row['metaDescription'] ?? ''),
                    (string) ($row['ogTitle'] ?? ''),
                    (string) ($row['ogDescription'] ?? ''),
                    (string) ($row['ogType'] ?? ''),
                    (string) ($row['ogImage'] ?? ''),
                    (string) ($row['twitterTitle'] ?? ''),
                    (string) ($row['twitterDescription'] ?? ''),
                    (string) ($row['twitterImage'] ?? ''),
                    (string) ($row['schemaType'] ?? ''),
                    (string) ($row['longtailKeyword'] ?? ''),
                    (string) ($row['robots'] ?? ''),
                    (string) ($row['sitemap'] ?? ''),
                ];
            }
        } elseif ($entity === 'recommendations') {
            $rows[] = ['post_id', 'post_type', 'title', 'issue'];
            $recommendations = isset($workspace['recommendations']) && is_array($workspace['recommendations']) ? $workspace['recommendations'] : [];
            foreach ($recommendations as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $rows[] = [
                    (string) ($row['postId'] ?? 0),
                    (string) ($row['postType'] ?? ''),
                    (string) ($row['title'] ?? ''),
                    (string) ($row['issue'] ?? ''),
                ];
            }
        } elseif ($entity === 'redirects') {
            $rows[] = ['from', 'to'];
            $redirects = isset($workspace['redirects']) && is_array($workspace['redirects']) ? $workspace['redirects'] : [];
            foreach ($redirects as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $rows[] = [
                    (string) ($row['from'] ?? ''),
                    (string) ($row['to'] ?? ''),
                ];
            }
        } else {
            $rows[] = ['path', 'source_url'];
            $broken_links = get_option('quick_seo_broken_links', []);
            if (is_array($broken_links)) {
                foreach ($broken_links as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $rows[] = [
                        (string) ($row['path'] ?? ''),
                        (string) ($row['sourceUrl'] ?? ''),
                    ];
                }
            }
        }

        $csv = $this->quick_importer_rows_to_csv($rows);
        if ($csv instanceof WP_Error) {
            return $csv;
        }

        return [
            'entity' => $entity,
            'filename' => sprintf('quick-seo-%s-%s.csv', $entity, gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    /**
     * @param array<string, string> $redirects
     * @return array<int, array<string, string>>
     */
    private function quick_seo_normalize_redirects(array $redirects): array
    {
        $rows = [];
        foreach ($redirects as $from => $to) {
            $rows[] = [
                'from' => (string) $from,
                'to' => (string) $to,
            ];
        }
        return $rows;
    }

    private function quick_seo_url_exists(string $path): bool
    {
        $url = site_url($path);
        $response = wp_remote_head($url);
        if (is_wp_error($response)) {
            return false;
        }

        $status_code = (int) wp_remote_retrieve_response_code($response);
        return $status_code > 0 && $status_code !== 404;
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_save_bulk_payload(array $payload)
    {
        $rows = isset($payload['rows']) && is_array($payload['rows']) ? $payload['rows'] : [];
        if (!$rows) {
            return new WP_Error('quick_seo_bulk_rows_required', 'rows array is required.', ['status' => 400]);
        }

        $saved_count = 0;
        foreach ($rows as $raw_row) {
            if (!is_array($raw_row)) {
                continue;
            }

            $target_type = sanitize_key((string) ($raw_row['targetType'] ?? ''));
            $target_id = absint($raw_row['id'] ?? 0);
            $fields = isset($raw_row['fields']) && is_array($raw_row['fields']) ? $raw_row['fields'] : [];
            if ($target_type === '' || $target_id <= 0 || !$fields) {
                continue;
            }

            $normalized = $this->quick_seo_normalize_fields_for_save($fields);
            if ($target_type === 'post') {
                if (!(get_post($target_id) instanceof WP_Post)) {
                    continue;
                }
                $this->quick_seo_write_post_fields($target_id, $normalized);
                $saved_count++;
            } elseif ($target_type === 'term') {
                if (!(get_term($target_id) instanceof WP_Term)) {
                    continue;
                }
                $this->quick_seo_write_term_fields($target_id, $normalized);
                $saved_count++;
            }
        }

        return $this->quick_seo_workspace_response([
            'savedCount' => $saved_count,
        ]);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_load_schema_template_payload(array $payload)
    {
        $schema_type = isset($payload['schemaType']) ? sanitize_text_field((string) $payload['schemaType']) : '';
        if ($schema_type === '') {
            return new WP_Error('quick_seo_schema_type_required', 'schemaType is required.', ['status' => 400]);
        }

        return $this->quick_seo_workspace_response([
            'schemaType' => $schema_type,
            'schemaTemplate' => (string) get_option('quickseo_schema_' . strtolower($schema_type), ''),
        ]);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_save_schema_template_payload(array $payload)
    {
        $schema_type = isset($payload['schemaType']) ? sanitize_text_field((string) $payload['schemaType']) : '';
        $schema_template = isset($payload['schemaTemplate']) ? wp_unslash((string) $payload['schemaTemplate']) : '';
        if ($schema_type === '') {
            return new WP_Error('quick_seo_schema_type_required', 'schemaType is required.', ['status' => 400]);
        }
        if (trim($schema_template) === '') {
            return new WP_Error('quick_seo_schema_template_required', 'schemaTemplate is required.', ['status' => 400]);
        }

        update_option('quickseo_schema_' . strtolower($schema_type), $schema_template, false);
        return $this->quick_seo_workspace_response([
            'schemaType' => $schema_type,
            'schemaTemplate' => $schema_template,
        ]);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_seo_save_canonical_mode_payload(array $payload)
    {
        $canonical_mode = isset($payload['canonicalMode']) ? sanitize_key((string) $payload['canonicalMode']) : '';
        if (!in_array($canonical_mode, ['default', 'clean', 'custom'], true)) {
            return new WP_Error('quick_seo_canonical_mode_invalid', 'canonicalMode must be default, clean, or custom.', ['status' => 400]);
        }

        update_option('quickseo_global_canonical', $canonical_mode, false);
        return $this->quick_seo_workspace_response([
            'canonicalMode' => $canonical_mode,
        ]);
    }

    /**
     * @param array<string, mixed> $extra
     * @return array<string, mixed>
     */
    private function quick_seo_workspace_response(array $extra = []): array
    {
        $workspace = $this->quick_seo_open_payload();
        return array_merge($workspace, $extra);
    }

    /**
     * @return array<int, string>
     */
    private function quick_seo_schema_types(): array
    {
        return [
            'WebPage',
            'Article',
            'BlogPosting',
            'NewsArticle',
            'Product',
            'Offer',
            'Person',
            'Organization',
            'Event',
            'LocalBusiness',
            'Service',
            'FAQPage',
            'HowTo',
        ];
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function quick_seo_legacy_content_row(array $row): array
    {
        return [
            'postId' => (int) ($row['postId'] ?? 0),
            'postType' => (string) ($row['postType'] ?? ''),
            'title' => (string) ($row['title'] ?? ''),
            'status' => (string) ($row['status'] ?? ''),
            'modified' => (string) ($row['modified'] ?? ''),
            'metaDescription' => (string) ($row['metaDescription'] ?? ''),
            'canonicalUrl' => (string) ($row['canonicalUrl'] ?? ''),
            'focusKeyword' => (string) ($row['focusKeyword'] ?? ''),
            'noindex' => trim((string) ($row['robots'] ?? '')) === 'noindex, follow' || trim((string) ($row['robots'] ?? '')) === 'noindex, nofollow',
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_seo_content_row_from_post(WP_Post $post): array
    {
        $post_id = (int) $post->ID;
        $meta_description = $this->quick_seo_first_non_empty_post_meta($post_id, [
            '_quickseo_meta_description',
            'quick_seo_meta_description',
            '_yoast_wpseo_metadesc',
            'rank_math_description',
        ]);
        $canonical_url = $this->quick_seo_first_non_empty_post_meta($post_id, [
            '_quickseo_canonical_override',
            'quick_seo_canonical',
        ]);
        $focus_keyword = $this->quick_seo_first_non_empty_post_meta($post_id, [
            '_quickseo_focus_keyword',
            'quick_seo_focus_keyword',
        ]);

        return [
            'postId' => $post_id,
            'postType' => (string) $post->post_type,
            'title' => (string) $post->post_title,
            'status' => (string) $post->post_status,
            'modified' => (string) get_post_modified_time('c', true, $post),
            'focusKeyword' => $focus_keyword,
            'secondaryKeyword' => trim((string) get_post_meta($post_id, '_quickseo_secondary_keyword', true)),
            'seoTitle' => trim((string) get_post_meta($post_id, '_quickseo_seo_title', true)),
            'metaDescription' => $meta_description,
            'ogTitle' => trim((string) get_post_meta($post_id, '_quickseo_og_title', true)),
            'ogDescription' => trim((string) get_post_meta($post_id, '_quickseo_og_description', true)),
            'ogType' => trim((string) get_post_meta($post_id, '_quickseo_og_type', true)),
            'ogImage' => trim((string) get_post_meta($post_id, '_quickseo_og_image', true)),
            'twitterTitle' => trim((string) get_post_meta($post_id, '_quickseo_twitter_title', true)),
            'twitterDescription' => trim((string) get_post_meta($post_id, '_quickseo_twitter_description', true)),
            'twitterImage' => trim((string) get_post_meta($post_id, '_quickseo_twitter_image', true)),
            'schemaType' => trim((string) get_post_meta($post_id, '_quickseo_schema', true)),
            'longtailKeyword' => trim((string) get_post_meta($post_id, '_quickseo_longtail_keyword', true)),
            'robots' => trim((string) get_post_meta($post_id, '_quickseo_robots', true)),
            'sitemap' => trim((string) get_post_meta($post_id, '_quickseo_sitemap', true)),
            'canonicalUrl' => $canonical_url,
        ];
    }

    /**
     * @param int $post_id
     * @param array<int, string> $keys
     */
    private function quick_seo_first_non_empty_post_meta(int $post_id, array $keys): string
    {
        foreach ($keys as $key) {
            $value = trim((string) get_post_meta($post_id, $key, true));
            if ($value !== '') {
                return $value;
            }
        }
        return '';
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_seo_term_rows(string $taxonomy, string $taxonomy_label): array
    {
        $rows = [];
        $terms = get_terms([
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
            'number' => 200,
        ]);
        if (is_wp_error($terms) || !is_array($terms)) {
            return $rows;
        }

        foreach ($terms as $term) {
            if (!$term instanceof WP_Term) {
                continue;
            }
            $term_id = (int) $term->term_id;
            $rows[] = [
                'termId' => $term_id,
                'taxonomy' => $taxonomy,
                'taxonomyLabel' => $taxonomy_label,
                'name' => (string) $term->name,
                'count' => (int) $term->count,
                'focusKeyword' => trim((string) get_term_meta($term_id, '_quickseo_focus_keyword', true)),
                'secondaryKeyword' => trim((string) get_term_meta($term_id, '_quickseo_secondary_keyword', true)),
                'seoTitle' => trim((string) get_term_meta($term_id, '_quickseo_seo_title', true)),
                'metaDescription' => trim((string) get_term_meta($term_id, '_quickseo_meta_description', true)),
                'ogTitle' => trim((string) get_term_meta($term_id, '_quickseo_og_title', true)),
                'ogDescription' => trim((string) get_term_meta($term_id, '_quickseo_og_description', true)),
                'ogType' => trim((string) get_term_meta($term_id, '_quickseo_og_type', true)),
                'ogImage' => trim((string) get_term_meta($term_id, '_quickseo_og_image', true)),
                'twitterTitle' => trim((string) get_term_meta($term_id, '_quickseo_twitter_title', true)),
                'twitterDescription' => trim((string) get_term_meta($term_id, '_quickseo_twitter_description', true)),
                'twitterImage' => trim((string) get_term_meta($term_id, '_quickseo_twitter_image', true)),
                'schemaType' => trim((string) get_term_meta($term_id, '_quickseo_schema', true)),
                'longtailKeyword' => trim((string) get_term_meta($term_id, '_quickseo_longtail_keyword', true)),
                'robots' => trim((string) get_term_meta($term_id, '_quickseo_robots', true)),
                'sitemap' => trim((string) get_term_meta($term_id, '_quickseo_sitemap', true)),
            ];
        }

        return $rows;
    }

    /**
     * @param array<string, mixed> $fields
     * @return array<string, string>
     */
    private function quick_seo_normalize_fields_for_save(array $fields): array
    {
        $normalized = [];
        $mapping = [
            'focusKeyword' => '_quickseo_focus_keyword',
            'secondaryKeyword' => '_quickseo_secondary_keyword',
            'seoTitle' => '_quickseo_seo_title',
            'metaDescription' => '_quickseo_meta_description',
            'ogTitle' => '_quickseo_og_title',
            'ogDescription' => '_quickseo_og_description',
            'ogType' => '_quickseo_og_type',
            'ogImage' => '_quickseo_og_image',
            'twitterTitle' => '_quickseo_twitter_title',
            'twitterDescription' => '_quickseo_twitter_description',
            'twitterImage' => '_quickseo_twitter_image',
            'schemaType' => '_quickseo_schema',
            'longtailKeyword' => '_quickseo_longtail_keyword',
            'robots' => '_quickseo_robots',
            'sitemap' => '_quickseo_sitemap',
            'canonicalUrl' => '_quickseo_canonical_override',
        ];

        foreach ($mapping as $input_key => $meta_key) {
            if (!array_key_exists($input_key, $fields)) {
                continue;
            }
            $raw = (string) $fields[$input_key];
            if ($input_key === 'ogImage' || $input_key === 'twitterImage' || $input_key === 'canonicalUrl') {
                $normalized[$meta_key] = esc_url_raw($raw);
            } elseif ($input_key === 'metaDescription' || $input_key === 'ogDescription' || $input_key === 'twitterDescription') {
                $normalized[$meta_key] = sanitize_textarea_field($raw);
            } elseif ($input_key === 'sitemap') {
                $normalized[$meta_key] = trim($raw) === 'yes' ? 'yes' : 'no';
            } else {
                $normalized[$meta_key] = sanitize_text_field($raw);
            }
        }

        if (isset($normalized['_quickseo_robots']) && strpos($normalized['_quickseo_robots'], 'noindex') !== false) {
            $normalized['quick_seo_noindex'] = '1';
        } else {
            $normalized['quick_seo_noindex'] = '0';
        }

        if (isset($normalized['_quickseo_meta_description'])) {
            $normalized['quick_seo_meta_description'] = $normalized['_quickseo_meta_description'];
        }
        if (isset($normalized['_quickseo_focus_keyword'])) {
            $normalized['quick_seo_focus_keyword'] = $normalized['_quickseo_focus_keyword'];
        }
        if (isset($normalized['_quickseo_canonical_override'])) {
            $normalized['quick_seo_canonical'] = $normalized['_quickseo_canonical_override'];
        }

        return $normalized;
    }

    /**
     * @param array<string, string> $normalized
     */
    private function quick_seo_write_post_fields(int $post_id, array $normalized): void
    {
        foreach ($normalized as $meta_key => $value) {
            update_post_meta($post_id, $meta_key, $value);
        }
    }

    /**
     * @param array<string, string> $normalized
     */
    private function quick_seo_write_term_fields(int $term_id, array $normalized): void
    {
        foreach ($normalized as $meta_key => $value) {
            if (strpos((string) $meta_key, 'quick_seo_') === 0) {
                continue;
            }
            update_term_meta($term_id, $meta_key, $value);
        }
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_audit_open_payload(array $scan_settings = []): array
    {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = get_plugins();
        $active_plugins = (array) get_option('active_plugins', []);
        $inactive_plugins = max(0, count($plugins) - count($active_plugins));
        $users_count = (int) count_users()['total_users'];

        $core_updates = get_site_transient('update_core');
        $core_update_available = false;
        if ($core_updates instanceof stdClass && isset($core_updates->updates) && is_array($core_updates->updates)) {
            foreach ($core_updates->updates as $core_update) {
                if ($core_update instanceof stdClass && isset($core_update->response) && $core_update->response === 'upgrade') {
                    $core_update_available = true;
                    break;
                }
            }
        }

        $plugin_updates = get_site_transient('update_plugins');
        $theme_updates = get_site_transient('update_themes');
        $plugin_update_count = ($plugin_updates instanceof stdClass && isset($plugin_updates->response) && is_array($plugin_updates->response))
            ? count($plugin_updates->response)
            : 0;
        $theme_update_count = ($theme_updates instanceof stdClass && isset($theme_updates->response) && is_array($theme_updates->response))
            ? count($theme_updates->response)
            : 0;

        $findings = [];
        if ($core_update_available) {
            $findings[] = ['severity' => 'high', 'code' => 'core_update', 'message' => 'WordPress core update is available.'];
        }
        if ($plugin_update_count > 0) {
            $findings[] = ['severity' => 'medium', 'code' => 'plugin_updates', 'message' => sprintf('%d plugin updates available.', $plugin_update_count)];
        }
        if ($theme_update_count > 0) {
            $findings[] = ['severity' => 'medium', 'code' => 'theme_updates', 'message' => sprintf('%d theme updates available.', $theme_update_count)];
        }
        if ((bool) get_option('users_can_register', false)) {
            $findings[] = ['severity' => 'low', 'code' => 'user_registration_open', 'message' => 'User registration is enabled.'];
        }

        $risk_score = 0;
        $risk_score += $core_update_available ? 40 : 0;
        $risk_score += min(30, $plugin_update_count * 5);
        $risk_score += min(20, $theme_update_count * 5);
        $risk_score += (bool) get_option('users_can_register', false) ? 10 : 0;
        if ($risk_score > 100) {
            $risk_score = 100;
        }

        $last_scan = get_option('quick_audit_last_scan', []);
        if (!is_array($last_scan)) {
            $last_scan = [];
        }
        $scan_max_pages = isset($last_scan['maxPages']) ? max(1, absint($last_scan['maxPages'])) : 40;
        $scan_max_depth = isset($last_scan['maxDepth']) ? max(0, min(8, absint($last_scan['maxDepth']))) : 3;
        $scan_mode = isset($last_scan['scanMode']) ? sanitize_key((string) $last_scan['scanMode']) : 'crawl';
        if (!in_array($scan_mode, ['crawl', 'content'], true)) {
            $scan_mode = 'crawl';
        }
        if (isset($scan_settings['maxPages'])) {
            $scan_max_pages = max(1, min(200, absint($scan_settings['maxPages'])));
        }
        if (isset($scan_settings['maxDepth'])) {
            $scan_max_depth = max(0, min(8, absint($scan_settings['maxDepth'])));
        }
        if (isset($scan_settings['scanMode'])) {
            $scan_mode_override = sanitize_key((string) $scan_settings['scanMode']);
            if (in_array($scan_mode_override, ['crawl', 'content'], true)) {
                $scan_mode = $scan_mode_override;
            }
        }
        $integrations = $this->quick_audit_get_integrations_settings();
        $pages = isset($last_scan['pages']) && is_array($last_scan['pages']) ? $last_scan['pages'] : [];
        $top_issues = isset($last_scan['topIssues']) && is_array($last_scan['topIssues']) ? $last_scan['topIssues'] : [];
        $scan_summary = isset($last_scan['scanSummary']) && is_array($last_scan['scanSummary']) ? $last_scan['scanSummary'] : [
            'pagesScanned' => 0,
            'issuesFound' => 0,
            'maxDepthReached' => 0,
            'averageWordCount' => 0,
        ];
        $crawl_site = isset($last_scan['site']) ? (string) $last_scan['site'] : home_url('/');
        $crawl_pages = isset($last_scan['crawlPages']) && is_array($last_scan['crawlPages']) ? $last_scan['crawlPages'] : [];
        $crawl_top_issues = isset($last_scan['crawlTopIssues']) && is_array($last_scan['crawlTopIssues']) ? $last_scan['crawlTopIssues'] : [];
        $crawl_summary = isset($last_scan['crawlSummary']) && is_array($last_scan['crawlSummary']) ? $last_scan['crawlSummary'] : [];

        return [
            'summary' => [
                'wordpressVersion' => get_bloginfo('version'),
                'phpVersion' => PHP_VERSION,
                'activePlugins' => count($active_plugins),
                'inactivePlugins' => $inactive_plugins,
                'totalUsers' => $users_count,
                'coreUpdateAvailable' => $core_update_available,
                'pluginUpdates' => $plugin_update_count,
                'themeUpdates' => $theme_update_count,
                'riskScore' => $risk_score,
                'scanPagesScanned' => isset($scan_summary['pagesScanned']) ? (int) $scan_summary['pagesScanned'] : 0,
                'scanIssuesFound' => isset($scan_summary['issuesFound']) ? (int) $scan_summary['issuesFound'] : 0,
                'scanMode' => $scan_mode,
                'lastScanAtUtc' => isset($last_scan['runAt']) ? (string) $last_scan['runAt'] : null,
            ],
            'findings' => $findings,
            'scanSettings' => [
                'maxPages' => $scan_max_pages,
                'maxDepth' => $scan_max_depth,
                'scanMode' => $scan_mode,
            ],
            'scanSummary' => $scan_summary,
            'topIssues' => $top_issues,
            'pages' => $pages,
            'crawl' => [
                'site' => $crawl_site,
                'summary' => $crawl_summary,
                'topIssues' => $crawl_top_issues,
                'pages' => $crawl_pages,
            ],
            'integrations' => $integrations,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function quick_audit_run_scan_payload(array $payload): array
    {
        $max_pages = isset($payload['maxPages']) ? max(1, min(200, absint($payload['maxPages']))) : 40;
        $max_depth = isset($payload['maxDepth']) ? max(0, min(8, absint($payload['maxDepth']))) : 3;
        $scan_mode = isset($payload['scanMode']) ? sanitize_key((string) $payload['scanMode']) : 'crawl';
        if (!in_array($scan_mode, ['crawl', 'content'], true)) {
            $scan_mode = 'crawl';
        }

        $scan = $scan_mode === 'content'
            ? $this->quick_audit_run_content_scan($max_pages, $max_depth)
            : $this->quick_audit_run_site_crawl_payload($max_pages, $max_depth);

        $integrations = $this->quick_audit_get_integrations_settings();
        if (!empty($integrations['quick_seo']) || !empty($integrations['quick_code']) || !empty($integrations['quick_traffic']) || !empty($integrations['quick_site'])) {
            do_action(
                'quickwoo_local/audit_completed',
                $scan,
                [
                    'source' => 'quick-audit',
                    'occurred_at' => current_time('mysql'),
                ]
            );
        }

        update_option('quick_audit_last_scan', [
            'maxPages' => $max_pages,
            'maxDepth' => $max_depth,
            'scanMode' => $scan_mode,
            'scanSummary' => isset($scan['scanSummary']) && is_array($scan['scanSummary']) ? $scan['scanSummary'] : [],
            'topIssues' => isset($scan['topIssues']) && is_array($scan['topIssues']) ? $scan['topIssues'] : [],
            'pages' => isset($scan['pages']) && is_array($scan['pages']) ? $scan['pages'] : [],
            'site' => isset($scan['site']) ? (string) $scan['site'] : home_url('/'),
            'crawlSummary' => isset($scan['crawlSummary']) && is_array($scan['crawlSummary']) ? $scan['crawlSummary'] : [],
            'crawlTopIssues' => isset($scan['crawlTopIssues']) && is_array($scan['crawlTopIssues']) ? $scan['crawlTopIssues'] : [],
            'crawlPages' => isset($scan['crawlPages']) && is_array($scan['crawlPages']) ? $scan['crawlPages'] : [],
            'runAt' => gmdate('c'),
        ], false);

        $workspace = $this->quick_audit_open_payload([
            'maxPages' => $max_pages,
            'maxDepth' => $max_depth,
        ]);
        return [
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'findings' => isset($workspace['findings']) && is_array($workspace['findings']) ? $workspace['findings'] : [],
            'scanSettings' => isset($workspace['scanSettings']) && is_array($workspace['scanSettings']) ? $workspace['scanSettings'] : [],
            'scanSummary' => isset($workspace['scanSummary']) && is_array($workspace['scanSummary']) ? $workspace['scanSummary'] : [],
            'topIssues' => isset($workspace['topIssues']) && is_array($workspace['topIssues']) ? $workspace['topIssues'] : [],
            'pages' => isset($workspace['pages']) && is_array($workspace['pages']) ? $workspace['pages'] : [],
            'crawl' => isset($workspace['crawl']) && is_array($workspace['crawl']) ? $workspace['crawl'] : [],
            'integrations' => isset($workspace['integrations']) && is_array($workspace['integrations']) ? $workspace['integrations'] : [],
            'runAt' => gmdate('c'),
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function quick_audit_save_integrations_payload(array $payload): array
    {
        $settings = [
            'quick_seo' => isset($payload['quickSeo']) ? $this->quick_points_bool_to_int($payload['quickSeo']) : 0,
            'quick_code' => isset($payload['quickCode']) ? $this->quick_points_bool_to_int($payload['quickCode']) : 0,
            'quick_traffic' => isset($payload['quickTraffic']) ? $this->quick_points_bool_to_int($payload['quickTraffic']) : 0,
            'quick_site' => isset($payload['quickSite']) ? $this->quick_points_bool_to_int($payload['quickSite']) : 0,
        ];
        update_option('qaud_integrations', $settings, false);
        $workspace = $this->quick_audit_open_payload();

        return [
            'saved' => true,
            'integrations' => $settings,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'findings' => isset($workspace['findings']) && is_array($workspace['findings']) ? $workspace['findings'] : [],
            'scanSettings' => isset($workspace['scanSettings']) && is_array($workspace['scanSettings']) ? $workspace['scanSettings'] : [],
            'scanSummary' => isset($workspace['scanSummary']) && is_array($workspace['scanSummary']) ? $workspace['scanSummary'] : [],
            'topIssues' => isset($workspace['topIssues']) && is_array($workspace['topIssues']) ? $workspace['topIssues'] : [],
            'pages' => isset($workspace['pages']) && is_array($workspace['pages']) ? $workspace['pages'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_audit_export_csv_payload(array $payload)
    {
        $entity = isset($payload['entity']) ? sanitize_key((string) $payload['entity']) : 'findings';
        if (!in_array($entity, ['findings', 'top-issues', 'pages', 'crawl-pages', 'crawl-issues', 'summary'], true)) {
            return new WP_Error('quick_audit_export_entity_invalid', 'entity must be one of findings, top-issues, pages, crawl-pages, crawl-issues, summary.', ['status' => 400]);
        }

        $workspace = $this->quick_audit_open_payload();
        $rows = [];
        if ($entity === 'findings') {
            $rows[] = ['severity', 'code', 'message'];
            $findings = isset($workspace['findings']) && is_array($workspace['findings']) ? $workspace['findings'] : [];
            foreach ($findings as $finding) {
                if (!is_array($finding)) {
                    continue;
                }
                $rows[] = [
                    (string) ($finding['severity'] ?? ''),
                    (string) ($finding['code'] ?? ''),
                    (string) ($finding['message'] ?? ''),
                ];
            }
        } elseif ($entity === 'top-issues') {
            $rows[] = ['code', 'count', 'severity', 'sample_message'];
            $issues = isset($workspace['topIssues']) && is_array($workspace['topIssues']) ? $workspace['topIssues'] : [];
            foreach ($issues as $issue) {
                if (!is_array($issue)) {
                    continue;
                }
                $rows[] = [
                    (string) ($issue['code'] ?? ''),
                    (string) ($issue['count'] ?? 0),
                    (string) ($issue['severity'] ?? ''),
                    (string) ($issue['sample'] ?? ''),
                ];
            }
        } elseif ($entity === 'pages') {
            $rows[] = ['post_id', 'url', 'status', 'depth', 'word_count', 'title_length', 'meta_description_length', 'issues'];
            $pages = isset($workspace['pages']) && is_array($workspace['pages']) ? $workspace['pages'] : [];
            foreach ($pages as $page) {
                if (!is_array($page)) {
                    continue;
                }
                $issues = isset($page['issues']) && is_array($page['issues']) ? implode('|', array_map('strval', $page['issues'])) : '';
                $rows[] = [
                    (string) ($page['postId'] ?? 0),
                    (string) ($page['url'] ?? ''),
                    (string) ($page['status'] ?? ''),
                    (string) ($page['depth'] ?? 0),
                    (string) ($page['wordCount'] ?? 0),
                    (string) ($page['titleLength'] ?? 0),
                    (string) ($page['metaDescriptionLength'] ?? 0),
                    $issues,
                ];
            }
        } elseif ($entity === 'crawl-pages') {
            $rows[] = ['url', 'status', 'depth', 'word_count', 'title', 'meta_description', 'canonical', 'robots', 'performance_ms', 'issues'];
            $crawl = isset($workspace['crawl']) && is_array($workspace['crawl']) ? $workspace['crawl'] : [];
            $crawl_pages = isset($crawl['pages']) && is_array($crawl['pages']) ? $crawl['pages'] : [];
            foreach ($crawl_pages as $page) {
                if (!is_array($page)) {
                    continue;
                }
                $issues = isset($page['issues']) && is_array($page['issues']) ? implode('|', array_map('strval', $page['issues'])) : '';
                $meta = isset($page['meta']) && is_array($page['meta']) ? $page['meta'] : [];
                $content = isset($page['content']) && is_array($page['content']) ? $page['content'] : [];
                $rows[] = [
                    (string) ($page['url'] ?? ''),
                    (string) ($page['status'] ?? ''),
                    (string) ($page['depth'] ?? 0),
                    (string) ($content['word_count'] ?? 0),
                    (string) ($meta['title'] ?? ''),
                    (string) ($meta['description'] ?? ''),
                    (string) ($meta['canonical'] ?? ''),
                    (string) ($meta['robots'] ?? ''),
                    (string) ($page['performance_ms'] ?? 0),
                    $issues,
                ];
            }
        } elseif ($entity === 'crawl-issues') {
            $rows[] = ['issue', 'count', 'severity'];
            $crawl = isset($workspace['crawl']) && is_array($workspace['crawl']) ? $workspace['crawl'] : [];
            $crawl_issues = isset($crawl['topIssues']) && is_array($crawl['topIssues']) ? $crawl['topIssues'] : [];
            foreach ($crawl_issues as $issue) {
                if (!is_array($issue)) {
                    continue;
                }
                $rows[] = [
                    (string) ($issue['issue'] ?? ''),
                    (string) ($issue['count'] ?? 0),
                    (string) $this->quick_audit_issue_severity((string) ($issue['issue'] ?? '')),
                ];
            }
        } else {
            $rows[] = ['metric', 'value'];
            $summary = isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [];
            foreach ($summary as $metric => $value) {
                $rows[] = [
                    (string) $metric,
                    is_scalar($value) ? (string) $value : wp_json_encode($value),
                ];
            }
            $crawl = isset($workspace['crawl']) && is_array($workspace['crawl']) ? $workspace['crawl'] : [];
            $crawl_summary = isset($crawl['summary']) && is_array($crawl['summary']) ? $crawl['summary'] : [];
            foreach ($crawl_summary as $metric => $value) {
                $rows[] = [
                    sprintf('crawl_%s', (string) $metric),
                    is_scalar($value) ? (string) $value : wp_json_encode($value),
                ];
            }
        }

        $csv = $this->quick_importer_rows_to_csv($rows);
        if ($csv instanceof WP_Error) {
            return $csv;
        }

        return [
            'entity' => $entity,
            'filename' => sprintf('quick-audit-%s-%s.csv', $entity, gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    /**
     * @return array<string, int>
     */
    private function quick_audit_get_integrations_settings(): array
    {
        $saved = get_option('qaud_integrations', []);
        if (!is_array($saved)) {
            $saved = [];
        }
        return [
            'quick_seo' => isset($saved['quick_seo']) ? $this->quick_points_bool_to_int($saved['quick_seo']) : 0,
            'quick_code' => isset($saved['quick_code']) ? $this->quick_points_bool_to_int($saved['quick_code']) : 0,
            'quick_traffic' => isset($saved['quick_traffic']) ? $this->quick_points_bool_to_int($saved['quick_traffic']) : 0,
            'quick_site' => isset($saved['quick_site']) ? $this->quick_points_bool_to_int($saved['quick_site']) : 0,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_audit_run_content_scan(int $max_pages, int $max_depth): array
    {
        $posts = get_posts([
            'post_type' => ['post', 'page', 'product'],
            'post_status' => ['publish'],
            'numberposts' => max(1, min(200, $max_pages)),
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);

        $pages = [];
        $issue_counts = [];
        $total_words = 0;
        $highest_depth = 0;

        foreach ($posts as $index => $post) {
            if (!$post instanceof WP_Post) {
                continue;
            }

            $depth = min($max_depth, $index % max(1, $max_depth + 1));
            if ($depth > $highest_depth) {
                $highest_depth = $depth;
            }

            $title = trim((string) $post->post_title);
            $title_length = function_exists('mb_strlen') ? mb_strlen($title) : strlen($title);
            $meta_description = trim((string) get_post_meta($post->ID, 'quick_seo_meta_description', true));
            if ($meta_description === '') {
                $meta_description = trim((string) get_post_meta($post->ID, '_yoast_wpseo_metadesc', true));
            }
            if ($meta_description === '') {
                $meta_description = trim((string) get_post_meta($post->ID, 'rank_math_description', true));
            }
            $meta_length = function_exists('mb_strlen') ? mb_strlen($meta_description) : strlen($meta_description);
            $plain = trim(wp_strip_all_tags((string) $post->post_content));
            $word_count = str_word_count($plain);
            $total_words += $word_count;

            $issues = [];
            if ($title === '') {
                $issues[] = 'missing_title';
            } elseif ($title_length < 30) {
                $issues[] = 'title_too_short';
            } elseif ($title_length > 60) {
                $issues[] = 'title_too_long';
            }
            if ($meta_description === '') {
                $issues[] = 'missing_meta_description';
            } elseif ($meta_length > 160) {
                $issues[] = 'meta_too_long';
            }
            if ($word_count < 300) {
                $issues[] = 'thin_content';
            }
            if (stripos((string) $post->post_content, '<h1') === false) {
                $issues[] = 'missing_h1';
            }
            if (stripos((string) $post->post_content, '<img') !== false) {
                $images = get_attached_media('image', $post->ID);
                foreach ($images as $image) {
                    if (!$image instanceof WP_Post) {
                        continue;
                    }
                    $alt = trim((string) get_post_meta($image->ID, '_wp_attachment_image_alt', true));
                    if ($alt === '') {
                        $issues[] = 'missing_image_alt';
                        break;
                    }
                }
            }

            foreach ($issues as $code) {
                if (!isset($issue_counts[$code])) {
                    $issue_counts[$code] = [
                        'count' => 0,
                        'severity' => in_array($code, ['missing_title', 'missing_meta_description', 'missing_h1'], true) ? 'high' : 'medium',
                        'sample' => sprintf('Issue %s found on post #%d.', $code, $post->ID),
                    ];
                }
                $issue_counts[$code]['count']++;
            }

            $pages[] = [
                'postId' => $post->ID,
                'url' => get_permalink($post),
                'status' => 200,
                'depth' => $depth,
                'title' => $title,
                'titleLength' => $title_length,
                'metaDescriptionLength' => $meta_length,
                'wordCount' => $word_count,
                'issues' => $issues,
            ];
        }

        uasort($issue_counts, static function (array $a, array $b): int {
            return (int) ($b['count'] ?? 0) <=> (int) ($a['count'] ?? 0);
        });

        $top_issues = [];
        foreach ($issue_counts as $code => $entry) {
            $top_issues[] = [
                'code' => (string) $code,
                'count' => isset($entry['count']) ? (int) $entry['count'] : 0,
                'severity' => isset($entry['severity']) ? (string) $entry['severity'] : 'low',
                'sample' => isset($entry['sample']) ? (string) $entry['sample'] : '',
            ];
        }

        $issues_found = 0;
        foreach ($top_issues as $issue) {
            $issues_found += (int) ($issue['count'] ?? 0);
        }

        $average_word_count = count($pages) > 0 ? (int) round($total_words / count($pages)) : 0;

        return [
            'scanSummary' => [
                'pagesScanned' => count($pages),
                'issuesFound' => $issues_found,
                'maxDepthReached' => $highest_depth,
                'averageWordCount' => $average_word_count,
            ],
            'topIssues' => array_slice($top_issues, 0, 15),
            'pages' => $pages,
            'crawlSummary' => [],
            'crawlTopIssues' => [],
            'crawlPages' => [],
            'site' => home_url('/'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_audit_run_site_crawl_payload(int $max_pages, int $max_depth): array
    {
        $site_url = home_url('/');
        $parts = wp_parse_url($site_url);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return $this->quick_audit_run_content_scan($max_pages, $max_depth);
        }

        $scheme = strtolower((string) $parts['scheme']);
        $host = $this->quick_audit_normalize_host((string) $parts['host']);
        $start = $this->quick_audit_normalize_internal_url($site_url, $scheme, $host);
        if ($start === '') {
            return $this->quick_audit_run_content_scan($max_pages, $max_depth);
        }

        $queue = [[$start, 0]];
        $visited = [];
        $pages = [];

        while (!empty($queue) && count($visited) < $max_pages) {
            $item = array_shift($queue);
            if (!is_array($item) || count($item) < 2) {
                continue;
            }

            $url = (string) $item[0];
            $depth = (int) $item[1];
            if ($depth > $max_depth || isset($visited[$url])) {
                continue;
            }

            $visited[$url] = true;
            $response = $this->quick_audit_http_get($url);

            if (isset($response['error'])) {
                $pages[] = [
                    'url' => $url,
                    'status' => null,
                    'depth' => $depth,
                    'issues' => ['Fetch failed: ' . (string) $response['error']],
                    'meta' => $this->quick_audit_empty_meta(),
                    'content' => $this->quick_audit_empty_content(),
                    'performance_ms' => 0,
                ];
                continue;
            }

            $status = (int) ($response['status'] ?? 0);
            $body = (string) ($response['body'] ?? '');
            $duration = (float) ($response['duration_ms'] ?? 0);

            $page = $this->quick_audit_analyze_page($url, $status, $body, $depth, $duration);
            $pages[] = $page;

            if ($status !== 200 || trim($body) === '') {
                continue;
            }

            $links = $this->quick_audit_extract_internal_links($body, $url, $scheme, $host);
            foreach ($links as $link) {
                if (!isset($visited[$link])) {
                    $queue[] = [$link, $depth + 1];
                }
            }
        }

        $crawl_summary = $this->quick_audit_build_crawl_summary($pages);
        $crawl_top_issues = $this->quick_audit_rollup_crawl_issues($pages);
        $scan_summary = [
            'pagesScanned' => isset($crawl_summary['pages_crawled']) ? (int) $crawl_summary['pages_crawled'] : 0,
            'issuesFound' => isset($crawl_summary['pages_with_issues']) ? (int) $crawl_summary['pages_with_issues'] : 0,
            'maxDepthReached' => isset($crawl_summary['max_depth']) ? (int) $crawl_summary['max_depth'] : 0,
            'averageWordCount' => isset($crawl_summary['avg_word_count']) ? (int) $crawl_summary['avg_word_count'] : 0,
        ];

        $top_issues = [];
        foreach ($crawl_top_issues as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $issue_text = (string) ($entry['issue'] ?? '');
            $top_issues[] = [
                'code' => sanitize_key(str_replace([' ', '-', ':'], '_', strtolower($issue_text))),
                'count' => isset($entry['count']) ? (int) $entry['count'] : 0,
                'severity' => $this->quick_audit_issue_severity($issue_text),
                'sample' => $issue_text,
            ];
        }

        $page_rows = [];
        foreach ($pages as $page) {
            if (!is_array($page)) {
                continue;
            }
            $meta = isset($page['meta']) && is_array($page['meta']) ? $page['meta'] : [];
            $content = isset($page['content']) && is_array($page['content']) ? $page['content'] : [];
            $title = (string) ($meta['title'] ?? '');
            $meta_description = (string) ($meta['description'] ?? '');
            $page_rows[] = [
                'postId' => 0,
                'url' => (string) ($page['url'] ?? ''),
                'status' => isset($page['status']) ? $page['status'] : 0,
                'depth' => isset($page['depth']) ? (int) $page['depth'] : 0,
                'title' => $title,
                'titleLength' => function_exists('mb_strlen') ? mb_strlen($title) : strlen($title),
                'metaDescriptionLength' => function_exists('mb_strlen') ? mb_strlen($meta_description) : strlen($meta_description),
                'wordCount' => isset($content['word_count']) ? (int) $content['word_count'] : 0,
                'issues' => isset($page['issues']) && is_array($page['issues']) ? $page['issues'] : [],
                'performanceMs' => isset($page['performance_ms']) ? (float) $page['performance_ms'] : 0,
            ];
        }

        return [
            'scanSummary' => $scan_summary,
            'topIssues' => array_slice($top_issues, 0, 15),
            'pages' => $page_rows,
            'crawlSummary' => $crawl_summary,
            'crawlTopIssues' => array_slice($crawl_top_issues, 0, 20),
            'crawlPages' => $pages,
            'site' => $start,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_audit_http_get(string $url): array
    {
        $started = microtime(true);
        $response = wp_remote_get($url, [
            'timeout' => 10,
            'redirection' => 3,
            'user-agent' => self::QUICK_AUDIT_USER_AGENT,
            'headers' => ['Accept' => 'text/html,application/xhtml+xml'],
        ]);
        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }
        return [
            'status' => (int) wp_remote_retrieve_response_code($response),
            'body' => (string) wp_remote_retrieve_body($response),
            'duration_ms' => round((microtime(true) - $started) * 1000, 1),
        ];
    }

    /**
     * @return array<int, string>
     */
    private function quick_audit_extract_internal_links(string $html, string $base_url, string $scheme, string $host): array
    {
        if (!class_exists('DOMDocument')) {
            return [];
        }

        $doc = new DOMDocument();
        libxml_use_internal_errors(true);
        $loaded = $doc->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();
        if (!$loaded) {
            return [];
        }

        $xpath = new DOMXPath($doc);
        $nodes = $xpath->query('//a[@href]');
        if (!$nodes instanceof DOMNodeList) {
            return [];
        }

        $links = [];
        $count = 0;
        foreach ($nodes as $node) {
            if (!$node instanceof DOMElement) {
                continue;
            }
            if ($count >= self::QUICK_AUDIT_MAX_LINKS_PER_PAGE) {
                break;
            }
            $href = trim((string) $node->getAttribute('href'));
            if ($href === '' || strpos($href, '#') === 0) {
                continue;
            }
            $lower = strtolower($href);
            if (strpos($lower, 'mailto:') === 0 || strpos($lower, 'tel:') === 0 || strpos($lower, 'javascript:') === 0 || strpos($lower, 'data:') === 0) {
                continue;
            }

            $absolute = $this->quick_audit_resolve_url($base_url, $href);
            if ($absolute === null || !$this->quick_audit_is_same_site($absolute, $host)) {
                continue;
            }
            $normalized = $this->quick_audit_normalize_internal_url($absolute, $scheme, $host);
            if ($normalized === '') {
                continue;
            }
            $links[$normalized] = true;
            $count++;
        }

        return array_values(array_keys($links));
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_audit_analyze_page(string $url, int $status, string $html, int $depth, float $duration): array
    {
        $page = [
            'url' => $url,
            'status' => $status,
            'depth' => $depth,
            'issues' => [],
            'meta' => $this->quick_audit_empty_meta(),
            'content' => $this->quick_audit_empty_content(),
            'performance_ms' => $duration,
        ];
        if ($status !== 200) {
            $page['issues'][] = 'Non-200 status: ' . $status;
            return $page;
        }
        if (trim($html) === '') {
            $page['issues'][] = 'Empty response body';
            return $page;
        }
        if (!class_exists('DOMDocument')) {
            $page['issues'][] = 'DOM extension unavailable';
            return $page;
        }
        if ($duration > 3000) {
            $page['issues'][] = 'Very slow response (>3s)';
        } elseif ($duration > 1500) {
            $page['issues'][] = 'Slow response (>1.5s)';
        }

        $doc = new DOMDocument();
        libxml_use_internal_errors(true);
        $loaded = $doc->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR | LIBXML_NOWARNING);
        libxml_clear_errors();
        if (!$loaded) {
            $page['issues'][] = 'HTML parse failure';
            return $page;
        }

        $xpath = new DOMXPath($doc);
        $title_nodes = $xpath->query('//title');
        $title = $title_nodes instanceof DOMNodeList && $title_nodes->length > 0 ? trim((string) $title_nodes->item(0)->textContent) : '';
        $page['meta']['title'] = $title;
        $title_length = function_exists('mb_strlen') ? mb_strlen($title) : strlen($title);
        if ($title === '') {
            $page['issues'][] = 'Missing title';
        } elseif ($title_length < 30 || $title_length > 60) {
            $page['issues'][] = 'Title length outside 30-60 chars';
        }

        $description_nodes = $xpath->query('//meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="description"]');
        $description = $description_nodes instanceof DOMNodeList && $description_nodes->length > 0 && $description_nodes->item(0) instanceof DOMElement
            ? trim((string) $description_nodes->item(0)->getAttribute('content'))
            : '';
        $page['meta']['description'] = $description;
        if ($description === '') {
            $page['issues'][] = 'Missing meta description';
        }

        $canonical_nodes = $xpath->query('//link[contains(translate(@rel,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"canonical")]');
        $canonical = $canonical_nodes instanceof DOMNodeList && $canonical_nodes->length > 0 && $canonical_nodes->item(0) instanceof DOMElement
            ? trim((string) $canonical_nodes->item(0)->getAttribute('href'))
            : '';
        $page['meta']['canonical'] = $canonical;
        if ($canonical === '') {
            $page['issues'][] = 'Missing canonical';
        }

        $robots_nodes = $xpath->query('//meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="robots"]');
        $robots = $robots_nodes instanceof DOMNodeList && $robots_nodes->length > 0 && $robots_nodes->item(0) instanceof DOMElement
            ? trim((string) $robots_nodes->item(0)->getAttribute('content'))
            : '';
        $page['meta']['robots'] = $robots;
        if ($robots !== '' && strpos(strtolower($robots), 'noindex') !== false) {
            $page['issues'][] = 'Page marked noindex';
        }

        $h1_nodes = $xpath->query('//h1');
        $h1_count = $h1_nodes instanceof DOMNodeList ? $h1_nodes->length : 0;
        if ($h1_count === 0) {
            $page['issues'][] = 'Missing H1';
        } elseif ($h1_count > 1) {
            $page['issues'][] = 'Multiple H1s';
        }

        $body_nodes = $xpath->query('//body');
        $text_root = $body_nodes instanceof DOMNodeList && $body_nodes->length > 0 ? $body_nodes->item(0) : $doc->documentElement;
        $text = $text_root instanceof DOMNode ? trim((string) preg_replace('/\s+/u', ' ', (string) $text_root->textContent)) : '';
        $word_count = $text !== '' ? str_word_count(wp_strip_all_tags($text)) : 0;
        $page['content']['word_count'] = $word_count;
        if ($word_count > 0 && $word_count < 250) {
            $page['issues'][] = 'Thin content (word count < 250)';
        }

        return $page;
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     * @return array<string, int>
     */
    private function quick_audit_build_crawl_summary(array $pages): array
    {
        $with_issues = 0;
        $non_200 = 0;
        $total_words = 0;
        $ok_pages = 0;
        $max_depth = 0;

        foreach ($pages as $page) {
            if (!empty($page['issues'])) {
                $with_issues++;
            }
            $status = isset($page['status']) ? (int) $page['status'] : 0;
            if ($status !== 200) {
                $non_200++;
            } else {
                $ok_pages++;
                $content = isset($page['content']) && is_array($page['content']) ? $page['content'] : [];
                $total_words += isset($content['word_count']) ? (int) $content['word_count'] : 0;
            }
            $max_depth = max($max_depth, isset($page['depth']) ? (int) $page['depth'] : 0);
        }

        return [
            'pages_crawled' => count($pages),
            'pages_with_issues' => $with_issues,
            'non_200_pages' => $non_200,
            'avg_word_count' => $ok_pages > 0 ? (int) round($total_words / $ok_pages) : 0,
            'max_depth' => $max_depth,
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     * @return array<int, array<string, mixed>>
     */
    private function quick_audit_rollup_crawl_issues(array $pages): array
    {
        $counts = [];
        foreach ($pages as $page) {
            $issues = isset($page['issues']) && is_array($page['issues']) ? $page['issues'] : [];
            foreach ($issues as $issue) {
                $issue_key = (string) $issue;
                if (!isset($counts[$issue_key])) {
                    $counts[$issue_key] = 0;
                }
                $counts[$issue_key]++;
            }
        }
        arsort($counts);

        $rows = [];
        foreach ($counts as $issue => $count) {
            $rows[] = [
                'issue' => (string) $issue,
                'count' => (int) $count,
            ];
        }
        return $rows;
    }

    private function quick_audit_issue_severity(string $issue): string
    {
        $text = strtolower(trim($issue));
        if (strpos($text, 'missing') !== false || strpos($text, 'broken') !== false || strpos($text, '4xx') !== false || strpos($text, '5xx') !== false || strpos($text, 'non-200') !== false) {
            return 'high';
        }
        if (strpos($text, 'slow') !== false || strpos($text, 'duplicate') !== false || strpos($text, 'long') !== false || strpos($text, 'short') !== false) {
            return 'medium';
        }
        return 'low';
    }

    private function quick_audit_normalize_host(string $host): string
    {
        $host = strtolower(trim($host));
        if (strpos($host, 'www.') === 0) {
            return substr($host, 4);
        }
        return $host;
    }

    private function quick_audit_is_same_site(string $url, string $base_host): bool
    {
        $parts = wp_parse_url($url);
        if (!is_array($parts) || empty($parts['host'])) {
            return false;
        }
        return $this->quick_audit_normalize_host((string) $parts['host']) === $base_host;
    }

    private function quick_audit_normalize_internal_url(string $url, string $scheme, string $host): string
    {
        $parts = wp_parse_url($url);
        if (!is_array($parts)) {
            return '';
        }
        $path = isset($parts['path']) ? (string) $parts['path'] : '/';
        $path = $path === '' ? '/' : rtrim($path, '/');
        if ($path === '') {
            $path = '/';
        }
        return sprintf('%s://%s%s', $scheme, $host, $path);
    }

    private function quick_audit_resolve_url(string $base_url, string $href): ?string
    {
        if (preg_match('#^https?://#i', $href) === 1) {
            return $href;
        }
        if (strpos($href, '//') === 0) {
            $parts = wp_parse_url($base_url);
            if (!is_array($parts) || empty($parts['scheme'])) {
                return null;
            }
            return (string) $parts['scheme'] . ':' . $href;
        }
        $base_parts = wp_parse_url($base_url);
        if (!is_array($base_parts) || empty($base_parts['scheme']) || empty($base_parts['host'])) {
            return null;
        }
        $scheme = (string) $base_parts['scheme'];
        $host = (string) $base_parts['host'];
        if (strpos($href, '/') === 0) {
            return sprintf('%s://%s%s', $scheme, $host, $href);
        }
        $path = isset($base_parts['path']) ? (string) $base_parts['path'] : '/';
        $dir = preg_replace('#/[^/]*$#', '/', $path);
        if (!is_string($dir) || $dir === '') {
            $dir = '/';
        }
        return sprintf('%s://%s%s%s', $scheme, $host, $dir, $href);
    }

    /**
     * @return array<string, string>
     */
    private function quick_audit_empty_meta(): array
    {
        return [
            'title' => '',
            'description' => '',
            'canonical' => '',
            'robots' => '',
        ];
    }

    /**
     * @return array<string, int>
     */
    private function quick_audit_empty_content(): array
    {
        return [
            'word_count' => 0,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_course_builder_open_payload(): array
    {
        $course_post_type = $this->quick_course_builder_detect_course_post_type();
        $module_post_type = $this->quick_course_builder_detect_module_post_type();
        $test_post_type = $this->quick_course_builder_detect_test_post_type();
        $fallback = $course_post_type === 'page';

        $course_query = [
            'post_type' => [$course_post_type],
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'numberposts' => 25,
            'orderby' => 'modified',
            'order' => 'DESC',
        ];
        if ($course_post_type === 'page') {
            $course_query['meta_key'] = '_quick_course_builder_course';
            $course_query['meta_value'] = '1';
        }
        $courses = get_posts($course_query);

        $items = [];
        $published = 0;
        $draft = 0;
        foreach ($courses as $course) {
            if (!$course instanceof WP_Post) {
                continue;
            }

            if ($course->post_status === 'publish') {
                $published++;
            }
            if ($course->post_status === 'draft') {
                $draft++;
            }

            $items[] = [
                'id' => $course->ID,
                'title' => (string) $course->post_title,
                'status' => (string) $course->post_status,
                'postType' => (string) $course->post_type,
                'modified' => get_post_modified_time('c', true, $course),
                'moduleCount' => $this->quick_course_builder_get_module_count($course->ID, $module_post_type),
            ];
        }

        $modules = [];
        if ($module_post_type !== '') {
            $module_posts = get_posts([
                'post_type' => [$module_post_type],
                'post_status' => ['publish', 'draft', 'private', 'pending'],
                'numberposts' => 80,
                'orderby' => 'modified',
                'order' => 'DESC',
            ]);
            foreach ($module_posts as $module) {
                if (!$module instanceof WP_Post) {
                    continue;
                }
                $modules[] = [
                    'id' => $module->ID,
                    'courseId' => (int) $module->post_parent,
                    'title' => (string) $module->post_title,
                    'status' => (string) $module->post_status,
                    'postType' => (string) $module->post_type,
                    'modified' => get_post_modified_time('c', true, $module),
                ];
            }
        }

        $tests = [];
        if ($test_post_type !== '') {
            $test_posts = get_posts([
                'post_type' => [$test_post_type],
                'post_status' => ['publish', 'draft', 'private', 'pending'],
                'numberposts' => 80,
                'orderby' => 'modified',
                'order' => 'DESC',
            ]);
            foreach ($test_posts as $test) {
                if (!$test instanceof WP_Post) {
                    continue;
                }
                $questions = get_post_meta($test->ID, '_qcb_test_questions', true);
                $question_count = is_array($questions) ? count($questions) : 0;
                $tests[] = [
                    'id' => $test->ID,
                    'title' => (string) $test->post_title,
                    'status' => (string) $test->post_status,
                    'postType' => (string) $test->post_type,
                    'questionCount' => $question_count,
                    'modified' => get_post_modified_time('c', true, $test),
                ];
            }
        }

        return [
            'summary' => [
                'totalCourses' => count($items),
                'publishedCourses' => $published,
                'draftCourses' => $draft,
                'totalModules' => count($modules),
                'totalTests' => count($tests),
                'fallbackMode' => $fallback,
            ],
            'courses' => $items,
            'modules' => $modules,
            'tests' => $tests,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_course_builder_create_course_payload(array $payload)
    {
        $title = isset($payload['title']) ? sanitize_text_field((string) $payload['title']) : '';
        $description = isset($payload['description']) ? wp_kses_post((string) $payload['description']) : '';

        if ($title === '') {
            return new WP_Error('quick_course_builder_title_required', 'Course title is required.', ['status' => 400]);
        }

        $course_post_type = $this->quick_course_builder_detect_course_post_type();
        $result = wp_insert_post([
            'post_type' => $course_post_type,
            'post_status' => 'draft',
            'post_title' => $title,
            'post_content' => $description,
        ], true);

        if (is_wp_error($result)) {
            return new WP_Error(
                'quick_course_builder_create_failed',
                'Could not create course.',
                ['status' => 500, 'details' => $result->get_error_message()]
            );
        }

        $course_id = (int) $result;
        if ($course_post_type === 'page') {
            update_post_meta($course_id, '_quick_course_builder_course', '1');
        }
        $workspace = $this->quick_course_builder_open_payload();

        return [
            'courseId' => $course_id,
            'postType' => $course_post_type,
            'status' => 'draft',
            'link' => get_edit_post_link($course_id, ''),
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'courses' => isset($workspace['courses']) && is_array($workspace['courses']) ? $workspace['courses'] : [],
            'modules' => isset($workspace['modules']) && is_array($workspace['modules']) ? $workspace['modules'] : [],
            'tests' => isset($workspace['tests']) && is_array($workspace['tests']) ? $workspace['tests'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_course_builder_create_module_payload(array $payload)
    {
        $module_post_type = $this->quick_course_builder_detect_module_post_type();
        if ($module_post_type === '') {
            return new WP_Error('quick_course_builder_module_post_type_missing', 'Module post type is not registered.', ['status' => 400]);
        }

        $title = isset($payload['title']) ? sanitize_text_field((string) $payload['title']) : '';
        $content = isset($payload['content']) ? wp_kses_post((string) $payload['content']) : '';
        $course_id = isset($payload['courseId']) ? absint($payload['courseId']) : 0;
        if ($title === '') {
            return new WP_Error('quick_course_builder_module_title_required', 'Module title is required.', ['status' => 400]);
        }
        if ($course_id <= 0) {
            return new WP_Error('quick_course_builder_course_required', 'Valid courseId is required.', ['status' => 400]);
        }

        $course = get_post($course_id);
        if (!$course instanceof WP_Post) {
            return new WP_Error('quick_course_builder_course_not_found', 'Course not found.', ['status' => 404]);
        }

        $result = wp_insert_post([
            'post_type' => $module_post_type,
            'post_status' => 'draft',
            'post_title' => $title,
            'post_content' => $content,
            'post_parent' => $course_id,
        ], true);
        if (is_wp_error($result)) {
            return new WP_Error('quick_course_builder_module_create_failed', 'Could not create module.', ['status' => 500, 'details' => $result->get_error_message()]);
        }

        $module_id = (int) $result;
        $workspace = $this->quick_course_builder_open_payload();
        return [
            'moduleId' => $module_id,
            'courseId' => $course_id,
            'postType' => $module_post_type,
            'status' => 'draft',
            'link' => get_edit_post_link($module_id, ''),
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'courses' => isset($workspace['courses']) && is_array($workspace['courses']) ? $workspace['courses'] : [],
            'modules' => isset($workspace['modules']) && is_array($workspace['modules']) ? $workspace['modules'] : [],
            'tests' => isset($workspace['tests']) && is_array($workspace['tests']) ? $workspace['tests'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_course_builder_create_test_payload(array $payload)
    {
        $test_post_type = $this->quick_course_builder_detect_test_post_type();
        if ($test_post_type === '') {
            return new WP_Error('quick_course_builder_test_post_type_missing', 'Test post type is not registered.', ['status' => 400]);
        }

        $title = isset($payload['title']) ? sanitize_text_field((string) $payload['title']) : '';
        if ($title === '') {
            return new WP_Error('quick_course_builder_test_title_required', 'Test title is required.', ['status' => 400]);
        }

        $questions_raw = isset($payload['questions']) && is_array($payload['questions']) ? $payload['questions'] : [];
        $questions = [];
        foreach ($questions_raw as $index => $question) {
            if (!is_array($question)) {
                continue;
            }
            $text = isset($question['question']) ? sanitize_text_field((string) $question['question']) : '';
            $answers_raw = isset($question['answers']) && is_array($question['answers']) ? $question['answers'] : [];
            $answers = [];
            foreach ($answers_raw as $answer) {
                $clean = sanitize_text_field((string) $answer);
                if ($clean !== '') {
                    $answers[] = $clean;
                }
            }
            if ($text === '' || count($answers) < 2) {
                continue;
            }
            $correct_index = isset($question['correctIndex']) ? absint($question['correctIndex']) : 0;
            if ($correct_index >= count($answers)) {
                $correct_index = 0;
            }
            $questions[] = [
                'id' => sanitize_key('q_' . $index . '_' . substr(md5($text), 0, 8)),
                'question' => $text,
                'answers' => array_values($answers),
                'correct_index' => $correct_index,
            ];
        }

        $result = wp_insert_post([
            'post_type' => $test_post_type,
            'post_status' => 'draft',
            'post_title' => $title,
        ], true);
        if (is_wp_error($result)) {
            return new WP_Error('quick_course_builder_test_create_failed', 'Could not create test.', ['status' => 500, 'details' => $result->get_error_message()]);
        }

        $test_id = (int) $result;
        update_post_meta($test_id, '_qcb_test_schema_version', 1);
        update_post_meta($test_id, '_qcb_test_questions', $questions);
        $workspace = $this->quick_course_builder_open_payload();
        return [
            'testId' => $test_id,
            'postType' => $test_post_type,
            'questionCount' => count($questions),
            'status' => 'draft',
            'link' => get_edit_post_link($test_id, ''),
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'courses' => isset($workspace['courses']) && is_array($workspace['courses']) ? $workspace['courses'] : [],
            'modules' => isset($workspace['modules']) && is_array($workspace['modules']) ? $workspace['modules'] : [],
            'tests' => isset($workspace['tests']) && is_array($workspace['tests']) ? $workspace['tests'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_course_builder_set_course_status_payload(array $payload)
    {
        $course_id = isset($payload['courseId']) ? absint($payload['courseId']) : 0;
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        if ($course_id <= 0) {
            return new WP_Error('quick_course_builder_course_required', 'Valid courseId is required.', ['status' => 400]);
        }
        if (!in_array($status, ['draft', 'publish', 'private', 'pending'], true)) {
            return new WP_Error('quick_course_builder_status_invalid', 'Status must be one of draft, publish, private, pending.', ['status' => 400]);
        }
        $course = get_post($course_id);
        if (!$course instanceof WP_Post) {
            return new WP_Error('quick_course_builder_course_not_found', 'Course not found.', ['status' => 404]);
        }

        $updated = wp_update_post([
            'ID' => $course_id,
            'post_status' => $status,
        ], true);
        if (is_wp_error($updated)) {
            return new WP_Error('quick_course_builder_status_update_failed', 'Could not update course status.', ['status' => 500, 'details' => $updated->get_error_message()]);
        }

        $workspace = $this->quick_course_builder_open_payload();
        return [
            'courseId' => $course_id,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'courses' => isset($workspace['courses']) && is_array($workspace['courses']) ? $workspace['courses'] : [],
            'modules' => isset($workspace['modules']) && is_array($workspace['modules']) ? $workspace['modules'] : [],
            'tests' => isset($workspace['tests']) && is_array($workspace['tests']) ? $workspace['tests'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_course_builder_delete_course_payload(array $payload)
    {
        $course_id = isset($payload['courseId']) ? absint($payload['courseId']) : 0;
        if ($course_id <= 0) {
            return new WP_Error('quick_course_builder_course_required', 'Valid courseId is required.', ['status' => 400]);
        }
        $course = get_post($course_id);
        if (!$course instanceof WP_Post) {
            return new WP_Error('quick_course_builder_course_not_found', 'Course not found.', ['status' => 404]);
        }

        $deleted = wp_delete_post($course_id, true);
        if (!$deleted) {
            return new WP_Error('quick_course_builder_delete_failed', 'Could not delete course.', ['status' => 500]);
        }

        $workspace = $this->quick_course_builder_open_payload();
        return [
            'courseId' => $course_id,
            'deleted' => true,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'courses' => isset($workspace['courses']) && is_array($workspace['courses']) ? $workspace['courses'] : [],
            'modules' => isset($workspace['modules']) && is_array($workspace['modules']) ? $workspace['modules'] : [],
            'tests' => isset($workspace['tests']) && is_array($workspace['tests']) ? $workspace['tests'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_course_builder_export_csv_payload(array $payload)
    {
        $entity = isset($payload['entity']) ? sanitize_key((string) $payload['entity']) : 'courses';
        if (!in_array($entity, ['courses', 'modules', 'tests'], true)) {
            return new WP_Error('quick_course_builder_export_entity_invalid', 'entity must be one of courses, modules, tests.', ['status' => 400]);
        }

        $workspace = $this->quick_course_builder_open_payload();
        $rows = [];
        if ($entity === 'courses') {
            $rows[] = ['id', 'title', 'status', 'post_type', 'module_count', 'modified'];
            $courses = isset($workspace['courses']) && is_array($workspace['courses']) ? $workspace['courses'] : [];
            foreach ($courses as $course) {
                if (!is_array($course)) {
                    continue;
                }
                $rows[] = [
                    (string) ($course['id'] ?? 0),
                    (string) ($course['title'] ?? ''),
                    (string) ($course['status'] ?? ''),
                    (string) ($course['postType'] ?? ''),
                    (string) ($course['moduleCount'] ?? 0),
                    (string) ($course['modified'] ?? ''),
                ];
            }
        } elseif ($entity === 'modules') {
            $rows[] = ['id', 'course_id', 'title', 'status', 'post_type', 'modified'];
            $modules = isset($workspace['modules']) && is_array($workspace['modules']) ? $workspace['modules'] : [];
            foreach ($modules as $module) {
                if (!is_array($module)) {
                    continue;
                }
                $rows[] = [
                    (string) ($module['id'] ?? 0),
                    (string) ($module['courseId'] ?? 0),
                    (string) ($module['title'] ?? ''),
                    (string) ($module['status'] ?? ''),
                    (string) ($module['postType'] ?? ''),
                    (string) ($module['modified'] ?? ''),
                ];
            }
        } else {
            $rows[] = ['id', 'title', 'status', 'post_type', 'question_count', 'modified'];
            $tests = isset($workspace['tests']) && is_array($workspace['tests']) ? $workspace['tests'] : [];
            foreach ($tests as $test) {
                if (!is_array($test)) {
                    continue;
                }
                $rows[] = [
                    (string) ($test['id'] ?? 0),
                    (string) ($test['title'] ?? ''),
                    (string) ($test['status'] ?? ''),
                    (string) ($test['postType'] ?? ''),
                    (string) ($test['questionCount'] ?? 0),
                    (string) ($test['modified'] ?? ''),
                ];
            }
        }

        $csv = $this->quick_importer_rows_to_csv($rows);
        if ($csv instanceof WP_Error) {
            return $csv;
        }

        return [
            'entity' => $entity,
            'filename' => sprintf('quick-course-builder-%s-%s.csv', $entity, gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    private function quick_course_builder_detect_course_post_type(): string
    {
        if (post_type_exists('qc_course')) {
            return 'qc_course';
        }
        if (post_type_exists('course')) {
            return 'course';
        }
        if (post_type_exists('sfwd-courses')) {
            return 'sfwd-courses';
        }
        return 'page';
    }

    private function quick_course_builder_detect_module_post_type(): string
    {
        if (post_type_exists('qc_module')) {
            return 'qc_module';
        }
        if (post_type_exists('module')) {
            return 'module';
        }
        return '';
    }

    private function quick_course_builder_detect_test_post_type(): string
    {
        if (post_type_exists('qc_test')) {
            return 'qc_test';
        }
        if (post_type_exists('test')) {
            return 'test';
        }
        return '';
    }

    private function quick_course_builder_get_module_count(int $course_id, string $module_post_type): int
    {
        if ($module_post_type === '' || $course_id <= 0) {
            return 0;
        }
        $module_ids = get_posts([
            'post_type' => [$module_post_type],
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'numberposts' => -1,
            'post_parent' => $course_id,
            'fields' => 'ids',
        ]);
        return is_array($module_ids) ? count($module_ids) : 0;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_code_open_payload(): array
    {
        $snippets = get_posts([
            'post_type' => ['quick-code-snippet'],
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'numberposts' => 20,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);

        $fallback = false;
        if (!is_array($snippets) || count($snippets) === 0) {
            $fallback = true;
            $snippets = get_posts([
                'post_type' => ['page'],
                'post_status' => ['publish', 'draft', 'private', 'pending'],
                'numberposts' => 20,
                'orderby' => 'modified',
                'order' => 'DESC',
                'meta_key' => '_quick_code_snippet',
                'meta_value' => '1',
            ]);
        }

        $items = [];
        $active = 0;
        foreach ($snippets as $snippet) {
            if (!$snippet instanceof WP_Post) {
                continue;
            }

            $enabled = (string) get_post_meta($snippet->ID, '_quick_code_enabled', true) === '1';
            if ($enabled) {
                $active++;
            }

            $language = (string) get_post_meta($snippet->ID, '_quick_code_language', true);
            if ($language === '') {
                $language = 'php';
            }

            $conditions = $this->quick_code_snippet_conditions($snippet->ID);
            $items[] = [
                'id' => $snippet->ID,
                'title' => (string) $snippet->post_title,
                'status' => (string) $snippet->post_status,
                'enabled' => $enabled,
                'postType' => (string) $snippet->post_type,
                'language' => $language,
                'code' => (string) $snippet->post_content,
                'conditions' => $conditions,
                'conditionsJson' => wp_json_encode($conditions),
                'modified' => get_post_modified_time('c', true, $snippet),
            ];
        }

        return [
            'summary' => [
                'totalSnippets' => count($items),
                'activeSnippets' => $active,
                'inactiveSnippets' => max(0, count($items) - $active),
                'fallbackMode' => $fallback,
            ],
            'settings' => $this->quick_code_get_settings(),
            'snippets' => $items,
            'history' => $this->quick_code_get_history_rows(30),
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    private function quick_code_bool_to_int($value): int
    {
        if (is_bool($value)) {
            return $value ? 1 : 0;
        }
        if (is_numeric($value)) {
            return ((int) $value) > 0 ? 1 : 0;
        }
        $normalized = strtolower(trim((string) $value));
        return in_array($normalized, ['1', 'true', 'yes', 'on'], true) ? 1 : 0;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_code_default_settings(): array
    {
        return [
            'enable_global' => 1,
            'enable_per_page' => 1,
            'default_css_location' => 'head',
            'default_js_location' => 'body_close',
            'body_open_fallback' => 0,
            'disable_all' => 0,
            'exclude_admins' => 0,
            'respect_dnt' => 0,
            'disable_on_preview' => 1,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_code_get_settings(): array
    {
        $saved = get_option('qcod_settings', []);
        if (!is_array($saved)) {
            $saved = [];
        }

        $raw = wp_parse_args($saved, $this->quick_code_default_settings());
        $allowed_locations = ['head', 'body_open', 'body_close'];

        $css_location = sanitize_key((string) $raw['default_css_location']);
        if (!in_array($css_location, $allowed_locations, true)) {
            $css_location = 'head';
        }
        $js_location = sanitize_key((string) $raw['default_js_location']);
        if (!in_array($js_location, $allowed_locations, true)) {
            $js_location = 'body_close';
        }

        return [
            'enable_global' => $this->quick_code_bool_to_int($raw['enable_global']),
            'enable_per_page' => $this->quick_code_bool_to_int($raw['enable_per_page']),
            'default_css_location' => $css_location,
            'default_js_location' => $js_location,
            'body_open_fallback' => $this->quick_code_bool_to_int($raw['body_open_fallback']),
            'disable_all' => $this->quick_code_bool_to_int($raw['disable_all']),
            'exclude_admins' => $this->quick_code_bool_to_int($raw['exclude_admins']),
            'respect_dnt' => $this->quick_code_bool_to_int($raw['respect_dnt']),
            'disable_on_preview' => $this->quick_code_bool_to_int($raw['disable_on_preview']),
        ];
    }

    /**
     * @param mixed $raw
     * @return array<string, mixed>
     */
    private function quick_code_normalize_conditions($raw): array
    {
        $defaults = [
            'include_post_types' => [],
            'exclude_post_types' => [],
            'include_ids' => [],
            'exclude_ids' => [],
            'path_exact' => [],
            'path_contains' => [],
            'logged_in_only' => 0,
            'logged_out_only' => 0,
            'roles' => [],
            'devices' => [],
            'schedule_start' => '',
            'schedule_end' => '',
            'preview_admin_only' => 0,
            'marketing_script' => 0,
            'test_mode' => 0,
        ];

        $data = [];
        if (is_string($raw)) {
            $raw = trim($raw);
            if ($raw !== '') {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    $data = $decoded;
                }
            }
        } elseif (is_array($raw)) {
            $data = $raw;
        }

        $data = wp_parse_args($data, $defaults);
        foreach (['include_post_types', 'exclude_post_types', 'include_ids', 'exclude_ids', 'path_exact', 'path_contains', 'roles', 'devices'] as $array_field) {
            if (!isset($data[$array_field]) || !is_array($data[$array_field])) {
                $data[$array_field] = [];
            }
        }

        $data['include_post_types'] = array_values(array_filter(array_map('sanitize_key', $data['include_post_types'])));
        $data['exclude_post_types'] = array_values(array_filter(array_map('sanitize_key', $data['exclude_post_types'])));
        $data['include_ids'] = array_values(array_filter(array_map('absint', $data['include_ids'])));
        $data['exclude_ids'] = array_values(array_filter(array_map('absint', $data['exclude_ids'])));
        $data['path_exact'] = array_values(array_filter(array_map('sanitize_text_field', $data['path_exact'])));
        $data['path_contains'] = array_values(array_filter(array_map('sanitize_text_field', $data['path_contains'])));
        $data['roles'] = array_values(array_filter(array_map('sanitize_key', $data['roles'])));
        $data['devices'] = array_values(array_filter(array_map('sanitize_key', $data['devices'])));
        foreach (['logged_in_only', 'logged_out_only', 'preview_admin_only', 'marketing_script', 'test_mode'] as $bool_field) {
            $data[$bool_field] = empty($data[$bool_field]) ? 0 : 1;
        }
        $data['schedule_start'] = sanitize_text_field((string) $data['schedule_start']);
        $data['schedule_end'] = sanitize_text_field((string) $data['schedule_end']);

        return $data;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_code_snippet_conditions(int $snippet_id): array
    {
        $raw = get_post_meta($snippet_id, '_quick_code_conditions_json', true);
        if (!is_string($raw) || trim($raw) === '') {
            $raw = get_post_meta($snippet_id, '_qcod_conditions_json', true);
        }

        return $this->quick_code_normalize_conditions($raw);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_code_save_settings_payload(array $payload)
    {
        $settings = $this->quick_code_get_settings();
        $allowed_locations = ['head', 'body_open', 'body_close'];

        foreach (['enable_global', 'enable_per_page', 'body_open_fallback', 'disable_all', 'exclude_admins', 'respect_dnt', 'disable_on_preview'] as $flag) {
            if (array_key_exists($flag, $payload)) {
                $settings[$flag] = $this->quick_code_bool_to_int($payload[$flag]);
            }
        }

        if (array_key_exists('default_css_location', $payload)) {
            $location = sanitize_key((string) $payload['default_css_location']);
            $settings['default_css_location'] = in_array($location, $allowed_locations, true) ? $location : 'head';
        }
        if (array_key_exists('default_js_location', $payload)) {
            $location = sanitize_key((string) $payload['default_js_location']);
            $settings['default_js_location'] = in_array($location, $allowed_locations, true) ? $location : 'body_close';
        }

        update_option('qcod_settings', $settings);
        $workspace = $this->quick_code_open_payload();

        return [
            'settings' => $settings,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'snippets' => isset($workspace['snippets']) && is_array($workspace['snippets']) ? $workspace['snippets'] : [],
            'history' => isset($workspace['history']) && is_array($workspace['history']) ? $workspace['history'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_code_get_history_rows(int $limit = 50): array
    {
        global $wpdb;

        $limit = max(1, $limit);
        $rows = [];
        $history_table = $wpdb->prefix . 'quick_code_history';
        $history_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $history_table));
        if (is_string($history_exists) && $history_exists === $history_table) {
            $db_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, snippet_id, changed_by, changed_at, old_values_json, new_values_json FROM {$history_table} ORDER BY changed_at DESC LIMIT %d",
                    $limit
                ),
                ARRAY_A
            );
            if (is_array($db_rows)) {
                foreach ($db_rows as $db_row) {
                    if (!is_array($db_row)) {
                        continue;
                    }
                    $changed_by = isset($db_row['changed_by']) ? absint($db_row['changed_by']) : 0;
                    $user = $changed_by > 0 ? get_user_by('id', $changed_by) : false;
                    $rows[] = [
                        'id' => isset($db_row['id']) ? absint($db_row['id']) : 0,
                        'snippetId' => isset($db_row['snippet_id']) ? absint($db_row['snippet_id']) : 0,
                        'action' => 'update',
                        'changedAt' => isset($db_row['changed_at']) ? mysql2date('c', (string) $db_row['changed_at'], false) : gmdate('c'),
                        'changedBy' => $changed_by,
                        'changedByName' => $user instanceof WP_User ? (string) $user->display_name : 'System',
                        'before' => isset($db_row['old_values_json']) ? json_decode((string) $db_row['old_values_json'], true) : [],
                        'after' => isset($db_row['new_values_json']) ? json_decode((string) $db_row['new_values_json'], true) : [],
                        'source' => 'plugin',
                    ];
                }
            }
        }

        $connector_rows = get_option('quick_connector_quick_code_history', []);
        if (!is_array($connector_rows)) {
            $connector_rows = [];
        }
        foreach ($connector_rows as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $rows[] = [
                'id' => isset($entry['id']) ? absint($entry['id']) : 0,
                'snippetId' => isset($entry['snippetId']) ? absint($entry['snippetId']) : 0,
                'action' => isset($entry['action']) ? sanitize_key((string) $entry['action']) : 'update',
                'changedAt' => isset($entry['changedAt']) ? sanitize_text_field((string) $entry['changedAt']) : gmdate('c'),
                'changedBy' => isset($entry['changedBy']) ? absint($entry['changedBy']) : 0,
                'changedByName' => isset($entry['changedByName']) ? sanitize_text_field((string) $entry['changedByName']) : 'System',
                'before' => isset($entry['before']) && is_array($entry['before']) ? $entry['before'] : [],
                'after' => isset($entry['after']) && is_array($entry['after']) ? $entry['after'] : [],
                'source' => 'connector',
            ];
        }

        usort($rows, function ($left, $right) {
            $left_ts = isset($left['changedAt']) ? strtotime((string) $left['changedAt']) : 0;
            $right_ts = isset($right['changedAt']) ? strtotime((string) $right['changedAt']) : 0;
            if ($left_ts === $right_ts) {
                return 0;
            }
            return ($left_ts > $right_ts) ? -1 : 1;
        });

        return array_slice($rows, 0, $limit);
    }

    /**
     * @param array<string, mixed> $before
     * @param array<string, mixed> $after
     */
    private function quick_code_add_history_row(int $snippet_id, string $action, array $before, array $after): void
    {
        $history = get_option('quick_connector_quick_code_history', []);
        if (!is_array($history)) {
            $history = [];
        }
        $user = wp_get_current_user();
        $history[] = [
            'id' => count($history) + 1,
            'snippetId' => $snippet_id,
            'action' => $action,
            'changedAt' => gmdate('c'),
            'changedBy' => isset($user->ID) ? (int) $user->ID : 0,
            'changedByName' => $user instanceof WP_User ? (string) $user->display_name : 'System',
            'before' => $before,
            'after' => $after,
        ];
        if (count($history) > 200) {
            $history = array_slice($history, -200);
        }
        update_option('quick_connector_quick_code_history', $history, false);
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function quick_code_history_payload(array $payload): array
    {
        $limit = isset($payload['limit']) ? absint($payload['limit']) : 30;
        $limit = max(1, min(200, $limit));
        $workspace = $this->quick_code_open_payload();

        return [
            'history' => $this->quick_code_get_history_rows($limit),
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'snippets' => isset($workspace['snippets']) && is_array($workspace['snippets']) ? $workspace['snippets'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_code_save_snippet_payload(array $payload)
    {
        $title = isset($payload['title']) ? sanitize_text_field((string) $payload['title']) : '';
        $language = isset($payload['language']) ? sanitize_key((string) $payload['language']) : 'php';
        $enabled = isset($payload['enabled']) ? (bool) $payload['enabled'] : true;
        $snippet_code = isset($payload['code']) ? (string) $payload['code'] : '';
        $conditions = isset($payload['conditions']) ? $payload['conditions'] : (isset($payload['conditionsJson']) ? $payload['conditionsJson'] : []);
        $normalized_conditions = $this->quick_code_normalize_conditions($conditions);

        if ($title === '') {
            return new WP_Error('quick_code_title_required', 'Snippet title is required.', ['status' => 400]);
        }
        if (trim($snippet_code) === '') {
            return new WP_Error('quick_code_content_required', 'Snippet code is required.', ['status' => 400]);
        }

        $snippet_post_type = post_type_exists('quick-code-snippet') ? 'quick-code-snippet' : 'page';
        $result = wp_insert_post([
            'post_type' => $snippet_post_type,
            'post_status' => 'draft',
            'post_title' => $title,
            'post_content' => $snippet_code,
        ], true);

        if (is_wp_error($result)) {
            return new WP_Error(
                'quick_code_save_failed',
                'Could not save code snippet.',
                ['status' => 500, 'details' => $result->get_error_message()]
            );
        }

        $snippet_id = (int) $result;
        update_post_meta($snippet_id, '_quick_code_language', $language);
        update_post_meta($snippet_id, '_quick_code_enabled', $enabled ? '1' : '0');
        update_post_meta($snippet_id, '_quick_code_conditions_json', wp_json_encode($normalized_conditions));
        if ($snippet_post_type === 'page') {
            update_post_meta($snippet_id, '_quick_code_snippet', '1');
        }
        $this->quick_code_add_history_row(
            $snippet_id,
            'create',
            [],
            [
                'title' => $title,
                'status' => 'draft',
                'enabled' => $enabled,
                'language' => $language,
                'conditions' => $normalized_conditions,
            ]
        );
        $workspace = $this->quick_code_open_payload();

        return [
            'snippetId' => $snippet_id,
            'postType' => $snippet_post_type,
            'status' => 'draft',
            'enabled' => $enabled,
            'language' => $language,
            'conditions' => $normalized_conditions,
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'link' => get_edit_post_link($snippet_id, ''),
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'snippets' => isset($workspace['snippets']) && is_array($workspace['snippets']) ? $workspace['snippets'] : [],
            'history' => isset($workspace['history']) && is_array($workspace['history']) ? $workspace['history'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_code_update_snippet_payload(array $payload)
    {
        $snippet_id = isset($payload['snippetId']) ? absint($payload['snippetId']) : 0;
        if ($snippet_id <= 0) {
            return new WP_Error('quick_code_snippet_required', 'Valid snippetId is required.', ['status' => 400]);
        }

        $snippet = get_post($snippet_id);
        if (!$snippet instanceof WP_Post || $snippet->post_type === 'revision') {
            return new WP_Error('quick_code_snippet_not_found', 'Snippet not found.', ['status' => 404]);
        }

        $is_snippet = (string) get_post_meta($snippet_id, '_quick_code_snippet', true) === '1' || $snippet->post_type === 'quick-code-snippet';
        if (!$is_snippet) {
            return new WP_Error('quick_code_not_managed_snippet', 'Post is not a Quick Code snippet.', ['status' => 400]);
        }

        $before = [
            'title' => (string) $snippet->post_title,
            'status' => (string) $snippet->post_status,
            'enabled' => (string) get_post_meta($snippet_id, '_quick_code_enabled', true) === '1',
            'language' => (string) get_post_meta($snippet_id, '_quick_code_language', true),
            'conditions' => $this->quick_code_snippet_conditions($snippet_id),
        ];

        $update = ['ID' => $snippet_id];
        if (isset($payload['title'])) {
            $title = sanitize_text_field((string) $payload['title']);
            if ($title !== '') {
                $update['post_title'] = $title;
            }
        }
        if (isset($payload['code'])) {
            $code = (string) $payload['code'];
            if (trim($code) !== '') {
                $update['post_content'] = $code;
            }
        }
        if (isset($payload['status'])) {
            $status = sanitize_key((string) $payload['status']);
            if (in_array($status, ['draft', 'publish', 'private', 'pending'], true)) {
                $update['post_status'] = $status;
            }
        }

        if (count($update) > 1) {
            $result = wp_update_post($update, true);
            if (is_wp_error($result)) {
                return new WP_Error(
                    'quick_code_update_failed',
                    'Could not update snippet.',
                    ['status' => 500, 'details' => $result->get_error_message()]
                );
            }
        }

        if (isset($payload['language'])) {
            $language = sanitize_key((string) $payload['language']);
            if ($language !== '') {
                update_post_meta($snippet_id, '_quick_code_language', $language);
            }
        }

        if (isset($payload['enabled'])) {
            $enabled = (bool) $payload['enabled'];
            update_post_meta($snippet_id, '_quick_code_enabled', $enabled ? '1' : '0');
        }

        if (array_key_exists('conditions', $payload) || array_key_exists('conditionsJson', $payload)) {
            $conditions = array_key_exists('conditions', $payload) ? $payload['conditions'] : $payload['conditionsJson'];
            $normalized_conditions = $this->quick_code_normalize_conditions($conditions);
            update_post_meta($snippet_id, '_quick_code_conditions_json', wp_json_encode($normalized_conditions));
        }

        $refreshed_snippet = get_post($snippet_id);
        $after = [
            'title' => $refreshed_snippet instanceof WP_Post ? (string) $refreshed_snippet->post_title : $before['title'],
            'status' => $refreshed_snippet instanceof WP_Post ? (string) $refreshed_snippet->post_status : $before['status'],
            'enabled' => (string) get_post_meta($snippet_id, '_quick_code_enabled', true) === '1',
            'language' => (string) get_post_meta($snippet_id, '_quick_code_language', true),
            'conditions' => $this->quick_code_snippet_conditions($snippet_id),
        ];
        $this->quick_code_add_history_row($snippet_id, 'update', $before, $after);

        $workspace = $this->quick_code_open_payload();
        return [
            'snippetId' => $snippet_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'snippets' => isset($workspace['snippets']) && is_array($workspace['snippets']) ? $workspace['snippets'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'history' => isset($workspace['history']) && is_array($workspace['history']) ? $workspace['history'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_code_set_enabled_payload(array $payload)
    {
        $snippet_id = isset($payload['snippetId']) ? absint($payload['snippetId']) : 0;
        if ($snippet_id <= 0) {
            return new WP_Error('quick_code_snippet_required', 'Valid snippetId is required.', ['status' => 400]);
        }

        $snippet = get_post($snippet_id);
        if (!$snippet instanceof WP_Post) {
            return new WP_Error('quick_code_snippet_not_found', 'Snippet not found.', ['status' => 404]);
        }

        $is_snippet = (string) get_post_meta($snippet_id, '_quick_code_snippet', true) === '1' || $snippet->post_type === 'quick-code-snippet';
        if (!$is_snippet) {
            return new WP_Error('quick_code_not_managed_snippet', 'Post is not a Quick Code snippet.', ['status' => 400]);
        }

        $before_enabled = (string) get_post_meta($snippet_id, '_quick_code_enabled', true) === '1';
        $enabled = isset($payload['enabled']) ? (bool) $payload['enabled'] : true;
        update_post_meta($snippet_id, '_quick_code_enabled', $enabled ? '1' : '0');
        $this->quick_code_add_history_row(
            $snippet_id,
            'toggle',
            ['enabled' => $before_enabled],
            ['enabled' => $enabled]
        );
        $workspace = $this->quick_code_open_payload();

        return [
            'snippetId' => $snippet_id,
            'enabled' => $enabled,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'snippets' => isset($workspace['snippets']) && is_array($workspace['snippets']) ? $workspace['snippets'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'history' => isset($workspace['history']) && is_array($workspace['history']) ? $workspace['history'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_code_delete_snippet_payload(array $payload)
    {
        $snippet_id = isset($payload['snippetId']) ? absint($payload['snippetId']) : 0;
        if ($snippet_id <= 0) {
            return new WP_Error('quick_code_snippet_required', 'Valid snippetId is required.', ['status' => 400]);
        }

        $snippet = get_post($snippet_id);
        if (!$snippet instanceof WP_Post) {
            return new WP_Error('quick_code_snippet_not_found', 'Snippet not found.', ['status' => 404]);
        }

        $is_snippet = (string) get_post_meta($snippet_id, '_quick_code_snippet', true) === '1' || $snippet->post_type === 'quick-code-snippet';
        if (!$is_snippet) {
            return new WP_Error('quick_code_not_managed_snippet', 'Post is not a Quick Code snippet.', ['status' => 400]);
        }

        $before = [
            'title' => (string) $snippet->post_title,
            'status' => (string) $snippet->post_status,
            'enabled' => (string) get_post_meta($snippet_id, '_quick_code_enabled', true) === '1',
            'language' => (string) get_post_meta($snippet_id, '_quick_code_language', true),
            'conditions' => $this->quick_code_snippet_conditions($snippet_id),
        ];
        $deleted = wp_delete_post($snippet_id, true);
        if (!$deleted) {
            return new WP_Error('quick_code_delete_failed', 'Could not delete snippet.', ['status' => 500]);
        }
        $this->quick_code_add_history_row($snippet_id, 'delete', $before, []);

        $workspace = $this->quick_code_open_payload();
        return [
            'snippetId' => $snippet_id,
            'deleted' => true,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'snippets' => isset($workspace['snippets']) && is_array($workspace['snippets']) ? $workspace['snippets'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'history' => isset($workspace['history']) && is_array($workspace['history']) ? $workspace['history'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_code_save_conditions_payload(array $payload)
    {
        $snippet_id = isset($payload['snippetId']) ? absint($payload['snippetId']) : 0;
        if ($snippet_id <= 0) {
            return new WP_Error('quick_code_snippet_required', 'Valid snippetId is required.', ['status' => 400]);
        }

        $snippet = get_post($snippet_id);
        if (!$snippet instanceof WP_Post || $snippet->post_type === 'revision') {
            return new WP_Error('quick_code_snippet_not_found', 'Snippet not found.', ['status' => 404]);
        }

        $is_snippet = (string) get_post_meta($snippet_id, '_quick_code_snippet', true) === '1' || $snippet->post_type === 'quick-code-snippet';
        if (!$is_snippet) {
            return new WP_Error('quick_code_not_managed_snippet', 'Post is not a Quick Code snippet.', ['status' => 400]);
        }

        $conditions = isset($payload['conditions']) ? $payload['conditions'] : (isset($payload['conditionsJson']) ? $payload['conditionsJson'] : []);
        $before = $this->quick_code_snippet_conditions($snippet_id);
        $normalized_conditions = $this->quick_code_normalize_conditions($conditions);
        update_post_meta($snippet_id, '_quick_code_conditions_json', wp_json_encode($normalized_conditions));
        $this->quick_code_add_history_row(
            $snippet_id,
            'conditions',
            ['conditions' => $before],
            ['conditions' => $normalized_conditions]
        );
        $workspace = $this->quick_code_open_payload();

        return [
            'snippetId' => $snippet_id,
            'conditions' => $normalized_conditions,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'snippets' => isset($workspace['snippets']) && is_array($workspace['snippets']) ? $workspace['snippets'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'history' => isset($workspace['history']) && is_array($workspace['history']) ? $workspace['history'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_code_export_csv_payload(array $payload)
    {
        $entity = isset($payload['entity']) ? sanitize_key((string) $payload['entity']) : 'snippets';
        if (!in_array($entity, ['snippets', 'history'], true)) {
            return new WP_Error('quick_code_export_entity_invalid', 'Entity must be snippets or history.', ['status' => 400]);
        }

        $rows = [];
        if ($entity === 'history') {
            $history = $this->quick_code_get_history_rows(500);
            $rows[] = ['id', 'snippet_id', 'action', 'changed_at', 'changed_by', 'changed_by_name', 'source', 'before_json', 'after_json'];
            foreach ($history as $entry) {
                if (!is_array($entry)) {
                    continue;
                }
                $rows[] = [
                    (string) ($entry['id'] ?? 0),
                    (string) ($entry['snippetId'] ?? 0),
                    (string) ($entry['action'] ?? ''),
                    (string) ($entry['changedAt'] ?? ''),
                    (string) ($entry['changedBy'] ?? 0),
                    (string) ($entry['changedByName'] ?? ''),
                    (string) ($entry['source'] ?? ''),
                    wp_json_encode(isset($entry['before']) && is_array($entry['before']) ? $entry['before'] : []),
                    wp_json_encode(isset($entry['after']) && is_array($entry['after']) ? $entry['after'] : []),
                ];
            }
        } else {
            $workspace = $this->quick_code_open_payload();
            $snippets = isset($workspace['snippets']) && is_array($workspace['snippets']) ? $workspace['snippets'] : [];
            $rows[] = ['id', 'title', 'status', 'enabled', 'post_type', 'language', 'modified', 'code', 'conditions_json'];
            foreach ($snippets as $snippet) {
                if (!is_array($snippet)) {
                    continue;
                }
                $rows[] = [
                    (string) ($snippet['id'] ?? 0),
                    (string) ($snippet['title'] ?? ''),
                    (string) ($snippet['status'] ?? ''),
                    !empty($snippet['enabled']) ? '1' : '0',
                    (string) ($snippet['postType'] ?? ''),
                    (string) ($snippet['language'] ?? ''),
                    (string) ($snippet['modified'] ?? ''),
                    (string) ($snippet['code'] ?? ''),
                    wp_json_encode(isset($snippet['conditions']) && is_array($snippet['conditions']) ? $snippet['conditions'] : []),
                ];
            }
        }

        $csv = $this->quick_importer_rows_to_csv($rows);
        if ($csv instanceof WP_Error) {
            return $csv;
        }

        return [
            'entity' => $entity,
            'filename' => sprintf('quick-code-%s-%s.csv', $entity, gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    private function quick_add_open_payload()
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_add_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $products = get_posts([
            'post_type' => 'product',
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'numberposts' => 10,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);

        $recent_products = [];
        foreach ($products as $product_post) {
            if (!$product_post instanceof WP_Post) {
                continue;
            }

            $product = wc_get_product($product_post->ID);
            $recent_products[] = [
                'id' => $product_post->ID,
                'name' => (string) $product_post->post_title,
                'status' => (string) $product_post->post_status,
                'price' => $product ? (string) $product->get_regular_price() : '',
                'sku' => $product ? (string) $product->get_sku() : '',
            ];
        }

        $count = wp_count_posts('product');
        $published = ($count instanceof stdClass && isset($count->publish)) ? (int) $count->publish : 0;
        $draft = ($count instanceof stdClass && isset($count->draft)) ? (int) $count->draft : 0;

        return [
            'summary' => [
                'publishedProducts' => $published,
                'draftProducts' => $draft,
                'recentCount' => count($recent_products),
            ],
            'recentProducts' => $recent_products,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_add_create_product_payload(array $payload)
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_add_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : '';
        $regular_price = isset($payload['regularPrice']) ? wc_format_decimal((string) $payload['regularPrice']) : '';
        $sku = isset($payload['sku']) ? wc_clean((string) $payload['sku']) : '';
        $stock_quantity = isset($payload['stockQuantity']) ? absint($payload['stockQuantity']) : null;

        if ($name === '') {
            return new WP_Error('quick_add_name_required', 'Product name is required.', ['status' => 400]);
        }

        $product = new WC_Product_Simple();
        $product->set_name($name);
        $product->set_status('draft');
        if ($regular_price !== '') {
            $product->set_regular_price((string) $regular_price);
        }
        if ($sku !== '') {
            $product->set_sku($sku);
        }
        if ($stock_quantity !== null) {
            $product->set_manage_stock(true);
            $product->set_stock_quantity($stock_quantity);
        }

        $product_id = $product->save();
        if (!$product_id) {
            return new WP_Error('quick_add_create_failed', 'Could not create product.', ['status' => 500]);
        }

        $workspace = $this->quick_add_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'productId' => $product_id,
            'status' => 'draft',
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'recentProducts' => isset($workspace['recentProducts']) && is_array($workspace['recentProducts']) ? $workspace['recentProducts'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    private function quick_edit_open_payload()
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_edit_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $products = get_posts([
            'post_type' => 'product',
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'numberposts' => 20,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);

        $recent_products = [];
        foreach ($products as $product_post) {
            if (!$product_post instanceof WP_Post) {
                continue;
            }

            $product = wc_get_product($product_post->ID);
            $recent_products[] = [
                'id' => $product_post->ID,
                'name' => (string) $product_post->post_title,
                'status' => (string) $product_post->post_status,
                'price' => $product ? (string) $product->get_regular_price() : '',
                'stockQuantity' => $product ? $product->get_stock_quantity() : null,
                'sku' => $product ? (string) $product->get_sku() : '',
            ];
        }

        return [
            'summary' => [
                'editableProducts' => count($recent_products),
            ],
            'recentProducts' => $recent_products,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_edit_list_products_payload(array $payload)
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_edit_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $search = isset($payload['search']) ? sanitize_text_field((string) $payload['search']) : '';
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        $page = isset($payload['page']) ? max(1, absint($payload['page'])) : 1;
        $per_page = isset($payload['perPage']) ? max(1, min(100, absint($payload['perPage']))) : 20;
        $offset = ($page - 1) * $per_page;

        $statuses = ['publish', 'draft', 'private', 'pending'];
        if ($status !== '' && in_array($status, $statuses, true)) {
            $statuses = [$status];
        }

        $query = [
            'post_type' => 'product',
            'post_status' => $statuses,
            'posts_per_page' => $per_page,
            'offset' => $offset,
            'orderby' => 'modified',
            'order' => 'DESC',
            's' => $search,
            'fields' => 'ids',
        ];
        $product_ids = get_posts($query);
        $rows = [];
        foreach ($product_ids as $product_id) {
            $product_id = (int) $product_id;
            if ($product_id <= 0) {
                continue;
            }

            $post = get_post($product_id);
            if (!$post instanceof WP_Post) {
                continue;
            }
            $product = wc_get_product($product_id);
            if (!$product) {
                continue;
            }

            $rows[] = [
                'id' => $product_id,
                'name' => (string) $post->post_title,
                'status' => (string) $post->post_status,
                'price' => (string) $product->get_regular_price(),
                'stockQuantity' => $product->get_stock_quantity(),
                'sku' => (string) $product->get_sku(),
            ];
        }

        return [
            'summary' => [
                'editableProducts' => count($rows),
                'filterStatus' => $status !== '' ? $status : 'all',
                'filterSearch' => $search,
            ],
            'recentProducts' => $rows,
            'page' => $page,
            'perPage' => $per_page,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_edit_update_product_payload(array $payload)
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_edit_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $product_id = isset($payload['productId']) ? absint($payload['productId']) : 0;
        if ($product_id <= 0) {
            return new WP_Error('quick_edit_product_required', 'Valid productId is required.', ['status' => 400]);
        }

        $product = wc_get_product($product_id);
        if (!$product) {
            return new WP_Error('quick_edit_product_not_found', 'Product not found.', ['status' => 404]);
        }

        if (isset($payload['name'])) {
            $name = sanitize_text_field((string) $payload['name']);
            if ($name !== '') {
                $product->set_name($name);
            }
        }
        if (isset($payload['regularPrice'])) {
            $regular_price = wc_format_decimal((string) $payload['regularPrice']);
            if ($regular_price !== '') {
                $product->set_regular_price((string) $regular_price);
            }
        }
        if (isset($payload['sku'])) {
            $sku = wc_clean((string) $payload['sku']);
            $product->set_sku($sku);
        }
        if (isset($payload['stockQuantity'])) {
            $stock_quantity = absint($payload['stockQuantity']);
            $product->set_manage_stock(true);
            $product->set_stock_quantity($stock_quantity);
        }
        if (isset($payload['status'])) {
            $status = sanitize_key((string) $payload['status']);
            if (in_array($status, ['draft', 'publish', 'private', 'pending'], true)) {
                $product->set_status($status);
            }
        }

        $product->save();
        $workspace = $this->quick_edit_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'productId' => $product_id,
            'name' => $product->get_name(),
            'status' => $product->get_status(),
            'regularPrice' => (string) $product->get_regular_price(),
            'sku' => (string) $product->get_sku(),
            'stockQuantity' => $product->get_stock_quantity(),
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'recentProducts' => isset($workspace['recentProducts']) && is_array($workspace['recentProducts']) ? $workspace['recentProducts'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_edit_bulk_update_products_payload(array $payload)
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_edit_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $product_ids = isset($payload['productIds']) && is_array($payload['productIds']) ? $payload['productIds'] : [];
        if (count($product_ids) === 0) {
            return new WP_Error('quick_edit_bulk_ids_required', 'productIds is required.', ['status' => 400]);
        }

        $regular_price = isset($payload['regularPrice']) ? wc_format_decimal((string) $payload['regularPrice']) : null;
        $sku = isset($payload['sku']) ? wc_clean((string) $payload['sku']) : null;
        $stock_quantity = isset($payload['stockQuantity']) ? absint($payload['stockQuantity']) : null;
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : null;

        $updated_count = 0;
        foreach ($product_ids as $raw_id) {
            $product_id = absint($raw_id);
            if ($product_id <= 0) {
                continue;
            }

            $product = wc_get_product($product_id);
            if (!$product) {
                continue;
            }

            if ($regular_price !== null && $regular_price !== '') {
                $product->set_regular_price((string) $regular_price);
            }
            if ($sku !== null) {
                $product->set_sku($sku);
            }
            if ($stock_quantity !== null) {
                $product->set_manage_stock(true);
                $product->set_stock_quantity($stock_quantity);
            }
            if ($status !== null && in_array($status, ['draft', 'publish', 'private', 'pending'], true)) {
                $product->set_status($status);
            }

            $product->save();
            $updated_count++;
        }

        $workspace = $this->quick_edit_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'updatedCount' => $updated_count,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'recentProducts' => isset($workspace['recentProducts']) && is_array($workspace['recentProducts']) ? $workspace['recentProducts'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    private function quick_variations_open_payload()
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_variations_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $variations = get_posts([
            'post_type' => 'product_variation',
            'post_status' => ['publish', 'private'],
            'numberposts' => 30,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);

        $items = [];
        $low_stock = 0;
        foreach ($variations as $variation_post) {
            if (!$variation_post instanceof WP_Post) {
                continue;
            }

            $variation = wc_get_product($variation_post->ID);
            if (!$variation instanceof WC_Product_Variation) {
                continue;
            }

            $stock = $variation->get_stock_quantity();
            if ($stock !== null && $stock <= 3) {
                $low_stock++;
            }

            $parent_id = $variation->get_parent_id();
            $items[] = [
                'id' => $variation->get_id(),
                'parentId' => $parent_id,
                'parentName' => get_the_title($parent_id),
                'status' => $variation->get_status(),
                'sku' => (string) $variation->get_sku(),
                'regularPrice' => (string) $variation->get_regular_price(),
                'stockQuantity' => $stock,
            ];
        }

        return [
            'summary' => [
                'recentVariations' => count($items),
                'lowStockVariations' => $low_stock,
            ],
            'recentVariations' => $items,
            'variableProducts' => $this->quick_variations_get_variable_products(100),
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_variations_update_variation_payload(array $payload)
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_variations_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $variation_id = isset($payload['variationId']) ? absint($payload['variationId']) : 0;
        if ($variation_id <= 0) {
            return new WP_Error('quick_variations_variation_required', 'Valid variationId is required.', ['status' => 400]);
        }

        $variation = wc_get_product($variation_id);
        if (!$variation instanceof WC_Product_Variation) {
            return new WP_Error('quick_variations_not_found', 'Variation not found.', ['status' => 404]);
        }

        if (isset($payload['regularPrice'])) {
            $regular_price = wc_format_decimal((string) $payload['regularPrice']);
            if ($regular_price !== '') {
                $variation->set_regular_price((string) $regular_price);
            }
        }
        if (isset($payload['sku'])) {
            $variation->set_sku(wc_clean((string) $payload['sku']));
        }
        if (isset($payload['stockQuantity'])) {
            $stock_quantity = absint($payload['stockQuantity']);
            $variation->set_manage_stock(true);
            $variation->set_stock_quantity($stock_quantity);
        }
        if (isset($payload['status'])) {
            $status = sanitize_key((string) $payload['status']);
            if (in_array($status, ['publish', 'private'], true)) {
                $variation->set_status($status);
            }
        }

        $variation->save();
        $workspace = $this->quick_variations_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'variationId' => $variation->get_id(),
            'parentId' => $variation->get_parent_id(),
            'status' => $variation->get_status(),
            'sku' => (string) $variation->get_sku(),
            'regularPrice' => (string) $variation->get_regular_price(),
            'stockQuantity' => $variation->get_stock_quantity(),
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'recentVariations' => isset($workspace['recentVariations']) && is_array($workspace['recentVariations']) ? $workspace['recentVariations'] : [],
            'variableProducts' => isset($workspace['variableProducts']) && is_array($workspace['variableProducts']) ? $workspace['variableProducts'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_variations_list_variable_products_payload(array $payload)
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_variations_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $limit = isset($payload['limit']) ? absint($payload['limit']) : 150;
        if ($limit < 1) {
            $limit = 150;
        }
        if ($limit > 500) {
            $limit = 500;
        }

        return [
            'variableProducts' => $this->quick_variations_get_variable_products($limit),
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_variations_generate_combinations_payload(array $payload)
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_variations_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $attribute_defs = $this->quick_variations_sanitize_attribute_defs(isset($payload['attributes']) ? $payload['attributes'] : []);
        if (empty($attribute_defs)) {
            return new WP_Error(
                'quick_variations_attributes_required',
                'At least one attribute with values is required.',
                ['status' => 400]
            );
        }

        $attribute_map = [];
        foreach ($attribute_defs as $def) {
            if (!isset($def['slug']) || !isset($def['options']) || !is_array($def['options'])) {
                continue;
            }
            $attribute_map[(string) $def['slug']] = $def['options'];
        }

        $combos = $this->quick_variations_build_cartesian_combinations($attribute_map, 500);
        if (empty($combos)) {
            return new WP_Error('quick_variations_no_combos', 'No combinations generated from attributes.', ['status' => 400]);
        }

        $default_price = isset($payload['defaultRegularPrice']) ? wc_format_decimal((string) $payload['defaultRegularPrice']) : '';
        $default_stock = isset($payload['defaultStockQuantity']) && $payload['defaultStockQuantity'] !== ''
            ? absint($payload['defaultStockQuantity'])
            : '';
        $sku_prefix = isset($payload['skuPrefix']) ? sanitize_text_field((string) $payload['skuPrefix']) : '';

        $rows = [];
        foreach ($combos as $index => $combo) {
            $rows[] = [
                'combo' => $combo,
                'regularPrice' => $default_price,
                'sku' => $this->quick_variations_default_sku_from_combo($sku_prefix, $combo, $index),
                'stockQuantity' => $default_stock,
            ];
        }

        return [
            'attributeDefs' => $attribute_defs,
            'generatedRows' => $rows,
            'combinationCount' => count($rows),
            'truncated' => count($rows) >= 500,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_variations_create_variations_payload(array $payload)
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_variations_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $product_id = isset($payload['productId']) ? absint($payload['productId']) : 0;
        if ($product_id <= 0) {
            return new WP_Error('quick_variations_product_required', 'Valid productId is required.', ['status' => 400]);
        }

        $product = wc_get_product($product_id);
        if (!$product instanceof WC_Product_Variable) {
            return new WP_Error('quick_variations_product_not_variable', 'Selected product is not variable.', ['status' => 400]);
        }

        $attribute_defs = $this->quick_variations_sanitize_attribute_defs(isset($payload['attributes']) ? $payload['attributes'] : []);
        $rows_raw = isset($payload['rows']) && is_array($payload['rows']) ? $payload['rows'] : [];

        if (empty($rows_raw) && !empty($attribute_defs)) {
            $attribute_map = [];
            foreach ($attribute_defs as $def) {
                if (!isset($def['slug']) || !isset($def['options']) || !is_array($def['options'])) {
                    continue;
                }
                $attribute_map[(string) $def['slug']] = $def['options'];
            }
            $combos = $this->quick_variations_build_cartesian_combinations($attribute_map, 500);
            foreach ($combos as $combo) {
                $rows_raw[] = ['combo' => $combo];
            }
        }

        if (empty($rows_raw)) {
            return new WP_Error('quick_variations_rows_required', 'No variation rows were supplied.', ['status' => 400]);
        }

        if (empty($attribute_defs)) {
            $attribute_defs = $this->quick_variations_infer_attribute_defs_from_rows($rows_raw);
        }
        if (empty($attribute_defs)) {
            return new WP_Error('quick_variations_attributes_invalid', 'Could not infer attributes from rows.', ['status' => 400]);
        }

        $attribute_name_map = $this->quick_variations_sync_product_attributes($product, $attribute_defs);
        $product->save();

        $existing_signatures = $this->quick_variations_get_existing_variation_signatures($product);
        $created = 0;
        $skipped = 0;
        $failed = 0;

        foreach ($rows_raw as $row) {
            if (!is_array($row) || !isset($row['combo']) || !is_array($row['combo'])) {
                $failed++;
                continue;
            }

            $combo = $this->quick_variations_normalize_combo($row['combo']);
            if (empty($combo)) {
                $failed++;
                continue;
            }

            $signature = $this->quick_variations_build_signature($combo);
            if ($signature !== '' && isset($existing_signatures[$signature])) {
                $skipped++;
                continue;
            }

            $variation_attrs = [];
            foreach ($combo as $attr_slug => $attr_value) {
                if (!isset($attribute_name_map[$attr_slug])) {
                    continue;
                }
                $variation_attrs[$attribute_name_map[$attr_slug]] = $attr_value;
            }
            if (empty($variation_attrs)) {
                $failed++;
                continue;
            }

            try {
                $variation = new WC_Product_Variation();
                $variation->set_parent_id($product_id);
                $variation->set_status('publish');
                $variation->set_attributes($variation_attrs);

                if (isset($row['regularPrice']) && (string) $row['regularPrice'] !== '') {
                    $price = wc_format_decimal((string) $row['regularPrice']);
                    if ($price !== '') {
                        $variation->set_regular_price((string) $price);
                        $variation->set_price((string) $price);
                    }
                }

                if (isset($row['sku']) && trim((string) $row['sku']) !== '') {
                    $variation->set_sku(wc_clean((string) $row['sku']));
                }

                if (isset($row['stockQuantity']) && (string) $row['stockQuantity'] !== '') {
                    $stock = max(0, absint($row['stockQuantity']));
                    $variation->set_manage_stock(true);
                    $variation->set_stock_quantity($stock);
                    $variation->set_stock_status($stock > 0 ? 'instock' : 'outofstock');
                } else {
                    $variation->set_manage_stock(false);
                }

                $saved_id = $variation->save();
                if ($saved_id > 0) {
                    $created++;
                    if ($signature !== '') {
                        $existing_signatures[$signature] = true;
                    }
                } else {
                    $failed++;
                }
            } catch (Throwable $exception) {
                $failed++;
            }
        }

        $workspace = $this->quick_variations_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'productId' => $product_id,
            'created' => $created,
            'skipped' => $skipped,
            'failed' => $failed,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'recentVariations' => isset($workspace['recentVariations']) && is_array($workspace['recentVariations']) ? $workspace['recentVariations'] : [],
            'variableProducts' => isset($workspace['variableProducts']) && is_array($workspace['variableProducts']) ? $workspace['variableProducts'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param int $limit
     * @return array<int, array<string, mixed>>
     */
    private function quick_variations_get_variable_products($limit = 150)
    {
        $products = wc_get_products([
            'type' => 'variable',
            'limit' => $limit,
            'orderby' => 'title',
            'order' => 'ASC',
            'status' => ['publish', 'draft', 'private'],
        ]);

        $rows = [];
        foreach ($products as $product) {
            if (!$product instanceof WC_Product) {
                continue;
            }

            $rows[] = [
                'id' => $product->get_id(),
                'name' => $product->get_name(),
                'label' => sprintf('#%d %s', $product->get_id(), $product->get_name()),
            ];
        }

        return $rows;
    }

    /**
     * @param mixed $raw_attribute_defs
     * @return array<int, array<string, mixed>>
     */
    private function quick_variations_sanitize_attribute_defs($raw_attribute_defs)
    {
        if (!is_array($raw_attribute_defs)) {
            return [];
        }

        $sanitized = [];
        foreach ($raw_attribute_defs as $raw_def) {
            if (!is_array($raw_def)) {
                continue;
            }

            $name = isset($raw_def['name']) ? sanitize_text_field((string) $raw_def['name']) : '';
            $raw_values = isset($raw_def['values']) ? $raw_def['values'] : [];

            $values = [];
            if (is_string($raw_values)) {
                $parts = explode(',', $raw_values);
                foreach ($parts as $part) {
                    $clean = wc_clean(trim((string) $part));
                    if ($clean !== '') {
                        $values[] = $clean;
                    }
                }
            } elseif (is_array($raw_values)) {
                foreach ($raw_values as $part) {
                    $clean = wc_clean(trim((string) $part));
                    if ($clean !== '') {
                        $values[] = $clean;
                    }
                }
            }

            $values = array_values(array_unique($values));
            $slug = sanitize_title($name);
            if ($name === '' || $slug === '' || empty($values)) {
                continue;
            }

            $sanitized[] = [
                'name' => $name,
                'slug' => $slug,
                'options' => $values,
            ];
        }

        return $sanitized;
    }

    /**
     * @param array<int, mixed> $rows_raw
     * @return array<int, array<string, mixed>>
     */
    private function quick_variations_infer_attribute_defs_from_rows(array $rows_raw)
    {
        $by_slug = [];
        foreach ($rows_raw as $row) {
            if (!is_array($row) || !isset($row['combo']) || !is_array($row['combo'])) {
                continue;
            }

            $combo = $this->quick_variations_normalize_combo($row['combo']);
            foreach ($combo as $slug => $value) {
                if (!isset($by_slug[$slug])) {
                    $by_slug[$slug] = [];
                }
                $by_slug[$slug][] = $value;
            }
        }

        $defs = [];
        foreach ($by_slug as $slug => $values) {
            $clean_values = array_values(array_unique(array_filter(array_map('wc_clean', $values), static function ($value) {
                return $value !== '';
            })));
            if (empty($clean_values)) {
                continue;
            }

            $defs[] = [
                'name' => ucwords(str_replace('-', ' ', (string) $slug)),
                'slug' => sanitize_title((string) $slug),
                'options' => $clean_values,
            ];
        }

        return $defs;
    }

    /**
     * @param array<string, array<int, string>> $attribute_map
     * @param int $limit
     * @return array<int, array<string, string>>
     */
    private function quick_variations_build_cartesian_combinations(array $attribute_map, $limit = 500)
    {
        $combinations = [[]];

        foreach ($attribute_map as $attribute_name => $options) {
            $next = [];
            foreach ($combinations as $combo) {
                foreach ($options as $option) {
                    $new_combo = $combo;
                    $new_combo[(string) $attribute_name] = wc_clean((string) $option);
                    $next[] = $new_combo;

                    if (count($next) >= $limit) {
                        break 3;
                    }
                }
            }
            $combinations = $next;
        }

        return $combinations;
    }

    /**
     * @param array<string, mixed> $combo
     * @return array<string, string>
     */
    private function quick_variations_normalize_combo(array $combo)
    {
        $normalized = [];
        foreach ($combo as $key => $value) {
            $clean_key = sanitize_title((string) $key);
            $clean_value = wc_clean((string) $value);
            if ($clean_key !== '' && $clean_value !== '') {
                $normalized[$clean_key] = $clean_value;
            }
        }

        return $normalized;
    }

    /**
     * @param array<string, string> $combo
     * @return string
     */
    private function quick_variations_build_signature(array $combo)
    {
        if (empty($combo)) {
            return '';
        }

        $parts = [];
        foreach ($combo as $key => $value) {
            $parts[] = sanitize_title((string) $key) . '=' . wc_clean((string) $value);
        }
        sort($parts, SORT_STRING);

        return implode('|', $parts);
    }

    /**
     * @param WC_Product_Variable $product
     * @return array<string, bool>
     */
    private function quick_variations_get_existing_variation_signatures(WC_Product_Variable $product)
    {
        $signatures = [];
        foreach ($product->get_children() as $variation_id) {
            $variation = wc_get_product($variation_id);
            if (!$variation instanceof WC_Product_Variation) {
                continue;
            }

            $attributes = $variation->get_attributes();
            if (!is_array($attributes) || empty($attributes)) {
                continue;
            }

            $normalized = [];
            foreach ($attributes as $key => $value) {
                $key = str_replace('attribute_', '', (string) $key);
                $key = sanitize_title(str_replace('pa_', '', $key));
                $value = wc_clean((string) $value);
                if ($key !== '' && $value !== '') {
                    $normalized[$key] = $value;
                }
            }

            $signature = $this->quick_variations_build_signature($normalized);
            if ($signature !== '') {
                $signatures[$signature] = true;
            }
        }

        return $signatures;
    }

    /**
     * @param WC_Product_Variable $product
     * @param array<int, array<string, mixed>> $attribute_defs
     * @return array<string, string>
     */
    private function quick_variations_sync_product_attributes(WC_Product_Variable $product, array $attribute_defs)
    {
        $current = $product->get_attributes();
        $by_slug = [];
        $name_map = [];

        foreach ($current as $attribute) {
            if (!$attribute instanceof WC_Product_Attribute) {
                continue;
            }

            $attr_name = (string) $attribute->get_name();
            $slug = sanitize_title(str_replace('pa_', '', $attr_name));
            if ($slug !== '') {
                $by_slug[$slug] = $attribute;
                $name_map[$slug] = $attr_name;
            }
        }

        foreach ($attribute_defs as $index => $def) {
            if (!isset($def['slug']) || !isset($def['name']) || !isset($def['options']) || !is_array($def['options'])) {
                continue;
            }

            $slug = sanitize_title((string) $def['slug']);
            if ($slug === '') {
                continue;
            }
            $options = array_values(array_unique(array_filter(array_map('wc_clean', $def['options']), static function ($value) {
                return $value !== '';
            })));
            if (empty($options)) {
                continue;
            }

            if (isset($by_slug[$slug])) {
                $attribute = $by_slug[$slug];
                $merged = array_values(array_unique(array_merge((array) $attribute->get_options(), $options)));
                $attribute->set_options($merged);
                $attribute->set_visible(true);
                $attribute->set_variation(true);
                $attribute->set_position((int) $index);
                $name_map[$slug] = (string) $attribute->get_name();
                continue;
            }

            $attribute = new WC_Product_Attribute();
            $attribute->set_id(0);
            $attribute->set_name(sanitize_text_field((string) $def['name']));
            $attribute->set_options($options);
            $attribute->set_position((int) $index);
            $attribute->set_visible(true);
            $attribute->set_variation(true);

            $by_slug[$slug] = $attribute;
            $name_map[$slug] = (string) $attribute->get_name();
        }

        $product->set_attributes(array_values($by_slug));

        return $name_map;
    }

    /**
     * @param string $prefix
     * @param array<string, string> $combo
     * @param int $index
     * @return string
     */
    private function quick_variations_default_sku_from_combo($prefix, array $combo, $index)
    {
        $prefix = sanitize_text_field((string) $prefix);
        if ($prefix === '') {
            return '';
        }

        $parts = [];
        foreach ($combo as $value) {
            $chunk = strtoupper(substr(preg_replace('/[^a-zA-Z0-9]+/', '', (string) $value), 0, 6));
            if ($chunk !== '') {
                $parts[] = $chunk;
            }
        }

        if (empty($parts)) {
            return sprintf('%s-%d', $prefix, (int) $index + 1);
        }

        return sprintf('%s-%s', $prefix, implode('-', $parts));
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    private function quick_accountant_open_payload()
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_accountant_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $sales_total = 0.0;
        $completed_orders = 0;
        $processing_total = 0.0;
        $processing_orders = 0;

        $completed = wc_get_orders([
            'limit' => 200,
            'status' => ['completed'],
            'date_created' => '>' . (new DateTime('-30 days'))->format('Y-m-d H:i:s'),
            'return' => 'objects',
        ]);
        foreach ($completed as $order) {
            if ($order instanceof WC_Order) {
                $completed_orders++;
                $sales_total += (float) $order->get_total();
            }
        }

        $processing = wc_get_orders([
            'limit' => 200,
            'status' => ['processing'],
            'return' => 'objects',
        ]);
        foreach ($processing as $order) {
            if ($order instanceof WC_Order) {
                $processing_orders++;
                $processing_total += (float) $order->get_total();
            }
        }

        $ledger = get_option('quick_accountant_entries', []);
        if (!is_array($ledger)) {
            $ledger = [];
        }
        $categories = get_option('quick_accountant_categories', []);
        if (!is_array($categories)) {
            $categories = [];
        }
        $budgets = get_option('quick_accountant_budgets', []);
        if (!is_array($budgets)) {
            $budgets = [];
        }
        $monthly_budget_total = 0.0;
        foreach ($budgets as $budget) {
            if (!is_array($budget)) {
                continue;
            }
            $amount = isset($budget['monthlyAmount']) ? (float) $budget['monthlyAmount'] : 0.0;
            $monthly_budget_total += $amount;
        }

        return [
            'summary' => [
                'salesLast30Days' => round($sales_total, 2),
                'completedOrdersLast30Days' => $completed_orders,
                'processingOrderValue' => round($processing_total, 2),
                'processingOrders' => $processing_orders,
                'manualEntries' => count($ledger),
                'categories' => count($categories),
                'budgets' => count($budgets),
                'monthlyBudgetTotal' => round($monthly_budget_total, 2),
            ],
            'entries' => array_slice($ledger, 0, 20),
            'categories' => array_slice($categories, 0, 40),
            'budgets' => array_slice($budgets, 0, 40),
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_accountant_record_entry_payload(array $payload)
    {
        $type = isset($payload['type']) ? sanitize_key((string) $payload['type']) : 'expense';
        $amount_raw = isset($payload['amount']) ? wc_format_decimal((string) $payload['amount']) : '';
        $note = isset($payload['note']) ? sanitize_text_field((string) $payload['note']) : '';

        if (!in_array($type, ['income', 'expense', 'adjustment'], true)) {
            return new WP_Error('quick_accountant_invalid_type', 'type must be income, expense, or adjustment.', ['status' => 400]);
        }
        if ($amount_raw === '') {
            return new WP_Error('quick_accountant_amount_required', 'Valid amount is required.', ['status' => 400]);
        }
        if ($note === '') {
            return new WP_Error('quick_accountant_note_required', 'Entry note is required.', ['status' => 400]);
        }

        $ledger = get_option('quick_accountant_entries', []);
        if (!is_array($ledger)) {
            $ledger = [];
        }
        $next_id = 1;
        if (count($ledger) > 0 && isset($ledger[0]['id'])) {
            $next_id = ((int) $ledger[0]['id']) + 1;
        }

        $entry = [
            'id' => $next_id,
            'type' => $type,
            'amount' => (string) $amount_raw,
            'note' => $note,
            'createdUtc' => gmdate('c'),
        ];
        array_unshift($ledger, $entry);
        $ledger = array_slice($ledger, 0, 200);
        update_option('quick_accountant_entries', $ledger);

        $workspace = $this->quick_accountant_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'entryId' => $next_id,
            'type' => $type,
            'amount' => (string) $amount_raw,
            'note' => $note,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'entries' => isset($workspace['entries']) && is_array($workspace['entries']) ? $workspace['entries'] : [],
            'categories' => isset($workspace['categories']) && is_array($workspace['categories']) ? $workspace['categories'] : [],
            'budgets' => isset($workspace['budgets']) && is_array($workspace['budgets']) ? $workspace['budgets'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_accountant_save_category_payload(array $payload)
    {
        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : '';
        if ($name === '') {
            return new WP_Error('quick_accountant_category_name_required', 'Category name is required.', ['status' => 400]);
        }

        $categories = get_option('quick_accountant_categories', []);
        if (!is_array($categories)) {
            $categories = [];
        }
        $next_id = 1;
        if (count($categories) > 0 && isset($categories[0]['id'])) {
            $next_id = ((int) $categories[0]['id']) + 1;
        }

        $entry = [
            'id' => $next_id,
            'name' => $name,
            'type' => isset($payload['type']) ? sanitize_key((string) $payload['type']) : 'expense',
            'updatedUtc' => gmdate('c'),
        ];
        array_unshift($categories, $entry);
        $categories = array_slice($categories, 0, 200);
        update_option('quick_accountant_categories', $categories);

        $workspace = $this->quick_accountant_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'categoryId' => $next_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'entries' => isset($workspace['entries']) && is_array($workspace['entries']) ? $workspace['entries'] : [],
            'categories' => isset($workspace['categories']) && is_array($workspace['categories']) ? $workspace['categories'] : [],
            'budgets' => isset($workspace['budgets']) && is_array($workspace['budgets']) ? $workspace['budgets'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_accountant_save_budget_payload(array $payload)
    {
        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : '';
        $monthly_amount = isset($payload['monthlyAmount']) ? wc_format_decimal((string) $payload['monthlyAmount']) : '';
        if ($name === '' || $monthly_amount === '') {
            return new WP_Error('quick_accountant_budget_required', 'Budget name and monthlyAmount are required.', ['status' => 400]);
        }

        $budgets = get_option('quick_accountant_budgets', []);
        if (!is_array($budgets)) {
            $budgets = [];
        }
        $next_id = 1;
        if (count($budgets) > 0 && isset($budgets[0]['id'])) {
            $next_id = ((int) $budgets[0]['id']) + 1;
        }

        $entry = [
            'id' => $next_id,
            'name' => $name,
            'monthlyAmount' => (string) $monthly_amount,
            'category' => isset($payload['category']) ? sanitize_text_field((string) $payload['category']) : '',
            'updatedUtc' => gmdate('c'),
        ];
        array_unshift($budgets, $entry);
        $budgets = array_slice($budgets, 0, 200);
        update_option('quick_accountant_budgets', $budgets);

        $workspace = $this->quick_accountant_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'budgetId' => $next_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'entries' => isset($workspace['entries']) && is_array($workspace['entries']) ? $workspace['entries'] : [],
            'categories' => isset($workspace['categories']) && is_array($workspace['categories']) ? $workspace['categories'] : [],
            'budgets' => isset($workspace['budgets']) && is_array($workspace['budgets']) ? $workspace['budgets'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_accountant_report_range_payload(array $payload)
    {
        $from = isset($payload['fromUtc']) ? sanitize_text_field((string) $payload['fromUtc']) : '';
        $to = isset($payload['toUtc']) ? sanitize_text_field((string) $payload['toUtc']) : '';

        try {
            $from_dt = $from !== '' ? new DateTime($from) : new DateTime('-30 days');
        } catch (Throwable $e) {
            return new WP_Error('quick_accountant_from_invalid', 'fromUtc is invalid.', ['status' => 400]);
        }
        try {
            $to_dt = $to !== '' ? new DateTime($to) : new DateTime('now');
        } catch (Throwable $e) {
            return new WP_Error('quick_accountant_to_invalid', 'toUtc is invalid.', ['status' => 400]);
        }

        $orders = wc_get_orders([
            'limit' => 500,
            'date_created' => $from_dt->format('Y-m-d H:i:s') . '...' . $to_dt->format('Y-m-d H:i:s'),
            'return' => 'objects',
        ]);

        $sales_total = 0.0;
        $refunded_total = 0.0;
        $tax_total = 0.0;
        $shipping_total = 0.0;
        $order_count = 0;

        foreach ($orders as $order) {
            if (!$order instanceof WC_Order) {
                continue;
            }

            $order_count++;
            $sales_total += (float) $order->get_total();
            $refunded_total += (float) $order->get_total_refunded();
            $tax_total += (float) $order->get_total_tax();
            $shipping_total += (float) $order->get_shipping_total();
        }

        $net = $sales_total - $refunded_total;
        $workspace = $this->quick_accountant_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'range' => [
                'fromUtc' => $from_dt->format(DateTimeInterface::ATOM),
                'toUtc' => $to_dt->format(DateTimeInterface::ATOM),
            ],
            'report' => [
                'orders' => $order_count,
                'grossSales' => round($sales_total, 2),
                'refunded' => round($refunded_total, 2),
                'netSales' => round($net, 2),
                'tax' => round($tax_total, 2),
                'shipping' => round($shipping_total, 2),
            ],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'entries' => isset($workspace['entries']) && is_array($workspace['entries']) ? $workspace['entries'] : [],
            'categories' => isset($workspace['categories']) && is_array($workspace['categories']) ? $workspace['categories'] : [],
            'budgets' => isset($workspace['budgets']) && is_array($workspace['budgets']) ? $workspace['budgets'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_accountant_export_csv_payload(array $payload)
    {
        $entity = isset($payload['entity']) ? sanitize_key((string) $payload['entity']) : 'entries';
        if (!in_array($entity, ['entries', 'categories', 'budgets'], true)) {
            return new WP_Error('quick_accountant_export_entity_invalid', 'entity must be entries, categories, or budgets.', ['status' => 400]);
        }

        $rows = [];
        if ($entity === 'entries') {
            $entries = get_option('quick_accountant_entries', []);
            if (!is_array($entries)) {
                $entries = [];
            }
            $rows[] = ['id', 'type', 'amount', 'note', 'createdUtc'];
            foreach ($entries as $entry) {
                if (!is_array($entry)) {
                    continue;
                }
                $rows[] = [
                    (string) ($entry['id'] ?? ''),
                    (string) ($entry['type'] ?? ''),
                    (string) ($entry['amount'] ?? ''),
                    (string) ($entry['note'] ?? ''),
                    (string) ($entry['createdUtc'] ?? ''),
                ];
            }
        } elseif ($entity === 'categories') {
            $categories = get_option('quick_accountant_categories', []);
            if (!is_array($categories)) {
                $categories = [];
            }
            $rows[] = ['id', 'name', 'type', 'updatedUtc'];
            foreach ($categories as $category) {
                if (!is_array($category)) {
                    continue;
                }
                $rows[] = [
                    (string) ($category['id'] ?? ''),
                    (string) ($category['name'] ?? ''),
                    (string) ($category['type'] ?? ''),
                    (string) ($category['updatedUtc'] ?? ''),
                ];
            }
        } else {
            $budgets = get_option('quick_accountant_budgets', []);
            if (!is_array($budgets)) {
                $budgets = [];
            }
            $rows[] = ['id', 'name', 'monthlyAmount', 'category', 'updatedUtc'];
            foreach ($budgets as $budget) {
                if (!is_array($budget)) {
                    continue;
                }
                $rows[] = [
                    (string) ($budget['id'] ?? ''),
                    (string) ($budget['name'] ?? ''),
                    (string) ($budget['monthlyAmount'] ?? ''),
                    (string) ($budget['category'] ?? ''),
                    (string) ($budget['updatedUtc'] ?? ''),
                ];
            }
        }

        $handle = fopen('php://temp', 'r+');
        if ($handle === false) {
            return new WP_Error('quick_accountant_export_open_failed', 'Could not open csv buffer.', ['status' => 500]);
        }
        foreach ($rows as $row) {
            fputcsv($handle, $row);
        }
        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);
        if (!is_string($csv)) {
            return new WP_Error('quick_accountant_export_read_failed', 'Could not read csv buffer.', ['status' => 500]);
        }

        return [
            'entity' => $entity,
            'filename' => sprintf('quick-accountant-%s-%s.csv', $entity, gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_forms_open_payload(): array
    {
        $forms = $this->quick_forms_get_forms();
        $submissions = $this->quick_forms_get_submissions();

        $published = 0;
        foreach ($forms as $form) {
            if (!is_array($form)) {
                continue;
            }
            $status = isset($form['status']) ? sanitize_key((string) $form['status']) : 'draft';
            if (in_array($status, ['publish', 'active'], true)) {
                $published++;
            }
        }

        $new_submissions = 0;
        foreach ($submissions as $submission) {
            if (!is_array($submission)) {
                continue;
            }
            if (isset($submission['status']) && sanitize_key((string) $submission['status']) === 'new') {
                $new_submissions++;
            }
        }

        return [
            'summary' => [
                'totalForms' => count($forms),
                'publishedForms' => $published,
                'draftForms' => max(0, count($forms) - $published),
                'totalSubmissions' => count($submissions),
                'newSubmissions' => $new_submissions,
            ],
            'forms' => array_slice($forms, 0, 50),
            'submissions' => array_slice($submissions, 0, 50),
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_forms_save_form_payload(array $payload)
    {
        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : '';
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : 'draft';
        $slug = isset($payload['slug']) ? sanitize_title((string) $payload['slug']) : '';
        $fields = isset($payload['fields']) && is_array($payload['fields']) ? $payload['fields'] : [];
        $settings = isset($payload['settings']) && is_array($payload['settings']) ? $payload['settings'] : [];

        if ($name === '') {
            return new WP_Error('quick_forms_name_required', 'Form name is required.', ['status' => 400]);
        }
        if (!in_array($status, ['draft', 'publish', 'active', 'inactive'], true)) {
            $status = 'draft';
        }
        if ($slug === '') {
            $slug = sanitize_title($name);
        }

        $clean_fields = $this->quick_forms_sanitize_fields($fields);
        if (empty($clean_fields)) {
            return new WP_Error('quick_forms_fields_required', 'At least one valid field is required.', ['status' => 400]);
        }
        $clean_settings = $this->quick_forms_sanitize_settings($settings);

        $forms = $this->quick_forms_get_forms();
        $next_id = 1;
        if (count($forms) > 0 && isset($forms[0]['id'])) {
            $next_id = ((int) $forms[0]['id']) + 1;
        }

        $entry = [
            'id' => $next_id,
            'name' => $name,
            'slug' => $slug,
            'status' => $status,
            'fields' => $clean_fields,
            'settings' => $clean_settings,
            'updatedUtc' => gmdate('c'),
        ];
        array_unshift($forms, $entry);
        $forms = array_slice($forms, 0, 200);
        update_option('quick_forms_configs', $forms);

        $workspace = $this->quick_forms_open_payload();
        return [
            'formId' => $next_id,
            'name' => $name,
            'slug' => $slug,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'forms' => isset($workspace['forms']) && is_array($workspace['forms']) ? $workspace['forms'] : [],
            'submissions' => isset($workspace['submissions']) && is_array($workspace['submissions']) ? $workspace['submissions'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_forms_update_form_payload(array $payload)
    {
        $form_id = isset($payload['formId']) ? absint($payload['formId']) : 0;
        if ($form_id <= 0) {
            return new WP_Error('quick_forms_form_required', 'Valid formId is required.', ['status' => 400]);
        }

        $forms = $this->quick_forms_get_forms();
        $target_index = -1;
        foreach ($forms as $index => $form) {
            if (is_array($form) && isset($form['id']) && absint($form['id']) === $form_id) {
                $target_index = (int) $index;
                break;
            }
        }
        if ($target_index < 0) {
            return new WP_Error('quick_forms_form_not_found', 'Form not found.', ['status' => 404]);
        }

        $current = is_array($forms[$target_index]) ? $forms[$target_index] : [];
        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : (string) ($current['name'] ?? '');
        $slug = isset($payload['slug']) ? sanitize_title((string) $payload['slug']) : (string) ($current['slug'] ?? '');
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : sanitize_key((string) ($current['status'] ?? 'draft'));
        if ($name === '') {
            return new WP_Error('quick_forms_name_required', 'Form name is required.', ['status' => 400]);
        }
        if ($slug === '') {
            $slug = sanitize_title($name);
        }
        if (!in_array($status, ['draft', 'publish', 'active', 'inactive'], true)) {
            $status = 'draft';
        }

        $fields_input = isset($payload['fields']) && is_array($payload['fields'])
            ? $payload['fields']
            : (isset($current['fields']) && is_array($current['fields']) ? $current['fields'] : []);
        $fields = $this->quick_forms_sanitize_fields($fields_input);
        if (empty($fields)) {
            return new WP_Error('quick_forms_fields_required', 'At least one valid field is required.', ['status' => 400]);
        }

        $settings_input = isset($payload['settings']) && is_array($payload['settings'])
            ? $payload['settings']
            : (isset($current['settings']) && is_array($current['settings']) ? $current['settings'] : []);
        $settings = $this->quick_forms_sanitize_settings($settings_input);

        $forms[$target_index] = [
            'id' => $form_id,
            'name' => $name,
            'slug' => $slug,
            'status' => $status,
            'fields' => $fields,
            'settings' => $settings,
            'updatedUtc' => gmdate('c'),
        ];
        update_option('quick_forms_configs', array_values($forms));

        $workspace = $this->quick_forms_open_payload();
        return [
            'formId' => $form_id,
            'name' => $name,
            'slug' => $slug,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'forms' => isset($workspace['forms']) && is_array($workspace['forms']) ? $workspace['forms'] : [],
            'submissions' => isset($workspace['submissions']) && is_array($workspace['submissions']) ? $workspace['submissions'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_forms_set_form_status_payload(array $payload)
    {
        $form_id = isset($payload['formId']) ? absint($payload['formId']) : 0;
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        if ($form_id <= 0) {
            return new WP_Error('quick_forms_form_required', 'Valid formId is required.', ['status' => 400]);
        }
        if (!in_array($status, ['active', 'inactive', 'publish', 'draft'], true)) {
            return new WP_Error('quick_forms_status_invalid', 'status must be active, inactive, publish, or draft.', ['status' => 400]);
        }

        $forms = $this->quick_forms_get_forms();
        $found = false;
        foreach ($forms as &$form) {
            if (!is_array($form) || !isset($form['id']) || absint($form['id']) !== $form_id) {
                continue;
            }
            $form['status'] = $status;
            $form['updatedUtc'] = gmdate('c');
            $found = true;
            break;
        }
        unset($form);
        if (!$found) {
            return new WP_Error('quick_forms_form_not_found', 'Form not found.', ['status' => 404]);
        }

        update_option('quick_forms_configs', array_values($forms));
        $workspace = $this->quick_forms_open_payload();
        return [
            'formId' => $form_id,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'forms' => isset($workspace['forms']) && is_array($workspace['forms']) ? $workspace['forms'] : [],
            'submissions' => isset($workspace['submissions']) && is_array($workspace['submissions']) ? $workspace['submissions'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_forms_duplicate_form_payload(array $payload)
    {
        $form_id = isset($payload['formId']) ? absint($payload['formId']) : 0;
        if ($form_id <= 0) {
            return new WP_Error('quick_forms_form_required', 'Valid formId is required.', ['status' => 400]);
        }

        $forms = $this->quick_forms_get_forms();
        $source = null;
        foreach ($forms as $form) {
            if (is_array($form) && isset($form['id']) && absint($form['id']) === $form_id) {
                $source = $form;
                break;
            }
        }
        if (!is_array($source)) {
            return new WP_Error('quick_forms_form_not_found', 'Form not found.', ['status' => 404]);
        }

        $next_id = 1;
        if (count($forms) > 0 && isset($forms[0]['id'])) {
            $next_id = ((int) $forms[0]['id']) + 1;
        }

        $copy_name = sprintf('%s (Copy)', (string) ($source['name'] ?? 'Form'));
        $copy_slug = sanitize_title((string) ($source['slug'] ?? 'form')) . '-copy-' . gmdate('His');
        $entry = [
            'id' => $next_id,
            'name' => $copy_name,
            'slug' => $copy_slug,
            'status' => 'draft',
            'fields' => isset($source['fields']) && is_array($source['fields']) ? $source['fields'] : [],
            'settings' => isset($source['settings']) && is_array($source['settings']) ? $source['settings'] : [],
            'updatedUtc' => gmdate('c'),
        ];

        array_unshift($forms, $entry);
        $forms = array_slice($forms, 0, 200);
        update_option('quick_forms_configs', $forms);

        $workspace = $this->quick_forms_open_payload();
        return [
            'formId' => $next_id,
            'name' => $copy_name,
            'slug' => $copy_slug,
            'status' => 'draft',
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'forms' => isset($workspace['forms']) && is_array($workspace['forms']) ? $workspace['forms'] : [],
            'submissions' => isset($workspace['submissions']) && is_array($workspace['submissions']) ? $workspace['submissions'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_forms_delete_form_payload(array $payload)
    {
        $form_id = isset($payload['formId']) ? absint($payload['formId']) : 0;
        if ($form_id <= 0) {
            return new WP_Error('quick_forms_form_required', 'Valid formId is required.', ['status' => 400]);
        }

        $forms = $this->quick_forms_get_forms();
        $next_forms = [];
        $found = false;
        foreach ($forms as $form) {
            if (!is_array($form) || !isset($form['id'])) {
                continue;
            }
            if (absint($form['id']) === $form_id) {
                $found = true;
                continue;
            }
            $next_forms[] = $form;
        }
        if (!$found) {
            return new WP_Error('quick_forms_form_not_found', 'Form not found.', ['status' => 404]);
        }
        update_option('quick_forms_configs', array_values($next_forms));

        $submissions = $this->quick_forms_get_submissions();
        $next_submissions = [];
        foreach ($submissions as $submission) {
            if (!is_array($submission)) {
                continue;
            }
            if (isset($submission['formId']) && absint($submission['formId']) === $form_id) {
                continue;
            }
            $next_submissions[] = $submission;
        }
        update_option('quick_forms_submissions', array_values($next_submissions));

        $workspace = $this->quick_forms_open_payload();
        return [
            'formId' => $form_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'forms' => isset($workspace['forms']) && is_array($workspace['forms']) ? $workspace['forms'] : [],
            'submissions' => isset($workspace['submissions']) && is_array($workspace['submissions']) ? $workspace['submissions'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_forms_record_submission_payload(array $payload)
    {
        $form_id = isset($payload['formId']) ? absint($payload['formId']) : 0;
        if ($form_id <= 0) {
            return new WP_Error('quick_forms_form_required', 'Valid formId is required.', ['status' => 400]);
        }

        $forms = $this->quick_forms_get_forms();
        $form_name = '';
        foreach ($forms as $form) {
            if (!is_array($form) || !isset($form['id']) || absint($form['id']) !== $form_id) {
                continue;
            }
            $form_name = isset($form['name']) ? sanitize_text_field((string) $form['name']) : '';
            break;
        }
        if ($form_name === '') {
            return new WP_Error('quick_forms_form_not_found', 'Form not found.', ['status' => 404]);
        }

        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : 'new';
        if (!in_array($status, ['new', 'read'], true)) {
            $status = 'new';
        }

        $data = isset($payload['data']) && is_array($payload['data']) ? $payload['data'] : [];
        $files = isset($payload['files']) && is_array($payload['files']) ? $payload['files'] : [];
        $clean_data = [];
        foreach ($data as $key => $value) {
            $clean_key = sanitize_key((string) $key);
            if ($clean_key === '') {
                continue;
            }
            $clean_data[$clean_key] = sanitize_text_field((string) $value);
        }
        $clean_files = [];
        foreach ($files as $file) {
            if (!is_array($file)) {
                continue;
            }
            $clean_files[] = [
                'url' => isset($file['url']) ? esc_url_raw((string) $file['url']) : '',
                'name' => isset($file['name']) ? sanitize_file_name((string) $file['name']) : '',
                'size' => isset($file['size']) ? absint($file['size']) : 0,
            ];
        }

        $submissions = $this->quick_forms_get_submissions();
        $next_id = 1;
        if (count($submissions) > 0 && isset($submissions[0]['id'])) {
            $next_id = ((int) $submissions[0]['id']) + 1;
        }

        $entry = [
            'id' => $next_id,
            'formId' => $form_id,
            'formName' => $form_name,
            'status' => $status,
            'submittedData' => $clean_data,
            'files' => $clean_files,
            'createdUtc' => gmdate('c'),
        ];
        array_unshift($submissions, $entry);
        $submissions = array_slice($submissions, 0, 2000);
        update_option('quick_forms_submissions', $submissions);

        $workspace = $this->quick_forms_open_payload();
        return [
            'submissionId' => $next_id,
            'formId' => $form_id,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'forms' => isset($workspace['forms']) && is_array($workspace['forms']) ? $workspace['forms'] : [],
            'submissions' => isset($workspace['submissions']) && is_array($workspace['submissions']) ? $workspace['submissions'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_forms_list_submissions_payload(array $payload)
    {
        $form_id = isset($payload['formId']) ? absint($payload['formId']) : 0;
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        $page = isset($payload['page']) ? absint($payload['page']) : 1;
        $per_page = isset($payload['perPage']) ? absint($payload['perPage']) : 20;
        if ($page < 1) {
            $page = 1;
        }
        if ($per_page < 1) {
            $per_page = 20;
        }
        if ($per_page > 100) {
            $per_page = 100;
        }

        $all = $this->quick_forms_get_submissions();
        $filtered = [];
        foreach ($all as $submission) {
            if (!is_array($submission)) {
                continue;
            }
            if ($form_id > 0 && (!isset($submission['formId']) || absint($submission['formId']) !== $form_id)) {
                continue;
            }
            if ($status !== '' && in_array($status, ['new', 'read'], true)) {
                $submission_status = isset($submission['status']) ? sanitize_key((string) $submission['status']) : 'new';
                if ($submission_status !== $status) {
                    continue;
                }
            }
            $filtered[] = $submission;
        }

        $total = count($filtered);
        $offset = ($page - 1) * $per_page;
        $rows = array_slice($filtered, $offset, $per_page);
        $total_pages = (int) ceil($total / $per_page);
        if ($total_pages < 1) {
            $total_pages = 1;
        }

        return [
            'submissions' => $rows,
            'page' => $page,
            'perPage' => $per_page,
            'total' => $total,
            'totalPages' => $total_pages,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_forms_set_submission_status_payload(array $payload)
    {
        $submission_id = isset($payload['submissionId']) ? absint($payload['submissionId']) : 0;
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        if ($submission_id <= 0) {
            return new WP_Error('quick_forms_submission_required', 'Valid submissionId is required.', ['status' => 400]);
        }
        if (!in_array($status, ['new', 'read'], true)) {
            return new WP_Error('quick_forms_submission_status_invalid', 'status must be new or read.', ['status' => 400]);
        }

        $submissions = $this->quick_forms_get_submissions();
        $found = false;
        foreach ($submissions as &$submission) {
            if (!is_array($submission) || !isset($submission['id']) || absint($submission['id']) !== $submission_id) {
                continue;
            }
            $submission['status'] = $status;
            $found = true;
            break;
        }
        unset($submission);
        if (!$found) {
            return new WP_Error('quick_forms_submission_not_found', 'Submission not found.', ['status' => 404]);
        }
        update_option('quick_forms_submissions', array_values($submissions));

        $workspace = $this->quick_forms_open_payload();
        return [
            'submissionId' => $submission_id,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'submissions' => isset($workspace['submissions']) && is_array($workspace['submissions']) ? $workspace['submissions'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_forms_delete_submission_payload(array $payload)
    {
        $submission_id = isset($payload['submissionId']) ? absint($payload['submissionId']) : 0;
        if ($submission_id <= 0) {
            return new WP_Error('quick_forms_submission_required', 'Valid submissionId is required.', ['status' => 400]);
        }

        $submissions = $this->quick_forms_get_submissions();
        $next = [];
        $found = false;
        foreach ($submissions as $submission) {
            if (!is_array($submission) || !isset($submission['id'])) {
                continue;
            }
            if (absint($submission['id']) === $submission_id) {
                $found = true;
                continue;
            }
            $next[] = $submission;
        }
        if (!$found) {
            return new WP_Error('quick_forms_submission_not_found', 'Submission not found.', ['status' => 404]);
        }
        update_option('quick_forms_submissions', array_values($next));

        $workspace = $this->quick_forms_open_payload();
        return [
            'submissionId' => $submission_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'submissions' => isset($workspace['submissions']) && is_array($workspace['submissions']) ? $workspace['submissions'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_forms_export_submissions_csv_payload(array $payload)
    {
        $form_id = isset($payload['formId']) ? absint($payload['formId']) : 0;
        if ($form_id <= 0) {
            return new WP_Error('quick_forms_form_required', 'Valid formId is required for CSV export.', ['status' => 400]);
        }

        $submissions = $this->quick_forms_get_submissions();
        $rows = [['Submission ID', 'Form ID', 'Form Name', 'Status', 'Created UTC', 'Data JSON', 'Files JSON']];
        foreach ($submissions as $submission) {
            if (!is_array($submission)) {
                continue;
            }
            if (!isset($submission['formId']) || absint($submission['formId']) !== $form_id) {
                continue;
            }
            $rows[] = [
                (string) ($submission['id'] ?? ''),
                (string) ($submission['formId'] ?? ''),
                (string) ($submission['formName'] ?? ''),
                (string) ($submission['status'] ?? ''),
                (string) ($submission['createdUtc'] ?? ''),
                wp_json_encode(isset($submission['submittedData']) && is_array($submission['submittedData']) ? $submission['submittedData'] : []),
                wp_json_encode(isset($submission['files']) && is_array($submission['files']) ? $submission['files'] : []),
            ];
        }

        $handle = fopen('php://temp', 'r+');
        if ($handle === false) {
            return new WP_Error('quick_forms_export_open_failed', 'Could not open csv buffer.', ['status' => 500]);
        }
        foreach ($rows as $row) {
            fputcsv($handle, $row);
        }
        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);
        if (!is_string($csv)) {
            return new WP_Error('quick_forms_export_read_failed', 'Could not read csv buffer.', ['status' => 500]);
        }

        return [
            'formId' => $form_id,
            'filename' => sprintf('quick-forms-submissions-%d-%s.csv', $form_id, gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_forms_get_forms()
    {
        $forms = get_option('quick_forms_configs', []);
        if (!is_array($forms)) {
            $forms = [];
        }
        $clean = [];
        foreach ($forms as $form) {
            if (!is_array($form)) {
                continue;
            }
            if (!isset($form['id'])) {
                continue;
            }
            $clean[] = [
                'id' => absint($form['id']),
                'name' => isset($form['name']) ? sanitize_text_field((string) $form['name']) : 'Form',
                'slug' => isset($form['slug']) ? sanitize_title((string) $form['slug']) : '',
                'status' => isset($form['status']) ? sanitize_key((string) $form['status']) : 'draft',
                'fields' => isset($form['fields']) && is_array($form['fields']) ? $form['fields'] : [],
                'settings' => isset($form['settings']) && is_array($form['settings']) ? $form['settings'] : [],
                'updatedUtc' => isset($form['updatedUtc']) ? sanitize_text_field((string) $form['updatedUtc']) : gmdate('c'),
            ];
        }

        usort($clean, static function (array $a, array $b) {
            return ((int) ($b['id'] ?? 0)) <=> ((int) ($a['id'] ?? 0));
        });

        return $clean;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_forms_get_submissions()
    {
        $submissions = get_option('quick_forms_submissions', []);
        if (!is_array($submissions)) {
            $submissions = [];
        }
        $clean = [];
        foreach ($submissions as $submission) {
            if (!is_array($submission) || !isset($submission['id'])) {
                continue;
            }
            $clean[] = [
                'id' => absint($submission['id']),
                'formId' => isset($submission['formId']) ? absint($submission['formId']) : 0,
                'formName' => isset($submission['formName']) ? sanitize_text_field((string) $submission['formName']) : '',
                'status' => isset($submission['status']) ? sanitize_key((string) $submission['status']) : 'new',
                'submittedData' => isset($submission['submittedData']) && is_array($submission['submittedData']) ? $submission['submittedData'] : [],
                'files' => isset($submission['files']) && is_array($submission['files']) ? $submission['files'] : [],
                'createdUtc' => isset($submission['createdUtc']) ? sanitize_text_field((string) $submission['createdUtc']) : gmdate('c'),
            ];
        }

        usort($clean, static function (array $a, array $b) {
            return ((int) ($b['id'] ?? 0)) <=> ((int) ($a['id'] ?? 0));
        });

        return $clean;
    }

    /**
     * @param array<int, mixed> $fields
     * @return array<int, array<string, mixed>>
     */
    private function quick_forms_sanitize_fields(array $fields)
    {
        $allowed_types = ['text', 'email', 'phone', 'textarea', 'dropdown', 'checkbox', 'radio', 'consent', 'hidden', 'file'];
        $clean_fields = [];
        foreach ($fields as $field) {
            if (!is_array($field)) {
                continue;
            }

            $key = isset($field['key']) ? sanitize_key((string) $field['key']) : '';
            if ($key === '') {
                $key = isset($field['name']) ? sanitize_key((string) $field['name']) : '';
            }
            if ($key === '') {
                continue;
            }

            $type = isset($field['type']) ? sanitize_key((string) $field['type']) : 'text';
            if (!in_array($type, $allowed_types, true)) {
                $type = 'text';
            }

            $options = [];
            if (isset($field['options'])) {
                $raw_options = is_array($field['options']) ? $field['options'] : explode(',', (string) $field['options']);
                foreach ($raw_options as $option) {
                    $option_clean = sanitize_text_field((string) $option);
                    if ($option_clean !== '') {
                        $options[] = $option_clean;
                    }
                }
            }

            $clean_fields[] = [
                'key' => $key,
                'label' => isset($field['label']) ? sanitize_text_field((string) $field['label']) : ucfirst($key),
                'type' => $type,
                'required' => !empty($field['required']),
                'placeholder' => isset($field['placeholder']) ? sanitize_text_field((string) $field['placeholder']) : '',
                'default' => isset($field['default']) ? sanitize_text_field((string) $field['default']) : '',
                'options' => array_values(array_unique($options)),
            ];
        }

        return $clean_fields;
    }

    /**
     * @param array<string, mixed> $settings
     * @return array<string, mixed>
     */
    private function quick_forms_sanitize_settings(array $settings)
    {
        $submission_mode = isset($settings['submission_mode']) && sanitize_key((string) $settings['submission_mode']) === 'instant_estimate'
            ? 'instant_estimate'
            : 'capture_only';

        return [
            'quote_type' => isset($settings['quote_type']) ? sanitize_title((string) $settings['quote_type']) : '',
            'submission_mode' => $submission_mode,
            'success_message' => isset($settings['success_message'])
                ? sanitize_textarea_field((string) $settings['success_message'])
                : 'Thank you! Your submission has been received.',
            'admin_notification' => !empty($settings['admin_notification']) ? 1 : 0,
            'notification_recipients' => isset($settings['notification_recipients'])
                ? sanitize_text_field((string) $settings['notification_recipients'])
                : '',
            'email_subject' => isset($settings['email_subject'])
                ? sanitize_text_field((string) $settings['email_subject'])
                : 'New submission for {{form_name}}',
            'redirect_url' => isset($settings['redirect_url']) ? esc_url_raw((string) $settings['redirect_url']) : '',
            'save_to_db' => isset($settings['save_to_db']) ? (!empty($settings['save_to_db']) ? 1 : 0) : 1,
            'spam_protection' => isset($settings['spam_protection']) ? (!empty($settings['spam_protection']) ? 1 : 0) : 1,
        ];
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    private function quick_quotes_open_payload()
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_quotes_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $quotes = $this->quick_quotes_get_quotes();
        $settings = $this->quick_quotes_get_settings();

        $open_quotes = 0;
        $approved_quotes = 0;
        $pending_quotes = 0;
        $rejected_quotes = 0;
        foreach ($quotes as $quote) {
            if (!is_array($quote) || !isset($quote['status'])) {
                continue;
            }
            $status = sanitize_key((string) $quote['status']);
            if ($status === 'open') {
                $open_quotes++;
            }
            if ($status === 'approved') {
                $approved_quotes++;
            }
            if ($status === 'pending') {
                $pending_quotes++;
            }
            if ($status === 'rejected') {
                $rejected_quotes++;
            }
        }

        return [
            'summary' => [
                'totalQuotes' => count($quotes),
                'openQuotes' => $open_quotes,
                'approvedQuotes' => $approved_quotes,
                'pendingQuotes' => $pending_quotes,
                'rejectedQuotes' => $rejected_quotes,
            ],
            'settings' => $settings,
            'quotes' => array_slice($quotes, 0, 100),
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_quotes_create_quote_payload(array $payload)
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_quotes_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $settings = $this->quick_quotes_get_settings();
        $customer_name = isset($payload['customerName']) ? sanitize_text_field((string) $payload['customerName']) : '';
        $customer_email = isset($payload['customerEmail']) ? sanitize_email((string) $payload['customerEmail']) : '';
        $product_id = isset($payload['productId']) ? absint($payload['productId']) : 0;
        $quantity = isset($payload['quantity']) ? max(1, absint($payload['quantity'])) : 1;
        $project_type = isset($payload['projectType']) ? sanitize_text_field((string) $payload['projectType']) : 'General';
        $line_items = isset($payload['lineItems']) && is_array($payload['lineItems']) ? $payload['lineItems'] : [];
        $note = isset($payload['note']) ? sanitize_textarea_field((string) $payload['note']) : '';
        $tax_percent = isset($payload['taxPercent'])
            ? max(0.0, min(100.0, (float) $payload['taxPercent']))
            : (float) $settings['default_tax_percent'];
        $discount_percent = isset($payload['discountPercent'])
            ? max(0.0, min(100.0, (float) $payload['discountPercent']))
            : (float) $settings['default_discount_percent'];
        $payment_mode = isset($payload['paymentMode']) ? sanitize_key((string) $payload['paymentMode']) : 'full';
        if (!in_array($payment_mode, ['full', 'percentage', 'consultation'], true)) {
            $payment_mode = 'full';
        }
        $payment_percent = isset($payload['paymentPercent']) ? max(0.0, min(100.0, (float) $payload['paymentPercent'])) : 100.0;
        $stripe_payment_url = isset($payload['stripePaymentUrl']) ? esc_url_raw((string) $payload['stripePaymentUrl']) : '';

        if ($customer_name === '') {
            return new WP_Error('quick_quotes_customer_required', 'Customer name is required.', ['status' => 400]);
        }
        if ($customer_email === '' || !is_email($customer_email)) {
            return new WP_Error('quick_quotes_email_required', 'Valid customer email is required.', ['status' => 400]);
        }

        $clean_line_items = [];
        if (!empty($line_items)) {
            $clean_line_items = $this->quick_quotes_sanitize_line_items($line_items);
        }
        if (empty($clean_line_items)) {
            if ($product_id <= 0) {
                return new WP_Error(
                    'quick_quotes_item_required',
                    'Provide either lineItems or a valid productId.',
                    ['status' => 400]
                );
            }

            $product = wc_get_product($product_id);
            if (!$product instanceof WC_Product) {
                return new WP_Error('quick_quotes_product_not_found', 'Product not found.', ['status' => 404]);
            }

            $unit_price = (float) $product->get_regular_price();
            $clean_line_items[] = [
                'description' => $product->get_name(),
                'qty' => $quantity,
                'unit_price' => round(max(0, $unit_price), 2),
                'price' => round(max(0, $unit_price) * $quantity, 2),
            ];
        }

        $totals = $this->quick_quotes_calculate_totals($clean_line_items, $tax_percent, $discount_percent);
        $due_today = round((float) $totals['final_total'] * ($payment_percent / 100), 2);

        $quotes = $this->quick_quotes_get_quotes();
        $next_id = 1;
        if (count($quotes) > 0 && isset($quotes[0]['id'])) {
            $next_id = ((int) $quotes[0]['id']) + 1;
        }

        $entry = [
            'id' => $next_id,
            'status' => isset($payload['status']) ? sanitize_key((string) $payload['status']) : 'pending',
            'customerName' => $customer_name,
            'customerEmail' => $customer_email,
            'projectType' => $project_type,
            'productId' => $product_id > 0 ? $product_id : 0,
            'quantity' => $quantity,
            'lineItems' => $clean_line_items,
            'subtotal' => $totals['subtotal'],
            'taxPercent' => $tax_percent,
            'discountPercent' => $discount_percent,
            'taxAmount' => $totals['tax_amount'],
            'discountAmount' => $totals['discount_amount'],
            'estimatedTotal' => $totals['final_total'],
            'dueToday' => $due_today,
            'paymentMode' => $payment_mode,
            'paymentPercent' => $payment_percent,
            'stripePaymentUrl' => $stripe_payment_url,
            'note' => $note,
            'createdUtc' => gmdate('c'),
            'updatedUtc' => gmdate('c'),
        ];
        if (!in_array($entry['status'], ['open', 'pending', 'approved', 'rejected'], true)) {
            $entry['status'] = 'pending';
        }
        array_unshift($quotes, $entry);
        $quotes = array_slice($quotes, 0, 300);
        update_option('quick_quotes_requests', $quotes);

        $workspace = $this->quick_quotes_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'quoteId' => $next_id,
            'status' => (string) $entry['status'],
            'customerName' => $customer_name,
            'customerEmail' => $customer_email,
            'projectType' => $project_type,
            'productId' => $product_id > 0 ? $product_id : 0,
            'lineItems' => $clean_line_items,
            'estimatedTotal' => $totals['final_total'],
            'subtotal' => $totals['subtotal'],
            'taxPercent' => $tax_percent,
            'discountPercent' => $discount_percent,
            'dueToday' => $due_today,
            'paymentMode' => $payment_mode,
            'paymentPercent' => $payment_percent,
            'stripePaymentUrl' => $stripe_payment_url,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'quotes' => isset($workspace['quotes']) && is_array($workspace['quotes']) ? $workspace['quotes'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_quotes_update_quote_payload(array $payload)
    {
        $quote_id = isset($payload['quoteId']) ? absint($payload['quoteId']) : 0;
        if ($quote_id <= 0) {
            return new WP_Error('quick_quotes_quote_required', 'Valid quoteId is required.', ['status' => 400]);
        }

        $quotes = $this->quick_quotes_get_quotes();
        $index = -1;
        foreach ($quotes as $row_index => $quote) {
            if (is_array($quote) && isset($quote['id']) && absint($quote['id']) === $quote_id) {
                $index = (int) $row_index;
                break;
            }
        }
        if ($index < 0) {
            return new WP_Error('quick_quotes_not_found', 'Quote not found.', ['status' => 404]);
        }

        $existing = is_array($quotes[$index]) ? $quotes[$index] : [];
        $settings = $this->quick_quotes_get_settings();
        $customer_name = isset($payload['customerName'])
            ? sanitize_text_field((string) $payload['customerName'])
            : (string) ($existing['customerName'] ?? '');
        $customer_email = isset($payload['customerEmail'])
            ? sanitize_email((string) $payload['customerEmail'])
            : (string) ($existing['customerEmail'] ?? '');
        $project_type = isset($payload['projectType'])
            ? sanitize_text_field((string) $payload['projectType'])
            : (string) ($existing['projectType'] ?? 'General');
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : sanitize_key((string) ($existing['status'] ?? 'pending'));
        if (!in_array($status, ['open', 'pending', 'approved', 'rejected'], true)) {
            $status = 'pending';
        }
        if ($customer_name === '') {
            return new WP_Error('quick_quotes_customer_required', 'Customer name is required.', ['status' => 400]);
        }
        if ($customer_email === '' || !is_email($customer_email)) {
            return new WP_Error('quick_quotes_email_required', 'Valid customer email is required.', ['status' => 400]);
        }

        $line_items = isset($payload['lineItems']) && is_array($payload['lineItems'])
            ? $this->quick_quotes_sanitize_line_items($payload['lineItems'])
            : (isset($existing['lineItems']) && is_array($existing['lineItems']) ? $this->quick_quotes_sanitize_line_items($existing['lineItems']) : []);
        if (empty($line_items)) {
            return new WP_Error('quick_quotes_items_required', 'At least one valid line item is required.', ['status' => 400]);
        }

        $tax_percent = isset($payload['taxPercent'])
            ? max(0.0, min(100.0, (float) $payload['taxPercent']))
            : (isset($existing['taxPercent']) ? (float) $existing['taxPercent'] : (float) $settings['default_tax_percent']);
        $discount_percent = isset($payload['discountPercent'])
            ? max(0.0, min(100.0, (float) $payload['discountPercent']))
            : (isset($existing['discountPercent']) ? (float) $existing['discountPercent'] : (float) $settings['default_discount_percent']);
        $payment_mode = isset($payload['paymentMode'])
            ? sanitize_key((string) $payload['paymentMode'])
            : sanitize_key((string) ($existing['paymentMode'] ?? 'full'));
        if (!in_array($payment_mode, ['full', 'percentage', 'consultation'], true)) {
            $payment_mode = 'full';
        }
        $payment_percent = isset($payload['paymentPercent'])
            ? max(0.0, min(100.0, (float) $payload['paymentPercent']))
            : (isset($existing['paymentPercent']) ? (float) $existing['paymentPercent'] : 100.0);
        $note = isset($payload['note'])
            ? sanitize_textarea_field((string) $payload['note'])
            : (string) ($existing['note'] ?? '');
        $stripe_payment_url = isset($payload['stripePaymentUrl'])
            ? esc_url_raw((string) $payload['stripePaymentUrl'])
            : (string) ($existing['stripePaymentUrl'] ?? '');
        $totals = $this->quick_quotes_calculate_totals($line_items, $tax_percent, $discount_percent);
        $due_today = round((float) $totals['final_total'] * ($payment_percent / 100), 2);

        $quotes[$index] = array_merge($existing, [
            'id' => $quote_id,
            'status' => $status,
            'customerName' => $customer_name,
            'customerEmail' => $customer_email,
            'projectType' => $project_type,
            'lineItems' => $line_items,
            'subtotal' => $totals['subtotal'],
            'taxPercent' => $tax_percent,
            'discountPercent' => $discount_percent,
            'taxAmount' => $totals['tax_amount'],
            'discountAmount' => $totals['discount_amount'],
            'estimatedTotal' => $totals['final_total'],
            'dueToday' => $due_today,
            'paymentMode' => $payment_mode,
            'paymentPercent' => $payment_percent,
            'stripePaymentUrl' => $stripe_payment_url,
            'note' => $note,
            'updatedUtc' => gmdate('c'),
        ]);
        update_option('quick_quotes_requests', array_values($quotes));

        $workspace = $this->quick_quotes_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'quoteId' => $quote_id,
            'status' => $status,
            'estimatedTotal' => $totals['final_total'],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'quotes' => isset($workspace['quotes']) && is_array($workspace['quotes']) ? $workspace['quotes'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_quotes_set_status_payload(array $payload)
    {
        $quote_id = isset($payload['quoteId']) ? absint($payload['quoteId']) : 0;
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        if ($quote_id <= 0) {
            return new WP_Error('quick_quotes_quote_required', 'Valid quoteId is required.', ['status' => 400]);
        }
        if (!in_array($status, ['open', 'pending', 'approved', 'rejected'], true)) {
            return new WP_Error('quick_quotes_status_invalid', 'status must be open, pending, approved, or rejected.', ['status' => 400]);
        }

        $quotes = $this->quick_quotes_get_quotes();
        $found = false;
        foreach ($quotes as &$quote) {
            if (!is_array($quote) || !isset($quote['id']) || absint($quote['id']) !== $quote_id) {
                continue;
            }
            $quote['status'] = $status;
            $quote['updatedUtc'] = gmdate('c');
            $found = true;
            break;
        }
        unset($quote);
        if (!$found) {
            return new WP_Error('quick_quotes_not_found', 'Quote not found.', ['status' => 404]);
        }
        update_option('quick_quotes_requests', array_values($quotes));

        $workspace = $this->quick_quotes_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'quoteId' => $quote_id,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'quotes' => isset($workspace['quotes']) && is_array($workspace['quotes']) ? $workspace['quotes'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_quotes_delete_quote_payload(array $payload)
    {
        $quote_id = isset($payload['quoteId']) ? absint($payload['quoteId']) : 0;
        if ($quote_id <= 0) {
            return new WP_Error('quick_quotes_quote_required', 'Valid quoteId is required.', ['status' => 400]);
        }

        $quotes = $this->quick_quotes_get_quotes();
        $next_quotes = [];
        $found = false;
        foreach ($quotes as $quote) {
            if (!is_array($quote) || !isset($quote['id'])) {
                continue;
            }
            if (absint($quote['id']) === $quote_id) {
                $found = true;
                continue;
            }
            $next_quotes[] = $quote;
        }
        if (!$found) {
            return new WP_Error('quick_quotes_not_found', 'Quote not found.', ['status' => 404]);
        }
        update_option('quick_quotes_requests', array_values($next_quotes));

        $workspace = $this->quick_quotes_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'quoteId' => $quote_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'quotes' => isset($workspace['quotes']) && is_array($workspace['quotes']) ? $workspace['quotes'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_quotes_export_csv_payload(array $payload)
    {
        $status_filter = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        $quotes = $this->quick_quotes_get_quotes();

        $rows = [[
            'Quote ID',
            'Customer Name',
            'Customer Email',
            'Project Type',
            'Status',
            'Subtotal',
            'Tax Percent',
            'Discount Percent',
            'Total',
            'Due Today',
            'Payment Mode',
            'Payment Percent',
            'Created UTC',
            'Updated UTC',
            'Line Items JSON',
            'Note',
        ]];
        foreach ($quotes as $quote) {
            if (!is_array($quote)) {
                continue;
            }
            $status = isset($quote['status']) ? sanitize_key((string) $quote['status']) : 'pending';
            if ($status_filter !== '' && $status !== $status_filter) {
                continue;
            }

            $rows[] = [
                (string) ($quote['id'] ?? ''),
                (string) ($quote['customerName'] ?? ''),
                (string) ($quote['customerEmail'] ?? ''),
                (string) ($quote['projectType'] ?? ''),
                (string) $status,
                (string) ($quote['subtotal'] ?? ''),
                (string) ($quote['taxPercent'] ?? ''),
                (string) ($quote['discountPercent'] ?? ''),
                (string) ($quote['estimatedTotal'] ?? ''),
                (string) ($quote['dueToday'] ?? ''),
                (string) ($quote['paymentMode'] ?? ''),
                (string) ($quote['paymentPercent'] ?? ''),
                (string) ($quote['createdUtc'] ?? ''),
                (string) ($quote['updatedUtc'] ?? ''),
                wp_json_encode(isset($quote['lineItems']) && is_array($quote['lineItems']) ? $quote['lineItems'] : []),
                (string) ($quote['note'] ?? ''),
            ];
        }

        $handle = fopen('php://temp', 'r+');
        if ($handle === false) {
            return new WP_Error('quick_quotes_export_open_failed', 'Could not open csv buffer.', ['status' => 500]);
        }
        foreach ($rows as $row) {
            fputcsv($handle, $row);
        }
        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);
        if (!is_string($csv)) {
            return new WP_Error('quick_quotes_export_read_failed', 'Could not read csv buffer.', ['status' => 500]);
        }

        return [
            'status' => $status_filter,
            'filename' => sprintf('quick-quotes-%s.csv', gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_quotes_save_settings_payload(array $payload)
    {
        $current = $this->quick_quotes_get_settings();
        $next = $current;

        if (isset($payload['defaultTaxPercent'])) {
            $next['default_tax_percent'] = max(0.0, min(100.0, (float) $payload['defaultTaxPercent']));
        }
        if (isset($payload['defaultDiscountPercent'])) {
            $next['default_discount_percent'] = max(0.0, min(100.0, (float) $payload['defaultDiscountPercent']));
        }
        if (isset($payload['emailNotifications'])) {
            $next['email_notifications'] = !empty($payload['emailNotifications']) ? '1' : '0';
        }
        if (isset($payload['notificationEmail'])) {
            $email = sanitize_email((string) $payload['notificationEmail']);
            $next['notification_email'] = is_email($email) ? $email : '';
        }

        update_option('quick_quotes_settings', $next);
        $workspace = $this->quick_quotes_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'settings' => $next,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'quotes' => isset($workspace['quotes']) && is_array($workspace['quotes']) ? $workspace['quotes'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_quotes_get_quotes()
    {
        $quotes = get_option('quick_quotes_requests', []);
        if (!is_array($quotes)) {
            $quotes = [];
        }
        $clean = [];
        foreach ($quotes as $quote) {
            if (!is_array($quote) || !isset($quote['id'])) {
                continue;
            }
            $clean[] = [
                'id' => absint($quote['id']),
                'status' => isset($quote['status']) ? sanitize_key((string) $quote['status']) : 'pending',
                'customerName' => isset($quote['customerName']) ? sanitize_text_field((string) $quote['customerName']) : '',
                'customerEmail' => isset($quote['customerEmail']) ? sanitize_email((string) $quote['customerEmail']) : '',
                'projectType' => isset($quote['projectType']) ? sanitize_text_field((string) $quote['projectType']) : 'General',
                'productId' => isset($quote['productId']) ? absint($quote['productId']) : 0,
                'quantity' => isset($quote['quantity']) ? max(1, absint($quote['quantity'])) : 1,
                'lineItems' => isset($quote['lineItems']) && is_array($quote['lineItems']) ? $this->quick_quotes_sanitize_line_items($quote['lineItems']) : [],
                'subtotal' => isset($quote['subtotal']) ? (float) $quote['subtotal'] : 0.0,
                'taxPercent' => isset($quote['taxPercent']) ? (float) $quote['taxPercent'] : 0.0,
                'discountPercent' => isset($quote['discountPercent']) ? (float) $quote['discountPercent'] : 0.0,
                'taxAmount' => isset($quote['taxAmount']) ? (float) $quote['taxAmount'] : 0.0,
                'discountAmount' => isset($quote['discountAmount']) ? (float) $quote['discountAmount'] : 0.0,
                'estimatedTotal' => isset($quote['estimatedTotal']) ? (float) $quote['estimatedTotal'] : 0.0,
                'dueToday' => isset($quote['dueToday']) ? (float) $quote['dueToday'] : 0.0,
                'paymentMode' => isset($quote['paymentMode']) ? sanitize_key((string) $quote['paymentMode']) : 'full',
                'paymentPercent' => isset($quote['paymentPercent']) ? (float) $quote['paymentPercent'] : 100.0,
                'stripePaymentUrl' => isset($quote['stripePaymentUrl']) ? esc_url_raw((string) $quote['stripePaymentUrl']) : '',
                'note' => isset($quote['note']) ? sanitize_textarea_field((string) $quote['note']) : '',
                'createdUtc' => isset($quote['createdUtc']) ? sanitize_text_field((string) $quote['createdUtc']) : gmdate('c'),
                'updatedUtc' => isset($quote['updatedUtc']) ? sanitize_text_field((string) $quote['updatedUtc']) : gmdate('c'),
            ];
        }

        usort($clean, static function (array $a, array $b) {
            return ((int) ($b['id'] ?? 0)) <=> ((int) ($a['id'] ?? 0));
        });

        return $clean;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_quotes_get_settings()
    {
        $settings = get_option('quick_quotes_settings', []);
        if (!is_array($settings)) {
            $settings = [];
        }

        $default_tax = isset($settings['default_tax_percent']) ? (float) $settings['default_tax_percent'] : 0.0;
        $default_discount = isset($settings['default_discount_percent']) ? (float) $settings['default_discount_percent'] : 0.0;
        $notification_email = isset($settings['notification_email']) ? sanitize_email((string) $settings['notification_email']) : '';

        return [
            'default_tax_percent' => max(0.0, min(100.0, $default_tax)),
            'default_discount_percent' => max(0.0, min(100.0, $default_discount)),
            'email_notifications' => isset($settings['email_notifications']) && (string) $settings['email_notifications'] === '1' ? '1' : '0',
            'notification_email' => is_email($notification_email) ? $notification_email : '',
        ];
    }

    /**
     * @param array<int, mixed> $line_items
     * @return array<int, array<string, mixed>>
     */
    private function quick_quotes_sanitize_line_items(array $line_items)
    {
        $clean = [];
        foreach ($line_items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $description = isset($item['description']) ? sanitize_text_field((string) $item['description']) : '';
            $qty = isset($item['qty']) ? max(1, absint($item['qty'])) : 1;
            $unit_price = isset($item['unit_price']) ? round(max(0, (float) $item['unit_price']), 2) : null;
            if ($unit_price === null && isset($item['unitPrice'])) {
                $unit_price = round(max(0, (float) $item['unitPrice']), 2);
            }
            if ($unit_price === null && isset($item['price'])) {
                $unit_price = round(max(0, (float) $item['price']), 2);
            }
            if ($description === '' || $unit_price === null) {
                continue;
            }

            $line_total = round($unit_price * $qty, 2);
            $clean[] = [
                'description' => $description,
                'qty' => $qty,
                'unit_price' => $unit_price,
                'price' => $line_total,
            ];
        }

        return $clean;
    }

    /**
     * @param array<int, array<string, mixed>> $line_items
     * @param float $tax_percent
     * @param float $discount_percent
     * @return array<string, float>
     */
    private function quick_quotes_calculate_totals(array $line_items, $tax_percent, $discount_percent)
    {
        $subtotal = 0.0;
        foreach ($line_items as $item) {
            if (!is_array($item)) {
                continue;
            }
            if (isset($item['price'])) {
                $subtotal += (float) $item['price'];
            }
        }
        $subtotal = round(max(0.0, $subtotal), 2);
        $discount_amount = round($subtotal * (max(0.0, min(100.0, (float) $discount_percent)) / 100), 2);
        $taxable = max(0.0, $subtotal - $discount_amount);
        $tax_amount = round($taxable * (max(0.0, min(100.0, (float) $tax_percent)) / 100), 2);
        $final_total = round($taxable + $tax_amount, 2);

        return [
            'subtotal' => $subtotal,
            'discount_amount' => $discount_amount,
            'tax_amount' => $tax_amount,
            'final_total' => $final_total,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_schedule_open_payload(): array
    {
        $jobs = $this->quick_schedule_get_jobs();
        $runs = $this->quick_schedule_get_runs();
        $appointments = $this->quick_schedule_get_appointments();
        $settings = $this->quick_schedule_get_settings();

        $active = 0;
        foreach ($jobs as $job) {
            if (is_array($job) && isset($job['status']) && $job['status'] === 'active') {
                $active++;
            }
        }

        return [
            'summary' => [
                'totalJobs' => count($jobs),
                'activeJobs' => $active,
                'pausedJobs' => max(0, count($jobs) - $active),
                'totalRuns' => count($runs),
                'totalAppointments' => count($appointments),
            ],
            'settings' => $settings,
            'jobs' => array_slice($jobs, 0, 80),
            'runs' => array_slice($runs, 0, 80),
            'appointments' => array_slice($appointments, 0, 80),
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_schedule_save_job_payload(array $payload)
    {
        $jobs = $this->quick_schedule_get_jobs();
        $job_id = isset($payload['jobId']) ? absint($payload['jobId']) : 0;
        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : '';
        $frequency = isset($payload['frequency']) ? sanitize_key((string) $payload['frequency']) : 'daily';
        $run_at_utc = isset($payload['runAtUtc']) ? sanitize_text_field((string) $payload['runAtUtc']) : gmdate('c');
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : 'active';
        $target = isset($payload['target']) ? sanitize_key((string) $payload['target']) : 'site';

        if ($name === '') {
            return new WP_Error('quick_schedule_name_required', 'Job name is required.', ['status' => 400]);
        }
        if (!in_array($frequency, ['hourly', 'daily', 'weekly'], true)) {
            $frequency = 'daily';
        }
        if (!in_array($status, ['active', 'paused'], true)) {
            $status = 'active';
        }
        if (!in_array($target, ['site', 'store', 'plugins'], true)) {
            $target = 'site';
        }

        if ($job_id > 0) {
            $found = false;
            foreach ($jobs as &$job) {
                if (!is_array($job) || !isset($job['id']) || absint($job['id']) !== $job_id) {
                    continue;
                }
                $job['name'] = $name;
                $job['frequency'] = $frequency;
                $job['runAtUtc'] = $run_at_utc;
                $job['status'] = $status;
                $job['target'] = $target;
                $job['updatedUtc'] = gmdate('c');
                $found = true;
                break;
            }
            unset($job);
            if (!$found) {
                return new WP_Error('quick_schedule_job_not_found', 'Job not found.', ['status' => 404]);
            }
            update_option('quick_schedule_jobs', array_values($jobs));

            $workspace = $this->quick_schedule_open_payload();
            return [
                'jobId' => $job_id,
                'name' => $name,
                'status' => $status,
                'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
                'jobs' => isset($workspace['jobs']) && is_array($workspace['jobs']) ? $workspace['jobs'] : [],
                'runs' => isset($workspace['runs']) && is_array($workspace['runs']) ? $workspace['runs'] : [],
                'appointments' => isset($workspace['appointments']) && is_array($workspace['appointments']) ? $workspace['appointments'] : [],
                'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
                'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
            ];
        }

        $entry = [
            'id' => $this->quick_schedule_next_id($jobs),
            'name' => $name,
            'frequency' => $frequency,
            'runAtUtc' => $run_at_utc,
            'status' => $status,
            'target' => $target,
            'updatedUtc' => gmdate('c'),
        ];
        array_unshift($jobs, $entry);
        $jobs = array_slice($jobs, 0, 250);
        update_option('quick_schedule_jobs', $jobs);

        $workspace = $this->quick_schedule_open_payload();
        return [
            'jobId' => (int) $entry['id'],
            'name' => $name,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'jobs' => isset($workspace['jobs']) && is_array($workspace['jobs']) ? $workspace['jobs'] : [],
            'runs' => isset($workspace['runs']) && is_array($workspace['runs']) ? $workspace['runs'] : [],
            'appointments' => isset($workspace['appointments']) && is_array($workspace['appointments']) ? $workspace['appointments'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_schedule_set_job_status_payload(array $payload)
    {
        $job_id = isset($payload['jobId']) ? absint($payload['jobId']) : 0;
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        if ($job_id <= 0) {
            return new WP_Error('quick_schedule_job_required', 'Valid jobId is required.', ['status' => 400]);
        }
        if (!in_array($status, ['active', 'paused'], true)) {
            return new WP_Error('quick_schedule_status_invalid', 'status must be active or paused.', ['status' => 400]);
        }

        $jobs = $this->quick_schedule_get_jobs();
        $found = false;
        foreach ($jobs as &$job) {
            if (!is_array($job) || !isset($job['id']) || absint($job['id']) !== $job_id) {
                continue;
            }
            $job['status'] = $status;
            $job['updatedUtc'] = gmdate('c');
            $found = true;
            break;
        }
        unset($job);
        if (!$found) {
            return new WP_Error('quick_schedule_job_not_found', 'Job not found.', ['status' => 404]);
        }
        update_option('quick_schedule_jobs', array_values($jobs));

        $workspace = $this->quick_schedule_open_payload();
        return [
            'jobId' => $job_id,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'jobs' => isset($workspace['jobs']) && is_array($workspace['jobs']) ? $workspace['jobs'] : [],
            'runs' => isset($workspace['runs']) && is_array($workspace['runs']) ? $workspace['runs'] : [],
            'appointments' => isset($workspace['appointments']) && is_array($workspace['appointments']) ? $workspace['appointments'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_schedule_delete_job_payload(array $payload)
    {
        $job_id = isset($payload['jobId']) ? absint($payload['jobId']) : 0;
        if ($job_id <= 0) {
            return new WP_Error('quick_schedule_job_required', 'Valid jobId is required.', ['status' => 400]);
        }

        $jobs = $this->quick_schedule_get_jobs();
        $next_jobs = [];
        $found = false;
        foreach ($jobs as $job) {
            if (!is_array($job) || !isset($job['id'])) {
                continue;
            }
            if (absint($job['id']) === $job_id) {
                $found = true;
                continue;
            }
            $next_jobs[] = $job;
        }
        if (!$found) {
            return new WP_Error('quick_schedule_job_not_found', 'Job not found.', ['status' => 404]);
        }

        update_option('quick_schedule_jobs', array_values($next_jobs));
        $workspace = $this->quick_schedule_open_payload();
        return [
            'jobId' => $job_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'jobs' => isset($workspace['jobs']) && is_array($workspace['jobs']) ? $workspace['jobs'] : [],
            'runs' => isset($workspace['runs']) && is_array($workspace['runs']) ? $workspace['runs'] : [],
            'appointments' => isset($workspace['appointments']) && is_array($workspace['appointments']) ? $workspace['appointments'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_schedule_run_job_payload(array $payload)
    {
        $job_id = isset($payload['jobId']) ? absint($payload['jobId']) : 0;
        if ($job_id <= 0) {
            return new WP_Error('quick_schedule_job_required', 'Valid jobId is required.', ['status' => 400]);
        }

        $jobs = $this->quick_schedule_get_jobs();
        $job_name = '';
        foreach ($jobs as &$job) {
            if (!is_array($job) || !isset($job['id']) || absint($job['id']) !== $job_id) {
                continue;
            }
            $job_name = isset($job['name']) ? sanitize_text_field((string) $job['name']) : '';
            $job['lastRunUtc'] = gmdate('c');
            $job['updatedUtc'] = gmdate('c');
            break;
        }
        unset($job);
        if ($job_name === '') {
            return new WP_Error('quick_schedule_job_not_found', 'Job not found.', ['status' => 404]);
        }
        update_option('quick_schedule_jobs', array_values($jobs));

        $duration_ms = rand(60, 500); // phpcs:ignore WordPress.WP.AlternativeFunctions.rand_rand
        $runs = $this->quick_schedule_get_runs();
        $run_id = $this->quick_schedule_next_id($runs);
        array_unshift($runs, [
            'id' => $run_id,
            'jobId' => $job_id,
            'jobName' => $job_name,
            'status' => 'success',
            'durationMs' => $duration_ms,
            'output' => sprintf('Run completed for %s target.', $this->quick_schedule_job_target($jobs, $job_id)),
            'runAtUtc' => gmdate('c'),
        ]);
        $runs = array_slice($runs, 0, 500);
        update_option('quick_schedule_runs', $runs);

        $workspace = $this->quick_schedule_open_payload();
        return [
            'jobId' => $job_id,
            'runId' => $run_id,
            'status' => 'success',
            'durationMs' => $duration_ms,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'jobs' => isset($workspace['jobs']) && is_array($workspace['jobs']) ? $workspace['jobs'] : [],
            'runs' => isset($workspace['runs']) && is_array($workspace['runs']) ? $workspace['runs'] : [],
            'appointments' => isset($workspace['appointments']) && is_array($workspace['appointments']) ? $workspace['appointments'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_schedule_record_appointment_payload(array $payload)
    {
        $client_name = isset($payload['clientName']) ? sanitize_text_field((string) $payload['clientName']) : '';
        $client_email = isset($payload['clientEmail']) ? sanitize_email((string) $payload['clientEmail']) : '';
        $client_phone = isset($payload['clientPhone']) ? sanitize_text_field((string) $payload['clientPhone']) : '';
        $appointment_at_utc = isset($payload['appointmentAtUtc']) ? sanitize_text_field((string) $payload['appointmentAtUtc']) : '';
        $quote_id = isset($payload['quoteId']) ? absint($payload['quoteId']) : 0;
        $quote_due_today = isset($payload['quoteDueToday']) ? max(0.0, (float) $payload['quoteDueToday']) : 0.0;
        $notes = isset($payload['notes']) ? sanitize_textarea_field((string) $payload['notes']) : '';
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : 'pending';
        if (!in_array($status, ['pending', 'confirmed', 'completed', 'cancelled'], true)) {
            $status = 'pending';
        }

        if ($client_name === '') {
            return new WP_Error('quick_schedule_client_required', 'Client name is required.', ['status' => 400]);
        }
        if ($client_email === '' || !is_email($client_email)) {
            return new WP_Error('quick_schedule_email_required', 'Valid client email is required.', ['status' => 400]);
        }
        if ($appointment_at_utc === '') {
            return new WP_Error('quick_schedule_appointment_required', 'appointmentAtUtc is required.', ['status' => 400]);
        }

        $settings = $this->quick_schedule_get_settings();
        $base_amount = (float) $settings['consultation_fee'];
        $fee_percent = (float) $settings['stripe_fee_percent'];
        $fee_fixed = (float) $settings['stripe_fee_fixed'];
        $total_due = round(max(0.0, $base_amount + $quote_due_today), 2);
        $processor_fee = round(($total_due * ($fee_percent / 100)) + $fee_fixed, 2);

        $appointments = $this->quick_schedule_get_appointments();
        $appointment_id = $this->quick_schedule_next_id($appointments);
        array_unshift($appointments, [
            'id' => $appointment_id,
            'quoteId' => $quote_id,
            'clientName' => $client_name,
            'clientEmail' => $client_email,
            'clientPhone' => $client_phone,
            'appointmentAtUtc' => $appointment_at_utc,
            'baseAmount' => $base_amount,
            'quoteDueToday' => $quote_due_today,
            'processorFee' => $processor_fee,
            'totalDue' => $total_due,
            'status' => $status,
            'notes' => $notes,
            'createdUtc' => gmdate('c'),
            'updatedUtc' => gmdate('c'),
        ]);
        $appointments = array_slice($appointments, 0, 1000);
        update_option('quick_schedule_appointments', $appointments);

        $workspace = $this->quick_schedule_open_payload();
        return [
            'appointmentId' => $appointment_id,
            'status' => $status,
            'totalDue' => $total_due,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'appointments' => isset($workspace['appointments']) && is_array($workspace['appointments']) ? $workspace['appointments'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_schedule_list_appointments_payload(array $payload)
    {
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        $page = isset($payload['page']) ? absint($payload['page']) : 1;
        $per_page = isset($payload['perPage']) ? absint($payload['perPage']) : 20;
        if ($page < 1) {
            $page = 1;
        }
        if ($per_page < 1) {
            $per_page = 20;
        }
        if ($per_page > 100) {
            $per_page = 100;
        }

        $appointments = $this->quick_schedule_get_appointments();
        $filtered = [];
        foreach ($appointments as $appointment) {
            if (!is_array($appointment)) {
                continue;
            }
            $appt_status = isset($appointment['status']) ? sanitize_key((string) $appointment['status']) : 'pending';
            if ($status !== '' && $status !== $appt_status) {
                continue;
            }
            $filtered[] = $appointment;
        }

        $total = count($filtered);
        $offset = ($page - 1) * $per_page;
        $rows = array_slice($filtered, $offset, $per_page);
        $total_pages = (int) ceil($total / $per_page);
        if ($total_pages < 1) {
            $total_pages = 1;
        }

        return [
            'appointments' => $rows,
            'page' => $page,
            'perPage' => $per_page,
            'total' => $total,
            'totalPages' => $total_pages,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_schedule_set_appointment_status_payload(array $payload)
    {
        $appointment_id = isset($payload['appointmentId']) ? absint($payload['appointmentId']) : 0;
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        if ($appointment_id <= 0) {
            return new WP_Error('quick_schedule_appointment_required', 'Valid appointmentId is required.', ['status' => 400]);
        }
        if (!in_array($status, ['pending', 'confirmed', 'completed', 'cancelled'], true)) {
            return new WP_Error(
                'quick_schedule_appointment_status_invalid',
                'status must be pending, confirmed, completed, or cancelled.',
                ['status' => 400]
            );
        }

        $appointments = $this->quick_schedule_get_appointments();
        $found = false;
        foreach ($appointments as &$appointment) {
            if (!is_array($appointment) || !isset($appointment['id']) || absint($appointment['id']) !== $appointment_id) {
                continue;
            }
            $appointment['status'] = $status;
            $appointment['updatedUtc'] = gmdate('c');
            $found = true;
            break;
        }
        unset($appointment);
        if (!$found) {
            return new WP_Error('quick_schedule_appointment_not_found', 'Appointment not found.', ['status' => 404]);
        }
        update_option('quick_schedule_appointments', array_values($appointments));

        $workspace = $this->quick_schedule_open_payload();
        return [
            'appointmentId' => $appointment_id,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'appointments' => isset($workspace['appointments']) && is_array($workspace['appointments']) ? $workspace['appointments'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_schedule_delete_appointment_payload(array $payload)
    {
        $appointment_id = isset($payload['appointmentId']) ? absint($payload['appointmentId']) : 0;
        if ($appointment_id <= 0) {
            return new WP_Error('quick_schedule_appointment_required', 'Valid appointmentId is required.', ['status' => 400]);
        }

        $appointments = $this->quick_schedule_get_appointments();
        $next = [];
        $found = false;
        foreach ($appointments as $appointment) {
            if (!is_array($appointment) || !isset($appointment['id'])) {
                continue;
            }
            if (absint($appointment['id']) === $appointment_id) {
                $found = true;
                continue;
            }
            $next[] = $appointment;
        }
        if (!$found) {
            return new WP_Error('quick_schedule_appointment_not_found', 'Appointment not found.', ['status' => 404]);
        }
        update_option('quick_schedule_appointments', array_values($next));

        $workspace = $this->quick_schedule_open_payload();
        return [
            'appointmentId' => $appointment_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'appointments' => isset($workspace['appointments']) && is_array($workspace['appointments']) ? $workspace['appointments'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_schedule_export_csv_payload(array $payload)
    {
        $entity = isset($payload['entity']) ? sanitize_key((string) $payload['entity']) : 'jobs';
        if (!in_array($entity, ['jobs', 'runs', 'appointments'], true)) {
            return new WP_Error('quick_schedule_export_entity_invalid', 'entity must be jobs, runs, or appointments.', ['status' => 400]);
        }

        $rows = [];
        if ($entity === 'jobs') {
            $rows[] = ['ID', 'Name', 'Frequency', 'Run At UTC', 'Status', 'Target', 'Last Run UTC', 'Updated UTC'];
            foreach ($this->quick_schedule_get_jobs() as $job) {
                if (!is_array($job)) {
                    continue;
                }
                $rows[] = [
                    (string) ($job['id'] ?? ''),
                    (string) ($job['name'] ?? ''),
                    (string) ($job['frequency'] ?? ''),
                    (string) ($job['runAtUtc'] ?? ''),
                    (string) ($job['status'] ?? ''),
                    (string) ($job['target'] ?? ''),
                    (string) ($job['lastRunUtc'] ?? ''),
                    (string) ($job['updatedUtc'] ?? ''),
                ];
            }
        } elseif ($entity === 'runs') {
            $rows[] = ['ID', 'Job ID', 'Job Name', 'Status', 'Duration MS', 'Output', 'Run At UTC'];
            foreach ($this->quick_schedule_get_runs() as $run) {
                if (!is_array($run)) {
                    continue;
                }
                $rows[] = [
                    (string) ($run['id'] ?? ''),
                    (string) ($run['jobId'] ?? ''),
                    (string) ($run['jobName'] ?? ''),
                    (string) ($run['status'] ?? ''),
                    (string) ($run['durationMs'] ?? ''),
                    (string) ($run['output'] ?? ''),
                    (string) ($run['runAtUtc'] ?? ''),
                ];
            }
        } else {
            $rows[] = [
                'ID',
                'Quote ID',
                'Client Name',
                'Client Email',
                'Client Phone',
                'Appointment At UTC',
                'Base Amount',
                'Quote Due Today',
                'Processor Fee',
                'Total Due',
                'Status',
                'Notes',
                'Created UTC',
                'Updated UTC',
            ];
            foreach ($this->quick_schedule_get_appointments() as $appointment) {
                if (!is_array($appointment)) {
                    continue;
                }
                $rows[] = [
                    (string) ($appointment['id'] ?? ''),
                    (string) ($appointment['quoteId'] ?? ''),
                    (string) ($appointment['clientName'] ?? ''),
                    (string) ($appointment['clientEmail'] ?? ''),
                    (string) ($appointment['clientPhone'] ?? ''),
                    (string) ($appointment['appointmentAtUtc'] ?? ''),
                    (string) ($appointment['baseAmount'] ?? ''),
                    (string) ($appointment['quoteDueToday'] ?? ''),
                    (string) ($appointment['processorFee'] ?? ''),
                    (string) ($appointment['totalDue'] ?? ''),
                    (string) ($appointment['status'] ?? ''),
                    (string) ($appointment['notes'] ?? ''),
                    (string) ($appointment['createdUtc'] ?? ''),
                    (string) ($appointment['updatedUtc'] ?? ''),
                ];
            }
        }

        $handle = fopen('php://temp', 'r+');
        if ($handle === false) {
            return new WP_Error('quick_schedule_export_open_failed', 'Could not open csv buffer.', ['status' => 500]);
        }
        foreach ($rows as $row) {
            fputcsv($handle, $row);
        }
        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);
        if (!is_string($csv)) {
            return new WP_Error('quick_schedule_export_read_failed', 'Could not read csv buffer.', ['status' => 500]);
        }

        return [
            'entity' => $entity,
            'filename' => sprintf('quick-schedule-%s-%s.csv', $entity, gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_schedule_save_settings_payload(array $payload)
    {
        $settings = $this->quick_schedule_get_settings();
        if (isset($payload['adminEmail'])) {
            $email = sanitize_email((string) $payload['adminEmail']);
            $settings['admin_email'] = is_email($email) ? $email : '';
        }
        if (isset($payload['consultationFee'])) {
            $settings['consultation_fee'] = max(0.0, (float) $payload['consultationFee']);
        }
        if (isset($payload['stripeFeePercent'])) {
            $settings['stripe_fee_percent'] = max(0.0, (float) $payload['stripeFeePercent']);
        }
        if (isset($payload['stripeFeeFixed'])) {
            $settings['stripe_fee_fixed'] = max(0.0, (float) $payload['stripeFeeFixed']);
        }
        if (isset($payload['quickQuotesIntegrationEnabled'])) {
            $settings['quick_quotes_integration_enabled'] = !empty($payload['quickQuotesIntegrationEnabled']) ? '1' : '0';
        }
        if (isset($payload['quickFormsIntegrationEnabled'])) {
            $settings['quick_forms_integration_enabled'] = !empty($payload['quickFormsIntegrationEnabled']) ? '1' : '0';
        }
        if (isset($payload['customBookingCss'])) {
            $settings['custom_booking_css'] = sanitize_textarea_field((string) $payload['customBookingCss']);
        }

        update_option('quick_schedule_settings', $settings);
        $workspace = $this->quick_schedule_open_payload();
        return [
            'settings' => $settings,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'jobs' => isset($workspace['jobs']) && is_array($workspace['jobs']) ? $workspace['jobs'] : [],
            'runs' => isset($workspace['runs']) && is_array($workspace['runs']) ? $workspace['runs'] : [],
            'appointments' => isset($workspace['appointments']) && is_array($workspace['appointments']) ? $workspace['appointments'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_schedule_get_jobs()
    {
        $jobs = get_option('quick_schedule_jobs', []);
        if (!is_array($jobs)) {
            $jobs = [];
        }

        $clean = [];
        foreach ($jobs as $job) {
            if (!is_array($job) || !isset($job['id'])) {
                continue;
            }
            $clean[] = [
                'id' => absint($job['id']),
                'name' => isset($job['name']) ? sanitize_text_field((string) $job['name']) : 'Job',
                'frequency' => isset($job['frequency']) ? sanitize_key((string) $job['frequency']) : 'daily',
                'runAtUtc' => isset($job['runAtUtc']) ? sanitize_text_field((string) $job['runAtUtc']) : gmdate('c'),
                'status' => isset($job['status']) ? sanitize_key((string) $job['status']) : 'active',
                'target' => isset($job['target']) ? sanitize_key((string) $job['target']) : 'site',
                'lastRunUtc' => isset($job['lastRunUtc']) ? sanitize_text_field((string) $job['lastRunUtc']) : '',
                'updatedUtc' => isset($job['updatedUtc']) ? sanitize_text_field((string) $job['updatedUtc']) : gmdate('c'),
            ];
        }

        usort($clean, static function (array $a, array $b) {
            return ((int) ($b['id'] ?? 0)) <=> ((int) ($a['id'] ?? 0));
        });

        return $clean;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_schedule_get_runs()
    {
        $runs = get_option('quick_schedule_runs', []);
        if (!is_array($runs)) {
            $runs = [];
        }

        $clean = [];
        foreach ($runs as $run) {
            if (!is_array($run) || !isset($run['id'])) {
                continue;
            }
            $clean[] = [
                'id' => absint($run['id']),
                'jobId' => isset($run['jobId']) ? absint($run['jobId']) : 0,
                'jobName' => isset($run['jobName']) ? sanitize_text_field((string) $run['jobName']) : '',
                'status' => isset($run['status']) ? sanitize_key((string) $run['status']) : 'success',
                'durationMs' => isset($run['durationMs']) ? absint($run['durationMs']) : 0,
                'output' => isset($run['output']) ? sanitize_text_field((string) $run['output']) : '',
                'runAtUtc' => isset($run['runAtUtc']) ? sanitize_text_field((string) $run['runAtUtc']) : gmdate('c'),
            ];
        }

        usort($clean, static function (array $a, array $b) {
            return ((int) ($b['id'] ?? 0)) <=> ((int) ($a['id'] ?? 0));
        });

        return $clean;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_schedule_get_appointments()
    {
        $appointments = get_option('quick_schedule_appointments', []);
        if (!is_array($appointments)) {
            $appointments = [];
        }

        $clean = [];
        foreach ($appointments as $appointment) {
            if (!is_array($appointment) || !isset($appointment['id'])) {
                continue;
            }
            $clean[] = [
                'id' => absint($appointment['id']),
                'quoteId' => isset($appointment['quoteId']) ? absint($appointment['quoteId']) : 0,
                'clientName' => isset($appointment['clientName']) ? sanitize_text_field((string) $appointment['clientName']) : '',
                'clientEmail' => isset($appointment['clientEmail']) ? sanitize_email((string) $appointment['clientEmail']) : '',
                'clientPhone' => isset($appointment['clientPhone']) ? sanitize_text_field((string) $appointment['clientPhone']) : '',
                'appointmentAtUtc' => isset($appointment['appointmentAtUtc']) ? sanitize_text_field((string) $appointment['appointmentAtUtc']) : '',
                'baseAmount' => isset($appointment['baseAmount']) ? (float) $appointment['baseAmount'] : 0.0,
                'quoteDueToday' => isset($appointment['quoteDueToday']) ? (float) $appointment['quoteDueToday'] : 0.0,
                'processorFee' => isset($appointment['processorFee']) ? (float) $appointment['processorFee'] : 0.0,
                'totalDue' => isset($appointment['totalDue']) ? (float) $appointment['totalDue'] : 0.0,
                'status' => isset($appointment['status']) ? sanitize_key((string) $appointment['status']) : 'pending',
                'notes' => isset($appointment['notes']) ? sanitize_textarea_field((string) $appointment['notes']) : '',
                'createdUtc' => isset($appointment['createdUtc']) ? sanitize_text_field((string) $appointment['createdUtc']) : gmdate('c'),
                'updatedUtc' => isset($appointment['updatedUtc']) ? sanitize_text_field((string) $appointment['updatedUtc']) : gmdate('c'),
            ];
        }

        usort($clean, static function (array $a, array $b) {
            return ((int) ($b['id'] ?? 0)) <=> ((int) ($a['id'] ?? 0));
        });

        return $clean;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_schedule_get_settings()
    {
        $settings = get_option('quick_schedule_settings', []);
        if (!is_array($settings)) {
            $settings = [];
        }

        $admin_email = isset($settings['admin_email']) ? sanitize_email((string) $settings['admin_email']) : '';
        return [
            'admin_email' => is_email($admin_email) ? $admin_email : '',
            'stripe_fee_percent' => isset($settings['stripe_fee_percent']) ? max(0.0, (float) $settings['stripe_fee_percent']) : 2.9,
            'stripe_fee_fixed' => isset($settings['stripe_fee_fixed']) ? max(0.0, (float) $settings['stripe_fee_fixed']) : 0.3,
            'consultation_fee' => isset($settings['consultation_fee']) ? max(0.0, (float) $settings['consultation_fee']) : 99.0,
            'quick_quotes_integration_enabled' =>
                isset($settings['quick_quotes_integration_enabled']) && (string) $settings['quick_quotes_integration_enabled'] === '1' ? '1' : '0',
            'quick_forms_integration_enabled' =>
                isset($settings['quick_forms_integration_enabled']) && (string) $settings['quick_forms_integration_enabled'] === '1' ? '1' : '0',
            'custom_booking_css' => isset($settings['custom_booking_css']) ? sanitize_textarea_field((string) $settings['custom_booking_css']) : '',
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     * @return int
     */
    private function quick_schedule_next_id(array $rows)
    {
        if (count($rows) > 0 && isset($rows[0]['id'])) {
            return ((int) $rows[0]['id']) + 1;
        }

        return 1;
    }

    /**
     * @param array<int, array<string, mixed>> $jobs
     * @param int $job_id
     * @return string
     */
    private function quick_schedule_job_target(array $jobs, $job_id)
    {
        foreach ($jobs as $job) {
            if (!is_array($job) || !isset($job['id']) || absint($job['id']) !== absint($job_id)) {
                continue;
            }

            return isset($job['target']) ? sanitize_key((string) $job['target']) : 'site';
        }

        return 'site';
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    private function quick_ship_open_payload()
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_ship_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $orders = wc_get_orders([
            'limit' => 25,
            'status' => ['processing', 'on-hold'],
            'return' => 'objects',
        ]);
        $pending = [];
        foreach ($orders as $order) {
            if (!$order instanceof WC_Order) {
                continue;
            }
            $pending[] = [
                'orderId' => $order->get_id(),
                'customer' => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
                'total' => (string) $order->get_total(),
                'currency' => $order->get_currency(),
                'status' => $order->get_status(),
            ];
        }

        $shipments = $this->quick_ship_get_shipments();
        $rules = $this->quick_ship_get_rules();
        $settings = $this->quick_ship_get_settings();
        $wizard_state = $this->quick_ship_get_wizard_state();
        $presets = $this->quick_ship_get_presets();

        return [
            'summary' => [
                'pendingShipments' => count($pending),
                'recordedShipments' => count($shipments),
                'rulesCount' => count($rules),
            ],
            'settings' => $settings,
            'wizardState' => $wizard_state,
            'presets' => $presets,
            'rules' => $rules,
            'pendingOrders' => array_slice($pending, 0, 20),
            'shipments' => array_slice($shipments, 0, 100),
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_ship_create_shipment_payload(array $payload)
    {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('quick_ship_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
        }

        $order_id = isset($payload['orderId']) ? absint($payload['orderId']) : 0;
        $carrier = isset($payload['carrier']) ? sanitize_text_field((string) $payload['carrier']) : '';
        $tracking_number = isset($payload['trackingNumber']) ? sanitize_text_field((string) $payload['trackingNumber']) : '';
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : 'label_created';

        if ($order_id <= 0) {
            return new WP_Error('quick_ship_order_required', 'Valid orderId is required.', ['status' => 400]);
        }
        if ($carrier === '' || $tracking_number === '') {
            return new WP_Error('quick_ship_tracking_required', 'carrier and trackingNumber are required.', ['status' => 400]);
        }
        if (!in_array($status, ['label_created', 'in_transit', 'delivered'], true)) {
            $status = 'label_created';
        }

        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            return new WP_Error('quick_ship_order_not_found', 'Order not found.', ['status' => 404]);
        }

        $shipments = $this->quick_ship_get_shipments();
        $next_id = $this->quick_ship_next_id($shipments);

        $entry = [
            'id' => $next_id,
            'orderId' => $order_id,
            'carrier' => $carrier,
            'trackingNumber' => $tracking_number,
            'status' => $status,
            'createdUtc' => gmdate('c'),
        ];
        array_unshift($shipments, $entry);
        $shipments = array_slice($shipments, 0, 500);
        update_option('quick_ship_shipments', $shipments);

        $order->add_order_note(sprintf('Shipment created via Quick Ship: %s %s (%s).', $carrier, $tracking_number, $status));
        update_post_meta($order_id, '_quick_ship_last_tracking', $tracking_number);
        update_post_meta($order_id, '_quick_ship_last_carrier', $carrier);
        update_post_meta($order_id, '_quick_ship_last_status', $status);

        $workspace = $this->quick_ship_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }

        return [
            'shipmentId' => $next_id,
            'orderId' => $order_id,
            'carrier' => $carrier,
            'trackingNumber' => $tracking_number,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'wizardState' => isset($workspace['wizardState']) && is_array($workspace['wizardState']) ? $workspace['wizardState'] : [],
            'presets' => isset($workspace['presets']) && is_array($workspace['presets']) ? $workspace['presets'] : [],
            'rules' => isset($workspace['rules']) && is_array($workspace['rules']) ? $workspace['rules'] : [],
            'pendingOrders' => isset($workspace['pendingOrders']) && is_array($workspace['pendingOrders']) ? $workspace['pendingOrders'] : [],
            'shipments' => isset($workspace['shipments']) && is_array($workspace['shipments']) ? $workspace['shipments'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_ship_set_shipment_status_payload(array $payload)
    {
        $shipment_id = isset($payload['shipmentId']) ? absint($payload['shipmentId']) : 0;
        $status = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        if ($shipment_id <= 0) {
            return new WP_Error('quick_ship_shipment_required', 'Valid shipmentId is required.', ['status' => 400]);
        }
        if (!in_array($status, ['label_created', 'in_transit', 'delivered', 'cancelled'], true)) {
            return new WP_Error('quick_ship_status_invalid', 'status is invalid.', ['status' => 400]);
        }

        $shipments = $this->quick_ship_get_shipments();
        $found = false;
        $order_id = 0;
        foreach ($shipments as &$shipment) {
            if (!is_array($shipment) || !isset($shipment['id']) || absint($shipment['id']) !== $shipment_id) {
                continue;
            }
            $shipment['status'] = $status;
            $shipment['updatedUtc'] = gmdate('c');
            $found = true;
            $order_id = isset($shipment['orderId']) ? absint($shipment['orderId']) : 0;
            break;
        }
        unset($shipment);
        if (!$found) {
            return new WP_Error('quick_ship_shipment_not_found', 'Shipment not found.', ['status' => 404]);
        }

        update_option('quick_ship_shipments', array_values($shipments));
        if ($order_id > 0) {
            update_post_meta($order_id, '_quick_ship_last_status', $status);
        }

        $workspace = $this->quick_ship_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }
        return [
            'shipmentId' => $shipment_id,
            'status' => $status,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'shipments' => isset($workspace['shipments']) && is_array($workspace['shipments']) ? $workspace['shipments'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_ship_delete_shipment_payload(array $payload)
    {
        $shipment_id = isset($payload['shipmentId']) ? absint($payload['shipmentId']) : 0;
        if ($shipment_id <= 0) {
            return new WP_Error('quick_ship_shipment_required', 'Valid shipmentId is required.', ['status' => 400]);
        }

        $shipments = $this->quick_ship_get_shipments();
        $next = [];
        $found = false;
        foreach ($shipments as $shipment) {
            if (!is_array($shipment) || !isset($shipment['id'])) {
                continue;
            }
            if (absint($shipment['id']) === $shipment_id) {
                $found = true;
                continue;
            }
            $next[] = $shipment;
        }
        if (!$found) {
            return new WP_Error('quick_ship_shipment_not_found', 'Shipment not found.', ['status' => 404]);
        }
        update_option('quick_ship_shipments', array_values($next));

        $workspace = $this->quick_ship_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }
        return [
            'shipmentId' => $shipment_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'shipments' => isset($workspace['shipments']) && is_array($workspace['shipments']) ? $workspace['shipments'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_ship_save_settings_payload(array $payload)
    {
        $settings = $this->quick_ship_get_settings();
        if (isset($payload['matchingMode'])) {
            $settings['matching_mode'] = sanitize_key((string) $payload['matchingMode']) === 'stack' ? 'stack' : 'first_match';
        }
        if (isset($payload['fallbackRate'])) {
            $settings['fallback_rate'] = wc_format_decimal((string) $payload['fallbackRate']);
        }
        if (isset($payload['taxable'])) {
            $settings['taxable'] = !empty($payload['taxable']) ? 1 : 0;
        }
        if (isset($payload['hideOtherMethods'])) {
            $settings['hide_other_methods'] = !empty($payload['hideOtherMethods']) ? 1 : 0;
        }
        update_option('quick_ship_settings', $settings);

        $workspace = $this->quick_ship_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }
        return [
            'settings' => $settings,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'rules' => isset($workspace['rules']) && is_array($workspace['rules']) ? $workspace['rules'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_ship_save_rule_payload(array $payload)
    {
        $rule_id = isset($payload['ruleId']) ? absint($payload['ruleId']) : 0;
        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : '';
        $method_type = isset($payload['methodType']) ? sanitize_key((string) $payload['methodType']) : 'flat_rate';
        $amount = isset($payload['amount']) ? (float) wc_format_decimal((string) $payload['amount']) : 0.0;
        $priority = isset($payload['priority']) ? absint($payload['priority']) : 100;
        $enabled = isset($payload['enabled']) ? !empty($payload['enabled']) : true;
        $taxable = isset($payload['taxable']) ? !empty($payload['taxable']) : false;
        $conditions = isset($payload['conditions']) && is_array($payload['conditions']) ? $payload['conditions'] : [];
        if ($name === '') {
            return new WP_Error('quick_ship_rule_name_required', 'Rule name is required.', ['status' => 400]);
        }
        if (!in_array($method_type, ['flat_rate', 'free_shipping', 'pickup'], true)) {
            $method_type = 'flat_rate';
        }

        $rules = $this->quick_ship_get_rules();
        $entry = [
            'id' => $rule_id > 0 ? $rule_id : $this->quick_ship_next_id($rules),
            'name' => $name,
            'enabled' => $enabled ? 1 : 0,
            'priority' => $priority,
            'method_type' => $method_type,
            'amount' => round(max(0.0, $amount), 2),
            'taxable' => $taxable ? 1 : 0,
            'conditions' => $this->quick_ship_sanitize_conditions($conditions),
            'updatedUtc' => gmdate('c'),
        ];

        $replaced = false;
        foreach ($rules as $index => $rule) {
            if (!is_array($rule) || !isset($rule['id']) || absint($rule['id']) !== (int) $entry['id']) {
                continue;
            }
            $rules[$index] = $entry;
            $replaced = true;
            break;
        }
        if (!$replaced) {
            $rules[] = $entry;
        }

        usort($rules, static function (array $a, array $b) {
            return ((int) ($a['priority'] ?? 100)) <=> ((int) ($b['priority'] ?? 100));
        });
        $rules = array_slice(array_values($rules), 0, 500);
        update_option('quick_ship_rules_data', $rules);

        $workspace = $this->quick_ship_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }
        return [
            'ruleId' => (int) $entry['id'],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'rules' => isset($workspace['rules']) && is_array($workspace['rules']) ? $workspace['rules'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_ship_delete_rule_payload(array $payload)
    {
        $rule_id = isset($payload['ruleId']) ? absint($payload['ruleId']) : 0;
        if ($rule_id <= 0) {
            return new WP_Error('quick_ship_rule_required', 'Valid ruleId is required.', ['status' => 400]);
        }

        $rules = $this->quick_ship_get_rules();
        $next = [];
        $found = false;
        foreach ($rules as $rule) {
            if (!is_array($rule) || !isset($rule['id'])) {
                continue;
            }
            if (absint($rule['id']) === $rule_id) {
                $found = true;
                continue;
            }
            $next[] = $rule;
        }
        if (!$found) {
            return new WP_Error('quick_ship_rule_not_found', 'Rule not found.', ['status' => 404]);
        }
        update_option('quick_ship_rules_data', array_values($next));

        $workspace = $this->quick_ship_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }
        return [
            'ruleId' => $rule_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'rules' => isset($workspace['rules']) && is_array($workspace['rules']) ? $workspace['rules'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_ship_apply_preset_payload(array $payload)
    {
        $preset_id = isset($payload['presetId']) ? sanitize_key((string) $payload['presetId']) : '';
        if ($preset_id === '') {
            return new WP_Error('quick_ship_preset_required', 'presetId is required.', ['status' => 400]);
        }

        $presets = $this->quick_ship_get_presets();
        $preset = null;
        foreach ($presets as $row) {
            if (is_array($row) && isset($row['id']) && sanitize_key((string) $row['id']) === $preset_id) {
                $preset = $row;
                break;
            }
        }
        if (!is_array($preset)) {
            return new WP_Error('quick_ship_preset_not_found', 'Preset not found.', ['status' => 404]);
        }

        $data = isset($preset['data']) && is_array($preset['data']) ? $preset['data'] : [];
        $rules = $this->quick_ship_generate_rules_from_preset($data);
        if (!empty($rules)) {
            update_option('quick_ship_rules_data', $rules);
        }
        update_option('quick_ship_wizard_state', [
            'fields' => $data,
            'current_step' => 3,
        ]);

        $workspace = $this->quick_ship_open_payload();
        if ($workspace instanceof WP_Error) {
            return $workspace;
        }
        return [
            'presetId' => $preset_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'rules' => isset($workspace['rules']) && is_array($workspace['rules']) ? $workspace['rules'] : [],
            'wizardState' => isset($workspace['wizardState']) && is_array($workspace['wizardState']) ? $workspace['wizardState'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_ship_export_csv_payload(array $payload)
    {
        $entity = isset($payload['entity']) ? sanitize_key((string) $payload['entity']) : 'shipments';
        if (!in_array($entity, ['shipments', 'rules'], true)) {
            return new WP_Error('quick_ship_export_entity_invalid', 'entity must be shipments or rules.', ['status' => 400]);
        }

        $rows = [];
        if ($entity === 'shipments') {
            $rows[] = ['ID', 'Order ID', 'Carrier', 'Tracking Number', 'Status', 'Created UTC', 'Updated UTC'];
            foreach ($this->quick_ship_get_shipments() as $shipment) {
                if (!is_array($shipment)) {
                    continue;
                }
                $rows[] = [
                    (string) ($shipment['id'] ?? ''),
                    (string) ($shipment['orderId'] ?? ''),
                    (string) ($shipment['carrier'] ?? ''),
                    (string) ($shipment['trackingNumber'] ?? ''),
                    (string) ($shipment['status'] ?? ''),
                    (string) ($shipment['createdUtc'] ?? ''),
                    (string) ($shipment['updatedUtc'] ?? ''),
                ];
            }
        } else {
            $rows[] = ['ID', 'Name', 'Enabled', 'Priority', 'Method Type', 'Amount', 'Taxable', 'Conditions JSON', 'Updated UTC'];
            foreach ($this->quick_ship_get_rules() as $rule) {
                if (!is_array($rule)) {
                    continue;
                }
                $rows[] = [
                    (string) ($rule['id'] ?? ''),
                    (string) ($rule['name'] ?? ''),
                    (string) ($rule['enabled'] ?? 0),
                    (string) ($rule['priority'] ?? 100),
                    (string) ($rule['method_type'] ?? ''),
                    (string) ($rule['amount'] ?? ''),
                    (string) ($rule['taxable'] ?? 0),
                    wp_json_encode(isset($rule['conditions']) && is_array($rule['conditions']) ? $rule['conditions'] : []),
                    (string) ($rule['updatedUtc'] ?? ''),
                ];
            }
        }

        $handle = fopen('php://temp', 'r+');
        if ($handle === false) {
            return new WP_Error('quick_ship_export_open_failed', 'Could not open csv buffer.', ['status' => 500]);
        }
        foreach ($rows as $row) {
            fputcsv($handle, $row);
        }
        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);
        if (!is_string($csv)) {
            return new WP_Error('quick_ship_export_read_failed', 'Could not read csv buffer.', ['status' => 500]);
        }

        return [
            'entity' => $entity,
            'filename' => sprintf('quick-ship-%s-%s.csv', $entity, gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_ship_get_shipments()
    {
        $shipments = get_option('quick_ship_shipments', []);
        if (!is_array($shipments)) {
            $shipments = [];
        }
        $clean = [];
        foreach ($shipments as $shipment) {
            if (!is_array($shipment) || !isset($shipment['id'])) {
                continue;
            }
            $clean[] = [
                'id' => absint($shipment['id']),
                'orderId' => isset($shipment['orderId']) ? absint($shipment['orderId']) : 0,
                'carrier' => isset($shipment['carrier']) ? sanitize_text_field((string) $shipment['carrier']) : '',
                'trackingNumber' => isset($shipment['trackingNumber']) ? sanitize_text_field((string) $shipment['trackingNumber']) : '',
                'status' => isset($shipment['status']) ? sanitize_key((string) $shipment['status']) : 'label_created',
                'createdUtc' => isset($shipment['createdUtc']) ? sanitize_text_field((string) $shipment['createdUtc']) : gmdate('c'),
                'updatedUtc' => isset($shipment['updatedUtc']) ? sanitize_text_field((string) $shipment['updatedUtc']) : '',
            ];
        }

        usort($clean, static function (array $a, array $b) {
            return ((int) ($b['id'] ?? 0)) <=> ((int) ($a['id'] ?? 0));
        });
        return $clean;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_ship_get_settings()
    {
        $settings = get_option('quick_ship_settings', []);
        if (!is_array($settings)) {
            $settings = [];
        }

        return [
            'matching_mode' => isset($settings['matching_mode']) && (string) $settings['matching_mode'] === 'stack' ? 'stack' : 'first_match',
            'fallback_rate' => isset($settings['fallback_rate']) ? wc_format_decimal((string) $settings['fallback_rate']) : '0',
            'taxable' => isset($settings['taxable']) && !empty($settings['taxable']) ? 1 : 0,
            'hide_other_methods' => isset($settings['hide_other_methods']) && !empty($settings['hide_other_methods']) ? 1 : 0,
            'wizard_completed' => isset($settings['wizard_completed']) && !empty($settings['wizard_completed']) ? 1 : 0,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_ship_get_wizard_state()
    {
        $state = get_option('quick_ship_wizard_state', []);
        if (!is_array($state)) {
            $state = [];
        }
        $fields = isset($state['fields']) && is_array($state['fields']) ? $state['fields'] : [];
        $base = function_exists('wc_get_base_location') ? wc_get_base_location() : ['country' => 'US'];
        $defaults = [
            'country' => strtoupper((string) ($base['country'] ?? 'US')),
            'domestic_enabled' => 1,
            'international_enabled' => 0,
            'flat_rate' => '9.99',
            'free_threshold' => '',
            'local_pickup' => 0,
        ];

        return [
            'current_step' => isset($state['current_step']) ? absint($state['current_step']) : 1,
            'fields' => array_merge($defaults, $fields),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_ship_get_presets()
    {
        $state = $this->quick_ship_get_wizard_state();
        $fields = isset($state['fields']) && is_array($state['fields']) ? $state['fields'] : [];
        $base_country = sanitize_text_field((string) ($fields['country'] ?? 'US'));
        $flat_rate = (float) wc_format_decimal((string) ($fields['flat_rate'] ?? '9.99'));
        $free_threshold = (float) wc_format_decimal((string) ($fields['free_threshold'] ?? '75'));

        return [
            [
                'id' => 'simple_flat_free',
                'label' => 'Simple Domestic Flat + Free',
                'description' => 'Domestic flat shipping with free threshold and optional local pickup.',
                'data' => [
                    'base_country' => $base_country,
                    'shipping_scope' => 'domestic',
                    'domestic_type' => 'flat_plus_free',
                    'flat_rate' => $flat_rate > 0 ? $flat_rate : 9.99,
                    'free_threshold' => $free_threshold > 0 ? $free_threshold : 75,
                    'intl_enabled' => !empty($fields['international_enabled']) ? 1 : 0,
                    'pickup_enabled' => !empty($fields['local_pickup']) ? 1 : 0,
                    'pickup_label' => 'Local Pickup',
                    'taxable' => 0,
                ],
            ],
            [
                'id' => 'weight_domestic',
                'label' => 'Weight Domestic Brackets',
                'description' => 'Three domestic weight bracket shipping rules.',
                'data' => [
                    'base_country' => $base_country,
                    'shipping_scope' => 'domestic',
                    'domestic_type' => 'weight',
                    'weight_brackets' => [
                        ['max' => 2, 'rate' => 8],
                        ['max' => 5, 'rate' => 12],
                        ['max' => 99999, 'rate' => 18],
                    ],
                    'intl_enabled' => 0,
                    'pickup_enabled' => !empty($fields['local_pickup']) ? 1 : 0,
                    'pickup_label' => 'Local Pickup',
                    'taxable' => 0,
                ],
            ],
            [
                'id' => 'pickup_only',
                'label' => 'Pickup Only',
                'description' => 'Disable shipping rates and only allow pickup.',
                'data' => [
                    'base_country' => $base_country,
                    'shipping_scope' => 'domestic',
                    'domestic_type' => 'pickup_only',
                    'flat_rate' => 0,
                    'free_threshold' => 0,
                    'intl_enabled' => 0,
                    'pickup_enabled' => 1,
                    'pickup_label' => 'Local Pickup',
                    'taxable' => 0,
                ],
            ],
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_ship_get_rules()
    {
        $rules = get_option('quick_ship_rules_data', []);
        if (!is_array($rules)) {
            $rules = [];
        }
        $clean = [];
        foreach ($rules as $rule) {
            if (!is_array($rule) || !isset($rule['id'])) {
                continue;
            }
            $clean[] = [
                'id' => absint($rule['id']),
                'name' => isset($rule['name']) ? sanitize_text_field((string) $rule['name']) : 'Quick Ship Rule',
                'enabled' => isset($rule['enabled']) && !empty($rule['enabled']) ? 1 : 0,
                'priority' => isset($rule['priority']) ? absint($rule['priority']) : 100,
                'method_type' => isset($rule['method_type']) ? sanitize_key((string) $rule['method_type']) : 'flat_rate',
                'amount' => isset($rule['amount']) ? round(max(0.0, (float) $rule['amount']), 2) : 0.0,
                'taxable' => isset($rule['taxable']) && !empty($rule['taxable']) ? 1 : 0,
                'conditions' => isset($rule['conditions']) && is_array($rule['conditions']) ? $rule['conditions'] : [],
                'updatedUtc' => isset($rule['updatedUtc']) ? sanitize_text_field((string) $rule['updatedUtc']) : gmdate('c'),
            ];
        }
        usort($clean, static function (array $a, array $b) {
            $priority = ((int) ($a['priority'] ?? 100)) <=> ((int) ($b['priority'] ?? 100));
            if ($priority !== 0) {
                return $priority;
            }

            return ((int) ($a['id'] ?? 0)) <=> ((int) ($b['id'] ?? 0));
        });

        return $clean;
    }

    /**
     * @param array<string, mixed> $conditions
     * @return array<string, mixed>
     */
    private function quick_ship_sanitize_conditions(array $conditions)
    {
        $clean = [];
        foreach (['country_in', 'country_not_in', 'state_in', 'postcode_prefix'] as $key) {
            if (!isset($conditions[$key])) {
                continue;
            }
            $raw = is_array($conditions[$key]) ? $conditions[$key] : explode(',', (string) $conditions[$key]);
            $values = [];
            foreach ($raw as $item) {
                $item_clean = strtoupper(sanitize_text_field(trim((string) $item)));
                if ($item_clean !== '') {
                    $values[] = $item_clean;
                }
            }
            if (!empty($values)) {
                $clean[$key] = array_values(array_unique($values));
            }
        }
        foreach (['subtotal_gte', 'subtotal_lte', 'weight_lte', 'weight_gte'] as $key) {
            if (isset($conditions[$key]) && $conditions[$key] !== '') {
                $clean[$key] = (float) $conditions[$key];
            }
        }
        foreach (['item_count_gte', 'item_count_lte'] as $key) {
            if (isset($conditions[$key]) && $conditions[$key] !== '') {
                $clean[$key] = absint($conditions[$key]);
            }
        }

        return $clean;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<int, array<string, mixed>>
     */
    private function quick_ship_generate_rules_from_preset(array $data)
    {
        $base_country = sanitize_text_field((string) ($data['base_country'] ?? 'US'));
        $shipping_type = sanitize_key((string) ($data['domestic_type'] ?? 'flat_plus_free'));
        $free_threshold = (float) wc_format_decimal((string) ($data['free_threshold'] ?? 0));
        $flat_rate = (float) wc_format_decimal((string) ($data['flat_rate'] ?? 0));
        $priority = 10;
        $rules = [];

        if (in_array($shipping_type, ['flat_plus_free', 'free_threshold'], true) && $free_threshold > 0) {
            $rules[] = [
                'id' => count($rules) + 1,
                'name' => 'Domestic Free Shipping',
                'enabled' => 1,
                'priority' => $priority,
                'method_type' => 'free_shipping',
                'amount' => 0,
                'taxable' => 0,
                'conditions' => [
                    'country_in' => [$base_country],
                    'subtotal_gte' => $free_threshold,
                ],
                'updatedUtc' => gmdate('c'),
            ];
            $priority += 10;
        }

        if ($shipping_type === 'weight') {
            $brackets = isset($data['weight_brackets']) && is_array($data['weight_brackets']) ? $data['weight_brackets'] : [];
            if (empty($brackets)) {
                $brackets = [
                    ['max' => 2, 'rate' => 8],
                    ['max' => 5, 'rate' => 12],
                    ['max' => 99999, 'rate' => 18],
                ];
            }
            foreach ($brackets as $index => $bracket) {
                $max = isset($bracket['max']) ? (float) $bracket['max'] : 99999;
                $rate = isset($bracket['rate']) ? (float) $bracket['rate'] : 0;
                $rules[] = [
                    'id' => count($rules) + 1 + $index,
                    'name' => sprintf('Domestic Weight Bracket %d', $index + 1),
                    'enabled' => 1,
                    'priority' => $priority,
                    'method_type' => 'flat_rate',
                    'amount' => $rate,
                    'taxable' => !empty($data['taxable']) ? 1 : 0,
                    'conditions' => [
                        'country_in' => [$base_country],
                        'weight_lte' => $max,
                    ],
                    'updatedUtc' => gmdate('c'),
                ];
                $priority += 10;
            }
        } elseif ($shipping_type === 'pickup_only') {
            $rules[] = [
                'id' => count($rules) + 1,
                'name' => isset($data['pickup_label']) ? sanitize_text_field((string) $data['pickup_label']) : 'Local Pickup',
                'enabled' => 1,
                'priority' => $priority,
                'method_type' => 'pickup',
                'amount' => 0,
                'taxable' => 0,
                'conditions' => ['country_in' => [$base_country]],
                'updatedUtc' => gmdate('c'),
            ];
            $priority += 10;
        } else {
            $rules[] = [
                'id' => count($rules) + 1,
                'name' => 'Domestic Flat Rate',
                'enabled' => 1,
                'priority' => $priority,
                'method_type' => 'flat_rate',
                'amount' => $flat_rate,
                'taxable' => !empty($data['taxable']) ? 1 : 0,
                'conditions' => ['country_in' => [$base_country]],
                'updatedUtc' => gmdate('c'),
            ];
            $priority += 10;
        }

        if (!empty($data['intl_enabled'])) {
            $rules[] = [
                'id' => count($rules) + 1,
                'name' => 'International Flat Rate',
                'enabled' => 1,
                'priority' => $priority,
                'method_type' => 'flat_rate',
                'amount' => (float) wc_format_decimal((string) ($data['intl_flat_rate'] ?? 20)),
                'taxable' => !empty($data['taxable']) ? 1 : 0,
                'conditions' => ['country_not_in' => [$base_country]],
                'updatedUtc' => gmdate('c'),
            ];
            $priority += 10;
        }

        if (!empty($data['pickup_enabled']) && $shipping_type !== 'pickup_only') {
            $rules[] = [
                'id' => count($rules) + 1,
                'name' => isset($data['pickup_label']) ? sanitize_text_field((string) $data['pickup_label']) : 'Local Pickup',
                'enabled' => 1,
                'priority' => 999,
                'method_type' => 'pickup',
                'amount' => 0,
                'taxable' => 0,
                'conditions' => ['country_in' => [$base_country]],
                'updatedUtc' => gmdate('c'),
            ];
        }

        return $rules;
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     * @return int
     */
    private function quick_ship_next_id(array $rows)
    {
        $max_id = 0;
        foreach ($rows as $row) {
            if (!is_array($row) || !isset($row['id'])) {
                continue;
            }
            $value = absint($row['id']);
            if ($value > $max_id) {
                $max_id = $value;
            }
        }

        return $max_id + 1;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_images_open_payload(): array
    {
        $watermark_id = (int) get_option('qimg_watermark_id', 0);
        $logo_id = (int) get_option('qimg_logo_id', 0);
        $images = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'post_mime_type' => 'image',
            'numberposts' => 30,
            'orderby' => 'modified',
            'order' => 'DESC',
        ]);

        $without_alt = 0;
        $recent = [];
        foreach ($images as $image) {
            if (!$image instanceof WP_Post) {
                continue;
            }

            $alt = trim((string) get_post_meta($image->ID, '_wp_attachment_image_alt', true));
            if ($alt === '') {
                $without_alt++;
            }

            $recent[] = [
                'id' => $image->ID,
                'title' => (string) $image->post_title,
                'alt' => $alt,
                'url' => wp_get_attachment_url($image->ID),
                'mimeType' => (string) $image->post_mime_type,
                'modified' => get_post_modified_time('c', true, $image),
            ];
        }

        return [
            'summary' => [
                'recentImages' => count($recent),
                'missingAltText' => $without_alt,
            ],
            'assets' => [
                'watermarkAttachmentId' => $watermark_id > 0 ? $watermark_id : null,
                'watermarkUrl' => $watermark_id > 0 ? wp_get_attachment_url($watermark_id) : null,
                'logoAttachmentId' => $logo_id > 0 ? $logo_id : null,
                'logoUrl' => $logo_id > 0 ? wp_get_attachment_url($logo_id) : null,
            ],
            'images' => $recent,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_images_set_brand_assets_payload(array $payload)
    {
        $watermark_id = isset($payload['watermarkAttachmentId']) ? absint($payload['watermarkAttachmentId']) : 0;
        $logo_id = isset($payload['logoAttachmentId']) ? absint($payload['logoAttachmentId']) : 0;

        if ($watermark_id > 0 && !wp_attachment_is_image($watermark_id)) {
            return new WP_Error('quick_images_watermark_invalid', 'Watermark must be an image attachment.', ['status' => 400]);
        }
        if ($logo_id > 0 && !wp_attachment_is_image($logo_id)) {
            return new WP_Error('quick_images_logo_invalid', 'Logo must be an image attachment.', ['status' => 400]);
        }

        update_option('qimg_watermark_id', $watermark_id);
        update_option('qimg_logo_id', $logo_id);

        $workspace = $this->quick_images_open_payload();
        return [
            'watermarkAttachmentId' => $watermark_id > 0 ? $watermark_id : null,
            'logoAttachmentId' => $logo_id > 0 ? $logo_id : null,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'assets' => isset($workspace['assets']) && is_array($workspace['assets']) ? $workspace['assets'] : [],
            'images' => isset($workspace['images']) && is_array($workspace['images']) ? $workspace['images'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_images_process_batch_payload(array $payload)
    {
        $rows = isset($payload['rows']) && is_array($payload['rows']) ? $payload['rows'] : [];
        if (count($rows) === 0) {
            return new WP_Error('quick_images_rows_required', 'rows are required for batch processing.', ['status' => 400]);
        }

        $watermark_id = isset($payload['watermarkAttachmentId']) ? absint($payload['watermarkAttachmentId']) : (int) get_option('qimg_watermark_id', 0);
        $logo_id = isset($payload['logoAttachmentId']) ? absint($payload['logoAttachmentId']) : (int) get_option('qimg_logo_id', 0);
        if ($watermark_id <= 0 || !wp_attachment_is_image($watermark_id)) {
            return new WP_Error('quick_images_watermark_required', 'A valid watermarkAttachmentId is required.', ['status' => 400]);
        }
        if ($logo_id <= 0 || !wp_attachment_is_image($logo_id)) {
            return new WP_Error('quick_images_logo_required', 'A valid logoAttachmentId is required.', ['status' => 400]);
        }

        update_option('qimg_watermark_id', $watermark_id);
        update_option('qimg_logo_id', $logo_id);

        $watermark_path = (string) get_attached_file($watermark_id);
        $logo_path = (string) get_attached_file($logo_id);
        if ($watermark_path === '' || !file_exists($watermark_path)) {
            return new WP_Error('quick_images_watermark_missing', 'Watermark file does not exist.', ['status' => 400]);
        }
        if ($logo_path === '' || !file_exists($logo_path)) {
            return new WP_Error('quick_images_logo_missing', 'Logo file does not exist.', ['status' => 400]);
        }

        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $processed = [];
        $errors = [];

        foreach ($rows as $index => $row) {
            if (!is_array($row)) {
                $errors[] = sprintf('Row %d is invalid.', $index + 1);
                continue;
            }

            $source_attachment_id = isset($row['attachmentId']) ? absint($row['attachmentId']) : 0;
            $strain_name = isset($row['name']) ? sanitize_text_field((string) $row['name']) : '';
            if ($source_attachment_id <= 0 || !wp_attachment_is_image($source_attachment_id)) {
                $errors[] = sprintf('Row %d has an invalid image attachment ID.', $index + 1);
                continue;
            }
            if ($strain_name === '') {
                $errors[] = sprintf('Row %d has an empty product/strain name.', $index + 1);
                continue;
            }

            $source_path = (string) get_attached_file($source_attachment_id);
            if ($source_path === '' || !file_exists($source_path)) {
                $errors[] = sprintf('Row %d source file is missing.', $index + 1);
                continue;
            }

            $source_for_compose = $this->quick_images_resize_if_needed($source_path, 2200);
            $composed = $this->quick_images_compose($source_for_compose, $watermark_path, $logo_path, $strain_name);
            if ($composed instanceof WP_Error) {
                $errors[] = sprintf('Row %d processing failed: %s', $index + 1, $composed->get_error_message());
                continue;
            }

            $target = $this->quick_images_make_target_path($strain_name, $source_path);
            if ($target instanceof WP_Error) {
                imagedestroy($composed['resource']);
                $errors[] = sprintf('Row %d could not create output path.', $index + 1);
                continue;
            }

            $saved = $this->quick_images_save_image_resource($composed['resource'], (string) $target['path'], (string) $target['ext']);
            imagedestroy($composed['resource']);
            if (!$saved) {
                $errors[] = sprintf('Row %d output save failed.', $index + 1);
                continue;
            }

            $new_attachment_id = $this->quick_images_insert_attachment((string) $target['path'], $strain_name);
            if ($new_attachment_id instanceof WP_Error) {
                wp_delete_file((string) $target['path']);
                $errors[] = sprintf('Row %d media insert failed.', $index + 1);
                continue;
            }

            $processed[] = [
                'sourceAttachmentId' => $source_attachment_id,
                'attachmentId' => (int) $new_attachment_id,
                'name' => $strain_name,
                'url' => wp_get_attachment_url((int) $new_attachment_id),
            ];
        }

        $workspace = $this->quick_images_open_payload();
        return [
            'processed' => $processed,
            'errors' => $errors,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'assets' => isset($workspace['assets']) && is_array($workspace['assets']) ? $workspace['assets'] : [],
            'images' => isset($workspace['images']) && is_array($workspace['images']) ? $workspace['images'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_images_optimize_image_payload(array $payload)
    {
        $attachment_id = isset($payload['attachmentId']) ? absint($payload['attachmentId']) : 0;
        $alt_text = isset($payload['altText']) ? sanitize_text_field((string) $payload['altText']) : '';

        if ($attachment_id <= 0) {
            return new WP_Error('quick_images_attachment_required', 'Valid attachmentId is required.', ['status' => 400]);
        }

        $attachment = get_post($attachment_id);
        if (!$attachment instanceof WP_Post || $attachment->post_type !== 'attachment') {
            return new WP_Error('quick_images_attachment_not_found', 'Attachment not found.', ['status' => 404]);
        }

        if ($alt_text === '') {
            $source = trim((string) $attachment->post_title);
            if ($source === '') {
                $source = trim(pathinfo((string) get_attached_file($attachment_id), PATHINFO_FILENAME));
            }
            $source = preg_replace('/[_-]+/', ' ', $source);
            $alt_text = $source ? ucwords($source) : sprintf('Image %d', $attachment_id);
        }

        update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt_text);
        $workspace = $this->quick_images_open_payload();

        return [
            'attachmentId' => $attachment_id,
            'altText' => $alt_text,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'assets' => isset($workspace['assets']) && is_array($workspace['assets']) ? $workspace['assets'] : [],
            'images' => isset($workspace['images']) && is_array($workspace['images']) ? $workspace['images'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    private function quick_images_resize_if_needed(string $source_path, int $max_size): string
    {
        $editor = wp_get_image_editor($source_path);
        if (is_wp_error($editor)) {
            return $source_path;
        }

        $size = $editor->get_size();
        $width = isset($size['width']) ? (int) $size['width'] : 0;
        $height = isset($size['height']) ? (int) $size['height'] : 0;
        if ($width <= $max_size && $height <= $max_size) {
            return $source_path;
        }

        $editor->resize($max_size, $max_size, false);
        $saved = $editor->save($source_path);
        if (is_wp_error($saved) || empty($saved['path'])) {
            return $source_path;
        }

        return (string) $saved['path'];
    }

    /**
     * @return array<string, mixed>|WP_Error
     */
    private function quick_images_compose(string $base_path, string $watermark_path, string $logo_path, string $strain_name)
    {
        $base = $this->quick_images_load_image_resource($base_path);
        $watermark = $this->quick_images_load_image_resource($watermark_path);
        $logo = $this->quick_images_load_image_resource($logo_path);

        if (!$base || !$watermark || !$logo) {
            if ($base) {
                imagedestroy($base);
            }
            if ($watermark) {
                imagedestroy($watermark);
            }
            if ($logo) {
                imagedestroy($logo);
            }
            return new WP_Error('quick_images_invalid_resource', 'Unable to load image resources.');
        }

        $base_w = imagesx($base);
        $base_h = imagesy($base);

        $wm_scale = 0.72;
        $wm_w = max(1, (int) floor($base_w * $wm_scale));
        $wm_h = max(1, (int) floor($base_h * $wm_scale));
        $wm_x = (int) floor(($base_w - $wm_w) / 2);
        $wm_y = (int) floor(($base_h - $wm_h) / 2);
        $this->quick_images_overlay_image($base, $watermark, $wm_x, $wm_y, $wm_w, $wm_h, 45);

        $margin = 20;
        $logo_w = max(1, (int) floor($base_w * 0.20));
        $logo_h = max(1, (int) floor($logo_w * (imagesy($logo) / max(imagesx($logo), 1))));
        $logo_x = $margin;
        $logo_y = max(0, $base_h - $logo_h - $margin);
        $this->quick_images_overlay_image($base, $logo, $logo_x, $logo_y, $logo_w, $logo_h, 100);

        $this->quick_images_draw_strain_label($base, $strain_name);

        imagedestroy($watermark);
        imagedestroy($logo);

        return ['resource' => $base];
    }

    private function quick_images_draw_strain_label($image, string $strain_name): void
    {
        $label = strtoupper(trim($strain_name));
        if ($label === '') {
            return;
        }

        $font_path = dirname(__FILE__, 4) . '/quickplugins/quick-images/assets/fonts/Montserrat-ExtraBold.ttf';
        if (!file_exists($font_path) || !function_exists('imagettftext')) {
            return;
        }

        $img_w = imagesx($image);
        $font_size = max(16, (int) floor($img_w * 0.032));
        $padding_x = 22;
        $padding_y = 48;
        $black = imagecolorallocate($image, 0, 0, 0);

        imagettftext($image, $font_size, 0, $padding_x, $padding_y, $black, $font_path, $label);
    }

    private function quick_images_overlay_image($base, $overlay, int $dst_x, int $dst_y, int $new_w, int $new_h, int $opacity = 100): void
    {
        $temp = imagecreatetruecolor($new_w, $new_h);
        imagealphablending($temp, false);
        imagesavealpha($temp, true);
        $transparent = imagecolorallocatealpha($temp, 0, 0, 0, 127);
        imagefilledrectangle($temp, 0, 0, $new_w, $new_h, $transparent);
        imagecopyresampled($temp, $overlay, 0, 0, 0, 0, $new_w, $new_h, imagesx($overlay), imagesy($overlay));

        if ($opacity >= 100) {
            imagecopy($base, $temp, $dst_x, $dst_y, 0, 0, $new_w, $new_h);
        } else {
            imagecopymerge($base, $temp, $dst_x, $dst_y, 0, 0, $new_w, $new_h, $opacity);
        }

        imagedestroy($temp);
    }

    private function quick_images_load_image_resource(string $path)
    {
        if (!file_exists($path)) {
            return null;
        }

        $mime = wp_get_image_mime($path);
        if (!$mime) {
            return null;
        }

        switch ($mime) {
            case 'image/jpeg':
                $img = imagecreatefromjpeg($path);
                break;
            case 'image/png':
                $img = imagecreatefrompng($path);
                break;
            case 'image/gif':
                $img = imagecreatefromgif($path);
                break;
            case 'image/webp':
                if (!function_exists('imagecreatefromwebp')) {
                    return null;
                }
                $img = imagecreatefromwebp($path);
                break;
            default:
                return null;
        }

        if (!is_resource($img) && !is_object($img)) {
            return null;
        }

        imagealphablending($img, true);
        imagesavealpha($img, true);
        return $img;
    }

    /**
     * @return array<string, string>|WP_Error
     */
    private function quick_images_make_target_path(string $name, string $source_path)
    {
        $upload_dir = wp_upload_dir();
        if (!empty($upload_dir['error'])) {
            return new WP_Error('quick_images_upload_dir', (string) $upload_dir['error']);
        }

        $base_name = sanitize_file_name(remove_accents($name));
        if ($base_name === '') {
            $base_name = 'quick-image';
        }

        $ext = strtolower((string) pathinfo($source_path, PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
            $ext = 'jpg';
        }

        $filename = wp_unique_filename((string) $upload_dir['path'], $base_name . '.' . $ext);
        return [
            'path' => trailingslashit((string) $upload_dir['path']) . $filename,
            'ext' => $ext,
        ];
    }

    private function quick_images_save_image_resource($resource, string $path, string $ext): bool
    {
        switch ($ext) {
            case 'jpg':
            case 'jpeg':
                return imagejpeg($resource, $path, 90);
            case 'png':
                return imagepng($resource, $path, 6);
            case 'gif':
                return imagegif($resource, $path);
            case 'webp':
                if (function_exists('imagewebp')) {
                    return imagewebp($resource, $path, 90);
                }
                return imagejpeg($resource, $path, 90);
            default:
                return imagejpeg($resource, $path, 90);
        }
    }

    /**
     * @return int|WP_Error
     */
    private function quick_images_insert_attachment(string $path, string $name)
    {
        $filetype = wp_check_filetype($path);
        $attachment = [
            'post_mime_type' => (string) ($filetype['type'] ?? 'image/jpeg'),
            'post_title' => sanitize_text_field($name),
            'post_name' => sanitize_title($name),
            'post_content' => '',
            'post_status' => 'inherit',
        ];

        $attachment_id = wp_insert_attachment($attachment, $path);
        if (is_wp_error($attachment_id)) {
            return $attachment_id;
        }

        $metadata = wp_generate_attachment_metadata($attachment_id, $path);
        if (!is_wp_error($metadata)) {
            wp_update_attachment_metadata($attachment_id, $metadata);
        }

        update_post_meta($attachment_id, '_wp_attachment_image_alt', sanitize_text_field($name));
        return (int) $attachment_id;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_mail_open_payload(): array
    {
        $settings = $this->quick_mail_get_settings();
        $queue = $this->quick_mail_get_queue_rows(100);
        $logs = $this->quick_mail_get_log_rows(120);
        $templates = $this->quick_mail_get_templates(80);
        $mappings = $this->quick_mail_get_mappings();
        $supported_events = $this->quick_mail_supported_events();
        $last_test = get_option('quick_mail_last_test', []);
        if (!is_array($last_test)) {
            $last_test = [];
        }

        $active_plugins = (array) get_option('active_plugins', []);
        $has_smtp_plugin = false;
        foreach ($active_plugins as $plugin) {
            if (!is_string($plugin)) {
                continue;
            }

            if (strpos($plugin, 'wp-mail-smtp/') === 0 || strpos($plugin, 'fluent-smtp/') === 0) {
                $has_smtp_plugin = true;
                break;
            }
        }

        return [
            'summary' => [
                'adminEmail' => (string) get_option('admin_email'),
                'hasSmtpPlugin' => $has_smtp_plugin,
                'lastTestStatus' => isset($last_test['status']) ? (string) $last_test['status'] : 'never',
                'lastTestUtc' => isset($last_test['timestamp']) ? (string) $last_test['timestamp'] : null,
                'provider' => isset($settings['provider']) ? (string) $settings['provider'] : 'sendgrid',
                'queueCount' => count($queue),
                'logCount' => count($logs),
                'templateCount' => count($templates),
                'mappingCount' => count($mappings),
            ],
            'settings' => [
                'deliveryMode' => (string) ($settings['delivery_mode'] ?? 'default'),
                'provider' => (string) ($settings['provider'] ?? 'sendgrid'),
                'fallbackToWpMail' => !empty($settings['fallback_to_wp_mail']),
                'queueEnabled' => !empty($settings['queue_enabled']),
                'queueBatchSize' => (int) ($settings['queue_batch_size'] ?? 20),
                'logBodies' => !empty($settings['log_bodies']),
                'logRetentionDays' => (int) ($settings['log_retention_days'] ?? 14),
                'fromName' => (string) ($settings['from_name'] ?? ''),
                'fromEmail' => (string) ($settings['from_email'] ?? ''),
                'replyTo' => (string) ($settings['reply_to'] ?? ''),
                'smtpHost' => (string) ($settings['smtp_host'] ?? ''),
                'smtpPort' => (string) ($settings['smtp_port'] ?? ''),
                'smtpEncryption' => (string) ($settings['smtp_encryption'] ?? 'tls'),
                'smtpUser' => (string) ($settings['smtp_user'] ?? ''),
                'smtpFromName' => (string) ($settings['smtp_from_name'] ?? ''),
                'smtpFromEmail' => (string) ($settings['smtp_from_email'] ?? ''),
                'smtpReplyTo' => (string) ($settings['smtp_reply_to'] ?? ''),
                'apiKeySet' => !empty($settings['provider_sendgrid_key']) || !empty($settings['provider_mailgun_key']) || !empty($settings['provider_postmark_key']) || !empty($settings['provider_ses_key']),
                'deliverabilityNotice' => !empty($settings['deliverability_notice']),
            ],
            'queue' => array_slice($queue, 0, 25),
            'logs' => array_slice($logs, 0, 50),
            'templates' => $templates,
            'mappings' => $mappings,
            'supportedEvents' => $supported_events,
            'lastTest' => $last_test,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_mail_default_settings(): array
    {
        return [
            'delivery_mode' => 'default',
            'provider' => 'sendgrid',
            'fallback_to_wp_mail' => 1,
            'queue_enabled' => 0,
            'queue_batch_size' => 20,
            'log_bodies' => 0,
            'log_retention_days' => 14,
            'smtp_host' => '',
            'smtp_port' => 587,
            'smtp_encryption' => 'tls',
            'smtp_user' => '',
            'smtp_pass' => '',
            'smtp_from_name' => '',
            'smtp_from_email' => '',
            'smtp_reply_to' => '',
            'provider_sendgrid_key' => '',
            'provider_mailgun_key' => '',
            'provider_mailgun_domain' => '',
            'provider_postmark_key' => '',
            'provider_ses_key' => '',
            'provider_ses_secret' => '',
            'provider_ses_region' => 'us-east-1',
            'provider_webhook_url' => '',
            'provider_webhook_key' => '',
            'from_name' => get_bloginfo('name'),
            'from_email' => get_option('admin_email'),
            'reply_to' => '',
            'deliverability_notice' => 1,
        ];
    }

    private function quick_mail_table_exists(string $table_name): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . $table_name;
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
        return is_string($found) && $found === $table;
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_mail_get_settings(): array
    {
        $saved = get_option('qmail_settings', []);
        if (!is_array($saved) || count($saved) === 0) {
            $legacy = get_option('quick_mail_settings', []);
            if (is_array($legacy) && count($legacy) > 0) {
                $saved = [
                    'provider' => isset($legacy['provider']) ? sanitize_key((string) $legacy['provider']) : 'sendgrid',
                    'from_name' => isset($legacy['fromName']) ? sanitize_text_field((string) $legacy['fromName']) : '',
                    'from_email' => isset($legacy['fromEmail']) ? sanitize_email((string) $legacy['fromEmail']) : '',
                    'smtp_host' => isset($legacy['smtpHost']) ? sanitize_text_field((string) $legacy['smtpHost']) : '',
                    'smtp_port' => isset($legacy['smtpPort']) ? absint($legacy['smtpPort']) : 587,
                    'smtp_user' => isset($legacy['smtpUser']) ? sanitize_text_field((string) $legacy['smtpUser']) : '',
                    'smtp_pass' => isset($legacy['smtpPass']) ? sanitize_text_field((string) $legacy['smtpPass']) : '',
                    'provider_sendgrid_key' => isset($legacy['apiKey']) ? sanitize_text_field((string) $legacy['apiKey']) : '',
                ];
            } else {
                $saved = [];
            }
        }

        $settings = wp_parse_args($saved, $this->quick_mail_default_settings());
        $settings['delivery_mode'] = in_array((string) $settings['delivery_mode'], ['default', 'smtp', 'api'], true)
            ? (string) $settings['delivery_mode']
            : 'default';
        $settings['provider'] = in_array((string) $settings['provider'], ['sendgrid', 'mailgun', 'postmark', 'ses', 'webhook', 'smtp', 'wp_mail'], true)
            ? (string) $settings['provider']
            : 'sendgrid';
        $settings['fallback_to_wp_mail'] = $this->quick_site_bool_to_int($settings['fallback_to_wp_mail']);
        $settings['queue_enabled'] = $this->quick_site_bool_to_int($settings['queue_enabled']);
        $settings['queue_batch_size'] = max(1, min(200, absint($settings['queue_batch_size'])));
        $settings['log_bodies'] = $this->quick_site_bool_to_int($settings['log_bodies']);
        $settings['log_retention_days'] = max(1, min(365, absint($settings['log_retention_days'])));
        $settings['smtp_port'] = max(1, min(65535, absint($settings['smtp_port'])));
        $settings['smtp_encryption'] = in_array((string) $settings['smtp_encryption'], ['', 'none', 'tls', 'ssl'], true)
            ? (string) $settings['smtp_encryption']
            : 'tls';

        return $settings;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_mail_get_queue_rows(int $limit = 100): array
    {
        global $wpdb;
        $limit = max(1, min(500, $limit));

        if ($this->quick_mail_table_exists('quick_mail_queue')) {
            $table = $wpdb->prefix . 'quick_mail_queue';
            $rows = $wpdb->get_results(
                $wpdb->prepare("SELECT id, payload, attempts, status, created_at, processed_at, last_error FROM {$table} ORDER BY id DESC LIMIT %d", $limit),
                ARRAY_A
            );
            if (is_array($rows)) {
                $items = [];
                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $payload = isset($row['payload']) ? json_decode((string) $row['payload'], true) : [];
                    if (!is_array($payload)) {
                        $payload = [];
                    }
                    $items[] = [
                        'id' => isset($row['id']) ? absint($row['id']) : 0,
                        'to' => isset($payload['to']) ? sanitize_email((string) $payload['to']) : '',
                        'subject' => isset($payload['subject']) ? sanitize_text_field((string) $payload['subject']) : '',
                        'status' => isset($row['status']) ? sanitize_key((string) $row['status']) : 'pending',
                        'attempts' => isset($row['attempts']) ? absint($row['attempts']) : 0,
                        'createdUtc' => isset($row['created_at']) ? mysql2date('c', (string) $row['created_at'], false) : '',
                        'processedUtc' => isset($row['processed_at']) ? mysql2date('c', (string) $row['processed_at'], false) : '',
                        'error' => isset($row['last_error']) ? sanitize_text_field((string) $row['last_error']) : '',
                    ];
                }
                return $items;
            }
        }

        $queue = get_option('quick_mail_queue', []);
        if (!is_array($queue)) {
            $queue = [];
        }
        return array_slice($queue, 0, $limit);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_mail_get_log_rows(int $limit = 120): array
    {
        global $wpdb;
        $limit = max(1, min(1000, $limit));

        if ($this->quick_mail_table_exists('quick_mail_log')) {
            $table = $wpdb->prefix . 'quick_mail_log';
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, sent_at, to_email, subject, template_id, provider, status, error_message, context_json FROM {$table} ORDER BY id DESC LIMIT %d",
                    $limit
                ),
                ARRAY_A
            );
            if (is_array($rows)) {
                $items = [];
                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $trigger = '';
                    if (!empty($row['context_json'])) {
                        $context = json_decode((string) $row['context_json'], true);
                        if (is_array($context)) {
                            $trigger = isset($context['trigger']) ? sanitize_key((string) $context['trigger']) : '';
                        }
                    }
                    $items[] = [
                        'id' => isset($row['id']) ? absint($row['id']) : 0,
                        'queueId' => 0,
                        'to' => isset($row['to_email']) ? sanitize_text_field((string) $row['to_email']) : '',
                        'subject' => isset($row['subject']) ? sanitize_text_field((string) $row['subject']) : '',
                        'templateId' => isset($row['template_id']) ? absint($row['template_id']) : 0,
                        'provider' => isset($row['provider']) ? sanitize_key((string) $row['provider']) : '',
                        'status' => isset($row['status']) ? sanitize_key((string) $row['status']) : '',
                        'error' => isset($row['error_message']) ? sanitize_text_field((string) $row['error_message']) : '',
                        'triggerEvent' => $trigger,
                        'timestamp' => isset($row['sent_at']) ? mysql2date('c', (string) $row['sent_at'], false) : gmdate('c'),
                    ];
                }
                return $items;
            }
        }

        $logs = get_option('quick_mail_logs', []);
        if (!is_array($logs)) {
            $logs = [];
        }
        return array_slice($logs, 0, $limit);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_mail_get_templates(int $limit = 100): array
    {
        $posts = get_posts([
            'post_type' => 'qmail_template',
            'post_status' => ['draft', 'publish'],
            'numberposts' => $limit,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);
        $items = [];
        foreach ($posts as $post) {
            if (!$post instanceof WP_Post) {
                continue;
            }
            $items[] = [
                'id' => $post->ID,
                'name' => (string) $post->post_title,
                'slug' => (string) $post->post_name,
                'status' => (string) $post->post_status,
                'subject' => (string) get_post_meta($post->ID, '_qmail_subject', true),
                'fromName' => (string) get_post_meta($post->ID, '_qmail_from_name', true),
                'fromEmail' => (string) get_post_meta($post->ID, '_qmail_from_email', true),
                'replyTo' => (string) get_post_meta($post->ID, '_qmail_reply_to', true),
                'html' => (string) get_post_meta($post->ID, '_qmail_html', true),
                'text' => (string) get_post_meta($post->ID, '_qmail_text', true),
                'category' => (string) (get_post_meta($post->ID, '_qmail_category', true) ?: 'transactional'),
                'triggerEvent' => (string) (get_post_meta($post->ID, '_qmail_trigger_event', true) ?: 'custom_hook'),
                'description' => (string) get_post_meta($post->ID, '_qmail_description', true),
            ];
        }
        return $items;
    }

    /**
     * @return array<string, array<string, mixed>>
     */
    private function quick_mail_get_mappings(): array
    {
        $saved = get_option('qmail_mappings', []);
        if (!is_array($saved)) {
            $saved = [];
        }
        $clean = [];
        foreach ($saved as $event_key => $row) {
            if (!is_array($row)) {
                continue;
            }
            $clean[sanitize_key((string) $event_key)] = [
                'enabled' => $this->quick_site_bool_to_int($row['enabled'] ?? 0),
                'templateId' => absint($row['template_id'] ?? 0),
                'role' => sanitize_text_field((string) ($row['role'] ?? '')),
                'orderStatus' => sanitize_text_field((string) ($row['order_status'] ?? '')),
                'userMeta' => sanitize_text_field((string) ($row['user_meta'] ?? '')),
            ];
        }
        return $clean;
    }

    /**
     * @return array<string, string>
     */
    private function quick_mail_supported_events(): array
    {
        $events = [
            'wp_new_user' => 'WordPress: New User Registration',
            'wp_password_reset' => 'WP: Password Reset',
            'abandoned_cart' => 'WooCommerce: Abandoned Cart',
            'newsletter_signup' => 'Newsletter Signup',
            'custom_hook' => 'Custom Hook Event',
        ];
        if (class_exists('WooCommerce')) {
            $events['wc_processing'] = 'Woo: Processing Order';
            $events['wc_completed'] = 'Woo: Completed Order';
            $events['wc_failed'] = 'Woo: Failed Order';
            $events['wc_refund'] = 'Woo: Refunded Order';
        }
        return $events;
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_mail_save_settings_payload(array $payload)
    {
        $settings = $this->quick_mail_get_settings();
        if (isset($payload['deliveryMode'])) {
            $mode = sanitize_key((string) $payload['deliveryMode']);
            if (in_array($mode, ['default', 'smtp', 'api'], true)) {
                $settings['delivery_mode'] = $mode;
            }
        }
        if (isset($payload['provider'])) {
            $provider = sanitize_key((string) $payload['provider']);
            if (in_array($provider, ['sendgrid', 'mailgun', 'postmark', 'ses', 'webhook', 'smtp', 'wp_mail'], true)) {
                $settings['provider'] = $provider;
            }
        }

        foreach (['fromName' => 'from_name', 'fromEmail' => 'from_email', 'replyTo' => 'reply_to', 'smtpHost' => 'smtp_host', 'smtpUser' => 'smtp_user', 'smtpFromName' => 'smtp_from_name', 'smtpFromEmail' => 'smtp_from_email', 'smtpReplyTo' => 'smtp_reply_to'] as $input => $key) {
            if (!array_key_exists($input, $payload)) {
                continue;
            }
            if (str_contains($input, 'Email') || str_contains($input, 'replyTo') || str_contains($input, 'ReplyTo')) {
                $candidate = sanitize_email((string) $payload[$input]);
                if ($candidate !== '' && !is_email($candidate)) {
                    return new WP_Error('quick_mail_from_email_invalid', "{$input} must be a valid email.", ['status' => 400]);
                }
                $settings[$key] = $candidate;
            } else {
                $settings[$key] = sanitize_text_field((string) $payload[$input]);
            }
        }

        if (isset($payload['smtpPort'])) {
            $settings['smtp_port'] = max(1, min(65535, absint($payload['smtpPort'])));
        }
        if (isset($payload['smtpEncryption'])) {
            $enc = sanitize_key((string) $payload['smtpEncryption']);
            $settings['smtp_encryption'] = in_array($enc, ['none', 'tls', 'ssl'], true) ? $enc : 'tls';
        }

        foreach (['fallbackToWpMail' => 'fallback_to_wp_mail', 'queueEnabled' => 'queue_enabled', 'logBodies' => 'log_bodies', 'deliverabilityNotice' => 'deliverability_notice'] as $input => $key) {
            if (array_key_exists($input, $payload)) {
                $settings[$key] = $this->quick_site_bool_to_int($payload[$input]);
            }
        }
        if (isset($payload['queueBatchSize'])) {
            $settings['queue_batch_size'] = max(1, min(200, absint($payload['queueBatchSize'])));
        }
        if (isset($payload['logRetentionDays'])) {
            $settings['log_retention_days'] = max(1, min(365, absint($payload['logRetentionDays'])));
        }

        // Provider secrets: keep existing when empty, update only with non-empty input.
        foreach ([
            'apiKey' => 'provider_sendgrid_key',
            'sendgridKey' => 'provider_sendgrid_key',
            'mailgunKey' => 'provider_mailgun_key',
            'mailgunDomain' => 'provider_mailgun_domain',
            'postmarkKey' => 'provider_postmark_key',
            'sesKey' => 'provider_ses_key',
            'sesSecret' => 'provider_ses_secret',
            'sesRegion' => 'provider_ses_region',
            'webhookUrl' => 'provider_webhook_url',
            'webhookKey' => 'provider_webhook_key',
            'smtpPass' => 'smtp_pass',
        ] as $input => $key) {
            if (!array_key_exists($input, $payload)) {
                continue;
            }
            $raw = trim((string) $payload[$input]);
            if ($raw === '') {
                continue;
            }
            if (str_contains(strtolower($key), 'url')) {
                $settings[$key] = esc_url_raw($raw);
            } else {
                $settings[$key] = sanitize_text_field($raw);
            }
        }

        update_option('qmail_settings', $settings, false);
        // Backward compatibility for existing bridge payload consumers.
        update_option('quick_mail_settings', [
            'provider' => (string) $settings['provider'],
            'fromName' => (string) $settings['from_name'],
            'fromEmail' => (string) $settings['from_email'],
            'smtpHost' => (string) $settings['smtp_host'],
            'smtpPort' => (string) $settings['smtp_port'],
            'smtpUser' => (string) $settings['smtp_user'],
            'smtpPass' => (string) $settings['smtp_pass'],
            'apiKey' => (string) $settings['provider_sendgrid_key'],
            'updatedUtc' => gmdate('c'),
        ], false);

        $workspace = $this->quick_mail_open_payload();
        return [
            'saved' => true,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'queue' => isset($workspace['queue']) && is_array($workspace['queue']) ? $workspace['queue'] : [],
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_mail_queue_email_payload(array $payload)
    {
        $to = isset($payload['to']) ? sanitize_email((string) $payload['to']) : '';
        $subject = isset($payload['subject']) ? sanitize_text_field((string) $payload['subject']) : '';
        $message = isset($payload['message']) ? wp_kses_post((string) $payload['message']) : '';
        if ($to === '' || !is_email($to)) {
            return new WP_Error('quick_mail_to_required', 'A valid recipient email is required.', ['status' => 400]);
        }
        if ($subject === '' || $message === '') {
            return new WP_Error('quick_mail_subject_message_required', 'subject and message are required.', ['status' => 400]);
        }

        $queue_id = 0;
        if ($this->quick_mail_table_exists('quick_mail_queue')) {
            global $wpdb;
            $table = $wpdb->prefix . 'quick_mail_queue';
            $payload_json = wp_json_encode([
                'to' => $to,
                'subject' => $subject,
                'message' => $message,
                'html' => wpautop($message),
                'text' => wp_strip_all_tags($message),
                'template_id' => isset($payload['templateId']) ? absint($payload['templateId']) : 0,
            ]);
            $inserted = $wpdb->insert($table, [
                'payload' => is_string($payload_json) ? $payload_json : '{}',
                'attempts' => 0,
                'status' => 'pending',
                'created_at' => gmdate('Y-m-d H:i:s'),
            ], ['%s', '%d', '%s', '%s']);
            if ($inserted !== false) {
                $queue_id = (int) $wpdb->insert_id;
            }
        }
        if ($queue_id <= 0) {
            $queue = get_option('quick_mail_queue', []);
            if (!is_array($queue)) {
                $queue = [];
            }
            $queue_id = 1;
            if (count($queue) > 0 && isset($queue[0]['id'])) {
                $queue_id = ((int) $queue[0]['id']) + 1;
            }
            $entry = [
                'id' => $queue_id,
                'to' => $to,
                'subject' => $subject,
                'message' => $message,
                'status' => 'queued',
                'createdUtc' => gmdate('c'),
            ];
            array_unshift($queue, $entry);
            $queue = array_slice($queue, 0, 500);
            update_option('quick_mail_queue', $queue, false);
        }

        $workspace = $this->quick_mail_open_payload();
        return [
            'queueId' => $queue_id,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'queue' => isset($workspace['queue']) && is_array($workspace['queue']) ? $workspace['queue'] : [],
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_mail_run_queue_payload(): array
    {
        if ($this->quick_mail_table_exists('quick_mail_queue')) {
            return $this->quick_mail_run_queue_table_payload();
        }

        $queue = get_option('quick_mail_queue', []);
        if (!is_array($queue)) {
            $queue = [];
        }
        $logs = get_option('quick_mail_logs', []);
        if (!is_array($logs)) {
            $logs = [];
        }

        $processed_count = 0;
        $sent_count = 0;
        $failed_count = 0;
        foreach ($queue as $index => $item) {
            if (!is_array($item)) {
                continue;
            }
            if (($item['status'] ?? '') !== 'queued') {
                continue;
            }
            if ($processed_count >= 10) {
                break;
            }

            $to = sanitize_email((string) ($item['to'] ?? ''));
            $subject = sanitize_text_field((string) ($item['subject'] ?? ''));
            $message = wp_kses_post((string) ($item['message'] ?? ''));
            $processed_count++;

            $sent = $to !== '' && $subject !== '' && $message !== '' ? wp_mail($to, $subject, wpautop($message), ['Content-Type: text/html; charset=UTF-8']) : false;
            $queue[$index]['status'] = $sent ? 'sent' : 'failed';
            $queue[$index]['processedUtc'] = gmdate('c');
            $queue[$index]['error'] = $sent ? '' : 'wp_mail returned false or payload invalid';

            array_unshift($logs, [
                'queueId' => isset($item['id']) ? (int) $item['id'] : 0,
                'to' => $to,
                'subject' => $subject,
                'status' => $sent ? 'sent' : 'failed',
                'timestamp' => gmdate('c'),
            ]);

            if ($sent) {
                $sent_count++;
            } else {
                $failed_count++;
            }
        }

        update_option('quick_mail_queue', array_slice($queue, 0, 500));
        update_option('quick_mail_logs', array_slice($logs, 0, 500));

        $workspace = $this->quick_mail_open_payload();
        return [
            'processedCount' => $processed_count,
            'sentCount' => $sent_count,
            'failedCount' => $failed_count,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'queue' => isset($workspace['queue']) && is_array($workspace['queue']) ? $workspace['queue'] : [],
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_mail_run_queue_table_payload(): array
    {
        global $wpdb;
        $settings = $this->quick_mail_get_settings();
        $batch = max(1, min(200, (int) ($settings['queue_batch_size'] ?? 20)));
        $queue_table = $wpdb->prefix . 'quick_mail_queue';
        $rows = $wpdb->get_results(
            $wpdb->prepare("SELECT id, payload, attempts FROM {$queue_table} WHERE status = %s ORDER BY id ASC LIMIT %d", 'pending', $batch),
            ARRAY_A
        );

        $processed = 0;
        $sent = 0;
        $failed = 0;
        if (is_array($rows)) {
            foreach ($rows as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $payload = isset($row['payload']) ? json_decode((string) $row['payload'], true) : [];
                if (!is_array($payload)) {
                    $payload = [];
                }
                $to = isset($payload['to']) ? sanitize_email((string) $payload['to']) : '';
                $subject = isset($payload['subject']) ? sanitize_text_field((string) $payload['subject']) : '';
                $html = isset($payload['html']) ? wp_kses_post((string) $payload['html']) : '';
                if ($html === '' && isset($payload['message'])) {
                    $html = wpautop((string) $payload['message']);
                }
                $processed++;
                $ok = $to !== '' && $subject !== '' && $html !== '' ? wp_mail($to, $subject, $html, ['Content-Type: text/html; charset=UTF-8']) : false;
                $attempts = isset($row['attempts']) ? absint($row['attempts']) + 1 : 1;
                $new_status = $ok ? 'sent' : ($attempts >= 3 ? 'failed' : 'pending');
                $error = $ok ? null : 'wp_mail returned false or payload invalid';
                $wpdb->update(
                    $queue_table,
                    [
                        'attempts' => $attempts,
                        'status' => $new_status,
                        'processed_at' => gmdate('Y-m-d H:i:s'),
                        'last_error' => $error,
                    ],
                    ['id' => absint($row['id'])],
                    ['%d', '%s', '%s', '%s'],
                    ['%d']
                );
                if ($ok) {
                    $sent++;
                } else {
                    $failed++;
                }
            }
        }

        $workspace = $this->quick_mail_open_payload();
        return [
            'processedCount' => $processed,
            'sentCount' => $sent,
            'failedCount' => $failed,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'queue' => isset($workspace['queue']) && is_array($workspace['queue']) ? $workspace['queue'] : [],
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [],
            'mappings' => isset($workspace['mappings']) && is_array($workspace['mappings']) ? $workspace['mappings'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_mail_clear_queue_payload(): array
    {
        if ($this->quick_mail_table_exists('quick_mail_queue')) {
            global $wpdb;
            $table = $wpdb->prefix . 'quick_mail_queue';
            $wpdb->query("DELETE FROM {$table}");
        }
        update_option('quick_mail_queue', [], false);
        $workspace = $this->quick_mail_open_payload();
        return [
            'cleared' => true,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'queue' => isset($workspace['queue']) && is_array($workspace['queue']) ? $workspace['queue'] : [],
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_mail_clear_logs_payload(): array
    {
        if ($this->quick_mail_table_exists('quick_mail_log')) {
            global $wpdb;
            $table = $wpdb->prefix . 'quick_mail_log';
            $wpdb->query("DELETE FROM {$table}");
        }
        update_option('quick_mail_logs', [], false);
        $workspace = $this->quick_mail_open_payload();
        return [
            'cleared' => true,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'queue' => isset($workspace['queue']) && is_array($workspace['queue']) ? $workspace['queue'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_mail_save_template_payload(array $payload)
    {
        $template_id = isset($payload['templateId']) ? absint($payload['templateId']) : 0;
        $name = isset($payload['name']) ? sanitize_text_field((string) $payload['name']) : '';
        if ($name === '') {
            return new WP_Error('quick_mail_template_name_required', 'Template name is required.', ['status' => 400]);
        }
        $slug = isset($payload['slug']) ? sanitize_title((string) $payload['slug']) : sanitize_title($name);
        $status = isset($payload['status']) && (string) $payload['status'] === 'publish' ? 'publish' : 'draft';
        $subject = isset($payload['subject']) ? sanitize_text_field((string) $payload['subject']) : '';
        $html = isset($payload['html']) ? (string) $payload['html'] : '';
        $text = isset($payload['text']) ? (string) $payload['text'] : '';
        if (trim($html) === '') {
            return new WP_Error('quick_mail_template_html_required', 'Template HTML is required.', ['status' => 400]);
        }

        $postarr = [
            'post_type' => 'qmail_template',
            'post_title' => $name,
            'post_name' => $slug,
            'post_status' => $status,
        ];
        if ($template_id > 0) {
            $postarr['ID'] = $template_id;
            $result = wp_update_post($postarr, true);
        } else {
            $result = wp_insert_post($postarr, true);
        }
        if (is_wp_error($result)) {
            return new WP_Error('quick_mail_template_save_failed', 'Could not save template.', ['status' => 500, 'details' => $result->get_error_message()]);
        }

        $template_id = (int) $result;
        update_post_meta($template_id, '_qmail_subject', $subject);
        update_post_meta($template_id, '_qmail_from_name', sanitize_text_field((string) ($payload['fromName'] ?? '')));
        update_post_meta($template_id, '_qmail_from_email', sanitize_email((string) ($payload['fromEmail'] ?? '')));
        update_post_meta($template_id, '_qmail_reply_to', sanitize_email((string) ($payload['replyTo'] ?? '')));
        update_post_meta($template_id, '_qmail_html', wp_kses_post($html));
        update_post_meta($template_id, '_qmail_text', wp_kses_post($text));
        update_post_meta($template_id, '_qmail_category', sanitize_key((string) ($payload['category'] ?? 'transactional')));
        update_post_meta($template_id, '_qmail_trigger_event', sanitize_key((string) ($payload['triggerEvent'] ?? 'custom_hook')));
        update_post_meta($template_id, '_qmail_description', sanitize_text_field((string) ($payload['description'] ?? '')));

        $workspace = $this->quick_mail_open_payload();
        return [
            'templateId' => $template_id,
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [],
            'mappings' => isset($workspace['mappings']) && is_array($workspace['mappings']) ? $workspace['mappings'] : [],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_mail_delete_template_payload(array $payload)
    {
        $template_id = isset($payload['templateId']) ? absint($payload['templateId']) : 0;
        if ($template_id <= 0) {
            return new WP_Error('quick_mail_template_id_required', 'Valid templateId is required.', ['status' => 400]);
        }
        $deleted = wp_delete_post($template_id, true);
        if (!$deleted) {
            return new WP_Error('quick_mail_template_delete_failed', 'Template could not be deleted.', ['status' => 500]);
        }

        $workspace = $this->quick_mail_open_payload();
        return [
            'templateId' => $template_id,
            'deleted' => true,
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [],
            'mappings' => isset($workspace['mappings']) && is_array($workspace['mappings']) ? $workspace['mappings'] : [],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_mail_duplicate_template_payload(array $payload)
    {
        $template_id = isset($payload['templateId']) ? absint($payload['templateId']) : 0;
        if ($template_id <= 0) {
            return new WP_Error('quick_mail_template_id_required', 'Valid templateId is required.', ['status' => 400]);
        }
        $template = get_post($template_id);
        if (!$template instanceof WP_Post || $template->post_type !== 'qmail_template') {
            return new WP_Error('quick_mail_template_not_found', 'Template not found.', ['status' => 404]);
        }

        $new_id = wp_insert_post([
            'post_type' => 'qmail_template',
            'post_title' => (string) $template->post_title . ' (Copy)',
            'post_name' => sanitize_title((string) $template->post_name . '-copy'),
            'post_status' => 'draft',
        ], true);
        if (is_wp_error($new_id)) {
            return new WP_Error('quick_mail_template_duplicate_failed', 'Could not duplicate template.', ['status' => 500, 'details' => $new_id->get_error_message()]);
        }

        $new_id = (int) $new_id;
        foreach (['_qmail_subject', '_qmail_from_name', '_qmail_from_email', '_qmail_reply_to', '_qmail_html', '_qmail_text', '_qmail_category', '_qmail_trigger_event', '_qmail_description'] as $meta_key) {
            update_post_meta($new_id, $meta_key, get_post_meta($template_id, $meta_key, true));
        }

        $workspace = $this->quick_mail_open_payload();
        return [
            'templateId' => $new_id,
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_mail_save_mappings_payload(array $payload)
    {
        $input = isset($payload['mappings']) && is_array($payload['mappings']) ? $payload['mappings'] : [];
        $clean = [];
        foreach ($input as $event_key => $row) {
            if (!is_array($row)) {
                continue;
            }
            $clean[sanitize_key((string) $event_key)] = [
                'enabled' => $this->quick_site_bool_to_int($row['enabled'] ?? 0),
                'template_id' => absint($row['templateId'] ?? $row['template_id'] ?? 0),
                'role' => sanitize_text_field((string) ($row['role'] ?? '')),
                'order_status' => sanitize_text_field((string) ($row['orderStatus'] ?? $row['order_status'] ?? '')),
                'user_meta' => sanitize_text_field((string) ($row['userMeta'] ?? $row['user_meta'] ?? '')),
            ];
        }
        update_option('qmail_mappings', $clean, false);
        $workspace = $this->quick_mail_open_payload();
        return [
            'mappings' => isset($workspace['mappings']) && is_array($workspace['mappings']) ? $workspace['mappings'] : $this->quick_mail_get_mappings(),
            'supportedEvents' => isset($workspace['supportedEvents']) && is_array($workspace['supportedEvents']) ? $workspace['supportedEvents'] : $this->quick_mail_supported_events(),
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [],
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_mail_test_provider_payload(): array
    {
        $settings = $this->quick_mail_get_settings();
        $provider = (string) ($settings['provider'] ?? 'sendgrid');
        $configured = false;
        if ($provider === 'sendgrid') {
            $configured = trim((string) ($settings['provider_sendgrid_key'] ?? '')) !== '';
        } elseif ($provider === 'mailgun') {
            $configured = trim((string) ($settings['provider_mailgun_key'] ?? '')) !== '' && trim((string) ($settings['provider_mailgun_domain'] ?? '')) !== '';
        } elseif ($provider === 'postmark') {
            $configured = trim((string) ($settings['provider_postmark_key'] ?? '')) !== '';
        } elseif ($provider === 'ses') {
            $configured = trim((string) ($settings['provider_ses_key'] ?? '')) !== '' && trim((string) ($settings['provider_ses_secret'] ?? '')) !== '';
        } elseif ($provider === 'webhook') {
            $configured = trim((string) ($settings['provider_webhook_url'] ?? '')) !== '';
        } elseif ($provider === 'smtp') {
            $configured = trim((string) ($settings['smtp_host'] ?? '')) !== '' && trim((string) ($settings['smtp_user'] ?? '')) !== '';
        } else {
            $configured = true;
        }

        $workspace = $this->quick_mail_open_payload();
        return [
            'provider' => $provider,
            'configured' => $configured,
            'testStatus' => $configured ? 'ready' : 'missing_credentials',
            'testMessage' => $configured ? 'Provider credentials/config appear configured.' : 'Provider credentials/config are missing.',
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_mail_export_logs_csv_payload(array $payload)
    {
        $status_filter = isset($payload['status']) ? sanitize_key((string) $payload['status']) : '';
        $provider_filter = isset($payload['provider']) ? sanitize_key((string) $payload['provider']) : '';
        $rows = [['id', 'timestamp', 'trigger_event', 'to', 'subject', 'template_id', 'provider', 'status', 'error']];
        $logs = $this->quick_mail_get_log_rows(1000);
        foreach ($logs as $log) {
            if (!is_array($log)) {
                continue;
            }
            $status = isset($log['status']) ? sanitize_key((string) $log['status']) : '';
            $provider = isset($log['provider']) ? sanitize_key((string) $log['provider']) : '';
            if ($status_filter !== '' && $status !== $status_filter) {
                continue;
            }
            if ($provider_filter !== '' && $provider !== $provider_filter) {
                continue;
            }
            $rows[] = [
                (string) ($log['id'] ?? 0),
                (string) ($log['timestamp'] ?? ''),
                (string) ($log['triggerEvent'] ?? ''),
                (string) ($log['to'] ?? ''),
                (string) ($log['subject'] ?? ''),
                (string) ($log['templateId'] ?? 0),
                $provider,
                $status,
                (string) ($log['error'] ?? ''),
            ];
        }
        $csv = $this->quick_importer_rows_to_csv($rows);
        if ($csv instanceof WP_Error) {
            return $csv;
        }

        return [
            'filename' => sprintf('quick-mail-logs-%s.csv', gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_mail_send_test_email_payload(array $payload)
    {
        $to = isset($payload['to']) ? sanitize_email((string) $payload['to']) : '';
        $subject = isset($payload['subject']) ? sanitize_text_field((string) $payload['subject']) : 'Quick Mail Test';
        $message = isset($payload['message']) ? wp_kses_post((string) $payload['message']) : '';
        $template_id = isset($payload['templateId']) ? absint($payload['templateId']) : 0;
        if ($template_id > 0) {
            $template = get_post($template_id);
            if ($template instanceof WP_Post && $template->post_type === 'qmail_template') {
                $template_subject = (string) get_post_meta($template_id, '_qmail_subject', true);
                $template_html = (string) get_post_meta($template_id, '_qmail_html', true);
                if ($template_subject !== '') {
                    $subject = $template_subject;
                }
                if (trim($template_html) !== '') {
                    $message = $template_html;
                }
            }
        }

        if ($to === '' || !is_email($to)) {
            return new WP_Error('quick_mail_to_required', 'A valid recipient email is required.', ['status' => 400]);
        }

        if ($message === '') {
            return new WP_Error('quick_mail_message_required', 'Message is required.', ['status' => 400]);
        }

        $headers = ['Content-Type: text/html; charset=UTF-8'];
        $sent = wp_mail($to, $subject, wpautop($message), $headers);
        if (!$sent) {
            update_option('quick_mail_last_test', [
                'status' => 'failed',
                'to' => $to,
                'subject' => $subject,
                'timestamp' => gmdate('c'),
            ]);

            return new WP_Error('quick_mail_send_failed', 'wp_mail failed to send test email.', ['status' => 500]);
        }

        $result = [
            'status' => 'sent',
            'to' => $to,
            'subject' => $subject,
            'templateId' => $template_id > 0 ? $template_id : null,
            'timestamp' => gmdate('c'),
        ];
        update_option('quick_mail_last_test', $result);
        $workspace = $this->quick_mail_open_payload();

        return [
            'to' => $to,
            'subject' => $subject,
            'sent' => true,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [],
            'mappings' => isset($workspace['mappings']) && is_array($workspace['mappings']) ? $workspace['mappings'] : [],
            'lastTest' => $result,
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_traffic_open_payload(array $filters = []): array
    {
        $post_counts = wp_count_posts('post');
        $page_counts = wp_count_posts('page');
        $product_counts = class_exists('WooCommerce') ? wp_count_posts('product') : null;

        $published_posts = ($post_counts instanceof stdClass && isset($post_counts->publish)) ? (int) $post_counts->publish : 0;
        $published_pages = ($page_counts instanceof stdClass && isset($page_counts->publish)) ? (int) $page_counts->publish : 0;
        $published_products = ($product_counts instanceof stdClass && isset($product_counts->publish)) ? (int) $product_counts->publish : 0;
        $approved_comments = (int) wp_count_comments()->approved;
        $settings = $this->quick_traffic_get_settings();

        $campaigns = $this->quick_traffic_get_campaigns();
        $range = $this->quick_traffic_resolve_range($filters);
        $page_filters = $this->quick_traffic_resolve_page_filters($filters);
        $report = $this->quick_traffic_get_report($range);
        $top_pages = $this->quick_traffic_get_top_pages($range, 12, $page_filters);
        $top_referrers = $this->quick_traffic_get_top_referrers($range, 12);
        $dashboard_summary = $this->quick_traffic_get_dashboard_summary();
        $integrations = $this->quick_traffic_get_integrations_settings();
        $last_audit_event = get_option('qtrf_last_audit_event', []);
        if (!is_array($last_audit_event)) {
            $last_audit_event = [];
        }

        return [
            'summary' => [
                'publishedPosts' => $published_posts,
                'publishedPages' => $published_pages,
                'publishedProducts' => $published_products,
                'approvedComments' => $approved_comments,
                'campaignsTracked' => count($campaigns),
                'rangeViews' => isset($report['totals']['views']) ? (int) $report['totals']['views'] : 0,
                'rangeUniques' => isset($report['totals']['uniques']) ? (int) $report['totals']['uniques'] : 0,
            ],
            'dashboardSummary' => $dashboard_summary,
            'settings' => $settings,
            'range' => $range,
            'pageFilters' => $page_filters,
            'report' => $report,
            'topPages' => $top_pages,
            'topReferrers' => $top_referrers,
            'recentCampaigns' => array_slice($campaigns, 0, 20),
            'integrations' => $integrations,
            'availableRoles' => $this->quick_traffic_get_available_roles(),
            'ownerExcludeUrl' => $this->quick_traffic_get_owner_exclude_url(),
            'lastAuditEvent' => $last_audit_event,
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_traffic_generate_utm_payload(array $payload)
    {
        $base_url = isset($payload['baseUrl']) ? esc_url_raw((string) $payload['baseUrl']) : '';
        $source = isset($payload['source']) ? sanitize_text_field((string) $payload['source']) : '';
        $medium = isset($payload['medium']) ? sanitize_text_field((string) $payload['medium']) : '';
        $campaign = isset($payload['campaign']) ? sanitize_text_field((string) $payload['campaign']) : '';
        $content = isset($payload['content']) ? sanitize_text_field((string) $payload['content']) : '';
        $term = isset($payload['term']) ? sanitize_text_field((string) $payload['term']) : '';

        if ($base_url === '' || !wp_http_validate_url($base_url)) {
            return new WP_Error('quick_traffic_base_url_required', 'A valid baseUrl is required.', ['status' => 400]);
        }
        if ($source === '' || $medium === '' || $campaign === '') {
            return new WP_Error('quick_traffic_utm_required', 'source, medium, and campaign are required.', ['status' => 400]);
        }

        $utm_params = [
            'utm_source' => $source,
            'utm_medium' => $medium,
            'utm_campaign' => $campaign,
        ];
        if ($content !== '') {
            $utm_params['utm_content'] = $content;
        }
        if ($term !== '') {
            $utm_params['utm_term'] = $term;
        }

        $utm_url = add_query_arg($utm_params, $base_url);
        $entry = [
            'url' => $utm_url,
            'baseUrl' => $base_url,
            'source' => $source,
            'medium' => $medium,
            'campaign' => $campaign,
            'content' => $content,
            'term' => $term,
            'timestamp' => gmdate('c'),
        ];

        $campaigns = $this->quick_traffic_get_campaigns();
        array_unshift($campaigns, $entry);
        $campaigns = array_slice($campaigns, 0, 25);
        update_option('quick_traffic_recent_campaigns', $campaigns);
        $workspace = $this->quick_traffic_open_payload();

        return [
            'utmUrl' => $utm_url,
            'entry' => $entry,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'dashboardSummary' => isset($workspace['dashboardSummary']) && is_array($workspace['dashboardSummary']) ? $workspace['dashboardSummary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'range' => isset($workspace['range']) && is_array($workspace['range']) ? $workspace['range'] : [],
            'pageFilters' => isset($workspace['pageFilters']) && is_array($workspace['pageFilters']) ? $workspace['pageFilters'] : [],
            'report' => isset($workspace['report']) && is_array($workspace['report']) ? $workspace['report'] : [],
            'topPages' => isset($workspace['topPages']) && is_array($workspace['topPages']) ? $workspace['topPages'] : [],
            'topReferrers' => isset($workspace['topReferrers']) && is_array($workspace['topReferrers']) ? $workspace['topReferrers'] : [],
            'recentCampaigns' => isset($workspace['recentCampaigns']) && is_array($workspace['recentCampaigns']) ? $workspace['recentCampaigns'] : [],
            'integrations' => isset($workspace['integrations']) && is_array($workspace['integrations']) ? $workspace['integrations'] : [],
            'availableRoles' => isset($workspace['availableRoles']) && is_array($workspace['availableRoles']) ? $workspace['availableRoles'] : [],
            'ownerExcludeUrl' => isset($workspace['ownerExcludeUrl']) ? (string) $workspace['ownerExcludeUrl'] : '',
            'lastAuditEvent' => isset($workspace['lastAuditEvent']) && is_array($workspace['lastAuditEvent']) ? $workspace['lastAuditEvent'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function quick_traffic_report_range_payload(array $payload): array
    {
        $workspace = $this->quick_traffic_open_payload($payload);
        return [
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'dashboardSummary' => isset($workspace['dashboardSummary']) && is_array($workspace['dashboardSummary']) ? $workspace['dashboardSummary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'range' => isset($workspace['range']) && is_array($workspace['range']) ? $workspace['range'] : [],
            'pageFilters' => isset($workspace['pageFilters']) && is_array($workspace['pageFilters']) ? $workspace['pageFilters'] : [],
            'report' => isset($workspace['report']) && is_array($workspace['report']) ? $workspace['report'] : [],
            'topPages' => isset($workspace['topPages']) && is_array($workspace['topPages']) ? $workspace['topPages'] : [],
            'topReferrers' => isset($workspace['topReferrers']) && is_array($workspace['topReferrers']) ? $workspace['topReferrers'] : [],
            'recentCampaigns' => isset($workspace['recentCampaigns']) && is_array($workspace['recentCampaigns']) ? $workspace['recentCampaigns'] : [],
            'integrations' => isset($workspace['integrations']) && is_array($workspace['integrations']) ? $workspace['integrations'] : [],
            'availableRoles' => isset($workspace['availableRoles']) && is_array($workspace['availableRoles']) ? $workspace['availableRoles'] : [],
            'ownerExcludeUrl' => isset($workspace['ownerExcludeUrl']) ? (string) $workspace['ownerExcludeUrl'] : '',
            'lastAuditEvent' => isset($workspace['lastAuditEvent']) && is_array($workspace['lastAuditEvent']) ? $workspace['lastAuditEvent'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function quick_traffic_save_settings_payload(array $payload): array
    {
        $settings = $this->quick_traffic_get_settings();
        if (isset($payload['respectDnt'])) {
            $settings['respect_dnt'] = $this->quick_points_bool_to_int($payload['respectDnt']);
        }
        if (isset($payload['botFiltering'])) {
            $settings['bot_filtering'] = $this->quick_points_bool_to_int($payload['botFiltering']);
        }
        if (isset($payload['eventsRetentionDays'])) {
            $settings['events_retention_days'] = max(1, absint($payload['eventsRetentionDays']));
        }
        if (isset($payload['dailyRetentionDays'])) {
            $settings['daily_retention_days'] = max(1, absint($payload['dailyRetentionDays']));
        }
        if (isset($payload['excludedIps'])) {
            $ips = [];
            $source = is_array($payload['excludedIps']) ? $payload['excludedIps'] : explode("\n", (string) $payload['excludedIps']);
            foreach ($source as $value) {
                $candidate = trim((string) $value);
                if ($candidate !== '' && filter_var($candidate, FILTER_VALIDATE_IP)) {
                    $ips[] = $candidate;
                }
            }
            $settings['excluded_ips'] = array_values(array_unique($ips));
        }
        if (isset($payload['excludedRoles']) && is_array($payload['excludedRoles'])) {
            $editable_roles = [];
            if (function_exists('get_editable_roles')) {
                $editable_roles = array_keys((array) get_editable_roles());
            }
            $roles = [];
            foreach ($payload['excludedRoles'] as $role) {
                if (!is_scalar($role)) {
                    continue;
                }
                $clean = sanitize_key((string) $role);
                if ($clean !== '') {
                    if (!empty($editable_roles) && !in_array($clean, $editable_roles, true)) {
                        continue;
                    }
                    $roles[] = $clean;
                }
            }
            $settings['excluded_roles'] = array_values(array_unique($roles));
        }
        if (count($settings['excluded_roles']) === 0) {
            $settings['excluded_roles'] = ['administrator'];
        }

        update_option('qtrf_settings', $settings, false);
        $workspace = $this->quick_traffic_open_payload();
        return [
            'saved' => true,
            'settings' => $settings,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'dashboardSummary' => isset($workspace['dashboardSummary']) && is_array($workspace['dashboardSummary']) ? $workspace['dashboardSummary'] : [],
            'range' => isset($workspace['range']) && is_array($workspace['range']) ? $workspace['range'] : [],
            'pageFilters' => isset($workspace['pageFilters']) && is_array($workspace['pageFilters']) ? $workspace['pageFilters'] : [],
            'report' => isset($workspace['report']) && is_array($workspace['report']) ? $workspace['report'] : [],
            'topPages' => isset($workspace['topPages']) && is_array($workspace['topPages']) ? $workspace['topPages'] : [],
            'topReferrers' => isset($workspace['topReferrers']) && is_array($workspace['topReferrers']) ? $workspace['topReferrers'] : [],
            'recentCampaigns' => isset($workspace['recentCampaigns']) && is_array($workspace['recentCampaigns']) ? $workspace['recentCampaigns'] : [],
            'integrations' => isset($workspace['integrations']) && is_array($workspace['integrations']) ? $workspace['integrations'] : [],
            'availableRoles' => isset($workspace['availableRoles']) && is_array($workspace['availableRoles']) ? $workspace['availableRoles'] : [],
            'ownerExcludeUrl' => isset($workspace['ownerExcludeUrl']) ? (string) $workspace['ownerExcludeUrl'] : '',
            'lastAuditEvent' => isset($workspace['lastAuditEvent']) && is_array($workspace['lastAuditEvent']) ? $workspace['lastAuditEvent'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function quick_traffic_save_integrations_payload(array $payload): array
    {
        $settings = [
            'quick_seo' => isset($payload['quickSeo']) ? $this->quick_points_bool_to_int($payload['quickSeo']) : 0,
            'quick_audit' => isset($payload['quickAudit']) ? $this->quick_points_bool_to_int($payload['quickAudit']) : 0,
            'quick_code' => isset($payload['quickCode']) ? $this->quick_points_bool_to_int($payload['quickCode']) : 0,
            'quick_site' => isset($payload['quickSite']) ? $this->quick_points_bool_to_int($payload['quickSite']) : 0,
        ];
        update_option('qtrf_integrations', $settings, false);
        $workspace = $this->quick_traffic_open_payload();

        return [
            'saved' => true,
            'integrations' => $settings,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'dashboardSummary' => isset($workspace['dashboardSummary']) && is_array($workspace['dashboardSummary']) ? $workspace['dashboardSummary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'range' => isset($workspace['range']) && is_array($workspace['range']) ? $workspace['range'] : [],
            'pageFilters' => isset($workspace['pageFilters']) && is_array($workspace['pageFilters']) ? $workspace['pageFilters'] : [],
            'report' => isset($workspace['report']) && is_array($workspace['report']) ? $workspace['report'] : [],
            'topPages' => isset($workspace['topPages']) && is_array($workspace['topPages']) ? $workspace['topPages'] : [],
            'topReferrers' => isset($workspace['topReferrers']) && is_array($workspace['topReferrers']) ? $workspace['topReferrers'] : [],
            'recentCampaigns' => isset($workspace['recentCampaigns']) && is_array($workspace['recentCampaigns']) ? $workspace['recentCampaigns'] : [],
            'availableRoles' => isset($workspace['availableRoles']) && is_array($workspace['availableRoles']) ? $workspace['availableRoles'] : [],
            'ownerExcludeUrl' => isset($workspace['ownerExcludeUrl']) ? (string) $workspace['ownerExcludeUrl'] : '',
            'lastAuditEvent' => isset($workspace['lastAuditEvent']) && is_array($workspace['lastAuditEvent']) ? $workspace['lastAuditEvent'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_traffic_reset_data_payload(array $payload)
    {
        $confirm = isset($payload['confirm']) ? strtoupper(trim((string) $payload['confirm'])) : '';
        if ($confirm !== 'YES') {
            return new WP_Error('quick_traffic_reset_confirmation_required', 'confirm must be YES to reset traffic data.', ['status' => 400]);
        }

        global $wpdb;
        if ($this->quick_points_table_exists('quick_traffic_events')) {
            $wpdb->query('TRUNCATE TABLE ' . $this->quick_points_table('quick_traffic_events'));
        }
        if ($this->quick_points_table_exists('quick_traffic_daily')) {
            $wpdb->query('TRUNCATE TABLE ' . $this->quick_points_table('quick_traffic_daily'));
        }
        if ($this->quick_points_table_exists('quick_traffic_daily_visitors')) {
            $wpdb->query('TRUNCATE TABLE ' . $this->quick_points_table('quick_traffic_daily_visitors'));
        }
        update_option('quick_traffic_recent_campaigns', [], false);

        $workspace = $this->quick_traffic_open_payload();
        return [
            'reset' => true,
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'dashboardSummary' => isset($workspace['dashboardSummary']) && is_array($workspace['dashboardSummary']) ? $workspace['dashboardSummary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'range' => isset($workspace['range']) && is_array($workspace['range']) ? $workspace['range'] : [],
            'pageFilters' => isset($workspace['pageFilters']) && is_array($workspace['pageFilters']) ? $workspace['pageFilters'] : [],
            'report' => isset($workspace['report']) && is_array($workspace['report']) ? $workspace['report'] : [],
            'topPages' => isset($workspace['topPages']) && is_array($workspace['topPages']) ? $workspace['topPages'] : [],
            'topReferrers' => isset($workspace['topReferrers']) && is_array($workspace['topReferrers']) ? $workspace['topReferrers'] : [],
            'recentCampaigns' => isset($workspace['recentCampaigns']) && is_array($workspace['recentCampaigns']) ? $workspace['recentCampaigns'] : [],
            'integrations' => isset($workspace['integrations']) && is_array($workspace['integrations']) ? $workspace['integrations'] : [],
            'availableRoles' => isset($workspace['availableRoles']) && is_array($workspace['availableRoles']) ? $workspace['availableRoles'] : [],
            'ownerExcludeUrl' => isset($workspace['ownerExcludeUrl']) ? (string) $workspace['ownerExcludeUrl'] : '',
            'lastAuditEvent' => isset($workspace['lastAuditEvent']) && is_array($workspace['lastAuditEvent']) ? $workspace['lastAuditEvent'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_traffic_export_csv_payload(array $payload)
    {
        $entity = isset($payload['entity']) ? sanitize_key((string) $payload['entity']) : 'campaigns';
        if (!in_array($entity, ['campaigns', 'daily-series', 'top-pages', 'top-referrers', 'summary'], true)) {
            return new WP_Error(
                'quick_traffic_export_entity_invalid',
                'entity must be one of campaigns, daily-series, top-pages, top-referrers, summary.',
                ['status' => 400]
            );
        }

        $workspace = $this->quick_traffic_open_payload($payload);
        $rows = [];
        if ($entity === 'campaigns') {
            $rows[] = ['timestamp', 'campaign', 'source', 'medium', 'content', 'term', 'base_url', 'url'];
            $campaigns = isset($workspace['recentCampaigns']) && is_array($workspace['recentCampaigns']) ? $workspace['recentCampaigns'] : [];
            foreach ($campaigns as $campaign) {
                if (!is_array($campaign)) {
                    continue;
                }
                $rows[] = [
                    (string) ($campaign['timestamp'] ?? ''),
                    (string) ($campaign['campaign'] ?? ''),
                    (string) ($campaign['source'] ?? ''),
                    (string) ($campaign['medium'] ?? ''),
                    (string) ($campaign['content'] ?? ''),
                    (string) ($campaign['term'] ?? ''),
                    (string) ($campaign['baseUrl'] ?? ''),
                    (string) ($campaign['url'] ?? ''),
                ];
            }
        } elseif ($entity === 'daily-series') {
            $rows[] = ['day', 'views', 'uniques'];
            $report = isset($workspace['report']) && is_array($workspace['report']) ? $workspace['report'] : [];
            $series = isset($report['series']) && is_array($report['series']) ? $report['series'] : [];
            foreach ($series as $point) {
                if (!is_array($point)) {
                    continue;
                }
                $rows[] = [
                    (string) ($point['day'] ?? ''),
                    (string) ($point['views'] ?? 0),
                    (string) ($point['uniques'] ?? 0),
                ];
            }
        } elseif ($entity === 'top-pages') {
            $rows[] = ['url_path', 'post_id', 'title', 'views', 'uniques', 'last_viewed'];
            $top_pages = isset($workspace['topPages']) && is_array($workspace['topPages']) ? $workspace['topPages'] : [];
            foreach ($top_pages as $page) {
                if (!is_array($page)) {
                    continue;
                }
                $rows[] = [
                    (string) ($page['urlPath'] ?? ''),
                    (string) ($page['postId'] ?? 0),
                    (string) ($page['title'] ?? ''),
                    (string) ($page['views'] ?? 0),
                    (string) ($page['uniques'] ?? 0),
                    (string) ($page['lastViewed'] ?? ''),
                ];
            }
        } elseif ($entity === 'top-referrers') {
            $rows[] = ['domain', 'views', 'uniques'];
            $top_referrers = isset($workspace['topReferrers']) && is_array($workspace['topReferrers']) ? $workspace['topReferrers'] : [];
            foreach ($top_referrers as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $rows[] = [
                    (string) ($row['domain'] ?? ''),
                    (string) ($row['views'] ?? 0),
                    (string) ($row['uniques'] ?? 0),
                ];
            }
        } else {
            $rows[] = ['metric', 'value'];
            $summary = isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [];
            foreach ($summary as $key => $value) {
                $rows[] = [
                    (string) $key,
                    is_scalar($value) ? (string) $value : wp_json_encode($value),
                ];
            }
            $dashboard_summary = isset($workspace['dashboardSummary']) && is_array($workspace['dashboardSummary']) ? $workspace['dashboardSummary'] : [];
            foreach ($dashboard_summary as $bucket => $metrics) {
                if (!is_array($metrics)) {
                    continue;
                }
                $rows[] = [sprintf('%s_views', (string) $bucket), (string) ($metrics['views'] ?? 0)];
                $rows[] = [sprintf('%s_uniques', (string) $bucket), (string) ($metrics['uniques'] ?? 0)];
            }
        }

        $csv = $this->quick_importer_rows_to_csv($rows);
        if ($csv instanceof WP_Error) {
            return $csv;
        }

        return [
            'entity' => $entity,
            'filename' => sprintf('quick-traffic-%s-%s.csv', $entity, gmdate('Ymd-His')),
            'rowCount' => max(0, count($rows) - 1),
            'csvBase64' => base64_encode($csv),
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'dashboardSummary' => isset($workspace['dashboardSummary']) && is_array($workspace['dashboardSummary']) ? $workspace['dashboardSummary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'range' => isset($workspace['range']) && is_array($workspace['range']) ? $workspace['range'] : [],
            'pageFilters' => isset($workspace['pageFilters']) && is_array($workspace['pageFilters']) ? $workspace['pageFilters'] : [],
            'report' => isset($workspace['report']) && is_array($workspace['report']) ? $workspace['report'] : [],
            'topPages' => isset($workspace['topPages']) && is_array($workspace['topPages']) ? $workspace['topPages'] : [],
            'topReferrers' => isset($workspace['topReferrers']) && is_array($workspace['topReferrers']) ? $workspace['topReferrers'] : [],
            'recentCampaigns' => isset($workspace['recentCampaigns']) && is_array($workspace['recentCampaigns']) ? $workspace['recentCampaigns'] : [],
            'integrations' => isset($workspace['integrations']) && is_array($workspace['integrations']) ? $workspace['integrations'] : [],
            'availableRoles' => isset($workspace['availableRoles']) && is_array($workspace['availableRoles']) ? $workspace['availableRoles'] : [],
            'ownerExcludeUrl' => isset($workspace['ownerExcludeUrl']) ? (string) $workspace['ownerExcludeUrl'] : '',
            'lastAuditEvent' => isset($workspace['lastAuditEvent']) && is_array($workspace['lastAuditEvent']) ? $workspace['lastAuditEvent'] : [],
            'serverTimeUtc' => isset($workspace['serverTimeUtc']) ? $workspace['serverTimeUtc'] : gmdate('c'),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_traffic_get_settings(): array
    {
        $defaults = [
            'excluded_roles' => ['administrator'],
            'excluded_ips' => [],
            'respect_dnt' => 1,
            'bot_filtering' => 1,
            'events_retention_days' => 30,
            'daily_retention_days' => 365,
        ];
        $saved = get_option('qtrf_settings', []);
        if (!is_array($saved)) {
            $saved = [];
        }
        $raw = wp_parse_args($saved, $defaults);

        $roles = [];
        if (isset($raw['excluded_roles']) && is_array($raw['excluded_roles'])) {
            foreach ($raw['excluded_roles'] as $role) {
                $clean = sanitize_key((string) $role);
                if ($clean !== '') {
                    $roles[] = $clean;
                }
            }
        }
        if (count($roles) === 0) {
            $roles = ['administrator'];
        }

        $ips = [];
        if (isset($raw['excluded_ips']) && is_array($raw['excluded_ips'])) {
            foreach ($raw['excluded_ips'] as $ip) {
                $candidate = trim((string) $ip);
                if ($candidate !== '' && filter_var($candidate, FILTER_VALIDATE_IP)) {
                    $ips[] = $candidate;
                }
            }
        }

        return [
            'excluded_roles' => array_values(array_unique($roles)),
            'excluded_ips' => array_values(array_unique($ips)),
            'respect_dnt' => $this->quick_points_bool_to_int($raw['respect_dnt']),
            'bot_filtering' => $this->quick_points_bool_to_int($raw['bot_filtering']),
            'events_retention_days' => max(1, absint($raw['events_retention_days'])),
            'daily_retention_days' => max(1, absint($raw['daily_retention_days'])),
        ];
    }

    /**
     * @return array<string, string>
     */
    private function quick_traffic_resolve_range(array $payload): array
    {
        $range = isset($payload['range']) ? sanitize_key((string) $payload['range']) : '7d';
        $today = gmdate('Y-m-d');
        if ($range === 'today') {
            return ['range' => 'today', 'start' => $today, 'end' => $today];
        }
        if ($range === '30d') {
            return ['range' => '30d', 'start' => gmdate('Y-m-d', strtotime('-29 days')), 'end' => $today];
        }
        if ($range === 'custom') {
            $start = isset($payload['start']) ? sanitize_text_field((string) $payload['start']) : $today;
            $end = isset($payload['end']) ? sanitize_text_field((string) $payload['end']) : $today;
            $start_valid = preg_match('/^\d{4}-\d{2}-\d{2}$/', $start) === 1;
            $end_valid = preg_match('/^\d{4}-\d{2}-\d{2}$/', $end) === 1;
            $resolved_start = $start_valid ? $start : $today;
            $resolved_end = $end_valid ? $end : $today;
            if ($resolved_start > $resolved_end) {
                $tmp = $resolved_start;
                $resolved_start = $resolved_end;
                $resolved_end = $tmp;
            }
            return ['range' => 'custom', 'start' => $resolved_start, 'end' => $resolved_end];
        }

        return ['range' => '7d', 'start' => gmdate('Y-m-d', strtotime('-6 days')), 'end' => $today];
    }

    /**
     * @return array<string, mixed>
     */
    private function quick_traffic_get_report(array $range): array
    {
        global $wpdb;

        $start = isset($range['start']) ? (string) $range['start'] : gmdate('Y-m-d', strtotime('-6 days'));
        $end = isset($range['end']) ? (string) $range['end'] : gmdate('Y-m-d');
        $series = [];
        $total_views = 0;
        $total_uniques = 0;

        if ($this->quick_points_table_exists('quick_traffic_daily')) {
            $table = $this->quick_points_table('quick_traffic_daily');
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT day, SUM(views) AS views, SUM(uniques) AS uniques
                     FROM {$table}
                     WHERE day BETWEEN %s AND %s
                     GROUP BY day
                     ORDER BY day ASC",
                    $start,
                    $end
                ),
                ARRAY_A
            );
            $map = [];
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $day = isset($row['day']) ? (string) $row['day'] : '';
                    if ($day === '') {
                        continue;
                    }
                    $map[$day] = [
                        'views' => isset($row['views']) ? (int) $row['views'] : 0,
                        'uniques' => isset($row['uniques']) ? (int) $row['uniques'] : 0,
                    ];
                }
            }

            $cursor = strtotime($start);
            $end_ts = strtotime($end);
            while ($cursor <= $end_ts) {
                $day = gmdate('Y-m-d', $cursor);
                $views = isset($map[$day]['views']) ? (int) $map[$day]['views'] : 0;
                $uniques = isset($map[$day]['uniques']) ? (int) $map[$day]['uniques'] : 0;
                $series[] = ['day' => $day, 'views' => $views, 'uniques' => $uniques];
                $total_views += $views;
                $total_uniques += $uniques;
                $cursor = strtotime('+1 day', $cursor);
            }
        } else {
            $campaigns = $this->quick_traffic_get_campaigns();
            $map = [];
            foreach ($campaigns as $campaign) {
                if (!is_array($campaign)) {
                    continue;
                }
                $ts = isset($campaign['timestamp']) ? (string) $campaign['timestamp'] : '';
                $day = substr($ts, 0, 10);
                if ($day < $start || $day > $end) {
                    continue;
                }
                if (!isset($map[$day])) {
                    $map[$day] = ['views' => 0, 'uniques' => 0];
                }
                $map[$day]['views']++;
                $map[$day]['uniques']++;
            }

            $cursor = strtotime($start);
            $end_ts = strtotime($end);
            while ($cursor <= $end_ts) {
                $day = gmdate('Y-m-d', $cursor);
                $views = isset($map[$day]['views']) ? (int) $map[$day]['views'] : 0;
                $uniques = isset($map[$day]['uniques']) ? (int) $map[$day]['uniques'] : 0;
                $series[] = ['day' => $day, 'views' => $views, 'uniques' => $uniques];
                $total_views += $views;
                $total_uniques += $uniques;
                $cursor = strtotime('+1 day', $cursor);
            }
        }

        return [
            'totals' => [
                'views' => $total_views,
                'uniques' => $total_uniques,
            ],
            'series' => $series,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_traffic_get_top_pages(array $range, int $limit = 10, array $filters = []): array
    {
        global $wpdb;
        $start = isset($range['start']) ? (string) $range['start'] : gmdate('Y-m-d', strtotime('-6 days'));
        $end = isset($range['end']) ? (string) $range['end'] : gmdate('Y-m-d');
        $result = [];
        $post_type = isset($filters['postType']) ? sanitize_key((string) $filters['postType']) : '';
        $sort_by = isset($filters['sortBy']) && in_array((string) $filters['sortBy'], ['views', 'uniques'], true) ? (string) $filters['sortBy'] : 'views';
        $sort_order = isset($filters['sortOrder']) && strtolower((string) $filters['sortOrder']) === 'asc' ? 'ASC' : 'DESC';

        if ($this->quick_points_table_exists('quick_traffic_daily')) {
            $table = $this->quick_points_table('quick_traffic_daily');
            $sql = "SELECT d.url_path, MAX(d.post_id) AS post_id, SUM(d.views) AS views, SUM(d.uniques) AS uniques, MAX(d.last_viewed) AS last_viewed
                FROM {$table} d
                LEFT JOIN {$wpdb->posts} p ON p.ID = d.post_id
                WHERE d.day BETWEEN %s AND %s";
            $params = [$start, $end];
            if ($post_type !== '') {
                $sql .= " AND p.post_type = %s";
                $params[] = $post_type;
            }
            $sql .= " GROUP BY d.url_path ORDER BY {$sort_by} {$sort_order} LIMIT %d";
            $params[] = max(1, $limit);
            $prepared_sql = $wpdb->prepare($sql, $params);
            $rows = $wpdb->get_results($prepared_sql, ARRAY_A);
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $post_id = isset($row['post_id']) ? absint($row['post_id']) : 0;
                    $title = $post_id > 0 ? (string) get_the_title($post_id) : '';
                    $resolved_post_type = '';
                    if ($post_id > 0) {
                        $resolved_post_type = (string) get_post_type($post_id);
                    }
                    $result[] = [
                        'urlPath' => isset($row['url_path']) ? (string) $row['url_path'] : '',
                        'postId' => $post_id,
                        'title' => $title,
                        'postType' => $resolved_post_type,
                        'views' => isset($row['views']) ? (int) $row['views'] : 0,
                        'uniques' => isset($row['uniques']) ? (int) $row['uniques'] : 0,
                        'lastViewed' => isset($row['last_viewed']) ? (string) $row['last_viewed'] : '',
                    ];
                }
            }
        } else {
            $posts = get_posts([
                'post_type' => ['post', 'page'],
                'post_status' => ['publish'],
                'numberposts' => max(1, $limit),
                'orderby' => 'comment_count',
                'order' => 'DESC',
            ]);
            foreach ($posts as $post) {
                if (!$post instanceof WP_Post) {
                    continue;
                }
                if ($post_type !== '' && $post->post_type !== $post_type) {
                    continue;
                }
                $result[] = [
                    'urlPath' => (string) parse_url((string) get_permalink($post), PHP_URL_PATH),
                    'postId' => $post->ID,
                    'title' => (string) $post->post_title,
                    'postType' => (string) $post->post_type,
                    'views' => (int) $post->comment_count,
                    'uniques' => (int) $post->comment_count,
                    'lastViewed' => get_post_modified_time('Y-m-d H:i:s', true, $post),
                ];
            }
        }

        return $result;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_traffic_get_top_referrers(array $range, int $limit = 10): array
    {
        global $wpdb;
        $start = isset($range['start']) ? (string) $range['start'] : gmdate('Y-m-d', strtotime('-6 days'));
        $end = isset($range['end']) ? (string) $range['end'] : gmdate('Y-m-d');
        $result = [];

        if ($this->quick_points_table_exists('quick_traffic_events')) {
            $table = $this->quick_points_table('quick_traffic_events');
            $site_host = (string) parse_url((string) home_url('/'), PHP_URL_HOST);
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT ref_domain, COUNT(*) AS views, COUNT(DISTINCT visitor_hash) AS uniques
                     FROM {$table}
                     WHERE DATE(occurred_at) BETWEEN %s AND %s
                       AND ref_domain IS NOT NULL
                       AND ref_domain <> ''
                       AND ref_domain <> %s
                     GROUP BY ref_domain
                     ORDER BY views DESC
                     LIMIT %d",
                    $start,
                    $end,
                    strtolower($site_host),
                    max(1, $limit)
                ),
                ARRAY_A
            );
            if (is_array($rows)) {
                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $result[] = [
                        'domain' => isset($row['ref_domain']) ? (string) $row['ref_domain'] : '',
                        'views' => isset($row['views']) ? (int) $row['views'] : 0,
                        'uniques' => isset($row['uniques']) ? (int) $row['uniques'] : 0,
                    ];
                }
            }
        } else {
            $campaigns = $this->quick_traffic_get_campaigns();
            $map = [];
            foreach ($campaigns as $campaign) {
                if (!is_array($campaign)) {
                    continue;
                }
                $source = isset($campaign['source']) ? sanitize_title((string) $campaign['source']) : '';
                if ($source === '') {
                    continue;
                }
                if (!isset($map[$source])) {
                    $map[$source] = ['views' => 0, 'uniques' => 0];
                }
                $map[$source]['views']++;
                $map[$source]['uniques']++;
            }
            arsort($map);
            foreach (array_slice($map, 0, max(1, $limit), true) as $domain => $metrics) {
                $result[] = [
                    'domain' => (string) $domain,
                    'views' => (int) $metrics['views'],
                    'uniques' => (int) $metrics['uniques'],
                ];
            }
        }

        return $result;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function quick_traffic_get_campaigns(): array
    {
        $campaigns = get_option('quick_traffic_recent_campaigns', []);
        if (!is_array($campaigns)) {
            return [];
        }
        $result = [];
        foreach ($campaigns as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $result[] = [
                'url' => isset($entry['url']) ? (string) $entry['url'] : '',
                'baseUrl' => isset($entry['baseUrl']) ? (string) $entry['baseUrl'] : '',
                'source' => isset($entry['source']) ? (string) $entry['source'] : '',
                'medium' => isset($entry['medium']) ? (string) $entry['medium'] : '',
                'campaign' => isset($entry['campaign']) ? (string) $entry['campaign'] : '',
                'content' => isset($entry['content']) ? (string) $entry['content'] : '',
                'term' => isset($entry['term']) ? (string) $entry['term'] : '',
                'timestamp' => isset($entry['timestamp']) ? (string) $entry['timestamp'] : gmdate('c'),
            ];
        }
        return $result;
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, string>
     */
    private function quick_traffic_resolve_page_filters(array $payload): array
    {
        $post_type = isset($payload['postType']) ? sanitize_key((string) $payload['postType']) : '';
        $sort_by = isset($payload['sortBy']) && in_array((string) $payload['sortBy'], ['views', 'uniques'], true)
            ? (string) $payload['sortBy']
            : 'views';
        $sort_order = isset($payload['sortOrder']) && strtolower((string) $payload['sortOrder']) === 'asc' ? 'asc' : 'desc';
        return [
            'postType' => $post_type,
            'sortBy' => $sort_by,
            'sortOrder' => $sort_order,
        ];
    }

    /**
     * @return array<string, array<string, int>>
     */
    private function quick_traffic_get_dashboard_summary(): array
    {
        $today = gmdate('Y-m-d');
        $seven_start = gmdate('Y-m-d', strtotime('-6 days'));
        $thirty_start = gmdate('Y-m-d', strtotime('-29 days'));
        return [
            'today' => $this->quick_traffic_get_views_uniques_for_window($today, $today),
            '7d' => $this->quick_traffic_get_views_uniques_for_window($seven_start, $today),
            '30d' => $this->quick_traffic_get_views_uniques_for_window($thirty_start, $today),
        ];
    }

    /**
     * @return array<string, int>
     */
    private function quick_traffic_get_views_uniques_for_window(string $start, string $end): array
    {
        global $wpdb;
        if ($this->quick_points_table_exists('quick_traffic_daily')) {
            $table = $this->quick_points_table('quick_traffic_daily');
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT COALESCE(SUM(views), 0) AS views, COALESCE(SUM(uniques), 0) AS uniques
                     FROM {$table}
                     WHERE day BETWEEN %s AND %s",
                    $start,
                    $end
                ),
                ARRAY_A
            );
            return [
                'views' => is_array($row) && isset($row['views']) ? (int) $row['views'] : 0,
                'uniques' => is_array($row) && isset($row['uniques']) ? (int) $row['uniques'] : 0,
            ];
        }
        return ['views' => 0, 'uniques' => 0];
    }

    /**
     * @return array<string, int>
     */
    private function quick_traffic_get_integrations_settings(): array
    {
        $saved = get_option('qtrf_integrations', []);
        if (!is_array($saved)) {
            $saved = [];
        }
        return [
            'quick_seo' => isset($saved['quick_seo']) ? $this->quick_points_bool_to_int($saved['quick_seo']) : 0,
            'quick_audit' => isset($saved['quick_audit']) ? $this->quick_points_bool_to_int($saved['quick_audit']) : 0,
            'quick_code' => isset($saved['quick_code']) ? $this->quick_points_bool_to_int($saved['quick_code']) : 0,
            'quick_site' => isset($saved['quick_site']) ? $this->quick_points_bool_to_int($saved['quick_site']) : 0,
        ];
    }

    /**
     * @return array<int, array<string, string>>
     */
    private function quick_traffic_get_available_roles(): array
    {
        if (!function_exists('wp_roles')) {
            return [];
        }
        $roles = wp_roles();
        if (!$roles || !isset($roles->roles) || !is_array($roles->roles)) {
            return [];
        }
        $rows = [];
        foreach ($roles->roles as $role_key => $role_data) {
            if (!is_array($role_data)) {
                continue;
            }
            $rows[] = [
                'key' => sanitize_key((string) $role_key),
                'label' => isset($role_data['name']) ? sanitize_text_field((string) $role_data['name']) : sanitize_text_field((string) $role_key),
            ];
        }
        return $rows;
    }

    private function quick_traffic_get_owner_exclude_url(): string
    {
        $payload = 'qtrf_exclude=1|' . home_url('/');
        $signature = hash_hmac('sha256', $payload, AUTH_SALT . '|' . home_url('/'));
        return (string) add_query_arg([
            'qtrf_exclude' => '1',
            'qtrf_sig' => $signature,
        ], home_url('/'));
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_importer_export_csv_payload(array $payload)
    {
        $start = microtime(true);
        $entity = $this->quick_importer_parse_entity(isset($payload['entity']) ? (string) $payload['entity'] : '');
        if ($entity === null) {
            return new WP_Error(
                'quick_importer_invalid_entity',
                'Entity must be one of posts, pages, products.',
                ['status' => 400]
            );
        }

        $rows = $this->quick_importer_export_rows($entity);
        if ($rows instanceof WP_Error) {
            return $rows;
        }

        $csv = $this->quick_importer_rows_to_csv($rows);
        if ($csv instanceof WP_Error) {
            return $csv;
        }

        $row_count = max(0, count($rows) - 1);
        $duration = max(0.0, microtime(true) - $start);
        $this->quick_importer_add_log('export', $entity, $row_count, $row_count, 0, $duration);
        $workspace = $this->quick_importer_open_payload();

        return [
            'entity' => $entity,
            'filename' => sprintf('quick-%s-%s.csv', $entity, gmdate('Ymd-His')),
            'rowCount' => $row_count,
            'csvBase64' => base64_encode($csv),
            'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
            'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
            'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
            'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [],
            'serverTimeUtc' => gmdate('c'),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>|WP_Error
     */
    private function quick_importer_import_csv_payload(array $payload)
    {
        $start = microtime(true);
        $entity = $this->quick_importer_parse_entity(isset($payload['entity']) ? (string) $payload['entity'] : '');
        if ($entity === null) {
            return new WP_Error(
                'quick_importer_invalid_entity',
                'Entity must be one of posts, pages, products.',
                ['status' => 400]
            );
        }

        $csv_base64 = isset($payload['csvBase64']) ? (string) $payload['csvBase64'] : '';
        if ($csv_base64 === '') {
            return new WP_Error('quick_importer_missing_csv', 'csvBase64 is required.', ['status' => 400]);
        }

        $csv_text = base64_decode($csv_base64, true);
        if (!is_string($csv_text)) {
            return new WP_Error('quick_importer_invalid_csv', 'csvBase64 could not be decoded.', ['status' => 400]);
        }

        $rows = $this->quick_importer_parse_csv($csv_text);
        if ($rows instanceof WP_Error) {
            return $rows;
        }

        if (count($rows) < 2) {
            $this->quick_importer_add_log('import', $entity, 0, 0, 0, max(0.0, microtime(true) - $start), ['message' => 'No rows to import']);
            $workspace = $this->quick_importer_open_payload();
            return [
                'entity' => $entity,
                'inserted' => 0,
                'updated' => 0,
                'errors' => [],
                'summary' => isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [],
                'settings' => isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [],
                'logs' => isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [],
                'templates' => isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [],
                'serverTimeUtc' => gmdate('c'),
            ];
        }

        $result = $this->quick_importer_import_rows($entity, $rows);
        if ($result instanceof WP_Error) {
            return $result;
        }

        update_option('quick_importer_last_run_utc', gmdate('c'));
        $result['entity'] = $entity;
        $failed_count = isset($result['errors']) && is_array($result['errors']) ? count($result['errors']) : 0;
        $total_rows = max(0, count($rows) - 1);
        $success_count = max(0, (int) ($result['inserted'] ?? 0) + (int) ($result['updated'] ?? 0));
        $this->quick_importer_add_log('import', $entity, $total_rows, $success_count, $failed_count, max(0.0, microtime(true) - $start), [
            'inserted' => (int) ($result['inserted'] ?? 0),
            'updated' => (int) ($result['updated'] ?? 0),
        ]);
        $workspace = $this->quick_importer_open_payload();
        $result['summary'] = isset($workspace['summary']) && is_array($workspace['summary']) ? $workspace['summary'] : [];
        $result['settings'] = isset($workspace['settings']) && is_array($workspace['settings']) ? $workspace['settings'] : [];
        $result['logs'] = isset($workspace['logs']) && is_array($workspace['logs']) ? $workspace['logs'] : [];
        $result['templates'] = isset($workspace['templates']) && is_array($workspace['templates']) ? $workspace['templates'] : [];
        $result['serverTimeUtc'] = gmdate('c');

        return $result;
    }

    private function quick_importer_parse_entity(string $entity): ?string
    {
        $normalized = strtolower(trim($entity));
        if (in_array($normalized, ['posts', 'pages', 'products'], true)) {
            return $normalized;
        }

        return null;
    }

    /**
     * @return array<int, array<int, string>>|WP_Error
     */
    private function quick_importer_export_rows(string $entity)
    {
        if ($entity === 'posts' || $entity === 'pages') {
            $post_type = $entity === 'posts' ? 'post' : 'page';
            $items = get_posts([
                'post_type' => $post_type,
                'post_status' => ['publish', 'draft', 'pending', 'private'],
                'numberposts' => -1,
                'orderby' => 'date',
                'order' => 'DESC',
            ]);

            $rows = [['id', 'title', 'content', 'status', 'slug']];
            foreach ($items as $item) {
                $rows[] = [
                    (string) $item->ID,
                    (string) $item->post_title,
                    (string) $item->post_content,
                    (string) $item->post_status,
                    (string) $item->post_name,
                ];
            }

            return $rows;
        }

        if ($entity === 'products') {
            if (!class_exists('WooCommerce')) {
                return new WP_Error('quick_importer_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
            }

            $items = get_posts([
                'post_type' => 'product',
                'post_status' => ['publish', 'draft', 'pending', 'private'],
                'numberposts' => -1,
                'orderby' => 'date',
                'order' => 'DESC',
            ]);

            $rows = [['id', 'name', 'description', 'status', 'regular_price', 'stock_quantity', 'sku']];
            foreach ($items as $item) {
                $rows[] = [
                    (string) $item->ID,
                    (string) $item->post_title,
                    (string) $item->post_content,
                    (string) $item->post_status,
                    (string) get_post_meta($item->ID, '_regular_price', true),
                    (string) get_post_meta($item->ID, '_stock', true),
                    (string) get_post_meta($item->ID, '_sku', true),
                ];
            }

            return $rows;
        }

        return new WP_Error('quick_importer_invalid_entity', 'Unsupported entity export.', ['status' => 400]);
    }

    /**
     * @param array<int, array<int, string>> $rows
     * @return string|WP_Error
     */
    private function quick_importer_rows_to_csv(array $rows)
    {
        $handle = fopen('php://temp', 'w+');
        if ($handle === false) {
            return new WP_Error('quick_importer_csv_write_failed', 'Could not open temp stream.', ['status' => 500]);
        }

        foreach ($rows as $row) {
            fputcsv($handle, $row);
        }

        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);

        if (!is_string($csv)) {
            return new WP_Error('quick_importer_csv_write_failed', 'Could not read temp CSV stream.', ['status' => 500]);
        }

        return $csv;
    }

    /**
     * @return array<int, array<int, string>>|WP_Error
     */
    private function quick_importer_parse_csv(string $csv)
    {
        $handle = fopen('php://temp', 'r+');
        if ($handle === false) {
            return new WP_Error('quick_importer_csv_parse_failed', 'Could not open temp stream.', ['status' => 500]);
        }

        fwrite($handle, $csv);
        rewind($handle);

        $rows = [];
        while (($row = fgetcsv($handle)) !== false) {
            $clean = [];
            foreach ($row as $value) {
                $clean[] = is_string($value) ? $value : '';
            }
            $rows[] = $clean;
        }

        fclose($handle);
        return $rows;
    }

    /**
     * @param array<int, array<int, string>> $rows
     * @return array<string, mixed>|WP_Error
     */
    private function quick_importer_import_rows(string $entity, array $rows)
    {
        $header = array_map('trim', $rows[0]);
        $inserted = 0;
        $updated = 0;
        $errors = [];

        for ($i = 1; $i < count($rows); $i++) {
            $row = $rows[$i];
            if (count(array_filter($row, static fn($value) => trim($value) !== '')) === 0) {
                continue;
            }

            $assoc = [];
            foreach ($header as $index => $column) {
                $assoc[$column] = isset($row[$index]) ? (string) $row[$index] : '';
            }

            if ($entity === 'posts' || $entity === 'pages') {
                $post_type = $entity === 'posts' ? 'post' : 'page';
                $post_id = isset($assoc['id']) ? absint($assoc['id']) : 0;

                $post_data = [
                    'post_type' => $post_type,
                    'post_title' => $assoc['title'] ?? '',
                    'post_content' => $assoc['content'] ?? '',
                    'post_status' => $assoc['status'] ?: 'draft',
                    'post_name' => $assoc['slug'] ?? '',
                ];

                if ($post_id > 0 && get_post($post_id) instanceof WP_Post) {
                    $post_data['ID'] = $post_id;
                    $result = wp_update_post($post_data, true);
                    if (is_wp_error($result)) {
                        $errors[] = sprintf('Row %d: %s', $i + 1, $result->get_error_message());
                    } else {
                        $updated++;
                    }
                } else {
                    $result = wp_insert_post($post_data, true);
                    if (is_wp_error($result)) {
                        $errors[] = sprintf('Row %d: %s', $i + 1, $result->get_error_message());
                    } else {
                        $inserted++;
                    }
                }

                continue;
            }

            if ($entity === 'products') {
                if (!class_exists('WooCommerce')) {
                    return new WP_Error('quick_importer_woo_missing', 'WooCommerce is not active.', ['status' => 400]);
                }

                $product_id = isset($assoc['id']) ? absint($assoc['id']) : 0;
                $post_data = [
                    'post_type' => 'product',
                    'post_title' => $assoc['name'] ?? '',
                    'post_content' => $assoc['description'] ?? '',
                    'post_status' => $assoc['status'] ?: 'draft',
                ];

                if ($product_id > 0 && get_post($product_id) instanceof WP_Post) {
                    $post_data['ID'] = $product_id;
                    $result = wp_update_post($post_data, true);
                    if (is_wp_error($result)) {
                        $errors[] = sprintf('Row %d: %s', $i + 1, $result->get_error_message());
                        continue;
                    }
                    $target_id = $product_id;
                    $updated++;
                } else {
                    $result = wp_insert_post($post_data, true);
                    if (is_wp_error($result)) {
                        $errors[] = sprintf('Row %d: %s', $i + 1, $result->get_error_message());
                        continue;
                    }
                    $target_id = (int) $result;
                    $inserted++;
                }

                update_post_meta($target_id, '_regular_price', $assoc['regular_price'] ?? '');
                update_post_meta($target_id, '_price', $assoc['regular_price'] ?? '');
                update_post_meta($target_id, '_sku', $assoc['sku'] ?? '');
                update_post_meta($target_id, '_manage_stock', 'yes');
                update_post_meta($target_id, '_stock', $assoc['stock_quantity'] ?? '0');
                update_post_meta($target_id, '_stock_status', ((int) ($assoc['stock_quantity'] ?? 0) > 0) ? 'instock' : 'outofstock');
            }
        }

        return [
            'inserted' => $inserted,
            'updated' => $updated,
            'errors' => $errors,
        ];
    }

    /**
     * @param array<string, mixed> $params
     * @return WP_REST_Response|WP_Error
     */
    private function proxy_wp_plugins_request(string $method, string $route, array $params = [])
    {
        $request = new WP_REST_Request($method, $route);
        foreach ($params as $key => $value) {
            $request->set_param($key, $value);
        }

        $response = rest_do_request($request);
        if ($response instanceof WP_Error) {
            return $response;
        }

        if ($response instanceof WP_REST_Response) {
            return $response;
        }

        if ($response instanceof WP_HTTP_Response) {
            return new WP_REST_Response($response->get_data(), $response->get_status());
        }

        return new WP_Error(
            'quick_connector_proxy_invalid_response',
            'Unexpected response while proxying plugin request.',
            ['status' => 500]
        );
    }

    private function register_default_modules(): void
    {
        $this->modules->register_module(new Quick_Connector_Module_WP_Content());
        $this->modules->register_module(new Quick_Connector_Module_Woo_Operations());
        $this->modules->register_module(new Quick_Connector_Module_Quick_Stack());
    }
}
