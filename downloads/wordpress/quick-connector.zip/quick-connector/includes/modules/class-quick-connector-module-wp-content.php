<?php

if (!defined('ABSPATH')) {
    exit;
}

class Quick_Connector_Module_WP_Content implements Quick_Connector_Module
{
    public function get_slug(): string
    {
        return 'wp-content';
    }

    public function get_name(): string
    {
        return 'WordPress Content';
    }

    public function get_description(): string
    {
        return 'Posts, pages, media, and core site content controls.';
    }

    public function get_version(): string
    {
        return QUICK_CONNECTOR_VERSION;
    }

    public function is_enabled(): bool
    {
        return true;
    }

    public function to_array(): array
    {
        return [
            'slug' => $this->get_slug(),
            'name' => $this->get_name(),
            'description' => $this->get_description(),
            'version' => $this->get_version(),
            'enabled' => $this->is_enabled(),
        ];
    }
}
