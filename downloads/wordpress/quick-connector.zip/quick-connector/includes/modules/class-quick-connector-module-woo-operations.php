<?php

if (!defined('ABSPATH')) {
    exit;
}

class Quick_Connector_Module_Woo_Operations implements Quick_Connector_Module
{
    public function get_slug(): string
    {
        return 'woo-operations';
    }

    public function get_name(): string
    {
        return 'WooCommerce Operations';
    }

    public function get_description(): string
    {
        return 'Orders, products, inventory, and customer operations.';
    }

    public function get_version(): string
    {
        return QUICK_CONNECTOR_VERSION;
    }

    public function is_enabled(): bool
    {
        return class_exists('WooCommerce');
    }

    public function to_array(): array
    {
        return [
            'slug' => $this->get_slug(),
            'name' => $this->get_name(),
            'description' => $this->get_description(),
            'version' => $this->get_version(),
            'enabled' => $this->is_enabled(),
        ];
    }
}
