<?php

if (!defined('ABSPATH')) {
    exit;
}

class Quick_Connector_Module_Quick_Stack implements Quick_Connector_Module
{
    public function get_slug(): string
    {
        return 'quick-stack';
    }

    public function get_name(): string
    {
        return 'Quick Stack';
    }

    public function get_description(): string
    {
        return 'Internal Quick-managed plugin stack and feature modules.';
    }

    public function get_version(): string
    {
        return QUICK_CONNECTOR_VERSION;
    }

    public function is_enabled(): bool
    {
        return true;
    }

    public function to_array(): array
    {
        return [
            'slug' => $this->get_slug(),
            'name' => $this->get_name(),
            'description' => $this->get_description(),
            'version' => $this->get_version(),
            'enabled' => $this->is_enabled(),
        ];
    }
}
