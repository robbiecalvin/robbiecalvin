<?php

if (!defined('ABSPATH')) {
    exit;
}

class Quick_Connector_Auth
{
    public function allow_public_health(): bool
    {
        return true;
    }

    /**
     * @return true|WP_Error
     */
    public function require_operator()
    {
        if (!is_user_logged_in()) {
            return new WP_Error(
                'quick_connector_auth_required',
                'Authentication required. Use a WordPress Application Password.',
                ['status' => 401]
            );
        }

        if (!current_user_can('manage_options')) {
            return new WP_Error(
                'quick_connector_forbidden',
                'Authenticated user does not have required capabilities.',
                ['status' => 403]
            );
        }

        return true;
    }
}
