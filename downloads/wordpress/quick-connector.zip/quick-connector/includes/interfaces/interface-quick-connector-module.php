<?php

if (!defined('ABSPATH')) {
    exit;
}

interface Quick_Connector_Module
{
    public function get_slug(): string;

    public function get_name(): string;

    public function get_description(): string;

    public function get_version(): string;

    public function is_enabled(): bool;

    /**
     * @return array<string, mixed>
     */
    public function to_array(): array;
}
