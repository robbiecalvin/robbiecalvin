<?php
/**
 * Plugin Name: Quick Mail
 * Plugin URI: https://quickwoo.pro
 * Description: Self-hosted email template builder and delivery layer for WordPress using SMTP or provider APIs.
 * Version: 1.0.0
 * Author: QuickWoo by Robbie Calvin
 * Author URI: https://quickwoo.pro
 * Text Domain: quick-mail
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/quick-core/bootstrap.php';
}

define( 'QMAIL_VERSION', '1.0.0' );
define( 'QMAIL_FILE', __FILE__ );
define( 'QMAIL_DIR', plugin_dir_path( __FILE__ ) );
define( 'QMAIL_URL', plugin_dir_url( __FILE__ ) );
define( 'QMAIL_IS_PREMIUM', true );
define( 'QMAIL_MODE_DEFAULT', 'default' );
define( 'QMAIL_MODE_SMTP', 'smtp' );
define( 'QMAIL_MODE_API', 'api' );

require_once QMAIL_DIR . 'includes/helpers.php';
require_once QMAIL_DIR . 'includes/class-qm-activator.php';
require_once QMAIL_DIR . 'includes/class-qm-settings.php';
require_once QMAIL_DIR . 'includes/class-qm-logger.php';
require_once QMAIL_DIR . 'includes/class-qm-renderer.php';
require_once QMAIL_DIR . 'includes/class-qm-templates.php';
require_once QMAIL_DIR . 'includes/class-qm-mappings.php';
require_once QMAIL_DIR . 'includes/class-qm-smtp.php';
require_once QMAIL_DIR . 'includes/class-qm-providers.php';
require_once QMAIL_DIR . 'includes/providers/class-qm-provider-sendgrid.php';
require_once QMAIL_DIR . 'includes/providers/class-qm-provider-mailgun.php';
require_once QMAIL_DIR . 'includes/providers/class-qm-provider-postmark.php';
require_once QMAIL_DIR . 'includes/providers/class-qm-provider-ses.php';
require_once QMAIL_DIR . 'includes/providers/class-qm-provider-webhook.php';
require_once QMAIL_DIR . 'includes/class-qm-queue.php';
require_once QMAIL_DIR . 'includes/class-qm-delivery.php';
require_once QMAIL_DIR . 'includes/class-qm-cron.php';
require_once QMAIL_DIR . 'includes/class-qm-tools.php';
require_once QMAIL_DIR . 'includes/class-qm-admin.php';

register_activation_hook( QMAIL_FILE, array( 'QMAIL_Activator', 'activate' ) );
register_deactivation_hook( QMAIL_FILE, array( 'QMAIL_Activator', 'deactivate' ) );

function qmail_bootstrap() {
    $settings  = new QMAIL_Settings();
    $logger    = new QMAIL_Logger( $settings );
    $renderer  = new QMAIL_Renderer();
    $templates = new QMAIL_Templates( $settings, $renderer );
    $providers = new QMAIL_Providers( $settings, $logger );
    $smtp      = new QMAIL_SMTP( $settings );
    $queue     = new QMAIL_Queue( $settings, $logger );
    $delivery  = new QMAIL_Delivery( $settings, $logger, $providers, $queue );
    global $qmail_delivery_instance;
    $qmail_delivery_instance = $delivery;
    $mappings  = new QMAIL_Mappings( $settings, $templates, $delivery );
    $cron      = new QMAIL_Cron( $settings, $logger, $queue );
    $tools     = new QMAIL_Tools( $settings, $templates, $delivery, $providers, $renderer );
    $admin     = new QMAIL_Admin( $settings, $templates, $mappings, $delivery, $logger, $tools, $renderer );

    $templates->hooks();
    $logger->hooks();
    $smtp->hooks();
    $queue->hooks();
    $delivery->hooks();
    $mappings->hooks();
    $cron->hooks();
    $admin->hooks();

    add_action(
        'quick_mail_send',
        function( $template_slug, $to, $context = array(), $headers = array(), $attachments = array() ) use ( $templates, $delivery ) {
            $rendered = $templates->build_email_from_slug( $template_slug, $context );
            if ( is_wp_error( $rendered ) ) {
                return $rendered;
            }

            return $delivery->send(
                array(
                    'to'          => $to,
                    'subject'     => $rendered['subject'],
                    'html'        => $rendered['html'],
                    'text'        => $rendered['text'],
                    'headers'     => $headers,
                    'attachments' => $attachments,
                    'template_id' => $rendered['template_id'],
                    'context'     => $context,
                    'from_name'   => $rendered['from_name'],
                    'from_email'  => $rendered['from_email'],
                    'reply_to'    => $rendered['reply_to'],
                )
            );
        },
        10,
        5
    );
}
add_action( 'plugins_loaded', 'qmail_bootstrap' );

if ( ! function_exists( 'qwoo_quick_mail_license_bootstrap' ) ) {
    function qwoo_quick_mail_license_bootstrap() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu', 'qwoo_quick_mail_license_menu' );
        add_action( 'admin_post_qwoo_quick_mail_activate_license', 'qwoo_quick_mail_license_handle_activate' );
        add_action( 'admin_post_qwoo_quick_mail_deactivate_license', 'qwoo_quick_mail_license_handle_deactivate' );
    }
    add_action( 'plugins_loaded', 'qwoo_quick_mail_license_bootstrap', 30 );

    function qwoo_quick_mail_license_option_key() {
        return 'qwoo_quick_mail_license';
    }

    function qwoo_quick_mail_license_product_scope() {
        return array( 'quick-mail' );
    }

    function qwoo_quick_mail_license_get_data() {
        $defaults = array(
            'license_key' => '',
            'license_status' => 'inactive',
            'license_message' => '',
        );

        $saved = get_option( qwoo_quick_mail_license_option_key(), array() );
        $saved = is_array( $saved ) ? $saved : array();

        return wp_parse_args( $saved, $defaults );
    }

    function qwoo_quick_mail_license_save_data( $data ) {
        $data = is_array( $data ) ? $data : array();

        $clean = array(
            'license_key' => sanitize_text_field( (string) ( $data['license_key'] ?? '' ) ),
            'license_status' => sanitize_key( (string) ( $data['license_status'] ?? 'inactive' ) ),
            'license_message' => sanitize_text_field( (string) ( $data['license_message'] ?? '' ) ),
        );

        update_option( qwoo_quick_mail_license_option_key(), $clean, false );
        return $clean;
    }

    function qwoo_quick_mail_license_menu() {
        add_options_page(
            'Lmail License',
            'Lmail License',
            'manage_options',
            'qwoo-quick-mail-license',
            'qwoo_quick_mail_license_render_page'
        );
    }

    function qwoo_quick_mail_license_render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = qwoo_quick_mail_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );

        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $status = qlic_get_license_status_for_key_products( $license_key, qwoo_quick_mail_license_product_scope() );
            if ( is_array( $status ) ) {
                $data['license_status'] = sanitize_key( (string) ( $status['status'] ?? $data['license_status'] ) );
                $data['license_message'] = sanitize_text_field( (string) ( $status['message'] ?? $data['license_message'] ) );
                if ( ! empty( $status['valid'] ) && ! empty( $status['domain_active'] ) ) {
                    $data['license_status'] = 'active';
                }
                qwoo_quick_mail_license_save_data( $data );
            }
        }

        $notice = isset( $_GET['qwoo_license_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qwoo_license_notice'] ) ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Lmail License', 'quick-mail' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-mail' ), (string) ( $data['license_status'] ?? 'inactive' ) ) ); ?></p>
            <?php if ( ! empty( $data['license_message'] ) ) : ?>
                <p><?php echo esc_html( (string) $data['license_message'] ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_mail_activate_license" />
                <?php wp_nonce_field( 'qwoo_quick_mail_activate_license', 'qwoo_quick_mail_activate_license_nonce' ); ?>
                <p>
                    <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( (string) ( $data['license_key'] ?? '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button type="submit" class="button button-primary"><?php echo esc_html__( 'Activate License', 'quick-mail' ); ?></button>
                </p>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_mail_deactivate_license" />
                <?php wp_nonce_field( 'qwoo_quick_mail_deactivate_license', 'qwoo_quick_mail_deactivate_license_nonce' ); ?>
                <p><button type="submit" class="button"><?php echo esc_html__( 'Deactivate License', 'quick-mail' ); ?></button></p>
            </form>
        </div>
        <?php
    }

    function qwoo_quick_mail_license_redirect( $message ) {
        $url = add_query_arg(
            array(
                'page' => 'qwoo-quick-mail-license',
                'qwoo_license_notice' => rawurlencode( (string) $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    function qwoo_quick_mail_license_handle_activate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-mail' ) );
        }

        check_admin_referer( 'qwoo_quick_mail_activate_license', 'qwoo_quick_mail_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        if ( '' === $license_key ) {
            qwoo_quick_mail_license_save_data(
                array(
                    'license_key' => '',
                    'license_status' => 'inactive',
                    'license_message' => 'License key is required.',
                )
            );
            qwoo_quick_mail_license_redirect( 'License key is required.' );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            qwoo_quick_mail_license_save_data(
                array(
                    'license_key' => $license_key,
                    'license_status' => 'invalid',
                    'license_message' => 'Quick License plugin is required for activation.',
                )
            );
            qwoo_quick_mail_license_redirect( 'Quick License plugin is required for activation.' );
        }

        $result = qlic_activate_license_key_for_products( $license_key, qwoo_quick_mail_license_product_scope() );
        $data = array(
            'license_key' => $license_key,
            'license_status' => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'license_message' => sanitize_text_field( (string) ( $result['message'] ?? 'License validation failed.' ) ),
        );
        if ( ! empty( $result['valid'] ) ) {
            $data['license_status'] = 'active';
        }

        qwoo_quick_mail_license_save_data( $data );
        qwoo_quick_mail_license_redirect( (string) $data['license_message'] );
    }

    function qwoo_quick_mail_license_handle_deactivate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-mail' ) );
        }

        check_admin_referer( 'qwoo_quick_mail_deactivate_license', 'qwoo_quick_mail_deactivate_license_nonce' );

        $data = qwoo_quick_mail_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );
        $message = 'License deactivated.';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products( $license_key, qwoo_quick_mail_license_product_scope() );
            if ( is_array( $result ) && ! empty( $result['message'] ) ) {
                $message = sanitize_text_field( (string) $result['message'] );
            }
        }

        qwoo_quick_mail_license_save_data(
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => $message,
            )
        );

        qwoo_quick_mail_license_redirect( $message );
    }
}
