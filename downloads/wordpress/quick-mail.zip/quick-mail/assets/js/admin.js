(function($){
  'use strict';

  function insertAtCursor(el, text) {
    if (!el) return;
    const start = el.selectionStart || 0;
    const end = el.selectionEnd || 0;
    const before = el.value.substring(0, start);
    const after = el.value.substring(end);
    el.value = before + text + after;
    const pos = start + text.length;
    el.selectionStart = pos;
    el.selectionEnd = pos;
    el.focus();
  }

  $(document).on('change', '.qmail-insert', function(){
    const val = $(this).val();
    if (!val) return;
    const targetId = $(this).data('target');
    const prefix = $(this).data('prefix') || '';
    const suffix = $(this).data('suffix') || '';
    const field = document.getElementById(targetId);
    if (field) {
      insertAtCursor(field, prefix + val + suffix);
    }
    $(this).val('');
  });
})(jQuery);
