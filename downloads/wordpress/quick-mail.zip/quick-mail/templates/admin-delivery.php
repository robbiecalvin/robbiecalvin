<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="wrap">
  <h1>Quick Mail - Delivery</h1>
  <?php if ( ! empty( $_GET['qmail_notice'] ) ) : ?>
    <div class="notice notice-info"><p><?php echo esc_html( wp_unslash( $_GET['qmail_notice'] ) ); ?></p></div>
  <?php endif; ?>
  <?php if ( ! qmail_is_premium() ) : ?>
    <div class="notice notice-warning"><p><?php echo esc_html( sprintf( 'Free tier usage: %d / 500 emails this month.', qmail_get_monthly_send_count() ) ); ?></p></div>
  <?php endif; ?>

  <form method="post" class="qmail-card">
    <?php wp_nonce_field( 'qmail_action', 'qmail_nonce' ); ?>
    <input type="hidden" name="qmail_action" value="save_delivery">

    <h2>Mode</h2>
    <p>
      <select name="settings[delivery_mode]">
        <option value="default" <?php selected( 'default', $settings['delivery_mode'] ); ?>>Default wp_mail</option>
        <option value="smtp" <?php selected( 'smtp', $settings['delivery_mode'] ); ?>>SMTP (PHPMailer)</option>
        <option value="api" <?php selected( 'api', $settings['delivery_mode'] ); ?>>Provider API</option>
      </select>
    </p>

    <h2>Global Sender</h2>
    <p><label>From Name <input type="text" name="settings[from_name]" value="<?php echo esc_attr( $settings['from_name'] ); ?>" class="regular-text"></label></p>
    <p><label>From Email <input type="email" name="settings[from_email]" value="<?php echo esc_attr( $settings['from_email'] ); ?>" class="regular-text"></label></p>
    <p><label>Reply-To <input type="email" name="settings[reply_to]" value="<?php echo esc_attr( $settings['reply_to'] ); ?>" class="regular-text"></label></p>

    <h2>SMTP Settings</h2>
    <div class="qmail-row">
      <p><label>Host <input type="text" name="settings[smtp_host]" value="<?php echo esc_attr( $settings['smtp_host'] ); ?>"></label></p>
      <p><label>Port <input type="number" name="settings[smtp_port]" value="<?php echo esc_attr( $settings['smtp_port'] ); ?>"></label></p>
      <p><label>Encryption
        <select name="settings[smtp_encryption]">
          <option value="none" <?php selected( 'none', $settings['smtp_encryption'] ); ?>>None</option>
          <option value="tls" <?php selected( 'tls', $settings['smtp_encryption'] ); ?>>TLS</option>
          <option value="ssl" <?php selected( 'ssl', $settings['smtp_encryption'] ); ?>>SSL</option>
        </select>
      </label></p>
      <p><label>Username <input type="text" name="settings[smtp_user]" value="<?php echo esc_attr( $settings['smtp_user'] ); ?>"></label></p>
      <p><label>Password <input type="password" name="settings[smtp_pass]" value="" placeholder="<?php echo esc_attr( qmail_mask_secret( $settings['smtp_pass'] ) ); ?>"></label></p>
      <p><label>SMTP From Name <input type="text" name="settings[smtp_from_name]" value="<?php echo esc_attr( $settings['smtp_from_name'] ); ?>"></label></p>
      <p><label>SMTP From Email <input type="email" name="settings[smtp_from_email]" value="<?php echo esc_attr( $settings['smtp_from_email'] ); ?>"></label></p>
      <p><label>SMTP Reply-To <input type="email" name="settings[smtp_reply_to]" value="<?php echo esc_attr( $settings['smtp_reply_to'] ); ?>"></label></p>
    </div>

    <h2>API Provider</h2>
    <p><label>Provider
      <select name="settings[provider]">
        <option value="sendgrid" <?php selected( 'sendgrid', $settings['provider'] ); ?>>SendGrid</option>
        <option value="mailgun" <?php selected( 'mailgun', $settings['provider'] ); ?>>Mailgun</option>
        <option value="postmark" <?php selected( 'postmark', $settings['provider'] ); ?>>Postmark</option>
        <option value="ses" <?php selected( 'ses', $settings['provider'] ); ?>>Amazon SES</option>
        <option value="webhook" <?php selected( 'webhook', $settings['provider'] ); ?>>Custom Webhook</option>
      </select>
    </label></p>

    <div class="qmail-row">
      <p><label>SendGrid Key <input type="password" name="settings[provider_sendgrid_key]" value="" placeholder="<?php echo esc_attr( qmail_mask_secret( $settings['provider_sendgrid_key'] ) ); ?>"></label></p>
      <p><label>Mailgun Key <input type="password" name="settings[provider_mailgun_key]" value="" placeholder="<?php echo esc_attr( qmail_mask_secret( $settings['provider_mailgun_key'] ) ); ?>"></label></p>
      <p><label>Mailgun Domain <input type="text" name="settings[provider_mailgun_domain]" value="<?php echo esc_attr( $settings['provider_mailgun_domain'] ); ?>"></label></p>
      <p><label>Postmark Key <input type="password" name="settings[provider_postmark_key]" value="" placeholder="<?php echo esc_attr( qmail_mask_secret( $settings['provider_postmark_key'] ) ); ?>"></label></p>
      <p><label>SES Key <input type="password" name="settings[provider_ses_key]" value="" placeholder="<?php echo esc_attr( qmail_mask_secret( $settings['provider_ses_key'] ) ); ?>"></label></p>
      <p><label>SES Secret <input type="password" name="settings[provider_ses_secret]" value="" placeholder="<?php echo esc_attr( qmail_mask_secret( $settings['provider_ses_secret'] ) ); ?>"></label></p>
      <p><label>SES Region <input type="text" name="settings[provider_ses_region]" value="<?php echo esc_attr( $settings['provider_ses_region'] ); ?>"></label></p>
      <p><label>Webhook URL <input type="url" name="settings[provider_webhook_url]" value="<?php echo esc_attr( $settings['provider_webhook_url'] ); ?>"></label></p>
      <p><label>Webhook Key <input type="password" name="settings[provider_webhook_key]" value="" placeholder="<?php echo esc_attr( qmail_mask_secret( $settings['provider_webhook_key'] ) ); ?>"></label></p>
    </div>

    <h2>Reliability</h2>
    <p><label><input type="checkbox" name="settings[fallback_to_wp_mail]" value="1" <?php checked( 1, (int) $settings['fallback_to_wp_mail'] ); ?>> Fallback to wp_mail if API provider fails</label></p>
    <p><label><input type="checkbox" name="settings[queue_enabled]" value="1" <?php checked( 1, (int) $settings['queue_enabled'] ); ?>> Enable queue mode (process via cron)</label></p>

    <?php submit_button( 'Save Delivery Settings' ); ?>
  </form>

  <form method="post" class="qmail-card" style="margin-top:16px;">
    <?php wp_nonce_field( 'qmail_action', 'qmail_nonce' ); ?>
    <input type="hidden" name="qmail_action" value="send_smtp_test">
    <h2>SMTP Test</h2>
    <p><label>Recipient Email <input type="email" name="smtp_test_to" class="regular-text" required></label></p>
    <?php submit_button( 'Send Test Email', 'secondary', 'submit', false ); ?>
  </form>
</div>
