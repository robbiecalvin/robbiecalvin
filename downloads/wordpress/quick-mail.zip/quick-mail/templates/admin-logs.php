<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="wrap">
  <h1>Quick Mail - Logs</h1>
  <p><a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'page' => 'qmail-logs', 'qmail_export_logs' => 1 ), admin_url( 'admin.php' ) ), 'qmail_export_logs' ) ); ?>">Export CSV</a></p>

  <table class="widefat striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Trigger</th>
        <th>Recipient</th>
        <th>Status</th>
        <th>Error</th>
      </tr>
    </thead>
    <tbody>
      <?php if ( empty( $logs ) ) : ?>
        <tr><td colspan="6">No logs found.</td></tr>
      <?php else : ?>
        <?php foreach ( $logs as $log ) : ?>
          <tr>
            <td><?php echo esc_html( $log['id'] ); ?></td>
            <td><?php echo esc_html( $log['sent_at'] ); ?></td>
            <td><?php echo esc_html( $log['trigger_event'] ?? '' ); ?></td>
            <td><?php echo esc_html( $log['to_email'] ); ?></td>
            <td><?php echo esc_html( $log['status'] ); ?></td>
            <td><?php echo esc_html( $log['error_message'] ); ?></td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>
