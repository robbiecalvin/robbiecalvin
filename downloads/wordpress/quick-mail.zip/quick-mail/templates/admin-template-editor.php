<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="wrap">
  <h1>Quick Mail - Templates</h1>
  <?php if ( ! empty( $_GET['qmail_notice'] ) ) : ?>
    <div class="notice notice-info"><p><?php echo esc_html( wp_unslash( $_GET['qmail_notice'] ) ); ?></p></div>
  <?php endif; ?>

  <div class="qmail-grid qmail-grid-2">
    <div class="qmail-card">
      <h2><?php echo $editing ? 'Edit Template' : 'New Template'; ?></h2>
      <form method="post">
        <?php wp_nonce_field( 'qmail_action', 'qmail_nonce' ); ?>
        <input type="hidden" name="qmail_action" value="save_template">
        <input type="hidden" name="template_id" value="<?php echo esc_attr( $editing['id'] ?? 0 ); ?>">

        <p><label>Template Name<br><input type="text" name="name" class="regular-text" required value="<?php echo esc_attr( $editing['name'] ?? '' ); ?>"></label></p>
        <p><label>Slug<br><input type="text" name="slug" class="regular-text" value="<?php echo esc_attr( $editing['slug'] ?? '' ); ?>"></label></p>
        <p><label>Subject<br><input type="text" name="subject" class="widefat" value="<?php echo esc_attr( $editing['subject'] ?? '' ); ?>"></label></p>

        <div class="qmail-row">
          <p><label>From Name<br><input type="text" name="from_name" class="regular-text" value="<?php echo esc_attr( $editing['from_name'] ?? '' ); ?>"></label></p>
          <p><label>From Email<br><input type="email" name="from_email" class="regular-text" value="<?php echo esc_attr( $editing['from_email'] ?? '' ); ?>"></label></p>
          <p><label>Reply-To<br><input type="email" name="reply_to" class="regular-text" value="<?php echo esc_attr( $editing['reply_to'] ?? '' ); ?>"></label></p>
        </div>

        <div class="qmail-row">
          <p><label>Status<br>
            <select name="status">
              <option value="draft" <?php selected( 'draft', $editing['status'] ?? 'draft' ); ?>>Draft</option>
              <option value="publish" <?php selected( 'publish', $editing['status'] ?? '' ); ?>>Published</option>
            </select>
          </label></p>
          <p><label>Category<br>
            <select name="category">
              <?php foreach ( $categories as $cat_key => $cat_label ) : ?>
              <option value="<?php echo esc_attr( $cat_key ); ?>" <?php selected( $cat_key, $editing['category'] ?? 'transactional' ); ?>><?php echo esc_html( $cat_label ); ?></option>
              <?php endforeach; ?>
            </select>
          </label></p>
          <p><label>Trigger Event<br>
            <select name="trigger_event">
              <?php foreach ( $events as $event_key => $event_label ) : ?>
              <option value="<?php echo esc_attr( $event_key ); ?>" <?php selected( $event_key, $editing['trigger_event'] ?? 'custom_hook' ); ?>><?php echo esc_html( $event_label ); ?></option>
              <?php endforeach; ?>
            </select>
          </label></p>
        </div>

        <p>
          <label>Insert Variable
            <select class="qmail-insert" data-target="qmail-html" data-prefix="{{" data-suffix="}}">
              <option value="">Select variable</option>
              <?php foreach ( $variables as $var_key => $var_val ) : ?>
              <option value="<?php echo esc_attr( $var_key ); ?>"><?php echo esc_html( $var_key ); ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <label>Insert Block
            <select class="qmail-insert" data-target="qmail-html">
              <option value="">Select block</option>
              <?php foreach ( $blocks as $block_key => $html ) : ?>
              <option value="<?php echo esc_attr( $html ); ?>"><?php echo esc_html( $block_key ); ?></option>
              <?php endforeach; ?>
            </select>
          </label>
        </p>

        <p><label>HTML Body (required)<br><textarea id="qmail-html" name="html" rows="14" class="large-text code" required><?php echo esc_textarea( $editing['html'] ?? '' ); ?></textarea></label></p>
        <p><label>Plain Text Body (optional)<br><textarea name="text" rows="7" class="large-text code"><?php echo esc_textarea( $editing['text'] ?? '' ); ?></textarea></label></p>
        <?php submit_button( 'Save Template' ); ?>
      </form>
    </div>

    <div class="qmail-card">
      <h2>Template Library</h2>
      <table class="widefat striped">
        <thead><tr><th>Name</th><th>Slug</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          <?php if ( empty( $templates ) ) : ?>
            <tr><td colspan="4">No templates found.</td></tr>
          <?php else : ?>
            <?php foreach ( $templates as $tpl ) : ?>
            <tr>
              <td><?php echo esc_html( $tpl['name'] ); ?></td>
              <td><?php echo esc_html( $tpl['slug'] ); ?></td>
              <td><?php echo esc_html( $tpl['status'] ); ?></td>
              <td>
                <a class="button button-small" href="<?php echo esc_url( add_query_arg( array( 'page' => 'qmail-templates', 'template_id' => $tpl['id'] ), admin_url( 'admin.php' ) ) ); ?>">Edit</a>
                <form method="post" style="display:inline-block">
                  <?php wp_nonce_field( 'qmail_action', 'qmail_nonce' ); ?>
                  <input type="hidden" name="qmail_action" value="duplicate_template">
                  <input type="hidden" name="template_id" value="<?php echo esc_attr( $tpl['id'] ); ?>">
                  <button type="submit" class="button button-small">Duplicate</button>
                </form>
                <form method="post" style="display:inline-block" onsubmit="return confirm('Delete this template?');">
                  <?php wp_nonce_field( 'qmail_action', 'qmail_nonce' ); ?>
                  <input type="hidden" name="qmail_action" value="delete_template">
                  <input type="hidden" name="template_id" value="<?php echo esc_attr( $tpl['id'] ); ?>">
                  <button type="submit" class="button button-small button-link-delete">Delete</button>
                </form>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>

      <h3>Variable Reference</h3>
      <p>Use tokens like <code>{{site_name}}</code> or default values like <code>{{user_display_name|there}}</code>.</p>
      <ul>
        <?php foreach ( $variables as $var_key => $var_val ) : ?>
          <li><code><?php echo esc_html( '{{' . $var_key . '}}' ); ?></code></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</div>
