<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="wrap">
  <h1>Quick Mail - Mappings</h1>
  <?php if ( ! empty( $_GET['qmail_notice'] ) ) : ?>
    <div class="notice notice-info"><p><?php echo esc_html( wp_unslash( $_GET['qmail_notice'] ) ); ?></p></div>
  <?php endif; ?>

  <form method="post" class="qmail-card">
    <?php wp_nonce_field( 'qmail_action', 'qmail_nonce' ); ?>
    <input type="hidden" name="qmail_action" value="save_mappings">

    <table class="widefat striped">
      <thead>
        <tr>
          <th>Event</th>
          <th>Enabled</th>
          <th>Template</th>
          <th>Role Condition</th>
          <th>Order Status Condition</th>
          <th>User Meta Key Condition</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ( $events as $event_key => $event_label ) :
          $row = $mappings[ $event_key ] ?? array();
        ?>
          <tr>
            <td><?php echo esc_html( $event_label ); ?></td>
            <td><input type="checkbox" name="mappings[<?php echo esc_attr( $event_key ); ?>][enabled]" value="1" <?php checked( 1, (int) ( $row['enabled'] ?? 0 ) ); ?>></td>
            <td>
              <select name="mappings[<?php echo esc_attr( $event_key ); ?>][template_id]">
                <option value="0">Select template</option>
                <?php foreach ( $templates as $tpl ) : ?>
                  <option value="<?php echo esc_attr( $tpl['id'] ); ?>" <?php selected( absint( $row['template_id'] ?? 0 ), $tpl['id'] ); ?>><?php echo esc_html( $tpl['name'] ); ?></option>
                <?php endforeach; ?>
              </select>
            </td>
            <td><input type="text" name="mappings[<?php echo esc_attr( $event_key ); ?>][role]" value="<?php echo esc_attr( $row['role'] ?? '' ); ?>" placeholder="subscriber"></td>
            <td><input type="text" name="mappings[<?php echo esc_attr( $event_key ); ?>][order_status]" value="<?php echo esc_attr( $row['order_status'] ?? '' ); ?>" placeholder="processing"></td>
            <td><input type="text" name="mappings[<?php echo esc_attr( $event_key ); ?>][user_meta]" value="<?php echo esc_attr( $row['user_meta'] ?? '' ); ?>" placeholder="meta_key"></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <?php submit_button( 'Save Mappings' ); ?>
  </form>
</div>
