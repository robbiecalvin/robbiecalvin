<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Settings {
    public function get_all() {
        return qmail_get_settings();
    }

    public function get( $key, $default = null ) {
        $settings = $this->get_all();
        return array_key_exists( $key, $settings ) ? $settings[ $key ] : $default;
    }

    public function update( $data ) {
        $current = $this->get_all();
        $clean   = $this->sanitize( $data, $current );
        update_option( 'qmail_settings', $clean );
        return $clean;
    }

    public function sanitize( $input, $base = array() ) {
        $input = is_array( $input ) ? $input : array();
        $base  = is_array( $base ) && ! empty( $base ) ? $base : qmail_default_settings();

        $base['delivery_mode']       = in_array( $input['delivery_mode'] ?? $base['delivery_mode'], array( QMAIL_MODE_DEFAULT, QMAIL_MODE_SMTP, QMAIL_MODE_API ), true ) ? $input['delivery_mode'] : $base['delivery_mode'];
        $base['provider']            = sanitize_key( $input['provider'] ?? $base['provider'] );
        $base['fallback_to_wp_mail'] = empty( $input['fallback_to_wp_mail'] ) ? 0 : 1;
        $base['queue_enabled']       = empty( $input['queue_enabled'] ) ? 0 : 1;
        $base['queue_batch_size']    = max( 1, min( 200, absint( $input['queue_batch_size'] ?? $base['queue_batch_size'] ) ) );
        $base['log_bodies']          = empty( $input['log_bodies'] ) ? 0 : 1;
        $base['log_retention_days']  = max( 1, min( 365, absint( $input['log_retention_days'] ?? $base['log_retention_days'] ) ) );

        $base['smtp_host']        = sanitize_text_field( $input['smtp_host'] ?? $base['smtp_host'] );
        $base['smtp_port']        = max( 1, min( 65535, absint( $input['smtp_port'] ?? $base['smtp_port'] ) ) );
        $base['smtp_encryption']  = in_array( $input['smtp_encryption'] ?? $base['smtp_encryption'], array( '', 'none', 'tls', 'ssl' ), true ) ? $input['smtp_encryption'] : 'tls';
        $base['smtp_user']        = sanitize_text_field( $input['smtp_user'] ?? $base['smtp_user'] );
        $base['smtp_pass']        = isset( $input['smtp_pass'] ) && '' !== trim( (string) $input['smtp_pass'] ) ? (string) $input['smtp_pass'] : $base['smtp_pass'];
        $base['smtp_from_name']   = sanitize_text_field( $input['smtp_from_name'] ?? $base['smtp_from_name'] );
        $base['smtp_from_email']  = sanitize_email( $input['smtp_from_email'] ?? $base['smtp_from_email'] );
        $base['smtp_reply_to']    = sanitize_email( $input['smtp_reply_to'] ?? $base['smtp_reply_to'] );
        $base['from_name']        = sanitize_text_field( $input['from_name'] ?? $base['from_name'] );
        $base['from_email']       = sanitize_email( $input['from_email'] ?? $base['from_email'] );
        $base['reply_to']         = sanitize_email( $input['reply_to'] ?? $base['reply_to'] );

        $provider_keys = array(
            'provider_sendgrid_key',
            'provider_mailgun_key',
            'provider_mailgun_domain',
            'provider_postmark_key',
            'provider_ses_key',
            'provider_ses_secret',
            'provider_ses_region',
            'provider_webhook_url',
            'provider_webhook_key',
        );

        foreach ( $provider_keys as $key ) {
            if ( isset( $input[ $key ] ) && '' !== trim( (string) $input[ $key ] ) ) {
                if ( false !== strpos( $key, 'url' ) ) {
                    $base[ $key ] = esc_url_raw( $input[ $key ] );
                } else {
                    $base[ $key ] = sanitize_text_field( $input[ $key ] );
                }
            }
        }

        $base['deliverability_notice'] = empty( $input['deliverability_notice'] ) ? 0 : 1;

        return $base;
    }

    public function get_mappings() {
        $mappings = get_option( 'qmail_mappings', array() );
        return is_array( $mappings ) ? $mappings : array();
    }

    public function update_mappings( $mappings ) {
        $clean = array();
        if ( ! is_array( $mappings ) ) {
            $mappings = array();
        }

        foreach ( $mappings as $event_key => $row ) {
            $clean[ sanitize_key( $event_key ) ] = array(
                'enabled'      => empty( $row['enabled'] ) ? 0 : 1,
                'template_id'  => absint( $row['template_id'] ?? 0 ),
                'role'         => sanitize_text_field( $row['role'] ?? '' ),
                'order_status' => sanitize_text_field( $row['order_status'] ?? '' ),
                'user_meta'    => sanitize_text_field( $row['user_meta'] ?? '' ),
            );
        }

        update_option( 'qmail_mappings', $clean );
        return $clean;
    }
}
