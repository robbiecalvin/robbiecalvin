<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Activator {
    public static function activate() {
        self::create_tables();

        if ( ! wp_next_scheduled( 'qmail_cron_prune_logs' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'qmail_cron_prune_logs' );
        }

        if ( ! wp_next_scheduled( 'qmail_cron_process_queue' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'qmail_cron_process_queue' );
        }

        $settings = get_option( 'qmail_settings', array() );
        if ( ! is_array( $settings ) ) {
            $settings = array();
        }

        update_option( 'qmail_settings', wp_parse_args( $settings, qmail_default_settings() ) );

        if ( false === get_option( qmail_usage_state_key(), false ) ) {
            update_option(
                qmail_usage_state_key(),
                array(
                    'month' => gmdate( 'Y-m' ),
                    'count' => 0,
                ),
                false
            );
        }
    }

    public static function deactivate() {
        wp_clear_scheduled_hook( 'qmail_cron_prune_logs' );
        wp_clear_scheduled_hook( 'qmail_cron_process_queue' );
    }

    private static function create_tables() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $log_table       = qmail_log_table_name();
        $queue_table     = qmail_queue_table_name();

        $sql_log = "CREATE TABLE {$log_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            sent_at DATETIME NOT NULL,
            to_email TEXT NOT NULL,
            subject TEXT NOT NULL,
            template_id BIGINT(20) UNSIGNED NULL,
            provider VARCHAR(50) NOT NULL,
            status VARCHAR(20) NOT NULL,
            error_message TEXT NULL,
            context_json LONGTEXT NULL,
            message_hash CHAR(64) NOT NULL,
            meta_json LONGTEXT NULL,
            PRIMARY KEY (id),
            KEY sent_at (sent_at),
            KEY status (status),
            KEY provider (provider)
        ) {$charset_collate};";

        $sql_queue = "CREATE TABLE {$queue_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            payload LONGTEXT NOT NULL,
            attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            created_at DATETIME NOT NULL,
            processed_at DATETIME NULL,
            last_error TEXT NULL,
            PRIMARY KEY (id),
            KEY status (status),
            KEY created_at (created_at)
        ) {$charset_collate};";

        dbDelta( $sql_log );
        dbDelta( $sql_queue );
    }
}
