<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Queue {
    private $settings;
    private $logger;

    public function __construct( QMAIL_Settings $settings, QMAIL_Logger $logger ) {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    public function hooks() {
        add_filter( 'cron_schedules', array( $this, 'add_minute_schedule' ) );
    }

    public function is_enabled() {
        return (bool) $this->settings->get( 'queue_enabled', 0 );
    }

    public function enqueue( $payload ) {
        global $wpdb;

        $result = $wpdb->insert(
            qmail_queue_table_name(),
            array(
                'payload'    => wp_json_encode( $payload ),
                'attempts'   => 0,
                'status'     => 'pending',
                'created_at' => gmdate( 'Y-m-d H:i:s' ),
            ),
            array( '%s', '%d', '%s', '%s' )
        );

        return false !== $result;
    }

    public function process_batch( $send_callback ) {
        global $wpdb;

        $batch = max( 1, absint( $this->settings->get( 'queue_batch_size', 20 ) ) );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM ' . qmail_queue_table_name() . ' WHERE status = %s ORDER BY id ASC LIMIT %d',
                'pending',
                $batch
            ),
            ARRAY_A
        );

        foreach ( $rows as $row ) {
            $payload = json_decode( (string) $row['payload'], true );
            if ( ! is_array( $payload ) ) {
                $this->mark_failed( (int) $row['id'], 'Invalid payload' );
                continue;
            }

            $result = call_user_func( $send_callback, $payload, true );
            if ( true === $result ) {
                $this->mark_sent( (int) $row['id'] );
            } else {
                $message = is_wp_error( $result ) ? $result->get_error_message() : (string) $result;
                $this->mark_failed( (int) $row['id'], $message );
            }
        }
    }

    public function add_minute_schedule( $schedules ) {
        if ( ! isset( $schedules['minute'] ) ) {
            $schedules['minute'] = array(
                'interval' => 60,
                'display'  => __( 'Every Minute', 'quick-mail' ),
            );
        }
        return $schedules;
    }

    private function mark_sent( $id ) {
        global $wpdb;
        $wpdb->update(
            qmail_queue_table_name(),
            array(
                'status'       => 'sent',
                'processed_at' => gmdate( 'Y-m-d H:i:s' ),
                'last_error'   => null,
            ),
            array( 'id' => absint( $id ) ),
            array( '%s', '%s', '%s' ),
            array( '%d' )
        );
    }

    private function mark_failed( $id, $error ) {
        global $wpdb;

        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT attempts FROM ' . qmail_queue_table_name() . ' WHERE id = %d', absint( $id ) ), ARRAY_A );
        $attempts = isset( $row['attempts'] ) ? absint( $row['attempts'] ) + 1 : 1;

        $wpdb->update(
            qmail_queue_table_name(),
            array(
                'attempts'     => $attempts,
                'status'       => ( $attempts >= 3 ) ? 'failed' : 'pending',
                'processed_at' => gmdate( 'Y-m-d H:i:s' ),
                'last_error'   => wp_strip_all_tags( (string) $error ),
            ),
            array( 'id' => absint( $id ) ),
            array( '%d', '%s', '%s', '%s' ),
            array( '%d' )
        );
    }
}
