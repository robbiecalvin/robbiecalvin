<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

interface QMAIL_Provider_Interface {
    public function send( $payload );
    public function test();
}

class QMAIL_Result {
    public $success = false;
    public $provider = '';
    public $message = '';
    public $meta = array();

    public function __construct( $success, $provider, $message = '', $meta = array() ) {
        $this->success  = (bool) $success;
        $this->provider = (string) $provider;
        $this->message  = (string) $message;
        $this->meta     = is_array( $meta ) ? $meta : array();
    }
}

class QMAIL_Providers {
    private $settings;
    private $logger;

    public function __construct( QMAIL_Settings $settings, QMAIL_Logger $logger ) {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    public function get_provider() {
        $provider = sanitize_key( $this->settings->get( 'provider', 'sendgrid' ) );

        switch ( $provider ) {
            case 'mailgun':
                return new QMAIL_Provider_Mailgun( $this->settings );
            case 'postmark':
                return new QMAIL_Provider_Postmark( $this->settings );
            case 'ses':
                return new QMAIL_Provider_SES( $this->settings );
            case 'webhook':
                return new QMAIL_Provider_Webhook( $this->settings );
            case 'sendgrid':
            default:
                return new QMAIL_Provider_SendGrid( $this->settings );
        }
    }

    public function send( $payload ) {
        $provider = $this->get_provider();
        if ( ! $provider instanceof QMAIL_Provider_Interface ) {
            return new QMAIL_Result( false, 'api', __( 'Provider adapter unavailable.', 'quick-mail' ) );
        }

        return $provider->send( $payload );
    }

    public function test_provider() {
        $provider = $this->get_provider();
        return $provider->test();
    }

    public static function wp_remote_send( $url, $headers, $body ) {
        return wp_remote_post(
            $url,
            array(
                'timeout' => 20,
                'headers' => $headers,
                'body'    => wp_json_encode( $body ),
            )
        );
    }

    public static function normalize_http_result( $response, $provider ) {
        if ( is_wp_error( $response ) ) {
            return new QMAIL_Result( false, $provider, $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        if ( $code >= 200 && $code < 300 ) {
            return new QMAIL_Result( true, $provider, 'ok', array( 'code' => $code, 'body' => substr( (string) $body, 0, 500 ) ) );
        }

        return new QMAIL_Result( false, $provider, 'HTTP ' . $code, array( 'code' => $code, 'body' => substr( (string) $body, 0, 500 ) ) );
    }
}
