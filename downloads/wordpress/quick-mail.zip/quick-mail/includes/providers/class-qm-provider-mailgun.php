<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Provider_Mailgun implements QMAIL_Provider_Interface {
    private $settings;

    public function __construct( QMAIL_Settings $settings ) {
        $this->settings = $settings;
    }

    public function send( $payload ) {
        $key    = qmail_get_option_or_constant( 'provider_mailgun_key', 'QUICK_MAIL_MAILGUN_KEY' );
        $domain = qmail_get_option_or_constant( 'provider_mailgun_domain', 'QUICK_MAIL_MAILGUN_DOMAIN' );
        if ( '' === $key || '' === $domain ) {
            return new QMAIL_Result( false, 'mailgun', __( 'Mailgun settings missing.', 'quick-mail' ) );
        }

        $to = qmail_extract_recipients( $payload['to'] ?? '' );
        if ( empty( $to ) ) {
            return new QMAIL_Result( false, 'mailgun', __( 'No valid recipients.', 'quick-mail' ) );
        }

        $response = wp_remote_post(
            'https://api.mailgun.net/v3/' . rawurlencode( $domain ) . '/messages',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Authorization' => 'Basic ' . base64_encode( 'api:' . $key ),
                ),
                'body'    => array(
                    'from'    => sprintf( '%s <%s>', $payload['from_name'], $payload['from_email'] ),
                    'to'      => implode( ',', $to ),
                    'subject' => $payload['subject'],
                    'html'    => $payload['html'],
                    'text'    => $payload['text'],
                    'h:Reply-To' => $payload['reply_to'] ?? '',
                ),
            )
        );

        return QMAIL_Providers::normalize_http_result( $response, 'mailgun' );
    }

    public function test() {
        return new QMAIL_Result( true, 'mailgun', __( 'Mailgun adapter loaded.', 'quick-mail' ) );
    }
}
