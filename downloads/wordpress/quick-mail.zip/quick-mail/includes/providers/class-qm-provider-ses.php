<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Provider_SES implements QMAIL_Provider_Interface {
    private $settings;

    public function __construct( QMAIL_Settings $settings ) {
        $this->settings = $settings;
    }

    public function send( $payload ) {
        $key    = qmail_get_option_or_constant( 'provider_ses_key', 'QUICK_MAIL_SES_KEY' );
        $secret = qmail_get_option_or_constant( 'provider_ses_secret', 'QUICK_MAIL_SES_SECRET' );
        $region = qmail_get_option_or_constant( 'provider_ses_region', 'QUICK_MAIL_SES_REGION' );

        if ( '' === $key || '' === $secret || '' === $region ) {
            return new QMAIL_Result( false, 'ses', __( 'SES credentials missing.', 'quick-mail' ) );
        }

        return new QMAIL_Result( false, 'ses', __( 'SES direct signing is not configured in this build. Use SMTP/API provider instead.', 'quick-mail' ) );
    }

    public function test() {
        return new QMAIL_Result( true, 'ses', __( 'SES adapter loaded.', 'quick-mail' ) );
    }
}
