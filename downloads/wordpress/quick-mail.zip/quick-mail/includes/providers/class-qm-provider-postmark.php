<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Provider_Postmark implements QMAIL_Provider_Interface {
    private $settings;

    public function __construct( QMAIL_Settings $settings ) {
        $this->settings = $settings;
    }

    public function send( $payload ) {
        $token = qmail_get_option_or_constant( 'provider_postmark_key', 'QUICK_MAIL_POSTMARK_KEY' );
        if ( '' === $token ) {
            return new QMAIL_Result( false, 'postmark', __( 'Postmark key missing.', 'quick-mail' ) );
        }

        $to = qmail_extract_recipients( $payload['to'] ?? '' );
        if ( empty( $to ) ) {
            return new QMAIL_Result( false, 'postmark', __( 'No valid recipients.', 'quick-mail' ) );
        }

        $body = array(
            'From'     => sprintf( '%s <%s>', $payload['from_name'], $payload['from_email'] ),
            'To'       => implode( ',', $to ),
            'Subject'  => $payload['subject'],
            'HtmlBody' => $payload['html'],
            'TextBody' => $payload['text'],
        );

        if ( ! empty( $payload['reply_to'] ) ) {
            $body['ReplyTo'] = $payload['reply_to'];
        }

        $response = QMAIL_Providers::wp_remote_send(
            'https://api.postmarkapp.com/email',
            array(
                'X-Postmark-Server-Token' => $token,
                'Accept'                  => 'application/json',
                'Content-Type'            => 'application/json',
            ),
            $body
        );

        return QMAIL_Providers::normalize_http_result( $response, 'postmark' );
    }

    public function test() {
        return new QMAIL_Result( true, 'postmark', __( 'Postmark adapter loaded.', 'quick-mail' ) );
    }
}
