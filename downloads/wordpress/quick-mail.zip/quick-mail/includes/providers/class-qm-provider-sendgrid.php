<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Provider_SendGrid implements QMAIL_Provider_Interface {
    private $settings;

    public function __construct( QMAIL_Settings $settings ) {
        $this->settings = $settings;
    }

    public function send( $payload ) {
        $key = qmail_get_option_or_constant( 'provider_sendgrid_key', 'QUICK_MAIL_SENDGRID_KEY' );
        if ( '' === $key ) {
            return new QMAIL_Result( false, 'sendgrid', __( 'SendGrid API key missing.', 'quick-mail' ) );
        }

        $to = qmail_extract_recipients( $payload['to'] ?? '' );
        if ( empty( $to ) ) {
            return new QMAIL_Result( false, 'sendgrid', __( 'No valid recipients.', 'quick-mail' ) );
        }

        $body = array(
            'personalizations' => array( array( 'to' => array_map( static function( $email ) { return array( 'email' => $email ); }, $to ) ) ),
            'from'             => array( 'email' => $payload['from_email'], 'name' => $payload['from_name'] ),
            'subject'          => $payload['subject'],
            'content'          => array(
                array( 'type' => 'text/plain', 'value' => $payload['text'] ),
                array( 'type' => 'text/html', 'value' => $payload['html'] ),
            ),
        );

        if ( ! empty( $payload['reply_to'] ) ) {
            $body['reply_to'] = array( 'email' => $payload['reply_to'] );
        }

        $response = QMAIL_Providers::wp_remote_send(
            'https://api.sendgrid.com/v3/mail/send',
            array(
                'Authorization' => 'Bearer ' . $key,
                'Content-Type'  => 'application/json',
            ),
            $body
        );

        return QMAIL_Providers::normalize_http_result( $response, 'sendgrid' );
    }

    public function test() {
        return new QMAIL_Result( true, 'sendgrid', __( 'SendGrid adapter loaded.', 'quick-mail' ) );
    }
}
