<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Provider_Webhook implements QMAIL_Provider_Interface {
    private $settings;

    public function __construct( QMAIL_Settings $settings ) {
        $this->settings = $settings;
    }

    public function send( $payload ) {
        $url = qmail_get_option_or_constant( 'provider_webhook_url', 'QUICK_MAIL_WEBHOOK_URL' );
        $key = qmail_get_option_or_constant( 'provider_webhook_key', 'QUICK_MAIL_WEBHOOK_KEY' );

        if ( '' === $url ) {
            return new QMAIL_Result( false, 'webhook', __( 'Webhook URL missing.', 'quick-mail' ) );
        }

        $headers = array( 'Content-Type' => 'application/json' );
        if ( '' !== $key ) {
            $headers['Authorization'] = 'Bearer ' . $key;
        }

        $response = QMAIL_Providers::wp_remote_send( $url, $headers, $payload );
        return QMAIL_Providers::normalize_http_result( $response, 'webhook' );
    }

    public function test() {
        return new QMAIL_Result( true, 'webhook', __( 'Webhook adapter loaded.', 'quick-mail' ) );
    }
}
