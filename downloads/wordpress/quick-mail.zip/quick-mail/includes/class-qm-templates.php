<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Templates {
    private $settings;
    private $renderer;

    public function __construct( QMAIL_Settings $settings, QMAIL_Renderer $renderer ) {
        $this->settings = $settings;
        $this->renderer = $renderer;
    }

    public function hooks() {
        add_action( 'init', array( $this, 'register_post_type' ) );
    }

    public function register_post_type() {
        register_post_type(
            'qmail_template',
            array(
                'labels'       => array(
                    'name'          => __( 'Mail Templates', 'quick-mail' ),
                    'singular_name' => __( 'Mail Template', 'quick-mail' ),
                ),
                'public'       => false,
                'show_ui'      => false,
                'show_in_menu' => false,
                'supports'     => array( 'title' ),
            )
        );
    }

    public function get_all_templates() {
        $posts = get_posts(
            array(
                'post_type'      => 'qmail_template',
                'post_status'    => array( 'draft', 'publish' ),
                'posts_per_page' => 500,
                'orderby'        => 'title',
                'order'          => 'ASC',
            )
        );

        $items = array();
        foreach ( $posts as $post ) {
            $items[] = $this->get_template( $post->ID );
        }

        return array_filter( $items );
    }

    public function get_template( $id ) {
        $id   = absint( $id );
        $post = get_post( $id );
        if ( ! $post || 'qmail_template' !== $post->post_type ) {
            return null;
        }

        return array(
            'id'          => $post->ID,
            'name'        => $post->post_title,
            'slug'        => $post->post_name,
            'status'      => $post->post_status,
            'subject'     => get_post_meta( $post->ID, '_qmail_subject', true ),
            'from_name'   => get_post_meta( $post->ID, '_qmail_from_name', true ),
            'from_email'  => get_post_meta( $post->ID, '_qmail_from_email', true ),
            'reply_to'    => get_post_meta( $post->ID, '_qmail_reply_to', true ),
            'html'        => get_post_meta( $post->ID, '_qmail_html', true ),
            'text'        => get_post_meta( $post->ID, '_qmail_text', true ),
            'category'    => get_post_meta( $post->ID, '_qmail_category', true ) ?: 'transactional',
            'trigger_event' => get_post_meta( $post->ID, '_qmail_trigger_event', true ) ?: 'custom_hook',
            'description' => get_post_meta( $post->ID, '_qmail_description', true ),
        );
    }

    public function save_template( $data, $id = 0 ) {
        $id   = absint( $id );
        $name = sanitize_text_field( $data['name'] ?? '' );
        if ( '' === $name ) {
            return new WP_Error( 'invalid_name', __( 'Template name is required.', 'quick-mail' ) );
        }

        $postarr = array(
            'post_type'   => 'qmail_template',
            'post_title'  => $name,
            'post_name'   => sanitize_title( $data['slug'] ?? $name ),
            'post_status' => ( 'publish' === ( $data['status'] ?? 'draft' ) ) ? 'publish' : 'draft',
        );

        if ( $id > 0 ) {
            $postarr['ID'] = $id;
            $result        = wp_update_post( $postarr, true );
        } else {
            $result = wp_insert_post( $postarr, true );
        }

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $template_id = absint( $result );

        $subject = sanitize_text_field( $data['subject'] ?? '' );
        $html    = isset( $data['html'] ) ? (string) $data['html'] : '';
        $text    = isset( $data['text'] ) ? (string) $data['text'] : '';

        if ( '' === trim( $html ) ) {
            return new WP_Error( 'invalid_html', __( 'HTML body is required.', 'quick-mail' ) );
        }

        update_post_meta( $template_id, '_qmail_subject', $subject );
        update_post_meta( $template_id, '_qmail_from_name', sanitize_text_field( $data['from_name'] ?? '' ) );
        update_post_meta( $template_id, '_qmail_from_email', sanitize_email( $data['from_email'] ?? '' ) );
        update_post_meta( $template_id, '_qmail_reply_to', sanitize_email( $data['reply_to'] ?? '' ) );
        update_post_meta( $template_id, '_qmail_html', wp_kses_post( $html ) );
        update_post_meta( $template_id, '_qmail_text', wp_kses_post( $text ) );
        update_post_meta( $template_id, '_qmail_category', sanitize_key( $data['category'] ?? 'transactional' ) );
        update_post_meta( $template_id, '_qmail_trigger_event', sanitize_key( $data['trigger_event'] ?? 'custom_hook' ) );
        update_post_meta( $template_id, '_qmail_description', sanitize_text_field( $data['description'] ?? '' ) );

        return $template_id;
    }

    public function delete_template( $id ) {
        return (bool) wp_delete_post( absint( $id ), true );
    }

    public function duplicate_template( $id ) {
        $template = $this->get_template( $id );
        if ( ! $template ) {
            return new WP_Error( 'not_found', __( 'Template not found.', 'quick-mail' ) );
        }

        $template['name'] .= ' (Copy)';
        $template['slug'] .= '-copy';
        return $this->save_template( $template, 0 );
    }

    public function build_email_from_template_id( $template_id, $context = array() ) {
        $template = $this->get_template( $template_id );
        if ( ! $template || 'publish' !== $template['status'] ) {
            return new WP_Error( 'template_unavailable', __( 'Template is unavailable.', 'quick-mail' ) );
        }

        return $this->build_rendered( $template, $context );
    }

    public function build_email_from_slug( $slug, $context = array() ) {
        $slug = sanitize_title( $slug );
        $post = get_page_by_path( $slug, OBJECT, 'qmail_template' );
        if ( ! $post ) {
            return new WP_Error( 'template_not_found', __( 'Template slug not found.', 'quick-mail' ) );
        }

        return $this->build_email_from_template_id( $post->ID, $context );
    }

    public function export_template_json( $template_id ) {
        $template = $this->get_template( $template_id );
        if ( ! $template ) {
            return new WP_Error( 'not_found', __( 'Template not found.', 'quick-mail' ) );
        }

        return wp_json_encode( $template, JSON_PRETTY_PRINT );
    }

    public function import_template_json( $json ) {
        $data = json_decode( (string) $json, true );
        if ( ! is_array( $data ) ) {
            return new WP_Error( 'invalid_json', __( 'Invalid JSON.', 'quick-mail' ) );
        }

        unset( $data['id'] );
        return $this->save_template( $data, 0 );
    }

    private function build_rendered( $template, $context ) {
        $subject = $this->renderer->render_string( (string) $template['subject'], $context, $template['id'] );
        $html    = $this->renderer->render_html( (string) $template['html'], $context, $template['id'] );
        $text    = (string) $template['text'];

        if ( '' === trim( $text ) ) {
            $text = $this->renderer->to_plain_text( $html );
        } else {
            $text = $this->renderer->render_string( $text, $context, $template['id'] );
        }

        return array(
            'template_id' => $template['id'],
            'subject'     => $subject,
            'html'        => $html,
            'text'        => $text,
            'from_name'   => $template['from_name'],
            'from_email'  => $template['from_email'],
            'reply_to'    => $template['reply_to'],
        );
    }
}
