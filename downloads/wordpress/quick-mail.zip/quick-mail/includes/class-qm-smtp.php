<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_SMTP {
    private $settings;

    public function __construct( QMAIL_Settings $settings ) {
        $this->settings = $settings;
    }

    public function hooks() {
        add_action( 'phpmailer_init', array( $this, 'configure_phpmailer' ) );
    }

    public function configure_phpmailer( $phpmailer ) {
        if ( QMAIL_MODE_SMTP !== $this->settings->get( 'delivery_mode', QMAIL_MODE_DEFAULT ) ) {
            return;
        }

        $host = $this->settings->get( 'smtp_host', '' );
        if ( '' === $host ) {
            return;
        }

        $phpmailer->isSMTP();
        $phpmailer->Host       = $host;
        $phpmailer->Port       = (int) $this->settings->get( 'smtp_port', 587 );
        $phpmailer->SMTPAuth   = true;
        $phpmailer->Username   = $this->settings->get( 'smtp_user', '' );
        $phpmailer->Password   = qmail_get_option_or_constant( 'smtp_pass', 'QUICK_MAIL_SMTP_PASS' );

        $enc = $this->settings->get( 'smtp_encryption', 'tls' );
        $phpmailer->SMTPSecure = ( 'none' === $enc || '' === $enc ) ? '' : $enc;

        $from_email = $this->settings->get( 'smtp_from_email', '' );
        $from_name  = $this->settings->get( 'smtp_from_name', '' );

        if ( is_email( $from_email ) ) {
            $phpmailer->setFrom( $from_email, $from_name ?: get_bloginfo( 'name' ), false );
        }

        $reply_to = $this->settings->get( 'smtp_reply_to', '' );
        if ( is_email( $reply_to ) ) {
            $phpmailer->addReplyTo( $reply_to );
        }
    }

    public function validate_connection() {
        if ( ! class_exists( 'PHPMailer\PHPMailer\PHPMailer' ) ) {
            return new WP_Error( 'missing_phpmailer', __( 'PHPMailer is not available.', 'quick-mail' ) );
        }

        $mail = new PHPMailer\PHPMailer\PHPMailer( true );
        try {
            $mail->isSMTP();
            $mail->Host       = $this->settings->get( 'smtp_host', '' );
            $mail->Port       = (int) $this->settings->get( 'smtp_port', 587 );
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->settings->get( 'smtp_user', '' );
            $mail->Password   = qmail_get_option_or_constant( 'smtp_pass', 'QUICK_MAIL_SMTP_PASS' );
            $enc              = $this->settings->get( 'smtp_encryption', 'tls' );
            $mail->SMTPSecure = ( 'none' === $enc || '' === $enc ) ? '' : $enc;
            $mail->Timeout    = 10;
            $mail->SMTPDebug  = 0;
            $mail->smtpConnect();
            $mail->smtpClose();
            return true;
        } catch ( Exception $e ) {
            return new WP_Error( 'smtp_connection_failed', $e->getMessage() );
        }
    }
}
