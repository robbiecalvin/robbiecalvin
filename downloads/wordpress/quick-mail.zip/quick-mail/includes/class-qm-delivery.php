<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Delivery {
    private $settings;
    private $logger;
    private $providers;
    private $queue;
    private $bypass = false;

    public function __construct( QMAIL_Settings $settings, QMAIL_Logger $logger, QMAIL_Providers $providers, QMAIL_Queue $queue ) {
        $this->settings  = $settings;
        $this->logger    = $logger;
        $this->providers = $providers;
        $this->queue     = $queue;
    }

    public function hooks() {
        add_filter( 'pre_wp_mail', array( $this, 'intercept_wp_mail' ), 10, 2 );
    }

    public function intercept_wp_mail( $return, $atts ) {
        if ( $this->bypass ) {
            return null;
        }

        $payload = array(
            'to'          => $atts['to'] ?? '',
            'subject'     => $atts['subject'] ?? '',
            'html'        => is_string( $atts['message'] ?? '' ) ? (string) $atts['message'] : '',
            'text'        => wp_strip_all_tags( (string) ( $atts['message'] ?? '' ) ),
            'headers'     => $atts['headers'] ?? array(),
            'attachments' => $atts['attachments'] ?? array(),
            'template_id' => 0,
            'context'     => array( 'source' => 'wp_mail' ),
        );

        $result = $this->send( $payload );
        return true === $result ? true : $return;
    }

    public function send( $payload ) {
        $payload = $this->normalize_payload( $payload );

        if ( empty( $payload['to'] ) || '' === $payload['subject'] ) {
            return new WP_Error( 'invalid_payload', __( 'Missing recipient or subject.', 'quick-mail' ) );
        }

        if ( ! qmail_is_premium() ) {
            $monthly_count = qmail_get_monthly_send_count();
            if ( $monthly_count >= 500 ) {
                $this->logger->log(
                    array(
                        'to'          => $payload['to'],
                        'subject'     => $payload['subject'],
                        'template_id' => $payload['template_id'],
                        'provider'    => 'limit',
                        'status'      => 'failed',
                        'error'       => __( 'Monthly free-tier email limit reached (500).', 'quick-mail' ),
                        'context'     => $payload['context'],
                    )
                );
                return new WP_Error( 'qmail_limit_reached', __( 'Free tier allows up to 500 emails per month. Upgrade to Pro for unlimited sending.', 'quick-mail' ) );
            }
        }

        if ( $this->queue->is_enabled() && empty( $payload['_queue_processing'] ) ) {
            $this->queue->enqueue( $payload );
            return true;
        }

        $mode = $this->settings->get( 'delivery_mode', QMAIL_MODE_DEFAULT );

        if ( QMAIL_MODE_API === $mode ) {
            $result = $this->send_via_api( $payload );
            if ( true === $result && ! qmail_is_premium() ) {
                qmail_increment_monthly_send_count();
            }
            return $result;
        }

        $result = $this->send_via_wp_mail( $payload, QMAIL_MODE_SMTP === $mode ? 'smtp' : 'wp_mail' );
        if ( true === $result && ! qmail_is_premium() ) {
            qmail_increment_monthly_send_count();
        }
        return $result;
    }

    public function send_from_queue( $payload, $is_queue = false ) {
        $payload['_queue_processing'] = $is_queue;
        return $this->send( $payload );
    }

    private function send_via_api( $payload ) {
        $result = $this->providers->send( $payload );
        if ( $result->success ) {
            $this->logger->log(
                array(
                    'to'          => $payload['to'],
                    'subject'     => $payload['subject'],
                    'template_id' => $payload['template_id'],
                    'provider'    => $result->provider,
                    'status'      => 'sent',
                    'context'     => $payload['context'],
                    'meta'        => $result->meta,
                )
            );
            return true;
        }

        if ( $this->settings->get( 'fallback_to_wp_mail', 1 ) ) {
            return $this->send_via_wp_mail( $payload, 'wp_mail_fallback', $result->message );
        }

        $this->logger->log(
            array(
                'to'          => $payload['to'],
                'subject'     => $payload['subject'],
                'template_id' => $payload['template_id'],
                'provider'    => $result->provider,
                'status'      => 'failed',
                'error'       => $result->message,
                'context'     => $payload['context'],
                'meta'        => $result->meta,
            )
        );

        return new WP_Error( 'provider_failed', $result->message );
    }

    private function send_via_wp_mail( $payload, $provider = 'wp_mail', $prior_error = '' ) {
        $headers = is_array( $payload['headers'] ) ? $payload['headers'] : array();
        $headers[] = 'Content-Type: text/html; charset=UTF-8';

        if ( $payload['from_email'] ) {
            $headers[] = 'From: ' . $payload['from_name'] . ' <' . $payload['from_email'] . '>';
        }

        if ( $payload['reply_to'] ) {
            $headers[] = 'Reply-To: ' . $payload['reply_to'];
        }

        $this->bypass = true;
        $sent         = wp_mail( $payload['to'], $payload['subject'], $payload['html'], $headers, $payload['attachments'] );
        $this->bypass = false;

        $this->logger->log(
            array(
                'to'          => $payload['to'],
                'subject'     => $payload['subject'],
                'template_id' => $payload['template_id'],
                'provider'    => $provider,
                'status'      => $sent ? 'sent' : 'failed',
                'error'       => $sent ? '' : ( $prior_error ?: __( 'wp_mail failed', 'quick-mail' ) ),
                'context'     => $payload['context'],
            )
        );

        return $sent ? true : new WP_Error( 'send_failed', $prior_error ?: __( 'Failed to send mail.', 'quick-mail' ) );
    }

    private function normalize_payload( $payload ) {
        $payload = is_array( $payload ) ? $payload : array();

        $to = $payload['to'] ?? '';
        if ( is_array( $to ) ) {
            $to = array_values( array_filter( array_map( 'sanitize_email', $to ) ) );
        } else {
            $to = sanitize_text_field( (string) $to );
        }

        $from_name  = sanitize_text_field( $payload['from_name'] ?? $this->settings->get( 'from_name', get_bloginfo( 'name' ) ) );
        $from_email = sanitize_email( $payload['from_email'] ?? $this->settings->get( 'from_email', get_option( 'admin_email' ) ) );
        $reply_to   = sanitize_email( $payload['reply_to'] ?? $this->settings->get( 'reply_to', '' ) );

        return array(
            'to'                => $to,
            'subject'           => sanitize_text_field( $payload['subject'] ?? '' ),
            'html'              => (string) ( $payload['html'] ?? '' ),
            'text'              => (string) ( $payload['text'] ?? '' ),
            'headers'           => $payload['headers'] ?? array(),
            'attachments'       => is_array( $payload['attachments'] ?? null ) ? $payload['attachments'] : array(),
            'template_id'       => absint( $payload['template_id'] ?? 0 ),
            'context'           => is_array( $payload['context'] ?? null ) ? $payload['context'] : array(),
            'from_name'         => $from_name,
            'from_email'        => $from_email,
            'reply_to'          => $reply_to,
            '_queue_processing' => ! empty( $payload['_queue_processing'] ),
        );
    }
}
