<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Renderer {
    public function render_string( $template, $context, $template_id = 0 ) {
        $template = (string) $template;
        $context  = $this->normalize_context( $context, $template_id );

        $output = preg_replace_callback(
            '/\{\{\s*([a-zA-Z0-9_\-\.]+)(\|([^\}]+))?\s*\}\}/',
            function( $matches ) use ( $context ) {
                $key     = $matches[1];
                $default = isset( $matches[3] ) ? $matches[3] : '';
                $value   = array_key_exists( $key, $context ) ? $context[ $key ] : $default;
                if ( is_array( $value ) || is_object( $value ) ) {
                    $value = wp_json_encode( $value );
                }
                return (string) $value;
            },
            $template
        );

        return (string) $output;
    }

    public function render_html( $html, $context, $template_id = 0 ) {
        $rendered = $this->render_string( $html, $context, $template_id );
        $rendered = apply_filters( 'quick_mail_render_html', $rendered, $context, $template_id );
        return $rendered;
    }

    public function to_plain_text( $html ) {
        $html = wp_kses( $html, qmail_email_kses_allowed_html() );
        return trim( wp_strip_all_tags( str_replace( array( '<br>', '<br/>', '<br />' ), "\n", $html ) ) );
    }

    private function normalize_context( $context, $template_id ) {
        $base = qmail_build_default_variables();

        if ( ! is_array( $context ) ) {
            $context = array();
        }

        if ( isset( $context['user_id'] ) ) {
            $user = get_user_by( 'id', absint( $context['user_id'] ) );
            if ( $user ) {
                $context['user_email']        = $user->user_email;
                $context['user_display_name'] = $user->display_name;
            }
        }

        if ( isset( $context['order_id'] ) && class_exists( 'WooCommerce' ) ) {
            $order = wc_get_order( absint( $context['order_id'] ) );
            if ( $order ) {
                $context['order_id']     = (string) $order->get_id();
                $context['order_total']  = (string) $order->get_total();
                $context['order_status'] = (string) $order->get_status();
                if ( empty( $context['user_email'] ) ) {
                    $context['user_email'] = $order->get_billing_email();
                }
            }
        }

        $context = array_merge( $base, $context );
        return apply_filters( 'quick_mail_render_context', $context, $template_id );
    }
}
