<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Logger {
    private $settings;

    public function __construct( QMAIL_Settings $settings ) {
        $this->settings = $settings;
    }

    public function hooks() {
        add_action( 'qmail_log_event', array( $this, 'log' ), 10, 1 );
    }

    public function log( $data ) {
        global $wpdb;

        $data = is_array( $data ) ? $data : array();

        $wpdb->insert(
            qmail_log_table_name(),
            array(
                'sent_at'       => gmdate( 'Y-m-d H:i:s' ),
                'to_email'      => sanitize_text_field( is_array( $data['to'] ?? '' ) ? implode( ',', $data['to'] ) : (string) ( $data['to'] ?? '' ) ),
                'subject'       => sanitize_text_field( $data['subject'] ?? '' ),
                'template_id'   => ! empty( $data['template_id'] ) ? absint( $data['template_id'] ) : null,
                'provider'      => sanitize_key( $data['provider'] ?? 'wp_mail' ),
                'status'        => sanitize_key( $data['status'] ?? 'failed' ),
                'error_message' => isset( $data['error'] ) ? wp_strip_all_tags( (string) $data['error'] ) : null,
                'context_json'  => isset( $data['context'] ) ? qmail_safe_json( $this->redact_context( $data['context'] ) ) : null,
                'message_hash'  => qmail_hash_message( $data['to'] ?? '', $data['subject'] ?? '', $data['template_id'] ?? 0 ),
                'meta_json'     => isset( $data['meta'] ) ? qmail_safe_json( $data['meta'] ) : null,
            ),
            array( '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
        );
    }

    public function prune_logs() {
        global $wpdb;
        $days = max( 1, absint( $this->settings->get( 'log_retention_days', 14 ) ) );
        $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . qmail_log_table_name() . ' WHERE sent_at < %s', gmdate( 'Y-m-d H:i:s', time() - ( DAY_IN_SECONDS * $days ) ) ) );
    }

    public function get_logs( $args = array() ) {
        global $wpdb;

        $defaults = array(
            'status'   => '',
            'provider' => '',
            'paged'    => 1,
            'per_page' => 50,
        );
        $args     = wp_parse_args( $args, $defaults );

        $where  = ' WHERE 1=1 ';
        $params = array();

        if ( '' !== $args['status'] ) {
            $where    .= ' AND status = %s ';
            $params[] = sanitize_key( $args['status'] );
        }

        if ( '' !== $args['provider'] ) {
            $where    .= ' AND provider = %s ';
            $params[] = sanitize_key( $args['provider'] );
        }

        $offset = ( max( 1, absint( $args['paged'] ) ) - 1 ) * max( 1, absint( $args['per_page'] ) );

        $sql = 'SELECT * FROM ' . qmail_log_table_name() . $where . ' ORDER BY id DESC LIMIT %d OFFSET %d';
        $params[] = max( 1, absint( $args['per_page'] ) );
        $params[] = $offset;

        $rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
        if ( ! is_array( $rows ) ) {
            return array();
        }

        foreach ( $rows as &$row ) {
            $row['trigger_event'] = '';
            if ( ! empty( $row['context_json'] ) ) {
                $context = json_decode( (string) $row['context_json'], true );
                if ( is_array( $context ) ) {
                    $row['trigger_event'] = sanitize_key( (string) ( $context['trigger'] ?? '' ) );
                }
            }
        }

        return $rows;
    }

    public function export_csv() {
        if ( ! qmail_can_manage() ) {
            wp_die( esc_html__( 'Not allowed', 'quick-mail' ) );
        }

        check_admin_referer( 'qmail_export_logs' );

        $logs = $this->get_logs( array( 'per_page' => 1000 ) );

        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=qmail-logs-' . gmdate( 'Ymd-His' ) . '.csv' );

        $out = fopen( 'php://output', 'w' );
        fputcsv( $out, array( 'id', 'sent_at', 'trigger_event', 'to_email', 'subject', 'template_id', 'provider', 'status', 'error_message' ) );

        foreach ( $logs as $row ) {
            fputcsv( $out, array( $row['id'], $row['sent_at'], $row['trigger_event'] ?? '', $row['to_email'], $row['subject'], $row['template_id'], $row['provider'], $row['status'], $row['error_message'] ) );
        }

        fclose( $out );
        exit;
    }

    private function redact_context( $context ) {
        if ( ! is_array( $context ) ) {
            return array();
        }

        $blocked = array( 'password', 'pass', 'token', 'secret', 'authorization', 'api_key' );
        foreach ( $context as $k => $v ) {
            if ( in_array( strtolower( (string) $k ), $blocked, true ) ) {
                $context[ $k ] = '[redacted]';
            }
        }

        return $context;
    }
}
