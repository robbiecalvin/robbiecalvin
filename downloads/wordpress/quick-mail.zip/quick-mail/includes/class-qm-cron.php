<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Cron {
    private $settings;
    private $logger;
    private $queue;

    public function __construct( QMAIL_Settings $settings, QMAIL_Logger $logger, QMAIL_Queue $queue ) {
        $this->settings = $settings;
        $this->logger   = $logger;
        $this->queue    = $queue;
    }

    public function hooks() {
        add_action( 'qmail_cron_prune_logs', array( $this, 'prune_logs' ) );
        add_action( 'qmail_cron_process_queue', array( $this, 'process_queue' ) );
        add_action( 'init', array( $this, 'ensure_schedule' ) );
    }

    public function prune_logs() {
        $this->logger->prune_logs();
    }

    public function process_queue() {
        if ( ! $this->queue->is_enabled() ) {
            return;
        }

        if ( ! class_exists( 'QMAIL_Delivery' ) ) {
            return;
        }

        global $qmail_delivery_instance;
        if ( ! $qmail_delivery_instance instanceof QMAIL_Delivery ) {
            return;
        }

        $this->queue->process_batch( array( $qmail_delivery_instance, 'send_from_queue' ) );
    }

    public function ensure_schedule() {
        if ( wp_next_scheduled( 'qmail_cron_process_queue' ) ) {
            return;
        }

        $schedules = wp_get_schedules();
        $recurrence = isset( $schedules['minute'] ) ? 'minute' : 'hourly';
        wp_schedule_event( time() + MINUTE_IN_SECONDS, $recurrence, 'qmail_cron_process_queue' );
    }
}
