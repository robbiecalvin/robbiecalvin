<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Tools {
    private $settings;
    private $templates;
    private $delivery;
    private $providers;
    private $renderer;

    public function __construct( QMAIL_Settings $settings, QMAIL_Templates $templates, QMAIL_Delivery $delivery, QMAIL_Providers $providers, QMAIL_Renderer $renderer ) {
        $this->settings  = $settings;
        $this->templates = $templates;
        $this->delivery  = $delivery;
        $this->providers = $providers;
        $this->renderer  = $renderer;
    }

    public function send_test_email( $to, $template_id, $context_json ) {
        $to          = sanitize_email( $to );
        $template_id = absint( $template_id );

        if ( ! is_email( $to ) ) {
            return new WP_Error( 'invalid_email', __( 'Invalid recipient email.', 'quick-mail' ) );
        }

        $context = json_decode( (string) $context_json, true );
        if ( ! is_array( $context ) ) {
            $context = array();
        }

        $rendered = $this->templates->build_email_from_template_id( $template_id, $context );
        if ( is_wp_error( $rendered ) ) {
            return $rendered;
        }

        return $this->delivery->send(
            array(
                'to'          => $to,
                'subject'     => $rendered['subject'],
                'html'        => $rendered['html'],
                'text'        => $rendered['text'],
                'template_id' => $template_id,
                'context'     => $context,
                'from_name'   => $rendered['from_name'],
                'from_email'  => $rendered['from_email'],
                'reply_to'    => $rendered['reply_to'],
            )
        );
    }

    public function preview_template( $template_id, $context_json ) {
        $template_id = absint( $template_id );
        $context     = json_decode( (string) $context_json, true );

        if ( ! is_array( $context ) ) {
            $context = array();
        }

        $rendered = $this->templates->build_email_from_template_id( $template_id, $context );
        if ( is_wp_error( $rendered ) ) {
            return $rendered;
        }

        return wp_kses( $rendered['html'], qmail_email_kses_allowed_html() );
    }

    public function test_provider() {
        return $this->providers->test_provider();
    }
}
