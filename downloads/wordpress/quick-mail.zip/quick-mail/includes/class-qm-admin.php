<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Admin {
    private $settings;
    private $templates;
    private $mappings;
    private $delivery;
    private $logger;
    private $tools;
    private $renderer;

    public function __construct( QMAIL_Settings $settings, QMAIL_Templates $templates, QMAIL_Mappings $mappings, QMAIL_Delivery $delivery, QMAIL_Logger $logger, QMAIL_Tools $tools, QMAIL_Renderer $renderer ) {
        $this->settings  = $settings;
        $this->templates = $templates;
        $this->mappings  = $mappings;
        $this->delivery  = $delivery;
        $this->logger    = $logger;
        $this->tools     = $tools;
        $this->renderer  = $renderer;
    }

    public function hooks() {
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'admin_init', array( $this, 'handle_actions' ) );
        add_action( 'admin_notices', array( $this, 'render_limit_notice' ) );
    }

    public function register_menu() {
        add_submenu_page( 'quickwoo', 'Quick Mail', 'Quick Mail', 'manage_options', 'qmail-templates', array( $this, 'render_templates_page' ) );
        add_menu_page( 'Quick Mail', 'Quick Mail', 'manage_options', 'qmail-templates', array( $this, 'render_templates_page' ), 'dashicons-email-alt2', 63 );
        add_submenu_page( 'qmail-templates', 'Templates', 'Templates', 'manage_options', 'qmail-templates', array( $this, 'render_templates_page' ) );
        add_submenu_page( 'qmail-templates', 'Mappings', 'Mappings', 'manage_options', 'qmail-mappings', array( $this, 'render_mappings_page' ) );
        add_submenu_page( 'qmail-templates', 'Delivery', 'Delivery', 'manage_options', 'qmail-delivery', array( $this, 'render_delivery_page' ) );
        add_submenu_page( 'qmail-templates', 'Logs', 'Logs', 'manage_options', 'qmail-logs', array( $this, 'render_logs_page' ) );
        add_submenu_page( 'qmail-templates', 'Tools', 'Tools', 'manage_options', 'qmail-tools', array( $this, 'render_tools_page' ) );
        add_submenu_page( 'qmail-templates', 'Settings', 'Settings', 'manage_options', 'qmail-settings', array( $this, 'render_settings_page' ) );
    }

    public function enqueue_assets( $hook ) {
        if ( false === strpos( (string) $hook, 'qmail' ) ) {
            return;
        }

        wp_enqueue_style( 'qmail-admin', QMAIL_URL . 'assets/css/admin.css', array(), QMAIL_VERSION );
        wp_enqueue_script( 'qmail-admin', QMAIL_URL . 'assets/js/admin.js', array( 'jquery' ), QMAIL_VERSION, true );
    }

    public function handle_actions() {
        if ( ! is_admin() || ! qmail_can_manage() ) {
            return;
        }

        if ( ! empty( $_POST['qmail_action'] ) ) {
            $action = sanitize_key( wp_unslash( $_POST['qmail_action'] ) );
            if ( ! isset( $_POST['qmail_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['qmail_nonce'] ) ), 'qmail_action' ) ) {
                return;
            }

            switch ( $action ) {
                case 'save_template':
                    $this->save_template();
                    break;
                case 'delete_template':
                    $this->delete_template();
                    break;
                case 'duplicate_template':
                    $this->duplicate_template();
                    break;
                case 'save_mappings':
                    $this->save_mappings();
                    break;
                case 'save_delivery':
                    $this->save_delivery();
                    break;
                case 'save_settings':
                    $this->save_settings();
                    break;
                case 'send_test_email':
                    $this->send_test_email();
                    break;
                case 'preview_template':
                    $this->preview_template();
                    break;
                case 'provider_test':
                    $this->provider_test();
                    break;
                case 'send_smtp_test':
                    $this->send_smtp_test();
                    break;
            }
        }

        if ( ! empty( $_GET['qmail_export_logs'] ) && ! empty( $_GET['_wpnonce'] ) ) {
            $this->logger->export_csv();
        }
    }

    public function render_templates_page() {
        if ( ! qmail_can_manage() ) {
            wp_die( esc_html__( 'Not allowed', 'quick-mail' ) );
        }

        $templates   = $this->templates->get_all_templates();
        $categories  = qmail_get_template_categories();
        $blocks      = qmail_template_blocks();
        $variables   = qmail_build_default_variables();
        $events      = $this->mappings->get_supported_events();
        $editing_id  = isset( $_GET['template_id'] ) ? absint( $_GET['template_id'] ) : 0;
        $editing     = $editing_id ? $this->templates->get_template( $editing_id ) : null;

        include QMAIL_DIR . 'templates/admin-template-editor.php';
    }

    public function render_mappings_page() {
        if ( ! qmail_can_manage() ) {
            wp_die( esc_html__( 'Not allowed', 'quick-mail' ) );
        }

        $events    = $this->mappings->get_supported_events();
        $mappings  = $this->settings->get_mappings();
        $templates = $this->templates->get_all_templates();

        include QMAIL_DIR . 'templates/admin-mappings.php';
    }

    public function render_delivery_page() {
        if ( ! qmail_can_manage() ) {
            wp_die( esc_html__( 'Not allowed', 'quick-mail' ) );
        }

        $settings = $this->settings->get_all();
        include QMAIL_DIR . 'templates/admin-delivery.php';
    }

    public function render_logs_page() {
        if ( ! qmail_can_manage() ) {
            wp_die( esc_html__( 'Not allowed', 'quick-mail' ) );
        }

        $logs = $this->logger->get_logs(
            array(
                'status'   => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '',
                'provider' => isset( $_GET['provider'] ) ? sanitize_key( wp_unslash( $_GET['provider'] ) ) : '',
            )
        );

        include QMAIL_DIR . 'templates/admin-logs.php';
    }

    public function render_tools_page() {
        if ( ! qmail_can_manage() ) {
            wp_die( esc_html__( 'Not allowed', 'quick-mail' ) );
        }

        $templates = $this->templates->get_all_templates();
        $preview   = get_transient( 'qmail_preview_' . get_current_user_id() );
        $message   = get_transient( 'qmail_tools_message_' . get_current_user_id() );

        delete_transient( 'qmail_preview_' . get_current_user_id() );
        delete_transient( 'qmail_tools_message_' . get_current_user_id() );

        echo '<div class="wrap"><h1>Quick Mail - Tools</h1>';
        if ( $message ) {
            echo '<div class="notice notice-info"><p>' . esc_html( $message ) . '</p></div>';
        }

        echo '<div class="qmail-grid">';
        echo '<div class="qmail-card"><h2>Send Test Email</h2><form method="post">';
        wp_nonce_field( 'qmail_action', 'qmail_nonce' );
        echo '<input type="hidden" name="qmail_action" value="send_test_email">';
        echo '<p><label>Recipient <input type="email" name="to" required class="regular-text"></label></p>';
        echo '<p><label>Template <select name="template_id">';
        foreach ( $templates as $tpl ) {
            echo '<option value="' . esc_attr( $tpl['id'] ) . '">' . esc_html( $tpl['name'] ) . '</option>';
        }
        echo '</select></label></p>';
        echo '<p><label>Context JSON<br><textarea name="context_json" class="large-text code" rows="5">{}</textarea></label></p>';
        submit_button( 'Send Test Email' );
        echo '</form></div>';

        echo '<div class="qmail-card"><h2>Preview Template</h2><form method="post">';
        wp_nonce_field( 'qmail_action', 'qmail_nonce' );
        echo '<input type="hidden" name="qmail_action" value="preview_template">';
        echo '<p><label>Template <select name="template_id">';
        foreach ( $templates as $tpl ) {
            echo '<option value="' . esc_attr( $tpl['id'] ) . '">' . esc_html( $tpl['name'] ) . '</option>';
        }
        echo '</select></label></p>';
        echo '<p><label>Context JSON<br><textarea name="context_json" class="large-text code" rows="5">{}</textarea></label></p>';
        submit_button( 'Preview' );
        echo '</form>';

        if ( ! empty( $preview ) ) {
            echo '<h3>Preview Output</h3><div class="qmail-preview">' . wp_kses( $preview, qmail_email_kses_allowed_html() ) . '</div>';
        }
        echo '</div>';

        echo '<div class="qmail-card"><h2>Provider API Test</h2><form method="post">';
        wp_nonce_field( 'qmail_action', 'qmail_nonce' );
        echo '<input type="hidden" name="qmail_action" value="provider_test">';
        submit_button( 'Run Provider Test' );
        echo '</form></div>';
        echo '</div></div>';
    }

    public function render_settings_page() {
        if ( ! qmail_can_manage() ) {
            wp_die( esc_html__( 'Not allowed', 'quick-mail' ) );
        }

        $settings = $this->settings->get_all();
        $memory   = size_format( memory_get_usage( true ) );

        echo '<div class="wrap"><h1>Quick Mail - Settings</h1><form method="post">';
        wp_nonce_field( 'qmail_action', 'qmail_nonce' );
        echo '<input type="hidden" name="qmail_action" value="save_settings">';
        echo '<table class="form-table">';
        echo '<tr><th scope="row">Queue batch size</th><td><input type="number" min="1" max="200" name="settings[queue_batch_size]" value="' . esc_attr( $settings['queue_batch_size'] ) . '"></td></tr>';
        echo '<tr><th scope="row">Log retention days</th><td><input type="number" min="1" max="365" name="settings[log_retention_days]" value="' . esc_attr( $settings['log_retention_days'] ) . '"></td></tr>';
        echo '<tr><th scope="row">Log email bodies</th><td><label><input type="checkbox" name="settings[log_bodies]" value="1" ' . checked( 1, (int) $settings['log_bodies'], false ) . '> Enable</label></td></tr>';
        echo '<tr><th scope="row">Deliverability notice</th><td><label><input type="checkbox" name="settings[deliverability_notice]" value="1" ' . checked( 1, (int) $settings['deliverability_notice'], false ) . '> Show SPF/DKIM/DMARC guidance</label></td></tr>';
        echo '<tr><th scope="row">Current memory usage</th><td>' . esc_html( $memory ) . '</td></tr>';
        echo '</table>';
        submit_button( 'Save Settings' );
        echo '</form></div>';
    }

    private function save_template() {
        $id = isset( $_POST['template_id'] ) ? absint( $_POST['template_id'] ) : 0;

        $result = $this->templates->save_template(
            array(
                'name'       => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
                'slug'       => sanitize_title( wp_unslash( $_POST['slug'] ?? '' ) ),
                'status'     => sanitize_key( wp_unslash( $_POST['status'] ?? 'draft' ) ),
                'subject'    => sanitize_text_field( wp_unslash( $_POST['subject'] ?? '' ) ),
                'from_name'  => sanitize_text_field( wp_unslash( $_POST['from_name'] ?? '' ) ),
                'from_email' => sanitize_email( wp_unslash( $_POST['from_email'] ?? '' ) ),
                'reply_to'   => sanitize_email( wp_unslash( $_POST['reply_to'] ?? '' ) ),
                'html'       => wp_unslash( $_POST['html'] ?? '' ),
                'text'       => wp_unslash( $_POST['text'] ?? '' ),
                'category'   => sanitize_key( wp_unslash( $_POST['category'] ?? 'transactional' ) ),
                'trigger_event' => sanitize_key( wp_unslash( $_POST['trigger_event'] ?? 'custom_hook' ) ),
            ),
            $id
        );

        if ( is_wp_error( $result ) ) {
            wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-templates', 'qmail_notice' => rawurlencode( $result->get_error_message() ) ), admin_url( 'admin.php' ) ) );
            exit;
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-templates', 'template_id' => absint( $result ), 'qmail_notice' => 'Template saved' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private function delete_template() {
        $id = isset( $_POST['template_id'] ) ? absint( $_POST['template_id'] ) : 0;
        if ( $id ) {
            $this->templates->delete_template( $id );
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-templates', 'qmail_notice' => 'Template deleted' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private function duplicate_template() {
        $id = isset( $_POST['template_id'] ) ? absint( $_POST['template_id'] ) : 0;
        if ( $id ) {
            $this->templates->duplicate_template( $id );
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-templates', 'qmail_notice' => 'Template duplicated' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private function save_mappings() {
        $mappings = isset( $_POST['mappings'] ) ? (array) wp_unslash( $_POST['mappings'] ) : array();
        $this->settings->update_mappings( $mappings );

        wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-mappings', 'qmail_notice' => 'Mappings saved' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private function save_delivery() {
        $settings = isset( $_POST['settings'] ) ? (array) wp_unslash( $_POST['settings'] ) : array();
        $this->settings->update( $settings );

        wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-delivery', 'qmail_notice' => 'Delivery settings saved' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private function save_settings() {
        $settings = isset( $_POST['settings'] ) ? (array) wp_unslash( $_POST['settings'] ) : array();
        $this->settings->update( $settings );

        wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-settings', 'qmail_notice' => 'Settings saved' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private function send_test_email() {
        $result = $this->tools->send_test_email(
            sanitize_email( wp_unslash( $_POST['to'] ?? '' ) ),
            absint( $_POST['template_id'] ?? 0 ),
            wp_unslash( $_POST['context_json'] ?? '{}' )
        );

        $message = is_wp_error( $result ) ? 'Send failed: ' . $result->get_error_message() : 'Test email sent/queued.';
        set_transient( 'qmail_tools_message_' . get_current_user_id(), $message, 120 );

        wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-tools' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private function preview_template() {
        $preview = $this->tools->preview_template(
            absint( $_POST['template_id'] ?? 0 ),
            wp_unslash( $_POST['context_json'] ?? '{}' )
        );

        if ( is_wp_error( $preview ) ) {
            set_transient( 'qmail_tools_message_' . get_current_user_id(), 'Preview failed: ' . $preview->get_error_message(), 120 );
        } else {
            set_transient( 'qmail_preview_' . get_current_user_id(), $preview, 120 );
            set_transient( 'qmail_tools_message_' . get_current_user_id(), 'Preview generated.', 120 );
        }

        wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-tools' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private function provider_test() {
        $result  = $this->tools->test_provider();
        $message = ( $result instanceof QMAIL_Result ) ? ( $result->success ? 'Provider check OK: ' . $result->provider : 'Provider check failed: ' . $result->message ) : 'Provider check could not run.';
        set_transient( 'qmail_tools_message_' . get_current_user_id(), $message, 120 );

        wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-tools' ), admin_url( 'admin.php' ) ) );
        exit;
    }

    private function send_smtp_test() {
        $to = sanitize_email( wp_unslash( $_POST['smtp_test_to'] ?? '' ) );
        if ( ! is_email( $to ) ) {
            wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-delivery', 'qmail_notice' => rawurlencode( 'Invalid SMTP test recipient email.' ) ), admin_url( 'admin.php' ) ) );
            exit;
        }

        $result = $this->delivery->send(
            array(
                'to'          => $to,
                'subject'     => 'Quick Mail SMTP Test',
                'html'        => '<p>SMTP configuration test from Quick Mail.</p>',
                'text'        => 'SMTP configuration test from Quick Mail.',
                'template_id' => 0,
                'context'     => array( 'trigger' => 'smtp_test' ),
            )
        );

        $message = is_wp_error( $result ) ? 'SMTP test failed: ' . $result->get_error_message() : 'SMTP test message sent.';
        wp_safe_redirect( add_query_arg( array( 'page' => 'qmail-delivery', 'qmail_notice' => rawurlencode( $message ) ), admin_url( 'admin.php' ) ) );
        exit;
    }

    public function render_limit_notice() {
        if ( ! qmail_can_manage() || qmail_is_premium() ) {
            return;
        }

        if ( empty( $_GET['page'] ) || false === strpos( sanitize_text_field( wp_unslash( $_GET['page'] ) ), 'qmail' ) ) {
            return;
        }

        $count = qmail_get_monthly_send_count();
        if ( $count < 500 ) {
            return;
        }

        echo '<div class="notice notice-warning"><p>';
        echo esc_html__( 'Free tier monthly limit reached (500 emails). Sending is blocked until next month or upgrade to Pro.', 'quick-mail' );
        echo '</p></div>';
    }
}
