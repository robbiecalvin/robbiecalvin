<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class QMAIL_Mappings {
    private $settings;
    private $templates;
    private $delivery;

    public function __construct( QMAIL_Settings $settings, QMAIL_Templates $templates, QMAIL_Delivery $delivery ) {
        $this->settings = $settings;
        $this->templates = $templates;
        $this->delivery = $delivery;
    }

    public function hooks() {
        add_filter( 'wp_new_user_notification_email', array( $this, 'map_new_user' ), 20, 3 );
        add_filter( 'retrieve_password_notification_email', array( $this, 'map_reset_password' ), 20, 4 );
        add_action( 'quick_mail_abandoned_cart', array( $this, 'map_abandoned_cart' ), 20, 1 );
        add_action( 'quick_mail_newsletter_signup', array( $this, 'map_newsletter_signup' ), 20, 1 );
        add_action( 'quick_mail_custom_hook', array( $this, 'map_custom_hook' ), 20, 2 );

        if ( class_exists( 'WooCommerce' ) ) {
            add_action( 'woocommerce_order_status_processing', array( $this, 'map_wc_processing' ), 20, 2 );
            add_action( 'woocommerce_order_status_completed', array( $this, 'map_wc_completed' ), 20, 2 );
            add_action( 'woocommerce_order_status_failed', array( $this, 'map_wc_failed' ), 20, 2 );
            add_action( 'woocommerce_order_fully_refunded', array( $this, 'map_wc_refund' ), 20, 2 );
        }
    }

    public function get_supported_events() {
        $events = array(
            'wp_new_user'       => __( 'WordPress: New User Registration', 'quick-mail' ),
            'wp_password_reset' => __( 'WP: Password Reset', 'quick-mail' ),
            'abandoned_cart'    => __( 'WooCommerce: Abandoned Cart', 'quick-mail' ),
            'newsletter_signup' => __( 'Newsletter Signup', 'quick-mail' ),
            'custom_hook'       => __( 'Custom Hook Event', 'quick-mail' ),
        );

        if ( class_exists( 'WooCommerce' ) ) {
            $events['wc_processing'] = __( 'Woo: Processing Order', 'quick-mail' );
            $events['wc_completed']  = __( 'Woo: Completed Order', 'quick-mail' );
            $events['wc_failed']     = __( 'Woo: Failed Order', 'quick-mail' );
            $events['wc_refund']     = __( 'Woo: Refunded Order', 'quick-mail' );
        }

        return $events;
    }

    public function map_abandoned_cart( $payload = array() ) {
        $this->send_generic_mapping( 'abandoned_cart', $payload );
    }

    public function map_newsletter_signup( $payload = array() ) {
        $this->send_generic_mapping( 'newsletter_signup', $payload );
    }

    public function map_custom_hook( $event_key = 'custom_hook', $payload = array() ) {
        $event_key = sanitize_key( (string) $event_key );
        if ( '' === $event_key ) {
            $event_key = 'custom_hook';
        }
        $this->send_generic_mapping( $event_key, $payload );
    }

    public function get_mapping( $event ) {
        $all = $this->settings->get_mappings();
        return isset( $all[ $event ] ) && is_array( $all[ $event ] ) ? $all[ $event ] : array();
    }

    public function map_new_user( $wp_new_user_notification_email, $user, $blogname ) {
        $mapping = $this->get_mapping( 'wp_new_user' );
        if ( empty( $mapping['enabled'] ) || empty( $mapping['template_id'] ) ) {
            return $wp_new_user_notification_email;
        }

        $role = isset( $user->roles[0] ) ? $user->roles[0] : '';
        if ( ! $this->passes_conditions( $mapping, $role, $user->ID, '' ) ) {
            return $wp_new_user_notification_email;
        }

        $rendered = $this->templates->build_email_from_template_id(
            $mapping['template_id'],
            array(
                'user_id'           => $user->ID,
                'user_email'        => $user->user_email,
                'user_display_name' => $user->display_name,
                'site_name'         => $blogname,
                'trigger'           => 'wp_new_user',
            )
        );

        if ( is_wp_error( $rendered ) ) {
            return $wp_new_user_notification_email;
        }

        $wp_new_user_notification_email['subject'] = $rendered['subject'];
        $wp_new_user_notification_email['message'] = $rendered['text'];
        $wp_new_user_notification_email['headers'] = array( 'Content-Type: text/html; charset=UTF-8' );

        return $wp_new_user_notification_email;
    }

    public function map_reset_password( $defaults, $key, $user_login, $user_data ) {
        $mapping = $this->get_mapping( 'wp_password_reset' );
        if ( empty( $mapping['enabled'] ) || empty( $mapping['template_id'] ) ) {
            return $defaults;
        }

        $role = isset( $user_data->roles[0] ) ? $user_data->roles[0] : '';
        if ( ! $this->passes_conditions( $mapping, $role, $user_data->ID, '' ) ) {
            return $defaults;
        }

        $reset_link = network_site_url( 'wp-login.php?action=rp&key=' . $key . '&login=' . rawurlencode( $user_login ), 'login' );

        $rendered = $this->templates->build_email_from_template_id(
            $mapping['template_id'],
            array(
                'user_id'           => $user_data->ID,
                'user_email'        => $user_data->user_email,
                'user_display_name' => $user_data->display_name,
                'reset_link'        => $reset_link,
                'trigger'           => 'wp_password_reset',
            )
        );

        if ( is_wp_error( $rendered ) ) {
            return $defaults;
        }

        $defaults['subject'] = $rendered['subject'];
        $defaults['message'] = $rendered['html'];
        $defaults['headers'] = array( 'Content-Type: text/html; charset=UTF-8' );

        return $defaults;
    }

    public function map_wc_processing( $order_id, $order ) {
        $this->send_wc_mapping( 'wc_processing', $order_id, $order, 'processing' );
    }

    public function map_wc_completed( $order_id, $order ) {
        $this->send_wc_mapping( 'wc_completed', $order_id, $order, 'completed' );
    }

    public function map_wc_failed( $order_id, $order ) {
        $this->send_wc_mapping( 'wc_failed', $order_id, $order, 'failed' );
    }

    public function map_wc_refund( $order_id, $refund_id ) {
        $order = wc_get_order( $order_id );
        $this->send_wc_mapping( 'wc_refund', $order_id, $order, 'refunded' );
    }

    private function send_wc_mapping( $event, $order_id, $order, $status ) {
        if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
            return;
        }

        $mapping = $this->get_mapping( $event );
        if ( empty( $mapping['enabled'] ) || empty( $mapping['template_id'] ) ) {
            return;
        }

        $user_id = $order->get_user_id();
        $role    = '';
        if ( $user_id ) {
            $user = get_user_by( 'id', $user_id );
            $role = $user && isset( $user->roles[0] ) ? $user->roles[0] : '';
        }

        if ( ! $this->passes_conditions( $mapping, $role, $user_id, $status ) ) {
            return;
        }

        $rendered = $this->templates->build_email_from_template_id(
            $mapping['template_id'],
            array(
                'order_id'          => $order_id,
                'order_number'      => $order->get_order_number(),
                'order_total'       => $order->get_total(),
                'order_status'      => $status,
                'user_id'           => $user_id,
                'user_email'        => $order->get_billing_email(),
                'user_display_name' => $order->get_formatted_billing_full_name(),
                'customer_name'     => $order->get_formatted_billing_full_name(),
            )
        );

        if ( is_wp_error( $rendered ) ) {
            return;
        }

        $this->delivery->send(
            array(
                'to'          => $order->get_billing_email(),
                'subject'     => $rendered['subject'],
                'html'        => $rendered['html'],
                'text'        => $rendered['text'],
                'template_id' => $mapping['template_id'],
                'context'     => array( 'order_id' => $order_id, 'order_status' => $status, 'trigger' => $event ),
                'from_name'   => $rendered['from_name'],
                'from_email'  => $rendered['from_email'],
                'reply_to'    => $rendered['reply_to'],
            )
        );
    }

    private function send_generic_mapping( $event, $payload ) {
        $mapping = $this->get_mapping( $event );
        if ( empty( $mapping['enabled'] ) || empty( $mapping['template_id'] ) ) {
            return;
        }

        $payload = is_array( $payload ) ? $payload : array();
        $to = sanitize_email( (string) ( $payload['to'] ?? ( $payload['user_email'] ?? '' ) ) );
        if ( ! is_email( $to ) ) {
            return;
        }

        $context = array_merge(
            array(
                'trigger' => $event,
            ),
            $payload
        );

        $rendered = $this->templates->build_email_from_template_id( (int) $mapping['template_id'], $context );
        if ( is_wp_error( $rendered ) ) {
            return;
        }

        $this->delivery->send(
            array(
                'to'          => $to,
                'subject'     => $rendered['subject'],
                'html'        => $rendered['html'],
                'text'        => $rendered['text'],
                'template_id' => (int) $mapping['template_id'],
                'context'     => $context,
                'from_name'   => $rendered['from_name'],
                'from_email'  => $rendered['from_email'],
                'reply_to'    => $rendered['reply_to'],
            )
        );
    }

    private function passes_conditions( $mapping, $role, $user_id, $order_status ) {
        if ( ! empty( $mapping['role'] ) && $mapping['role'] !== $role ) {
            return false;
        }

        if ( ! empty( $mapping['order_status'] ) && $mapping['order_status'] !== $order_status ) {
            return false;
        }

        if ( ! empty( $mapping['user_meta'] ) && $user_id ) {
            $meta = get_user_meta( $user_id, $mapping['user_meta'], true );
            if ( empty( $meta ) ) {
                return false;
            }
        }

        return true;
    }
}
