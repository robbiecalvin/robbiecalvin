<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function qmail_can_manage() {
    return current_user_can( 'manage_options' );
}

function qmail_is_premium() {
    // Owner-authorized free promotional edition. Set QW_DISABLE_FREE_PROMO to true to restore standard licensing.
    if ( ! defined( 'QW_DISABLE_FREE_PROMO' ) || ! QW_DISABLE_FREE_PROMO ) {
        return true;
    }

    return (bool) apply_filters( 'quick_mail_is_premium', defined( 'QMAIL_IS_PREMIUM' ) ? QMAIL_IS_PREMIUM : false );
}

function qmail_default_settings() {
    return array(
        'delivery_mode'           => QMAIL_MODE_DEFAULT,
        'provider'                => 'sendgrid',
        'fallback_to_wp_mail'     => 1,
        'queue_enabled'           => 0,
        'queue_batch_size'        => 20,
        'log_bodies'              => 0,
        'log_retention_days'      => 14,
        'smtp_host'               => '',
        'smtp_port'               => 587,
        'smtp_encryption'         => 'tls',
        'smtp_user'               => '',
        'smtp_pass'               => '',
        'smtp_from_name'          => '',
        'smtp_from_email'         => '',
        'smtp_reply_to'           => '',
        'provider_sendgrid_key'   => '',
        'provider_mailgun_key'    => '',
        'provider_mailgun_domain' => '',
        'provider_postmark_key'   => '',
        'provider_ses_key'        => '',
        'provider_ses_secret'     => '',
        'provider_ses_region'     => 'us-east-1',
        'provider_webhook_url'    => '',
        'provider_webhook_key'    => '',
        'from_name'               => get_bloginfo( 'name' ),
        'from_email'              => get_option( 'admin_email' ),
        'reply_to'                => '',
        'deliverability_notice'   => 1,
    );
}

function qmail_get_settings() {
    $saved = get_option( 'qmail_settings', array() );
    if ( ! is_array( $saved ) ) {
        $saved = array();
    }

    return wp_parse_args( $saved, qmail_default_settings() );
}

function qmail_get_option_or_constant( $setting_key, $constant_name ) {
    if ( defined( $constant_name ) && '' !== (string) constant( $constant_name ) ) {
        return (string) constant( $constant_name );
    }

    $settings = qmail_get_settings();
    return isset( $settings[ $setting_key ] ) ? (string) $settings[ $setting_key ] : '';
}

function qmail_mask_secret( $value ) {
    $value = (string) $value;
    if ( '' === $value ) {
        return '';
    }

    $len = strlen( $value );
    if ( $len <= 6 ) {
        return str_repeat( '*', $len );
    }

    return substr( $value, 0, 3 ) . str_repeat( '*', max( 4, $len - 6 ) ) . substr( $value, -3 );
}

function qmail_safe_json( $data, $limit = 5000 ) {
    $json = wp_json_encode( $data );
    if ( ! is_string( $json ) ) {
        return '{}';
    }

    if ( strlen( $json ) > $limit ) {
        $json = substr( $json, 0, $limit ) . '...';
    }

    return $json;
}

function qmail_hash_message( $to, $subject, $template_id ) {
    $to = is_array( $to ) ? implode( ',', $to ) : (string) $to;
    return hash( 'sha256', strtolower( trim( $to ) ) . '|' . trim( (string) $subject ) . '|' . (int) $template_id . '|' . gmdate( 'YmdH' ) );
}

function qmail_email_kses_allowed_html() {
    return array(
        'a'      => array( 'href' => true, 'title' => true, 'style' => true, 'target' => true ),
        'p'      => array( 'style' => true, 'align' => true ),
        'br'     => array(),
        'strong' => array(),
        'em'     => array(),
        'span'   => array( 'style' => true ),
        'div'    => array( 'style' => true, 'align' => true ),
        'table'  => array( 'style' => true, 'width' => true, 'cellpadding' => true, 'cellspacing' => true, 'border' => true, 'align' => true ),
        'tbody'  => array(),
        'thead'  => array(),
        'tr'     => array( 'style' => true, 'align' => true ),
        'td'     => array( 'style' => true, 'width' => true, 'valign' => true, 'align' => true, 'colspan' => true, 'rowspan' => true ),
        'th'     => array( 'style' => true, 'width' => true, 'valign' => true, 'align' => true ),
        'h1'     => array( 'style' => true, 'align' => true ),
        'h2'     => array( 'style' => true, 'align' => true ),
        'h3'     => array( 'style' => true, 'align' => true ),
        'h4'     => array( 'style' => true, 'align' => true ),
        'h5'     => array( 'style' => true, 'align' => true ),
        'h6'     => array( 'style' => true, 'align' => true ),
        'img'    => array( 'src' => true, 'alt' => true, 'width' => true, 'height' => true, 'style' => true ),
        'hr'     => array( 'style' => true ),
        'ul'     => array( 'style' => true ),
        'ol'     => array( 'style' => true ),
        'li'     => array( 'style' => true ),
    );
}

function qmail_extract_recipients( $to ) {
    if ( is_array( $to ) ) {
        return array_values( array_filter( array_map( 'sanitize_email', $to ) ) );
    }

    if ( ! is_string( $to ) ) {
        return array();
    }

    $parts = preg_split( '/[,;]+/', $to );
    return array_values( array_filter( array_map( 'sanitize_email', $parts ) ) );
}

function qmail_build_default_variables() {
    $vars = array(
        'site_name'         => get_bloginfo( 'name' ),
        'site_url'          => home_url( '/' ),
        'admin_email'       => get_option( 'admin_email' ),
        'current_date'      => wp_date( 'Y-m-d' ),
        'current_time'      => wp_date( 'H:i:s' ),
        'user_email'        => '',
        'user_display_name' => '',
        'customer_name'     => '',
        'reset_link'        => '',
        'order_id'          => '',
        'order_number'      => '',
        'order_total'       => '',
        'order_status'      => '',
    );

    return apply_filters( 'quick_mail_variables', $vars, array() );
}

function qmail_get_template_categories() {
    return array(
        'transactional' => 'Transactional',
        'marketing'     => 'Marketing',
        'system'        => 'System',
    );
}

function qmail_template_blocks() {
    return array(
        'button'      => '<table role="presentation" cellspacing="0" cellpadding="0" border="0"><tr><td style="border-radius:4px;background:#2271b1;"><a href="{{site_url}}" style="display:inline-block;padding:12px 18px;color:#ffffff;text-decoration:none;font-weight:600;">Call To Action</a></td></tr></table>',
        'divider'     => '<hr style="border:none;border-top:1px solid #e1e4e8;margin:24px 0;" />',
        'two_col'     => '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="50%" style="padding:8px;vertical-align:top;">Column A</td><td width="50%" style="padding:8px;vertical-align:top;">Column B</td></tr></table>',
        'logo_header' => '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td align="center" style="padding:20px;"><img src="{{site_url}}/wp-content/uploads/logo.png" alt="{{site_name}}" style="max-width:180px;height:auto;"></td></tr></table>',
        'footer'      => '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td style="padding:20px;font-size:12px;color:#666;">{{site_name}}<br>{{site_url}}<br><a href="#">Twitter</a> | <a href="#">LinkedIn</a></td></tr></table>',
    );
}

function qmail_log_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'quick_mail_log';
}

function qmail_queue_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'quick_mail_queue';
}

function qmail_usage_state_key() {
    return 'quickwoo_mail_usage';
}

function qmail_get_monthly_send_count() {
    $state = get_option( qmail_usage_state_key(), array() );
    if ( ! is_array( $state ) ) {
        $state = array();
    }

    $month = gmdate( 'Y-m' );
    if ( empty( $state['month'] ) || $state['month'] !== $month ) {
        $state = array(
            'month' => $month,
            'count' => 0,
        );
        update_option( qmail_usage_state_key(), $state, false );
    }

    return max( 0, absint( $state['count'] ?? 0 ) );
}

function qmail_increment_monthly_send_count() {
    $count = qmail_get_monthly_send_count() + 1;
    update_option(
        qmail_usage_state_key(),
        array(
            'month' => gmdate( 'Y-m' ),
            'count' => $count,
        ),
        false
    );

    return $count;
}
