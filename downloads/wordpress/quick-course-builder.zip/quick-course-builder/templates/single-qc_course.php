<?php
/**
 * Single Course Template
 */

if (!defined('ABSPATH')) exit;

get_header();

$course_id = get_the_ID();
$user_id   = get_current_user_id();
$is_logged = is_user_logged_in();

$course_modules = QCOU_Course_Modules_Panel::get_modules($course_id);
$module_entries = [];

if (!empty($course_modules)) {
  foreach ($course_modules as $module) {
    if (empty($module['enabled'])) {
      continue;
    }

    $module_entries[] = [
      'key' => (string) $module['id'],
      'title' => (string) $module['title'],
      'sections' => (array) ($module['sections'] ?? []),
      'exercise_enabled' => !empty($module['exercise_enabled']),
      'exercise_text' => (string) ($module['exercise_text'] ?? ''),
      'complete_marker' => !empty($module['complete_marker']),
      'legacy_url' => '',
    ];
  }
} else {
  $legacy_modules = get_posts([
    'post_type' => QCOU_Constants::CPT_MODULE,
    'post_parent' => $course_id,
    'post_status' => 'publish',
    'orderby' => 'menu_order',
    'order' => 'ASC',
    'numberposts' => -1,
  ]);

  foreach ($legacy_modules as $legacy) {
    $module_entries[] = [
      'key' => 'legacy_' . (int) $legacy->ID,
      'title' => (string) $legacy->post_title,
      'sections' => [
        ['type' => 'paragraph', 'content' => (string) $legacy->post_content],
      ],
      'exercise_enabled' => false,
      'exercise_text' => '',
      'complete_marker' => true,
      'legacy_url' => (string) get_permalink($legacy->ID),
    ];
  }
}

$module_total = count($module_entries);
$module_done = ($is_logged && $module_total > 0) ? QCOU_Progress::completed_count($user_id, $course_id) : 0;
$progress_pct = $module_total > 0 ? min(100, (int) round(($module_done / $module_total) * 100)) : 0;

$test_id  = QCOU_Tests::get_linked_test_id($course_id);
$passing  = QCOU_Tests::get_course_passing_grade($course_id);
$woo_paid = QCOU_Access::course_is_paid($course_id);
$has_access = $is_logged ? QCOU_Access::user_has_course_access($user_id, $course_id) : (!$woo_paid);

$latest_score = $is_logged ? QCOU_Tests::get_latest_score($user_id, $course_id) : 0;
$passed       = $is_logged ? QCOU_Tests::user_passed($user_id, $course_id) : false;
$premium_enabled = qcou_is_premium_active();

$cert_feedback = $is_logged ? QCOU_Certificate_Actions::pull_feedback($user_id, $course_id) : [];
?>

<div class="qcb-layout">
  <aside class="qcb-layout-sidebar">
    <?php QCOU_Sidebar::render(); ?>
  </aside>

  <main class="qcb-layout-content qcb-course">

    <header class="qcb-course-hero">
      <h1 class="qcb-course-title"><?php the_title(); ?></h1>
      <div class="qcb-course-overview"><?php the_content(); ?></div>

      <div class="qcb-progress-wrap" aria-label="<?php echo esc_attr__('Course progress', 'quick-courses-builder'); ?>">
        <div class="qcb-progress-label">
          <span><?php echo esc_html__('Progress', 'quick-courses-builder'); ?></span>
          <strong><?php echo esc_html($progress_pct . '%'); ?></strong>
        </div>
        <div class="qcb-progress-track"><span style="width: <?php echo esc_attr((string) $progress_pct); ?>%"></span></div>
      </div>

      <a class="button button-primary" href="#qcb-modules-section"><?php echo esc_html__('Start Course', 'quick-courses-builder'); ?></a>
    </header>

    <section class="qcb-course-modules" id="qcb-modules-section">
      <h2><?php echo esc_html__('Modules', 'quick-courses-builder'); ?></h2>

      <?php if (empty($module_entries)): ?>
        <p><?php echo esc_html__('No modules have been added to this course yet.', 'quick-courses-builder'); ?></p>
      <?php else: ?>
        <div class="qcb-module-grid">
          <?php foreach ($module_entries as $entry): ?>
            <?php $is_complete = $is_logged ? QCOU_Progress::is_module_complete($user_id, $course_id, $entry['key']) : false; ?>
            <article class="qcb-module-card">
              <h3><?php echo esc_html($entry['title']); ?></h3>

              <?php foreach ($entry['sections'] as $section): ?>
                <?php
                  $type = isset($section['type']) ? sanitize_key((string) $section['type']) : 'paragraph';
                  $content = isset($section['content']) ? (string) $section['content'] : '';
                ?>
                <?php if ($type === 'divider'): ?>
                  <hr class="qcb-module-divider" />
                <?php elseif ($type === 'header'): ?>
                  <h4 class="qcb-module-heading"><?php echo esc_html($content); ?></h4>
                <?php elseif ($type === 'list'): ?>
                  <div class="qcb-module-list"><?php echo wpautop(wp_kses_post($content)); ?></div>
                <?php else: ?>
                  <div class="qcb-module-paragraph"><?php echo wpautop(wp_kses_post($content)); ?></div>
                <?php endif; ?>
              <?php endforeach; ?>

              <?php if (!empty($entry['exercise_enabled'])): ?>
                <div class="qcb-exercise-callout">
                  <strong><?php echo esc_html__('Exercise', 'quick-courses-builder'); ?></strong>
                  <div><?php echo wpautop(wp_kses_post($entry['exercise_text'])); ?></div>
                </div>
              <?php endif; ?>

              <?php if ($entry['legacy_url'] !== ''): ?>
                <p><a href="<?php echo esc_url($entry['legacy_url']); ?>"><?php echo esc_html__('Open module page', 'quick-courses-builder'); ?></a></p>
              <?php endif; ?>

              <?php if (!empty($entry['complete_marker']) && $is_logged): ?>
                <form method="post" class="qcb-module-complete-form">
                  <?php wp_nonce_field('qcou_toggle_course_module', 'qcou_nonce'); ?>
                  <input type="hidden" name="qcou_course_module_toggle" value="1">
                  <input type="hidden" name="qcou_course_id" value="<?php echo esc_attr((string) $course_id); ?>">
                  <input type="hidden" name="qcou_module_key" value="<?php echo esc_attr($entry['key']); ?>">
                  <input type="hidden" name="qcou_action" value="<?php echo esc_attr($is_complete ? 'incomplete' : 'complete'); ?>">
                  <button type="submit" class="button <?php echo esc_attr($is_complete ? '' : 'button-primary'); ?>">
                    <?php echo esc_html($is_complete ? __('Mark Incomplete', 'quick-courses-builder') : __('Mark Complete', 'quick-courses-builder')); ?>
                  </button>
                </form>
              <?php elseif (!$is_logged): ?>
                <p><?php echo esc_html__('Login required to track module completion.', 'quick-courses-builder'); ?></p>
              <?php endif; ?>
            </article>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>

    <section class="qcb-course-test">
      <h2><?php echo esc_html__('Test', 'quick-courses-builder'); ?></h2>

      <?php if (!$test_id): ?>
        <p><?php echo esc_html__('No test is linked to this course yet.', 'quick-courses-builder'); ?></p>
      <?php elseif (!$premium_enabled): ?>
        <p><?php echo esc_html__('Tests are available on premium.', 'quick-courses-builder'); ?></p>
      <?php elseif (!$is_logged): ?>
        <p><?php echo esc_html__('Login required to take the test.', 'quick-courses-builder'); ?></p>
      <?php elseif (!$has_access): ?>
        <p><?php echo esc_html__('This test is locked. Purchase required.', 'quick-courses-builder'); ?></p>
      <?php elseif (!QCOU_Progress::all_modules_complete($user_id, $course_id)): ?>
        <p><?php echo esc_html__('This test unlocks after all modules are completed.', 'quick-courses-builder'); ?></p>
      <?php else: ?>
        <p>
          <?php echo esc_html__('Passing grade:', 'quick-courses-builder'); ?>
          <strong><?php echo esc_html($passing . '%'); ?></strong>
        </p>

        <?php if ($latest_score > 0 || $passed): ?>
          <p>
            <?php echo esc_html__('Latest score:', 'quick-courses-builder'); ?>
            <strong><?php echo esc_html($latest_score . '%'); ?></strong>
            <span class="qcb-status-pill <?php echo esc_attr($passed ? 'is-pass' : 'is-fail'); ?>">
              <?php echo esc_html($passed ? __('Passed', 'quick-courses-builder') : __('Not passed yet', 'quick-courses-builder')); ?>
            </span>
          </p>
        <?php endif; ?>

        <?php
          $questions = QCOU_Test_Builder::get_questions($test_id);
          if (empty($questions)) {
            echo '<p>' . esc_html__('This test has no questions yet.', 'quick-courses-builder') . '</p>';
          } else {
        ?>
          <form method="post" class="qcb-test-form">
            <?php wp_nonce_field('qcou_submit_test', 'qcou_test_nonce'); ?>
            <input type="hidden" name="qcou_test_submit" value="1">
            <input type="hidden" name="qcou_course_id" value="<?php echo esc_attr((string) $course_id); ?>">
            <input type="hidden" name="qcou_test_id" value="<?php echo esc_attr((string) $test_id); ?>">

            <?php foreach ($questions as $q): ?>
              <?php
                $qid = (string) ($q['id'] ?? '');
                $qt  = (string) ($q['question'] ?? '');
                $ans = (array)  ($q['answers'] ?? []);
                if ($qid === '' || $qt === '' || count($ans) < 2) continue;
              ?>
              <fieldset class="qcb-test-question">
                <legend><?php echo esc_html($qt); ?></legend>
                <?php foreach ($ans as $i => $a): ?>
                  <label>
                    <input type="radio" name="qcou_answers[<?php echo esc_attr($qid); ?>]" value="<?php echo esc_attr((string) ((int) $i)); ?>" required>
                    <?php echo esc_html((string) $a); ?>
                  </label>
                <?php endforeach; ?>
              </fieldset>
            <?php endforeach; ?>

            <button type="submit" class="button button-primary"><?php echo esc_html__('Submit Test', 'quick-courses-builder'); ?></button>
          </form>
        <?php } ?>
      <?php endif; ?>
    </section>

    <section class="qcb-course-certificate">
      <h2><?php echo esc_html__('Certificate', 'quick-courses-builder'); ?></h2>

      <?php if (!empty($cert_feedback['message'])): ?>
        <div class="qcb-cert-feedback <?php echo esc_attr(($cert_feedback['type'] ?? '') === 'error' ? 'is-error' : 'is-success'); ?>">
          <?php echo esc_html((string) $cert_feedback['message']); ?>
        </div>
      <?php endif; ?>

      <?php if (!$is_logged): ?>
        <p><?php echo esc_html__('Login required to claim your certificate.', 'quick-courses-builder'); ?></p>
      <?php elseif (!$premium_enabled): ?>
        <p><?php echo esc_html__('Certificates are available on premium.', 'quick-courses-builder'); ?></p>
      <?php else: ?>
        <?php
          $issued = QCOU_Certificates::get_issued($user_id, $course_id);
          $is_issued = !empty($issued['code']);
          $can_claim = QCOU_Certificates::can_claim($user_id, $course_id);
        ?>

        <?php if ($is_issued): ?>
          <p>
            <strong><?php echo esc_html__('Issued:', 'quick-courses-builder'); ?></strong>
            <?php echo esc_html((string) $issued['code']); ?>
            <span class="qcb-issued-date"><?php echo esc_html((string) ($issued['issued_at'] ?? '')); ?></span>
          </p>

          <?php if (!empty($issued['note'])): ?>
            <p><?php echo esc_html((string) $issued['note']); ?></p>
          <?php endif; ?>

          <?php if (!empty($issued['pdf_attachment_id'])): ?>
            <?php $url = wp_get_attachment_url((int) $issued['pdf_attachment_id']); ?>
            <?php if ($url): ?>
              <p><a class="button button-primary" href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener"><?php echo esc_html__('Download Certificate PDF', 'quick-courses-builder'); ?></a></p>
            <?php endif; ?>
          <?php else: ?>
            <p><?php echo esc_html__('Text-based completion confirmation is active for this certificate.', 'quick-courses-builder'); ?></p>
          <?php endif; ?>

        <?php elseif (!$can_claim): ?>
          <p><?php echo esc_html__('Certificate unlocks after all modules are complete and the linked test is passed.', 'quick-courses-builder'); ?></p>
        <?php else: ?>
          <p><?php echo esc_html__('Enter your name as it should appear on the certificate.', 'quick-courses-builder'); ?></p>
          <form method="post" class="qcb-certificate-claim">
            <?php wp_nonce_field('qcou_claim_certificate', 'qcou_cert_nonce'); ?>
            <input type="hidden" name="qcou_certificate_claim" value="1">
            <input type="hidden" name="qcou_course_id" value="<?php echo esc_attr((string) $course_id); ?>">
            <p><input type="text" name="qcou_certificate_name" required maxlength="80" class="qcb-input" placeholder="<?php echo esc_attr__('Full name', 'quick-courses-builder'); ?>"></p>
            <button type="submit" class="button button-primary"><?php echo esc_html__('Generate Certificate', 'quick-courses-builder'); ?></button>
          </form>
        <?php endif; ?>
      <?php endif; ?>
    </section>

  </main>
</div>

<?php get_footer(); ?>
