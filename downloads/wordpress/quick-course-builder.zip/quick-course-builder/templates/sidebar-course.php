<?php
if (!defined('ABSPATH')) exit;
$current_id = get_the_ID();
?>

<aside class="qcb-course-sidebar">

  <h2 class="qcb-course-title">
    <?php echo esc_html(get_the_title($course_id)); ?>
  </h2>

  <div class="qcb-course-progress">
    <strong><?php echo esc_html__('Progress', 'quick-courses-builder'); ?></strong>
    <span><?php echo esc_html($done . ' / ' . $total); ?></span>
  </div>

  <ul class="qcb-module-list">
    <?php foreach ($modules as $m): ?>
      <?php
        $is_current = ($m->ID === $current_id);
        $is_done = in_array($m->ID, $completed, true);
      ?>
      <li class="
        qcb-module-item
        <?php echo $is_current ? 'is-current' : ''; ?>
        <?php echo $is_done ? 'is-complete' : ''; ?>
      ">
        <a href="<?php echo esc_url(get_permalink($m->ID)); ?>">
          <?php echo esc_html($m->post_title); ?>
        </a>
      </li>
    <?php endforeach; ?>
  </ul>

  <div class="qcb-course-status">

    <div class="qcb-test-status">
      <strong><?php echo esc_html__('Test', 'quick-courses-builder'); ?>:</strong>
      <span>
     <?php
  if (!is_user_logged_in()) {
    echo esc_html__('Login required', 'quick-courses-builder');
  } elseif (!QCOU_Access::user_has_course_access($user_id, $course_id)) {
    echo esc_html__('Locked (purchase required)', 'quick-courses-builder');
  } elseif (!QCOU_Progress::all_modules_complete($user_id, $course_id)) {
    echo esc_html__('Locked (complete modules)', 'quick-courses-builder');
  } else {
    $score = QCOU_Tests::get_latest_score($user_id, $course_id);
    $passed = QCOU_Tests::user_passed($user_id, $course_id);
    if ($score > 0 || $passed) {
      echo esc_html(($passed ? 'Passed' : 'Unlocked') . ' • ' . $score . '%');
    } else {
      echo esc_html__('Unlocked', 'quick-courses-builder');
    }
  }
?>
      </span>
    </div>

    <div class="qcb-cert-status">
      <strong><?php echo esc_html__('Certificate', 'quick-courses-builder'); ?>:</strong>
      <span>
       <?php
  if (!is_user_logged_in()) {
    echo esc_html__('Login required', 'quick-courses-builder');
  } elseif (!QCOU_Access::user_has_course_access($user_id, $course_id)) {
    echo esc_html__('Locked (purchase required)', 'quick-courses-builder');
  } elseif (!QCOU_Progress::all_modules_complete($user_id, $course_id)) {
    echo esc_html__('Locked (complete modules)', 'quick-courses-builder');
  } elseif (!QCOU_Tests::user_passed($user_id, $course_id)) {
    echo esc_html__('Locked (pass test)', 'quick-courses-builder');
  } else {
    $issued = QCOU_Certificates::get_issued($user_id, $course_id);
    if (!empty($issued['code'])) {
      echo esc_html__('Issued • ', 'quick-courses-builder');
      echo esc_html($issued['code']);
    } else {
      echo esc_html__('Unlocked', 'quick-courses-builder');
    }
  }
?>

      </span>
    </div>

  </div>

</aside>
