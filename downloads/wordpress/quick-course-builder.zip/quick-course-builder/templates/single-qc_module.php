<?php
/**
 * Single Module Template
 * Used for qc_module post type
 */

if (!defined('ABSPATH')) exit;

get_header();

$module_id = get_the_ID();
$course_id = QCOU_Relations::get_course_id_for_module($module_id);

// Safety: module must belong to a course (already enforced earlier, but belt + suspenders)
if ($course_id <= 0) {
  echo '<main class="qcb-module">';
  echo '<p>' . esc_html__('This module is not assigned to a course.', 'quick-courses-builder') . '</p>';
  echo '</main>';
  get_footer();
  return;
}
?>

<div class="qcb-layout">

  <aside class="qcb-layout-sidebar">
    <?php QCOU_Sidebar::render(); ?>
  </aside>

  <main class="qcb-layout-content">

  <header class="qcb-module-header">
    <h1 class="qcb-module-title"><?php the_title(); ?></h1>
  </header>

  <section class="qcb-module-content">
    <?php
      // Render structured module blocks
      QCOU_Module_Builder::render_blocks($module_id);

      // Optional exercise section
      QCOU_Module_Builder::render_exercise($module_id);
    ?>
  </section>

  <?php if (is_user_logged_in()): ?>
    <section class="qcb-module-progress">
      <form method="post" class="qcb-module-toggle">
        <?php wp_nonce_field('qcou_toggle_module', 'qcou_nonce'); ?>
        <input type="hidden" name="qcou_module_id" value="<?php echo esc_attr($module_id); ?>">

        <?php
          $done = QCOU_Progress::is_module_complete(
            get_current_user_id(),
            $course_id,
            $module_id
          );
        ?>

        <input type="hidden" name="qcou_action" value="<?php echo $done ? 'incomplete' : 'complete'; ?>">

        <button type="submit" class="qcb-mark-btn">
          <?php
            echo $done
              ? esc_html__('Mark Module Incomplete', 'quick-courses-builder')
              : esc_html__('Mark Module Complete', 'quick-courses-builder');
          ?>
        </button>
      </form>
    </section>
  <?php endif; ?>

  <nav class="qcb-module-nav">
    <?php
      // Next / Previous module navigation
      QCOU_Module_Builder::render_navigation($module_id);
    ?>
  </nav>

</main>

         </div>

<?php get_footer(); ?>
