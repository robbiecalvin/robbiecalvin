(function ($) {
  function renumberAll() {
    $('#qcb-test-questions .qcb-question').each(function (qi) {
      const $q = $(this);

      $q.find('input, textarea').each(function () {
        const name = $(this).attr('name');
        if (!name) return;
        $(this).attr('name', name.replace(/qcou_test\[q\]\[\d+\]/, 'qcou_test[q][' + qi + ']'));
      });
    });
  }

  function addQuestion() {
    const qi = $('#qcb-test-questions .qcb-question').length;

    const html = `
      <div class="qcb-question" data-qcb-question>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <strong>Question</strong>
          <button type="button" class="button-link-delete qcb-remove-question">Remove</button>
        </div>

        <input type="hidden" name="qcou_test[q][${qi}][id]" value="qcbq_${Date.now()}_${Math.floor(Math.random() * 999999)}">

        <p><textarea name="qcou_test[q][${qi}][question]" rows="2" style="width:100%;"></textarea></p>

        <div class="qcb-answers" data-qcb-answers>
          ${answerRow(qi, 0, true)}
          ${answerRow(qi, 1, false)}
        </div>

        <button type="button" class="button qcb-add-answer">Add Answer</button>
        <hr style="margin:16px 0;">
      </div>
    `;

    $('#qcb-test-questions').append(html);
  }

  function answerRow(qi, ai, checked) {
    return `
      <div class="qcb-answer" data-qcb-answer style="display:flex;gap:10px;align-items:center;margin:6px 0;">
        <input type="radio" name="qcou_test[q][${qi}][correct_index]" value="${ai}" ${checked ? 'checked' : ''}>
        <input type="text" name="qcou_test[q][${qi}][answers][${ai}]" value="" style="width:100%;">
        <button type="button" class="button qcb-remove-answer" style="white-space:nowrap;">Remove</button>
      </div>
    `;
  }

  $(document).on('click', '#qcb-add-question', function () {
    addQuestion();
    renumberAll();
  });

  $(document).on('click', '.qcb-remove-question', function () {
    $(this).closest('.qcb-question').remove();
    renumberAll();
  });

  $(document).on('click', '.qcb-add-answer', function () {
    const $q = $(this).closest('.qcb-question');
    const qiMatch = ($q.find('textarea[name^="qcou_test[q]"]').attr('name') || '').match(/qcou_test\[q\]\[(\d+)\]/);
    const qi = qiMatch ? parseInt(qiMatch[1], 10) : 0;

    const $answers = $q.find('[data-qcb-answers]');
    const ai = $answers.find('[data-qcb-answer]').length;

    $answers.append(answerRow(qi, ai, false));
    renumberAll();
  });

  $(document).on('click', '.qcb-remove-answer', function () {
    const $q = $(this).closest('.qcb-question');
    $(this).closest('[data-qcb-answer]').remove();

    // Ensure at least 2 answers remain visually; if user deletes too much, they can re-add.
    renumberAll();
  });

})(jQuery);
