(function ($) {
  'use strict';

  function nextSectionIndex($container) {
    return $container.find('[data-qcb-section]').length;
  }

  function refreshModuleIndexes($root) {
    $root.find('[data-qcb-module-card]').each(function (moduleIndex) {
      var $module = $(this);

      $module.find('input, textarea, select').each(function () {
        var name = $(this).attr('name');
        if (!name) {
          return;
        }

        name = name.replace(/qcou_course_modules\[[^\]]+\]/, 'qcou_course_modules[' + moduleIndex + ']');
        $(this).attr('name', name);
      });

      $module.find('[data-qcb-section]').each(function (sectionIndex) {
        $(this).find('input, textarea, select').each(function () {
          var name = $(this).attr('name');
          if (!name) {
            return;
          }

          name = name.replace(/\[sections\]\[[^\]]+\]/, '[sections][' + sectionIndex + ']');
          $(this).attr('name', name);
        });
      });
    });
  }

  $(function () {
    var $root = $('[data-qcb-modules-root]');
    if (!$root.length) {
      return;
    }

    $root.sortable({
      items: '[data-qcb-module-card]',
      handle: '.qcb-drag-handle',
      update: function () {
        refreshModuleIndexes($root);
      }
    });

    $(document).on('click', '[data-qcb-add-module]', function () {
      var tpl = $('#qcb-module-template').html();
      if (!tpl) {
        return;
      }

      var index = $root.find('[data-qcb-module-card]').length;
      tpl = tpl.replace(/__INDEX__/g, String(index));
      $root.append(tpl);
      refreshModuleIndexes($root);
    });

    $(document).on('click', '[data-qcb-remove-module]', function () {
      $(this).closest('[data-qcb-module-card]').remove();
      refreshModuleIndexes($root);
    });

    $(document).on('click', '[data-qcb-add-section]', function () {
      var $module = $(this).closest('[data-qcb-module-card]');
      var $sections = $module.find('[data-qcb-sections]').first();
      var tpl = $('#qcb-module-section-template').html();
      if (!$sections.length || !tpl) {
        return;
      }

      var moduleMatch = ($module.find('input[type="hidden"][name*="[id]"]').attr('name') || '').match(/qcou_course_modules\[([^\]]+)\]/);
      var moduleIndex = moduleMatch ? moduleMatch[1] : '0';
      var sectionIndex = nextSectionIndex($sections);

      tpl = tpl.replace(/__INDEX__/g, String(moduleIndex)).replace(/__SECTION__/g, String(sectionIndex));
      $sections.append(tpl);
      refreshModuleIndexes($root);
    });

    $(document).on('click', '[data-qcb-remove-section]', function () {
      var $module = $(this).closest('[data-qcb-module-card]');
      $(this).closest('[data-qcb-section]').remove();
      refreshModuleIndexes($root);

      if (!$module.find('[data-qcb-section]').length) {
        $module.find('[data-qcb-add-section]').trigger('click');
      }
    });
  });
})(jQuery);
