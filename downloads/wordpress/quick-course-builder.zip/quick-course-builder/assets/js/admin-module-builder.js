jQuery(function ($) {
  function renumberBlocks($wrap) {
    $wrap.find('[data-qcb-block]').each(function (i) {
      const $block = $(this);

      // Update input/textarea names qcou_blocks[IDX][field]
      $block.find('input[name^="qcou_blocks["], textarea[name^="qcou_blocks["]').each(function () {
        const $field = $(this);
        const name = $field.attr('name');
        if (!name) return;

        const updated = name.replace(/^qcou_blocks\[[^\]]+\]/, 'qcou_blocks[' + i + ']');
        $field.attr('name', updated);
      });
    });
  }

  function buildBlockFromTemplate() {
    const tpl = $('#qcb-block-template').html();
    const $node = $(tpl.replaceAll('__INDEX__', '0')); // temp index; will be renumbered
    return $node;
  }

  function pickImage($block) {
    const frame = wp.media({
      title: (QCBModuleBuilder && QCBModuleBuilder.strings && QCBModuleBuilder.strings.chooseImage) ? QCBModuleBuilder.strings.chooseImage : 'Choose Image',
      button: { text: 'Use this image' },
      multiple: false
    });

    frame.on('select', function () {
      const attachment = frame.state().get('selection').first().toJSON();
      if (!attachment || !attachment.id) return;

      $block.find('[data-qcb-image-id]').val(String(attachment.id));

      const url = attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url;
      const html = '<img src="' + url + '" alt="" style="max-width:220px;height:auto;border:1px solid #ccd0d4;border-radius:4px;">';
      $block.find('[data-qcb-image-preview]').html(html);
    });

    frame.open();
  }

  function removeImage($block) {
    $block.find('[data-qcb-image-id]').val('0');
    $block.find('[data-qcb-image-preview]').html('<div class="qcb-image-empty">No image selected.</div>');
  }

  const $blocksWrap = $('[data-qcb-blocks]');

  $(document).on('click', '[data-qcb-add-block]', function () {
    const $newBlock = buildBlockFromTemplate();
    $blocksWrap.append($newBlock);
    renumberBlocks($blocksWrap);
  });

  $(document).on('click', '[data-qcb-remove-block]', function () {
    const $block = $(this).closest('[data-qcb-block]');
    $block.remove();
    renumberBlocks($blocksWrap);

    // Ensure at least one block exists to avoid a dead UI
    if ($blocksWrap.find('[data-qcb-block]').length === 0) {
      $blocksWrap.append(buildBlockFromTemplate());
      renumberBlocks($blocksWrap);
    }
  });

  $(document).on('click', '[data-qcb-pick-image]', function () {
    const $block = $(this).closest('[data-qcb-block]');
    pickImage($block);
  });

  $(document).on('click', '[data-qcb-remove-image]', function () {
    const $block = $(this).closest('[data-qcb-block]');
    removeImage($block);
  });

  // Initial clean renumber
  if ($blocksWrap.length) {
    renumberBlocks($blocksWrap);
  }
});
