<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Progress {

  private const META_KEY = 'qcou_modules_completed';

  public static function get_completed_modules(int $user_id, int $course_id): array {
    $all = get_user_meta($user_id, self::META_KEY, true);
    if (!is_array($all)) {
      return [];
    }

    $course = $all[$course_id] ?? [];
    if (!is_array($course)) {
      return [];
    }

    return array_map('strval', array_keys($course));
  }

  public static function is_module_complete(int $user_id, int $course_id, $module_key): bool {
    $module_key = sanitize_key((string) $module_key);
    if ($module_key === '') {
      return false;
    }

    $all = get_user_meta($user_id, self::META_KEY, true);
    return isset($all[$course_id][$module_key]);
  }

  public static function mark_complete(int $user_id, int $course_id, $module_key): void {
    $module_key = sanitize_key((string) $module_key);
    if ($module_key === '') {
      return;
    }

    $all = get_user_meta($user_id, self::META_KEY, true);
    if (!is_array($all)) {
      $all = [];
    }

    if (!isset($all[$course_id]) || !is_array($all[$course_id])) {
      $all[$course_id] = [];
    }

    $all[$course_id][$module_key] = true;
    update_user_meta($user_id, self::META_KEY, $all);
  }

  public static function mark_incomplete(int $user_id, int $course_id, $module_key): void {
    $module_key = sanitize_key((string) $module_key);
    if ($module_key === '') {
      return;
    }

    $all = get_user_meta($user_id, self::META_KEY, true);
    if (!is_array($all)) {
      return;
    }

    if (isset($all[$course_id][$module_key])) {
      unset($all[$course_id][$module_key]);

      if (empty($all[$course_id])) {
        unset($all[$course_id]);
      }

      update_user_meta($user_id, self::META_KEY, $all);
    }
  }

  public static function get_course_module_keys(int $course_id): array {
    $keys = QCOU_Course_Modules_Panel::get_module_keys($course_id);
    if (!empty($keys)) {
      return array_values(array_unique(array_map('sanitize_key', $keys)));
    }

    $legacy = get_posts([
      'post_type'   => QCOU_Constants::CPT_MODULE,
      'post_parent' => $course_id,
      'post_status' => 'publish',
      'numberposts' => -1,
      'orderby'     => 'menu_order',
      'order'       => 'ASC',
      'fields'      => 'ids',
    ]);

    if (empty($legacy) || !is_array($legacy)) {
      return [];
    }

    return array_map(static function ($id) {
      return 'legacy_' . absint($id);
    }, $legacy);
  }

  public static function total_modules_in_course(int $course_id): int {
    return count(self::get_course_module_keys($course_id));
  }

  public static function completed_count(int $user_id, int $course_id): int {
    $completed = self::get_completed_modules($user_id, $course_id);
    $allowed = self::get_course_module_keys($course_id);

    if (empty($allowed)) {
      return 0;
    }

    return count(array_intersect($completed, $allowed));
  }

  public static function all_modules_complete(int $user_id, int $course_id): bool {
    $module_keys = self::get_course_module_keys($course_id);

    if (empty($module_keys)) {
      return true;
    }

    $completed = self::get_completed_modules($user_id, $course_id);
    return count(array_intersect($module_keys, $completed)) >= count($module_keys);
  }
}
