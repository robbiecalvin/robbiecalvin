<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Tests {

  private const META_SCORE_KEY  = 'qcou_test_latest_score';
  private const META_PASSED_KEY = 'qcou_course_passed';

  public static function get_course_passing_grade(int $course_id): int {
    $passing = (int) get_post_meta($course_id, '_qcb_passing_grade', true);
    if ($passing < 0) $passing = 0;
    if ($passing > 100) $passing = 100;
    return $passing;
  }

  public static function get_linked_test_id(int $course_id): int {
    $test_id = (int) get_post_meta($course_id, '_qcb_test_id', true);
    if ($test_id <= 0) return 0;
    return (get_post_type($test_id) === QCOU_Constants::CPT_TEST) ? $test_id : 0;
  }

  public static function get_latest_score(int $user_id, int $course_id): int {
    $all = get_user_meta($user_id, self::META_SCORE_KEY, true);
    if (!is_array($all)) return 0;
    $s = isset($all[$course_id]) ? (int) $all[$course_id] : 0;
    if ($s < 0) $s = 0;
    if ($s > 100) $s = 100;
    return $s;
  }

  public static function set_latest_score(int $user_id, int $course_id, int $score): void {
    $score = max(0, min(100, (int) $score));
    $all = get_user_meta($user_id, self::META_SCORE_KEY, true);
    if (!is_array($all)) $all = [];
    $all[$course_id] = $score;
    update_user_meta($user_id, self::META_SCORE_KEY, $all);
  }

  public static function user_passed(int $user_id, int $course_id): bool {
    $all = get_user_meta($user_id, self::META_PASSED_KEY, true);
    if (!is_array($all)) return false;
    return !empty($all[$course_id]);
  }

  public static function set_user_passed(int $user_id, int $course_id, bool $passed): void {
    $all = get_user_meta($user_id, self::META_PASSED_KEY, true);
    if (!is_array($all)) $all = [];
    $all[$course_id] = $passed ? true : false;
    update_user_meta($user_id, self::META_PASSED_KEY, $all);
  }

  public static function update_pass_state(int $user_id, int $course_id): void {
    $passing = self::get_course_passing_grade($course_id);
    $latest  = self::get_latest_score($user_id, $course_id);
    self::set_user_passed($user_id, $course_id, ($latest >= $passing));
  }
}
