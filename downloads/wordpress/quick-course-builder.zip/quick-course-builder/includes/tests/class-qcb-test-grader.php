<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Test_Grader {

  /**
   * @param array $questions normalized questions array
   * @param array $submitted map: question_id => chosen_index
   * @return int percent score 0-100
   */
  public static function grade(array $questions, array $submitted): int {
    $total = 0;
    $correct = 0;

    foreach ($questions as $q) {
      if (!is_array($q)) continue;

      $qid = isset($q['id']) ? (string) $q['id'] : '';
      if ($qid === '') continue;

      if (!isset($q['correct_index'])) continue;

      $total++;
      $correct_index = (int) $q['correct_index'];
      $chosen = isset($submitted[$qid]) ? (int) $submitted[$qid] : -1;

      if ($chosen === $correct_index) {
        $correct++;
      }
    }

    if ($total <= 0) return 0;

    $pct = (int) round(($correct / $total) * 100);
    return max(0, min(100, $pct));
  }
}
