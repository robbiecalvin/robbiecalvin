<?php
if (!defined('ABSPATH')) {
    exit;
}

final class QCOU_PDF
{
    public static function generate_certificate_pdf(int $certificate_post_id, string $name, string $issued_at_mysql, string $code): array
    {
        $image_url = (string) get_post_meta($certificate_post_id, '_qcb_cert_template_image_url', true);
        if ($image_url === '') {
            return ['ok' => false, 'error' => __('Certificate image URL not set.', 'quick-courses-builder')];
        }

        $response = wp_remote_get($image_url, ['timeout' => 15]);
        if (is_wp_error($response)) {
            return ['ok' => false, 'error' => __('Failed to fetch certificate image.', 'quick-courses-builder')];
        }

        $bytes = wp_remote_retrieve_body($response);
        if (!is_string($bytes) || $bytes === '') {
            return ['ok' => false, 'error' => __('Empty certificate image response.', 'quick-courses-builder')];
        }

        $tmp = wp_tempnam('qcou_cert');
        if (!is_string($tmp) || $tmp === '') {
            return ['ok' => false, 'error' => __('Could not create temporary file.', 'quick-courses-builder')];
        }

        if (file_put_contents($tmp, $bytes) === false) {
            return ['ok' => false, 'error' => __('Could not write temporary image.', 'quick-courses-builder')];
        }

        $jpeg_path = self::ensure_jpeg($tmp);
        if ($jpeg_path === false) {
            return ['ok' => false, 'error' => __('Failed to prepare certificate image.', 'quick-courses-builder')];
        }

        $info = @getimagesize($jpeg_path);
        if (!$info || empty($info[0]) || empty($info[1])) {
            return ['ok' => false, 'error' => __('Invalid certificate image.', 'quick-courses-builder')];
        }

        $w_px = (int) $info[0];
        $h_px = (int) $info[1];
        $w_pt = $w_px * 0.75;
        $h_pt = $h_px * 0.75;

        $name_x = (int) get_post_meta($certificate_post_id, '_qcb_cert_name_x', true);
        $name_y = (int) get_post_meta($certificate_post_id, '_qcb_cert_name_y', true);
        $name_size = (int) get_post_meta($certificate_post_id, '_qcb_cert_name_font_size', true);
        $name_color = (string) get_post_meta($certificate_post_id, '_qcb_cert_name_color', true);
        if ($name_size <= 0) {
            $name_size = 32;
        }
        if ($name_color === '') {
            $name_color = '#111111';
        }

        $date_enabled = (int) get_post_meta($certificate_post_id, '_qcb_cert_date_enabled', true);
        $date_x = (int) get_post_meta($certificate_post_id, '_qcb_cert_date_x', true);
        $date_y = (int) get_post_meta($certificate_post_id, '_qcb_cert_date_y', true);
        $date_size = (int) get_post_meta($certificate_post_id, '_qcb_cert_date_font_size', true);
        $date_color = (string) get_post_meta($certificate_post_id, '_qcb_cert_date_color', true);
        if ($date_size <= 0) {
            $date_size = 14;
        }
        if ($date_color === '') {
            $date_color = '#111111';
        }

        $date_str = mysql2date('F j, Y', $issued_at_mysql);
        $jpeg_bytes = file_get_contents($jpeg_path);
        if (!is_string($jpeg_bytes) || $jpeg_bytes === '') {
            return ['ok' => false, 'error' => __('Unable to read certificate image.', 'quick-courses-builder')];
        }

        $pdf_bytes = self::build_pdf([
            'page_w' => $w_pt,
            'page_h' => $h_pt,
            'jpeg' => $jpeg_bytes,
            'name' => $name,
            'name_x' => $name_x,
            'name_y' => $name_y,
            'name_size' => $name_size,
            'name_color' => $name_color,
            'date_enabled' => ($date_enabled === 1),
            'date' => $date_str,
            'date_x' => $date_x,
            'date_y' => $date_y,
            'date_size' => $date_size,
            'date_color' => $date_color,
            'code' => $code,
        ]);

        if (!is_string($pdf_bytes) || $pdf_bytes === '') {
            return ['ok' => false, 'error' => __('PDF generation failed.', 'quick-courses-builder')];
        }

        $upload = wp_upload_dir();
        if (empty($upload['basedir']) || empty($upload['baseurl'])) {
            return ['ok' => false, 'error' => __('Uploads directory unavailable.', 'quick-courses-builder')];
        }

        $dir = trailingslashit($upload['basedir']) . 'qcb-certificates';
        if (!wp_mkdir_p($dir)) {
            return ['ok' => false, 'error' => __('Unable to create certificate directory.', 'quick-courses-builder')];
        }

        $filename = sanitize_file_name(strtolower($code)) . '.pdf';
        $path = trailingslashit($dir) . $filename;
        if (file_put_contents($path, $pdf_bytes) === false) {
            return ['ok' => false, 'error' => __('Unable to write PDF file.', 'quick-courses-builder')];
        }

        $attachment = [
            'post_mime_type' => 'application/pdf',
            'post_title' => 'Certificate ' . $code,
            'post_content' => '',
            'post_status' => 'private',
        ];

        $attach_id = wp_insert_attachment($attachment, $path);
        if (is_wp_error($attach_id) || $attach_id <= 0) {
            return ['ok' => true, 'attachment_id' => 0];
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';
        wp_update_attachment_metadata($attach_id, wp_generate_attachment_metadata($attach_id, $path));

        return ['ok' => true, 'attachment_id' => (int) $attach_id];
    }

    private static function ensure_jpeg(string $path)
    {
        $ext = strtolower((string) pathinfo($path, PATHINFO_EXTENSION));
        if ($ext === 'jpg' || $ext === 'jpeg') {
            return $path;
        }

        if (!function_exists('imagecreatefromstring')) {
            return false;
        }

        $bytes = file_get_contents($path);
        if ($bytes === false) {
            return false;
        }

        $im = @imagecreatefromstring($bytes);
        if (!$im) {
            return false;
        }

        $tmp = wp_tempnam('qcou_jpg');
        if (!is_string($tmp) || $tmp === '') {
            imagedestroy($im);
            return false;
        }

        $jpg = $tmp . '.jpg';
        imagejpeg($im, $jpg, 92);
        imagedestroy($im);

        return file_exists($jpg) ? $jpg : false;
    }

    private static function hex_to_rgb(string $hex): array
    {
        $hex = trim($hex);
        if ($hex === '') {
            return [0.07, 0.07, 0.07];
        }
        if ($hex[0] === '#') {
            $hex = substr($hex, 1);
        }
        if (!preg_match('/^[0-9a-fA-F]{6}$/', $hex)) {
            return [0.07, 0.07, 0.07];
        }

        $r = hexdec(substr($hex, 0, 2)) / 255;
        $g = hexdec(substr($hex, 2, 2)) / 255;
        $b = hexdec(substr($hex, 4, 2)) / 255;
        return [$r, $g, $b];
    }

    private static function pdf_escape(string $s): string
    {
        $s = str_replace('\\', '\\\\', $s);
        $s = str_replace('(', '\\(', $s);
        $s = str_replace(')', '\\)', $s);
        return $s;
    }

    private static function build_pdf(array $d)
    {
        $page_w = (float) $d['page_w'];
        $page_h = (float) $d['page_h'];
        $jpeg = (string) $d['jpeg'];
        $jpeg_len = strlen($jpeg);

        $objs = [];
        $objs[] = '<< /Type /Catalog /Pages 2 0 R >>';
        $objs[] = '<< /Type /Pages /Kids [3 0 R] /Count 1 >>';
        $objs[] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {$page_w} {$page_h}] /Resources << /XObject << /Im0 4 0 R >> /Font << /F0 6 0 R >> >> /Contents 5 0 R >>";
        $objs[] = "<< /Type /XObject /Subtype /Image /Width 1 /Height 1 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length {$jpeg_len} >>\nstream\n{$jpeg}\nendstream";

        $content = '';
        $content .= "q\n{$page_w} 0 0 {$page_h} 0 0 cm\n/Im0 Do\nQ\n";

        [$nr, $ng, $nb] = self::hex_to_rgb((string) $d['name_color']);
        $name = self::pdf_escape((string) $d['name']);
        $nx = (float) $d['name_x'];
        $ny = (float) $d['name_y'];
        $ns = (float) $d['name_size'];
        $content .= "BT\n/F0 {$ns} Tf\n{$nr} {$ng} {$nb} rg\n{$nx} {$ny} Td\n({$name}) Tj\nET\n";

        if (!empty($d['date_enabled'])) {
            [$dr, $dg, $db] = self::hex_to_rgb((string) $d['date_color']);
            $date = self::pdf_escape((string) $d['date']);
            $dx = (float) $d['date_x'];
            $dy = (float) $d['date_y'];
            $ds = (float) $d['date_size'];
            $content .= "BT\n/F0 {$ds} Tf\n{$dr} {$dg} {$db} rg\n{$dx} {$dy} Td\n({$date}) Tj\nET\n";
        }

        $content_len = strlen($content);
        $objs[] = "<< /Length {$content_len} >>\nstream\n{$content}\nendstream";
        $objs[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';

        $pdf = "%PDF-1.4\n";
        $offsets = [0];
        for ($i = 0; $i < count($objs); $i++) {
            $offsets[] = strlen($pdf);
            $n = $i + 1;
            $pdf .= "{$n} 0 obj\n{$objs[$i]}\nendobj\n";
        }

        $xref_pos = strlen($pdf);
        $pdf .= 'xref' . "\n";
        $pdf .= '0 ' . (count($objs) + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ($i = 1; $i <= count($objs); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }

        $pdf .= "trailer\n<< /Size " . (count($objs) + 1) . " /Root 1 0 R >>\nstartxref\n{$xref_pos}\n%%EOF";
        return $pdf;
    }
}
