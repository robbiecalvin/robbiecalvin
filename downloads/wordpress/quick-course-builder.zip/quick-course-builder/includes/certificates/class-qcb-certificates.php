<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Certificates {

  private const META_KEY = 'qcou_certificate_issued';

  public static function get_linked_certificate_id(int $course_id): int {
    $cid = (int) get_post_meta($course_id, '_qcb_certificate_id', true);
    if ($cid <= 0) return 0;
    return (get_post_type($cid) === QCOU_Constants::CPT_CERTIFICATE) ? $cid : 0;
  }

  public static function can_claim(int $user_id, int $course_id): bool {
    if ($user_id <= 0) return false;

    if (!QCOU_Access::user_has_course_access($user_id, $course_id)) {
      return false;
    }

    if (!QCOU_Progress::all_modules_complete($user_id, $course_id)) {
      return false;
    }

    $test_id = QCOU_Tests::get_linked_test_id($course_id);
    if ($test_id <= 0) {
      return false;
    }

    if (!QCOU_Tests::user_passed($user_id, $course_id)) {
      return false;
    }

    $cert_post_id = self::get_linked_certificate_id($course_id);
    if ($cert_post_id <= 0) {
      return false;
    }

    return true;
  }

  public static function get_issued(int $user_id, int $course_id): array {
    $all = get_user_meta($user_id, self::META_KEY, true);
    if (!is_array($all)) return [];
    $rec = $all[$course_id] ?? [];
    return is_array($rec) ? $rec : [];
  }

  public static function is_issued(int $user_id, int $course_id): bool {
    $rec = self::get_issued($user_id, $course_id);
    return !empty($rec['code']) && !empty($rec['issued_at']);
  }

  public static function issue(int $user_id, int $course_id, string $typed_name): array {
    $typed_name = sanitize_text_field(wp_strip_all_tags(trim($typed_name)));

    if ($typed_name === '' || strlen($typed_name) > 80) {
      return ['ok' => false, 'error' => __('Please enter a valid name.', 'quick-courses-builder')];
    }

    if (!self::can_claim($user_id, $course_id)) {
      return ['ok' => false, 'error' => __('Certificate is locked or misconfigured.', 'quick-courses-builder')];
    }

    $existing = self::get_issued($user_id, $course_id);
    if (!empty($existing['code'])) {
      return ['ok' => true, 'issued' => $existing, 'already' => true];
    }

    $cert_post_id = self::get_linked_certificate_id($course_id);
    $code = self::generate_code($user_id, $course_id);
    $issued_at = current_time('mysql');

    $record = [
      'certificate_post_id' => $cert_post_id,
      'issued_at' => $issued_at,
      'code' => $code,
      'name' => $typed_name,
      'pdf_attachment_id' => 0,
      'status' => 'text',
      'note' => __('Completion record issued. PDF is unavailable for this template.', 'quick-courses-builder'),
    ];

    try {
      $image_url = (string) get_post_meta($cert_post_id, '_qcb_cert_template_image_url', true);
      if ($image_url !== '') {
        $pdf = QCOU_PDF::generate_certificate_pdf($cert_post_id, $typed_name, $issued_at, $code);
        if (!empty($pdf['ok'])) {
          $record['pdf_attachment_id'] = (int) ($pdf['attachment_id'] ?? 0);
          $record['status'] = 'pdf';
          $record['note'] = __('Certificate PDF generated successfully.', 'quick-courses-builder');
        } else {
          $record['note'] = isset($pdf['error']) ? sanitize_text_field((string) $pdf['error']) : __('PDF generation failed. Completion record was still issued.', 'quick-courses-builder');
        }
      }
    } catch (Throwable $e) {
      $record['note'] = __('PDF generation failed. Completion record was still issued.', 'quick-courses-builder');
    }

    $all = get_user_meta($user_id, self::META_KEY, true);
    if (!is_array($all)) $all = [];
    $all[$course_id] = $record;
    update_user_meta($user_id, self::META_KEY, $all);

    return ['ok' => true, 'issued' => $record, 'already' => false];
  }

  private static function generate_code(int $user_id, int $course_id): string {
    $seed = $user_id . '|' . $course_id . '|' . microtime(true) . '|' . wp_rand();
    $hash = hash_hmac('sha256', $seed, wp_salt('auth'));
    $short = strtoupper(substr($hash, 0, 12));
    return 'QCB-' . $short;
  }
}
