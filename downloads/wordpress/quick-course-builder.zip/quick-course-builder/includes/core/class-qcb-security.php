<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Security {

  public static function current_user_can_manage(): bool {
    return current_user_can(QCOU_Constants::CAP_MANAGE);
  }

  public static function deny_if_cannot_manage(): void {
    if (!self::current_user_can_manage()) {
      wp_die(esc_html__('You do not have permission to access this page.', 'quick-courses-builder'));
    }
  }
}

