<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Rewrite {

  /**
   * Registers rewrite rules for module URLs:
   * /courses/{course_slug}/{module_slug}/
   */
  public static function register_rules(): void {
    // Module under course:
    // courses/course-slug/module-slug/
    add_rewrite_rule(
      '^' . QCOU_Constants::COURSES_BASE . '/([^/]+)/([^/]+)/?$',
      'index.php?post_type=' . QCOU_Constants::CPT_MODULE . '&name=$matches[2]&' . QCOU_Constants::QV_COURSE_SLUG . '=$matches[1]',
      'top'
    );
  }

  public static function register_query_vars(array $vars): array {
    $vars[] = QCOU_Constants::QV_COURSE_SLUG;
    return $vars;
  }

  /**
   * Generates canonical module permalinks:
   * /courses/{course_slug}/{module_slug}/
   */
  public static function filter_module_permalink(string $post_link, WP_Post $post): string {
    if ($post->post_type !== QCOU_Constants::CPT_MODULE) {
      return $post_link;
    }

    $module_id = (int) $post->ID;

    // If no valid parent course, leave link as-is (we will enforce frontend rules later).
    if (!QCOU_Relations::module_has_valid_course_parent($module_id)) {
      return $post_link;
    }

    $course_slug = QCOU_Relations::get_course_slug_for_module($module_id);
    if ($course_slug === '') {
      return $post_link;
    }

    $url = home_url(trailingslashit(QCOU_Constants::COURSES_BASE) . trailingslashit($course_slug) . $post->post_name . '/');
    return $url;
  }

  /**
   * Enforce canonical module URLs and validate that the module belongs to the course slug in the URL.
   *
   * Behaviors:
   * - /qc_module/module-slug/ -> 301 -> /courses/course-slug/module-slug/
   * - /courses/wrong-course/module-slug/ -> 301 -> correct canonical
   * - module without course parent -> 404 (controlled)
   */
  public static function enforce_module_canonical(): void {
    if (!is_singular(QCOU_Constants::CPT_MODULE)) {
      return;
    }

    global $post;
    if (!($post instanceof WP_Post)) {
      return;
    }

    $module_id = (int) $post->ID;

    // Module must have a valid course parent, otherwise controlled failure.
    if (!QCOU_Relations::module_has_valid_course_parent($module_id)) {
      self::force_404();
      return;
    }

    $canonical = get_permalink($module_id);
    if (!$canonical) {
      self::force_404();
      return;
    }

    $requested_course_slug = get_query_var(QCOU_Constants::QV_COURSE_SLUG, '');
    if (is_string($requested_course_slug) && $requested_course_slug !== '') {
      // If URL includes course slug, validate relationship.
      if (!QCOU_Relations::module_belongs_to_course_slug($module_id, $requested_course_slug)) {
        wp_safe_redirect($canonical, 301);
        exit;
      }
    } else {
      // URL did not come in via /courses/{course}/{module}/, enforce canonical anyway.
      $current = self::current_url();
      if ($current && !self::urls_match($current, $canonical)) {
        wp_safe_redirect($canonical, 301);
        exit;
      }
    }
  }

  private static function force_404(): void {
    global $wp_query;
    if ($wp_query instanceof WP_Query) {
      $wp_query->set_404();
      status_header(404);
      nocache_headers();
    }
  }

  private static function current_url(): string {
    $scheme = is_ssl() ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $uri  = $_SERVER['REQUEST_URI'] ?? '';
    if ($host === '' || $uri === '') return '';
    return $scheme . $host . $uri;
  }

  private static function urls_match(string $a, string $b): bool {
    $a = untrailingslashit($a);
    $b = untrailingslashit($b);
    return hash_equals($a, $b);
  }
}

