<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Relations {

  /**
   * Canonical relationship (single source of truth):
   * qc_module.post_parent === qc_course.ID
   */
  public static function get_course_id_for_module(int $module_id): int {
    $p = (int) wp_get_post_parent_id($module_id);
    return $p > 0 ? $p : 0;
  }

  public static function get_course_slug_for_module(int $module_id): string {
    $course_id = self::get_course_id_for_module($module_id);
    if (!$course_id) return '';
    $course = get_post($course_id);
    if (!$course || $course->post_type !== QCOU_Constants::CPT_COURSE) return '';
    return $course->post_name;
  }

  public static function module_has_valid_course_parent(int $module_id): bool {
    $course_id = self::get_course_id_for_module($module_id);
    if ($course_id <= 0) return false;
    $course = get_post($course_id);
    return ($course instanceof WP_Post) && $course->post_type === QCOU_Constants::CPT_COURSE && $course->post_status !== 'trash';
  }

  public static function module_belongs_to_course_slug(int $module_id, string $course_slug): bool {
    $actual = self::get_course_slug_for_module($module_id);
    if ($actual === '' || $course_slug === '') return false;
    return hash_equals($actual, $course_slug);
  }
}

