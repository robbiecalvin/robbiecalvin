<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Access {

  public static function is_woo_active(): bool {
    return class_exists('WooCommerce');
  }

  public static function course_is_paid(int $course_id): bool {
    if (!self::is_woo_active()) {
      return false; // Woo inactive => behave as free (per spec)
    }

    $is_paid = (int) get_post_meta($course_id, '_qcb_is_paid', true);
    $product_id = (int) get_post_meta($course_id, '_qcb_wc_product_id', true);

    return ($is_paid === 1 && $product_id > 0 && get_post_type($product_id) === 'product');
  }

  public static function user_has_course_access(int $user_id, int $course_id): bool {
    // Free course or Woo inactive => accessible
    if (!self::course_is_paid($course_id)) {
      return true;
    }

    if (!self::is_woo_active()) {
      return true;
    }

    $product_id = (int) get_post_meta($course_id, '_qcb_wc_product_id', true);
    if ($product_id <= 0 || get_post_type($product_id) !== 'product') {
      return true; // fail open to avoid blocking due to misconfig (admin warnings handled elsewhere)
    }

    $user = get_userdata($user_id);
    if (!$user) return false;

    $email = $user->user_email ?? '';
    if (!is_string($email) || $email === '') return false;

    if (!function_exists('wc_customer_bought_product')) {
      return false;
    }

    return (bool) wc_customer_bought_product($email, $user_id, $product_id);
  }

  public static function can_take_test(int $user_id, int $course_id): bool {
    if ($user_id <= 0) return false;

    if (!self::user_has_course_access($user_id, $course_id)) {
      return false;
    }

    return QCOU_Progress::all_modules_complete($user_id, $course_id);
  }
}
