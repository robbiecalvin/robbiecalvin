<?php
if (!defined('ABSPATH')) exit;

require_once QCOU_PATH . 'includes/class-qcb-constants.php';

require_once QCOU_PATH . 'includes/core/class-qcb-security.php';
require_once QCOU_PATH . 'includes/core/class-qcb-relations.php';
require_once QCOU_PATH . 'includes/core/class-qcb-cpt.php';
require_once QCOU_PATH . 'includes/core/class-qcb-rewrite.php';

require_once QCOU_PATH . 'includes/utils/class-qcb-sanitize.php';

require_once QCOU_PATH . 'includes/admin/class-qcb-admin-menu.php';
require_once QCOU_PATH . 'includes/admin/class-qcb-admin-notices.php';
require_once QCOU_PATH . 'includes/admin/class-qcb-course-meta.php';
require_once QCOU_PATH . 'includes/admin/class-qcb-module-meta.php';
require_once QCOU_PATH . 'includes/admin/class-qcb-module-builder.php';
require_once QCOU_PATH . 'includes/progress/class-qcb-progress.php';
require_once QCOU_PATH . 'includes/frontend/class-qcb-module-actions.php';
require_once QCOU_PATH . 'includes/frontend/class-qcb-sidebar.php';
require_once QCOU_PATH . 'includes/core/class-qcb-access.php';

require_once QCOU_PATH . 'includes/tests/class-qcb-tests.php';
require_once QCOU_PATH . 'includes/tests/class-qcb-test-grader.php';

require_once QCOU_PATH . 'includes/admin/class-qcb-test-builder.php';

require_once QCOU_PATH . 'includes/frontend/class-qcb-test-actions.php';

require_once QCOU_PATH . 'includes/woo/class-qcb-woo.php';

require_once QCOU_PATH . 'includes/admin/class-qcb-certificate-builder.php';

require_once QCOU_PATH . 'includes/certificates/class-qcb-certificates.php';
require_once QCOU_PATH . 'includes/certificates/class-qcb-pdf.php';

require_once QCOU_PATH . 'includes/frontend/class-qcb-certificate-actions.php';
require_once QCOU_PATH . 'includes/admin/class-qcb-course-modules-panel.php';







final class QCOU_Plugin {

  private static ?QCOU_Plugin $instance = null;

  public static function instance(): QCOU_Plugin {
    if (self::$instance === null) {
      self::$instance = new self();
    }
    return self::$instance;
  }

  private function __construct() {
    $this->register_activation();
    $this->init_modules();
    $this->register_hooks();
  }

  private function register_activation(): void {
    register_activation_hook(QCOU_PATH . 'quick-courses-builder.php', [__CLASS__, 'on_activate']);
    register_deactivation_hook(QCOU_PATH . 'quick-courses-builder.php', [__CLASS__, 'on_deactivate']);
  }

  public static function on_activate(): void {
    // Ensure CPTs + rewrites exist before flushing.
    QCOU_CPT::register_all();
    QCOU_Rewrite::register_rules();
    flush_rewrite_rules(false);
  }

  public static function on_deactivate(): void {
    flush_rewrite_rules(false);
  }

  private function init_modules(): void {
    // Intentionally empty. Construction happens via hooks to keep load deterministic.
  }

public static function load_templates(string $template): string {
  if (is_singular(QCOU_Constants::CPT_MODULE)) {
    $t = QCOU_PATH . 'templates/single-qc_module.php';
    if (file_exists($t)) return $t;
  }

  if (is_singular(QCOU_Constants::CPT_COURSE)) {
    $t = QCOU_PATH . 'templates/single-qc_course.php';
    if (file_exists($t)) return $t;
  }

  return $template;
}


  private function register_hooks(): void {
    add_action('init', [QCOU_CPT::class, 'register_all'], 0);
    add_action('init', [QCOU_Rewrite::class, 'register_rules'], 20);

    add_filter('query_vars', [QCOU_Rewrite::class, 'register_query_vars']);

    add_filter('post_type_link', [QCOU_Rewrite::class, 'filter_module_permalink'], 10, 2);

    add_action('template_redirect', [QCOU_Rewrite::class, 'enforce_module_canonical']);

    if (is_admin()) {
      add_action('admin_menu', [QCOU_Admin_Menu::class, 'register']);
    }
    add_action('admin_init', [QCOU_Course_Meta::class, 'register']);
    add_action('admin_init', [QCOU_Module_Meta::class, 'register']);
    add_action('admin_init', [QCOU_Module_Builder::class, 'register']);
    add_action('init', [QCOU_Module_Actions::class, 'register']);
    add_filter('template_include', [QCOU_Plugin::class, 'load_templates']);
    add_action('admin_init', [QCOU_Test_Builder::class, 'register']);
add_action('init', [QCOU_Test_Actions::class, 'register']);
add_action('init', [QCOU_Woo::class, 'register']);
add_action('admin_init', [QCOU_Certificate_Builder::class, 'register']);
add_action('init', [QCOU_Certificate_Actions::class, 'register']);
add_action('admin_init', [QCOU_Course_Modules_Panel::class, 'register']);
add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_frontend_assets']);







  }

  public static function enqueue_frontend_assets(): void {
    if (!is_singular(array(QCOU_Constants::CPT_COURSE, QCOU_Constants::CPT_MODULE))) {
      return;
    }

    wp_enqueue_style(
      'qcou-frontend',
      QCOU_URL . 'assets/css/frontend.css',
      array(),
      QCOU_VERSION
    );
  }
}
