<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Sanitize {

  /**
   * Sanitizes HTML based on user capability.
   * - If user has unfiltered_html: allow broader "post" HTML with common attributes.
   * - Otherwise: strict wp_kses_post.
   */
  public static function html(string $html): string {
    $html = (string) $html;

    if (current_user_can('unfiltered_html')) {
      $allowed = wp_kses_allowed_html('post');

      // Permit common attributes across all tags without turning this into XSS Disneyland.
      foreach ($allowed as $tag => $attrs) {
        if (!is_array($attrs)) $attrs = [];
        $attrs['class'] = true;
        $attrs['id'] = true;
        $attrs['style'] = true; // still filtered by kses rules
        $attrs['data-*'] = true;
        $allowed[$tag] = $attrs;
      }

      // Allow <code> and <pre> attributes (often stripped in some setups)
      if (!isset($allowed['code'])) $allowed['code'] = [];
      $allowed['code']['class'] = true;

      if (!isset($allowed['pre'])) $allowed['pre'] = [];
      $allowed['pre']['class'] = true;

      return wp_kses($html, $allowed);
    }

    return wp_kses_post($html);
  }

  public static function text(string $value): string {
    return sanitize_text_field($value);
  }

  public static function bool01($value): int {
    return !empty($value) ? 1 : 0;
  }

  public static function int($value): int {
    return (int) $value;
  }
}
