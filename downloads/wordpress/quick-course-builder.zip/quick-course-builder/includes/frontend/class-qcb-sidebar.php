<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Sidebar {

  public static function get_course_context(): int {
    if (is_singular(QCOU_Constants::CPT_COURSE)) {
      return get_the_ID();
    }

    if (is_singular(QCOU_Constants::CPT_MODULE)) {
      return QCOU_Relations::get_course_id_for_module(get_the_ID());
    }

    return 0;
  }

  public static function get_modules(int $course_id): array {
    return get_posts([
      'post_type' => QCOU_Constants::CPT_MODULE,
      'post_parent' => $course_id,
      'post_status' => 'publish',
      'orderby' => 'menu_order',
      'order' => 'ASC',
      'numberposts' => -1,
    ]);
  }

  public static function render(): void {
    $course_id = self::get_course_context();
    if ($course_id <= 0) {
      return;
    }

    $course = get_post($course_id);
    if (!$course) {
      return;
    }

    $modules = self::get_modules($course_id);
    $user_id = get_current_user_id();

    $completed = is_user_logged_in()
      ? QCOU_Progress::get_completed_modules($user_id, $course_id)
      : [];

    $total = count($modules);
    $done  = is_user_logged_in()
      ? QCOU_Progress::completed_count($user_id, $course_id)
      : 0;

    include QCOU_PATH . 'templates/sidebar-course.php';
  }
}
