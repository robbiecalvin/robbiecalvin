<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Certificate_Actions {

  private const FEEDBACK_KEY = 'qcou_cert_feedback_';

  public static function register(): void {
    add_action('template_redirect', [__CLASS__, 'handle_post']);
  }

  public static function pull_feedback(int $user_id, int $course_id): array {
    $key = self::FEEDBACK_KEY . $user_id . '_' . $course_id;
    $data = get_transient($key);
    delete_transient($key);
    return is_array($data) ? $data : [];
  }

  private static function set_feedback(int $user_id, int $course_id, string $type, string $message): void {
    $key = self::FEEDBACK_KEY . $user_id . '_' . $course_id;
    set_transient($key, [
      'type' => sanitize_key($type),
      'message' => sanitize_text_field($message),
    ], MINUTE_IN_SECONDS * 5);
  }

  public static function handle_post(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['qcou_certificate_claim'])) {
      return;
    }

    if (!qcou_is_premium_active() || !is_user_logged_in()) {
      return;
    }

    if (!isset($_POST['qcou_cert_nonce']) || !wp_verify_nonce((string) $_POST['qcou_cert_nonce'], 'qcou_claim_certificate')) {
      return;
    }

    $course_id = isset($_POST['qcou_course_id']) ? absint($_POST['qcou_course_id']) : 0;
    if ($course_id <= 0 || get_post_type($course_id) !== QCOU_Constants::CPT_COURSE) {
      return;
    }

    $user_id = get_current_user_id();
    $name = isset($_POST['qcou_certificate_name']) ? (string) $_POST['qcou_certificate_name'] : '';

    try {
      $res = QCOU_Certificates::issue($user_id, $course_id, $name);

      if (empty($res['ok'])) {
        $message = isset($res['error']) ? (string) $res['error'] : __('Certificate request failed.', 'quick-courses-builder');
        self::set_feedback($user_id, $course_id, 'error', $message);
      } else {
        $note = (string) ($res['issued']['note'] ?? __('Certificate issued successfully.', 'quick-courses-builder'));
        self::set_feedback($user_id, $course_id, 'success', $note);
      }
    } catch (Throwable $e) {
      self::set_feedback($user_id, $course_id, 'error', __('Certificate request failed unexpectedly. Please try again.', 'quick-courses-builder'));
    }

    wp_safe_redirect(get_permalink($course_id));
    exit;
  }
}
