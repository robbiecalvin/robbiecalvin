<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Test_Actions {

  public static function register(): void {
    add_action('template_redirect', [__CLASS__, 'handle_post']);
  }

  public static function handle_post(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    if (!isset($_POST['qcou_test_submit'])) return;
    if (!qcou_is_premium_active()) return;

    if (!is_user_logged_in()) return;

    if (!isset($_POST['qcou_test_nonce']) || !wp_verify_nonce($_POST['qcou_test_nonce'], 'qcou_submit_test')) {
      return;
    }

    $course_id = (int) ($_POST['qcou_course_id'] ?? 0);
    $test_id   = (int) ($_POST['qcou_test_id'] ?? 0);

    if ($course_id <= 0 || get_post_type($course_id) !== QCOU_Constants::CPT_COURSE) return;
    if ($test_id <= 0 || get_post_type($test_id) !== QCOU_Constants::CPT_TEST) return;

    // Validate course->test link (single source of truth)
    $linked = QCOU_Tests::get_linked_test_id($course_id);
    if ($linked !== $test_id) return;

    $user_id = get_current_user_id();

    // Enforce locking rules
    if (!QCOU_Access::can_take_test($user_id, $course_id)) {
      wp_safe_redirect(get_permalink($course_id));
      exit;
    }

    $answers_raw = $_POST['qcou_answers'] ?? [];
    $submitted = [];

    if (is_array($answers_raw)) {
      foreach ($answers_raw as $qid => $val) {
        $qid = sanitize_key((string) $qid);
        $submitted[$qid] = (int) $val;
      }
    }

    $questions = QCOU_Test_Builder::get_questions($test_id);
    $score = QCOU_Test_Grader::grade($questions, $submitted);

    QCOU_Tests::set_latest_score($user_id, $course_id, $score);
    QCOU_Tests::update_pass_state($user_id, $course_id);

    wp_safe_redirect(get_permalink($course_id));
    exit;
  }
}
