<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Module_Actions {

  public static function register(): void {
    add_action('template_redirect', [__CLASS__, 'handle_post']);
  }

  public static function handle_post(): void {
    if (!is_user_logged_in() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
      return;
    }

    // New flow: module completion is tracked inside course page.
    if (isset($_POST['qcou_course_module_toggle'])) {
      self::handle_course_module_toggle();
      return;
    }

    // Legacy fallback: module CPT completion route.
    if (isset($_POST['qcou_action'], $_POST['qcou_module_id'], $_POST['qcou_nonce'])) {
      self::handle_legacy_module_toggle();
    }
  }

  private static function handle_course_module_toggle(): void {
    if (!isset($_POST['qcou_nonce']) || !wp_verify_nonce((string) $_POST['qcou_nonce'], 'qcou_toggle_course_module')) {
      return;
    }

    $course_id = isset($_POST['qcou_course_id']) ? absint($_POST['qcou_course_id']) : 0;
    if ($course_id <= 0 || get_post_type($course_id) !== QCOU_Constants::CPT_COURSE) {
      return;
    }

    $module_key = isset($_POST['qcou_module_key']) ? sanitize_key((string) $_POST['qcou_module_key']) : '';
    if ($module_key === '') {
      return;
    }

    $valid_keys = QCOU_Progress::get_course_module_keys($course_id);
    if (!in_array($module_key, $valid_keys, true)) {
      return;
    }

    $action = isset($_POST['qcou_action']) ? sanitize_key((string) $_POST['qcou_action']) : '';
    $user_id = get_current_user_id();

    if ($action === 'complete') {
      QCOU_Progress::mark_complete($user_id, $course_id, $module_key);
    } elseif ($action === 'incomplete') {
      QCOU_Progress::mark_incomplete($user_id, $course_id, $module_key);
    }

    wp_safe_redirect(get_permalink($course_id));
    exit;
  }

  private static function handle_legacy_module_toggle(): void {
    if (!wp_verify_nonce((string) $_POST['qcou_nonce'], 'qcou_toggle_module')) {
      return;
    }

    $module_id = absint($_POST['qcou_module_id']);
    if (get_post_type($module_id) !== QCOU_Constants::CPT_MODULE) {
      return;
    }

    $course_id = QCOU_Relations::get_course_id_for_module($module_id);
    if ($course_id <= 0) {
      return;
    }

    $module_key = 'legacy_' . $module_id;
    $action  = sanitize_key((string) $_POST['qcou_action']);

    if ($action === 'complete') {
      QCOU_Progress::mark_complete(get_current_user_id(), $course_id, $module_key);
    } elseif ($action === 'incomplete') {
      QCOU_Progress::mark_incomplete(get_current_user_id(), $course_id, $module_key);
    }

    wp_safe_redirect(get_permalink($module_id));
    exit;
  }
}
