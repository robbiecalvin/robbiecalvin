<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Woo {

  public static function register(): void {
    if (!class_exists('WooCommerce')) {
      return;
    }

    add_action('save_post_' . QCOU_Constants::CPT_COURSE, [__CLASS__, 'maybe_create_product'], 20, 2);
  }

  /**
   * Auto-create or validate Woo product for paid courses
   */
  public static function maybe_create_product(int $post_id, WP_Post $post): void {
    if (!current_user_can(QCOU_Constants::CAP_MANAGE, $post_id)) {
      return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    if (wp_is_post_autosave($post_id)) return;

    $is_paid = (int) get_post_meta($post_id, '_qcb_is_paid', true);
    if ($is_paid !== 1) {
      // Course is free, unlink product if one exists
      delete_post_meta($post_id, '_qcb_wc_product_id');
      return;
    }

    $existing_product_id = (int) get_post_meta($post_id, '_qcb_wc_product_id', true);
    if ($existing_product_id > 0 && get_post_type($existing_product_id) === 'product') {
      return; // Already linked and valid
    }

    // Auto-create a simple product
    $product_id = wp_insert_post([
      'post_title'  => $post->post_title,
      'post_status' => 'publish',
      'post_type'   => 'product',
    ]);

    if (is_wp_error($product_id) || $product_id <= 0) {
      QCOU_Admin_Notices::add($post_id, __('Failed to create WooCommerce product.', 'quick-courses-builder'));
      return;
    }

    // Configure product
    update_post_meta($product_id, '_virtual', 'yes');
    update_post_meta($product_id, '_downloadable', 'no');
    update_post_meta($product_id, '_sold_individually', 'yes');
    update_post_meta($product_id, '_visibility', 'visible');

    // Default price = 0 (admin can change later)
    update_post_meta($product_id, '_regular_price', '0');
    update_post_meta($product_id, '_price', '0');

    update_post_meta($post_id, '_qcb_wc_product_id', $product_id);

    QCOU_Admin_Notices::add(
      $post_id,
      __('WooCommerce product created and linked. Set price in Products.', 'quick-courses-builder')
    );
  }
}
