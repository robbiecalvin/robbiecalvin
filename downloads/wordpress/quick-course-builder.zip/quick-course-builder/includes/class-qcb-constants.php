<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Constants {

  // Capability gate: Admins + Editors.
  public const CAP_MANAGE = 'edit_others_posts';

  // CPT slugs
  public const CPT_COURSE      = 'qc_course';
  public const CPT_MODULE      = 'qc_module';
  public const CPT_TEST        = 'qc_test';
  public const CPT_CERTIFICATE = 'qc_certificate';

  // Rewrite base
  public const COURSES_BASE = 'courses';

  // Query vars
  public const QV_COURSE_SLUG = 'qcou_course';

  // Menu slugs
  public const MENU_TOP   = 'qcou_dashboard';
  public const MENU_COURSES = 'edit.php?post_type=' . self::CPT_COURSE;
  public const MENU_TESTS   = 'edit.php?post_type=' . self::CPT_TEST;
  public const MENU_CERTS   = 'edit.php?post_type=' . self::CPT_CERTIFICATE;
}

