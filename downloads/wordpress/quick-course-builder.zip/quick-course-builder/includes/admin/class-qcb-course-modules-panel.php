<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Course_Modules_Panel {

  public const META_KEY = 'quickwoo_course_modules';

  public static function register(): void {
    add_action('add_meta_boxes', [__CLASS__, 'add_box']);
    add_action('save_post_' . QCOU_Constants::CPT_COURSE, [__CLASS__, 'save'], 20, 2);
    add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue']);
  }

  public static function enqueue(string $hook): void {
    if (!in_array($hook, ['post.php', 'post-new.php'], true)) {
      return;
    }

    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== QCOU_Constants::CPT_COURSE) {
      return;
    }

    wp_enqueue_script('jquery-ui-sortable');

    wp_enqueue_style(
      'qcb-admin',
      QCOU_URL . 'assets/css/admin.css',
      [],
      QCOU_VERSION
    );

    wp_enqueue_script(
      'qcb-admin-course-modules',
      QCOU_URL . 'assets/js/admin-course-modules.js',
      ['jquery', 'jquery-ui-sortable'],
      QCOU_VERSION,
      true
    );

    wp_localize_script('qcb-admin-course-modules', 'QCBModulesBuilder', [
      'strings' => [
        'addModule' => __('Add Module', 'quick-courses-builder'),
        'addSection' => __('Add Section', 'quick-courses-builder'),
        'remove'    => __('Remove', 'quick-courses-builder'),
      ],
    ]);
  }

  public static function add_box(): void {
    add_meta_box(
      'qcou_course_modules',
      __('Module Builder', 'quick-courses-builder'),
      [__CLASS__, 'render'],
      QCOU_Constants::CPT_COURSE,
      'normal',
      'high'
    );
  }

  public static function get_modules(int $course_id): array {
    $modules = get_post_meta($course_id, self::META_KEY, true);
    if (!is_array($modules)) {
      return [];
    }

    $normalized = [];
    foreach ($modules as $raw) {
      if (!is_array($raw)) {
        continue;
      }

      $id = isset($raw['id']) ? sanitize_key((string) $raw['id']) : '';
      if ($id === '') {
        $id = 'module_' . wp_generate_password(8, false, false);
      }

      $title = isset($raw['title']) ? sanitize_text_field((string) $raw['title']) : '';
      if ($title === '') {
        continue;
      }

      $sections = [];
      if (!empty($raw['sections']) && is_array($raw['sections'])) {
        foreach ($raw['sections'] as $section) {
          if (!is_array($section)) {
            continue;
          }

          $type = isset($section['type']) ? sanitize_key((string) $section['type']) : 'paragraph';
          if (!in_array($type, ['header', 'paragraph', 'list', 'divider'], true)) {
            $type = 'paragraph';
          }

          $content = isset($section['content']) ? wp_kses_post((string) $section['content']) : '';
          if ($type !== 'divider' && trim(wp_strip_all_tags($content)) === '') {
            continue;
          }

          $sections[] = [
            'type'    => $type,
            'content' => $content,
          ];
        }
      }

      if (empty($sections)) {
        $sections[] = [
          'type'    => 'paragraph',
          'content' => '',
        ];
      }

      $normalized[] = [
        'id'              => $id,
        'title'           => $title,
        'enabled'         => !empty($raw['enabled']) ? 1 : 0,
        'complete_marker' => !empty($raw['complete_marker']) ? 1 : 0,
        'exercise_enabled'=> !empty($raw['exercise_enabled']) ? 1 : 0,
        'exercise_text'   => isset($raw['exercise_text']) ? wp_kses_post((string) $raw['exercise_text']) : '',
        'sections'        => $sections,
      ];
    }

    return $normalized;
  }

  public static function get_module_by_key(int $course_id, string $module_key): array {
    $module_key = sanitize_key($module_key);
    foreach (self::get_modules($course_id) as $module) {
      if (($module['id'] ?? '') === $module_key) {
        return $module;
      }
    }

    return [];
  }

  public static function get_module_keys(int $course_id): array {
    $keys = [];
    foreach (self::get_modules($course_id) as $module) {
      if (!empty($module['enabled']) && !empty($module['id'])) {
        $keys[] = (string) $module['id'];
      }
    }

    return $keys;
  }

  public static function render(WP_Post $post): void {
    QCOU_Security::deny_if_cannot_manage();
    wp_nonce_field('qcou_save_course_modules', 'qcou_course_modules_nonce');

    $modules = self::get_modules((int) $post->ID);
    if (empty($modules)) {
      $modules[] = [
        'id'               => 'module_' . wp_generate_password(8, false, false),
        'title'            => '',
        'enabled'          => 1,
        'complete_marker'  => 1,
        'exercise_enabled' => 0,
        'exercise_text'    => '',
        'sections'         => [
          ['type' => 'header', 'content' => ''],
          ['type' => 'paragraph', 'content' => ''],
        ],
      ];
    }

    echo '<p class="description">' . esc_html__('Build and reorder modules directly in the course editor. Each module can include headers, paragraphs, lists, and dividers.', 'quick-courses-builder') . '</p>';
    echo '<div class="qcb-course-modules" data-qcb-modules-root>';

    foreach ($modules as $index => $module) {
      self::render_module_card((int) $index, $module);
    }

    echo '</div>';
    echo '<p><button type="button" class="button button-secondary" data-qcb-add-module>' . esc_html__('Add Module', 'quick-courses-builder') . '</button></p>';

    echo '<script type="text/template" id="qcb-module-template">';
    ob_start();
    self::render_module_card('__INDEX__', [
      'id'               => '__MODULE_ID__',
      'title'            => '',
      'enabled'          => 1,
      'complete_marker'  => 1,
      'exercise_enabled' => 0,
      'exercise_text'    => '',
      'sections'         => [
        ['type' => 'header', 'content' => ''],
        ['type' => 'paragraph', 'content' => ''],
      ],
    ], true);
    echo str_replace('__MODULE_ID__', 'module_' . wp_generate_password(8, false, false), (string) ob_get_clean());
    echo '</script>';

    echo '<script type="text/template" id="qcb-module-section-template">';
    self::render_section_row('__INDEX__', '__SECTION__', ['type' => 'paragraph', 'content' => ''], true);
    echo '</script>';
  }

  private static function render_module_card($index, array $module, bool $is_template = false): void {
    $title = isset($module['title']) ? (string) $module['title'] : '';
    $enabled = !empty($module['enabled']) ? 1 : 0;
    $complete_marker = !empty($module['complete_marker']) ? 1 : 0;
    $exercise_enabled = !empty($module['exercise_enabled']) ? 1 : 0;
    $exercise_text = isset($module['exercise_text']) ? (string) $module['exercise_text'] : '';
    $module_id = isset($module['id']) ? sanitize_key((string) $module['id']) : 'module_' . wp_generate_password(8, false, false);

    $index_attr = $is_template ? '__INDEX__' : (string) $index;

    echo '<div class="qcb-course-module" data-qcb-module-card>';
    echo '<div class="qcb-course-module__head">';
    echo '<span class="qcb-drag-handle" aria-hidden="true">&#x2630;</span>';
    echo '<strong>' . esc_html__('Module', 'quick-courses-builder') . '</strong>';
    echo '<button type="button" class="button-link-delete" data-qcb-remove-module>' . esc_html__('Remove', 'quick-courses-builder') . '</button>';
    echo '</div>';

    echo '<input type="hidden" name="qcou_course_modules[' . esc_attr($index_attr) . '][id]" value="' . esc_attr($module_id) . '">';

    echo '<p><label><strong>' . esc_html__('Module Title', 'quick-courses-builder') . '</strong></label><br>';
    echo '<input type="text" class="widefat" name="qcou_course_modules[' . esc_attr($index_attr) . '][title]" value="' . esc_attr($title) . '"></p>';

    echo '<p class="qcb-inline-checks">';
    echo '<label><input type="checkbox" name="qcou_course_modules[' . esc_attr($index_attr) . '][enabled]" value="1" ' . checked(1, $enabled, false) . '> ' . esc_html__('Enable module', 'quick-courses-builder') . '</label>';
    echo '<label><input type="checkbox" name="qcou_course_modules[' . esc_attr($index_attr) . '][complete_marker]" value="1" ' . checked(1, $complete_marker, false) . '> ' . esc_html__('Show completion marker', 'quick-courses-builder') . '</label>';
    echo '<label><input type="checkbox" name="qcou_course_modules[' . esc_attr($index_attr) . '][exercise_enabled]" value="1" ' . checked(1, $exercise_enabled, false) . '> ' . esc_html__('Enable exercise', 'quick-courses-builder') . '</label>';
    echo '</p>';

    echo '<p><label><strong>' . esc_html__('Exercise Content', 'quick-courses-builder') . '</strong></label><br>';
    echo '<textarea class="widefat" rows="3" name="qcou_course_modules[' . esc_attr($index_attr) . '][exercise_text]">' . esc_textarea($exercise_text) . '</textarea></p>';

    echo '<div class="qcb-module-sections" data-qcb-sections>';
    $sections = isset($module['sections']) && is_array($module['sections']) ? $module['sections'] : [];
    if (empty($sections)) {
      $sections[] = ['type' => 'paragraph', 'content' => ''];
    }

    foreach ($sections as $section_index => $section) {
      self::render_section_row($index_attr, (string) $section_index, $section);
    }
    echo '</div>';

    echo '<p><button type="button" class="button" data-qcb-add-section>' . esc_html__('Add Section', 'quick-courses-builder') . '</button></p>';
    echo '</div>';
  }

  private static function render_section_row($module_index, $section_index, array $section, bool $is_template = false): void {
    $type = isset($section['type']) ? sanitize_key((string) $section['type']) : 'paragraph';
    if (!in_array($type, ['header', 'paragraph', 'list', 'divider'], true)) {
      $type = 'paragraph';
    }
    $content = isset($section['content']) ? (string) $section['content'] : '';

    $module_attr = $is_template ? '__INDEX__' : (string) $module_index;
    $section_attr = $is_template ? '__SECTION__' : (string) $section_index;

    echo '<div class="qcb-module-section" data-qcb-section>';
    echo '<div class="qcb-module-section__row">';
    echo '<select name="qcou_course_modules[' . esc_attr($module_attr) . '][sections][' . esc_attr($section_attr) . '][type]">';
    echo '<option value="header" ' . selected($type, 'header', false) . '>' . esc_html__('Header', 'quick-courses-builder') . '</option>';
    echo '<option value="paragraph" ' . selected($type, 'paragraph', false) . '>' . esc_html__('Paragraph', 'quick-courses-builder') . '</option>';
    echo '<option value="list" ' . selected($type, 'list', false) . '>' . esc_html__('List', 'quick-courses-builder') . '</option>';
    echo '<option value="divider" ' . selected($type, 'divider', false) . '>' . esc_html__('Section Divider', 'quick-courses-builder') . '</option>';
    echo '</select>';

    echo '<button type="button" class="button-link-delete" data-qcb-remove-section>' . esc_html__('Remove', 'quick-courses-builder') . '</button>';
    echo '</div>';

    echo '<textarea rows="3" class="widefat" name="qcou_course_modules[' . esc_attr($module_attr) . '][sections][' . esc_attr($section_attr) . '][content]" placeholder="' . esc_attr__('Section content', 'quick-courses-builder') . '">' . esc_textarea($content) . '</textarea>';
    echo '</div>';
  }

  public static function save(int $post_id, WP_Post $post): void {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;

    if (!isset($_POST['qcou_course_modules_nonce']) || !wp_verify_nonce((string) $_POST['qcou_course_modules_nonce'], 'qcou_save_course_modules')) {
      return;
    }

    if (!current_user_can(QCOU_Constants::CAP_MANAGE, $post_id)) {
      return;
    }

    $raw_modules = $_POST['qcou_course_modules'] ?? [];
    $sanitized = [];

    if (is_array($raw_modules)) {
      foreach ($raw_modules as $raw) {
        if (!is_array($raw)) {
          continue;
        }

        $title = isset($raw['title']) ? sanitize_text_field((string) $raw['title']) : '';
        if ($title === '') {
          continue;
        }

        $module_id = isset($raw['id']) ? sanitize_key((string) $raw['id']) : '';
        if ($module_id === '') {
          $module_id = 'module_' . wp_generate_password(8, false, false);
        }

        $sections = [];
        if (!empty($raw['sections']) && is_array($raw['sections'])) {
          foreach ($raw['sections'] as $section) {
            if (!is_array($section)) {
              continue;
            }

            $type = isset($section['type']) ? sanitize_key((string) $section['type']) : 'paragraph';
            if (!in_array($type, ['header', 'paragraph', 'list', 'divider'], true)) {
              $type = 'paragraph';
            }

            $content = isset($section['content']) ? wp_kses_post((string) $section['content']) : '';
            if ($type !== 'divider' && trim(wp_strip_all_tags($content)) === '') {
              continue;
            }

            $sections[] = [
              'type' => $type,
              'content' => $content,
            ];
          }
        }

        if (empty($sections)) {
          $sections[] = [
            'type' => 'paragraph',
            'content' => '',
          ];
        }

        $sanitized[] = [
          'id'               => $module_id,
          'title'            => $title,
          'enabled'          => !empty($raw['enabled']) ? 1 : 0,
          'complete_marker'  => !empty($raw['complete_marker']) ? 1 : 0,
          'exercise_enabled' => !empty($raw['exercise_enabled']) ? 1 : 0,
          'exercise_text'    => isset($raw['exercise_text']) ? wp_kses_post((string) $raw['exercise_text']) : '',
          'sections'         => $sections,
        ];
      }
    }

    update_post_meta($post_id, self::META_KEY, $sanitized);
  }
}
