<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Admin_Menu {

  public static function register(): void {
    if (!current_user_can(QCOU_Constants::CAP_MANAGE)) {
      return;
    }

    add_menu_page(
      __('Quick Courses Builder', 'quick-courses-builder'),
      __('Quick Courses Builder', 'quick-courses-builder'),
      QCOU_Constants::CAP_MANAGE,
      QCOU_Constants::MENU_TOP,
      [__CLASS__, 'render_dashboard'],
      'dashicons-welcome-learn-more',
      26
    );

    add_submenu_page(
      QCOU_Constants::MENU_TOP,
      __('Courses', 'quick-courses-builder'),
      __('Courses', 'quick-courses-builder'),
      QCOU_Constants::CAP_MANAGE,
      QCOU_Constants::MENU_COURSES
    );

    add_submenu_page(
      QCOU_Constants::MENU_TOP,
      __('Tests', 'quick-courses-builder'),
      __('Tests', 'quick-courses-builder'),
      QCOU_Constants::CAP_MANAGE,
      QCOU_Constants::MENU_TESTS
    );

    add_submenu_page(
      QCOU_Constants::MENU_TOP,
      __('Certificates', 'quick-courses-builder'),
      __('Certificates', 'quick-courses-builder'),
      QCOU_Constants::CAP_MANAGE,
      QCOU_Constants::MENU_CERTS
    );

    remove_submenu_page(QCOU_Constants::MENU_TOP, QCOU_Constants::MENU_TOP);
  }

  public static function render_dashboard(): void {
    QCOU_Security::deny_if_cannot_manage();

    echo '<div class="wrap">';
    echo '<h1>' . esc_html__('Quick Courses Builder', 'quick-courses-builder') . '</h1>';
    echo '<p>' . esc_html__('Courses now manage modules directly inside the course editor. Tests and Certificates stay as dedicated workflows.', 'quick-courses-builder') . '</p>';
    echo '<ul style="list-style:disc;padding-left:20px;">';
    echo '<li><strong>' . esc_html__('Courses:', 'quick-courses-builder') . '</strong> ' . esc_html__('Build structured modules, progression, and completion flow in one place.', 'quick-courses-builder') . '</li>';
    echo '<li><strong>' . esc_html__('Tests:', 'quick-courses-builder') . '</strong> ' . esc_html__('Link graded tests to specific courses.', 'quick-courses-builder') . '</li>';
    echo '<li><strong>' . esc_html__('Certificates:', 'quick-courses-builder') . '</strong> ' . esc_html__('Configure templates and issue completion records safely.', 'quick-courses-builder') . '</li>';
    echo '</ul>';
    echo '</div>';
  }
}
