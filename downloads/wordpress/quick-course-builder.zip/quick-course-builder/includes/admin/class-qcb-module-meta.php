<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Module_Meta {

  public static function register(): void {
    add_action('add_meta_boxes', [__CLASS__, 'add_meta_box']);
    add_action('save_post_' . QCOU_Constants::CPT_MODULE, [__CLASS__, 'save'], 10, 2);
  }

  public static function add_meta_box(): void {
    add_meta_box(
      'qcou_module_course',
      __('Parent Course', 'quick-courses-builder'),
      [__CLASS__, 'render'],
      QCOU_Constants::CPT_MODULE,
      'side',
      'high'
    );
  }

  public static function render(WP_Post $post): void {
    QCOU_Security::deny_if_cannot_manage();
    wp_nonce_field('qcou_save_module', 'qcou_module_nonce');

    $courses = get_posts([
      'post_type' => QCOU_Constants::CPT_COURSE,
      'numberposts' => -1,
      'post_status' => 'publish',
      'orderby' => 'title',
      'order' => 'ASC',
    ]);

    echo '<p><label><strong>' . esc_html__('Parent Course', 'quick-courses-builder') . '</strong></label>';
    echo '<select name="qcou_parent_course" style="width:100%">';

    echo '<option value="0">' . esc_html__('— Select Course —', 'quick-courses-builder') . '</option>';

  $selected_parent = (int) $post->post_parent;

// Allow preselect via ?parent_course=ID
if ($selected_parent === 0 && isset($_GET['parent_course'])) {
  $selected_parent = (int) $_GET['parent_course'];
}

foreach ($courses as $course) {
  echo '<option value="' . esc_attr($course->ID) . '" ' . selected($selected_parent, $course->ID, false) . '>';

      echo esc_html($course->post_title);
      echo '</option>';
    }

    echo '</select></p>';

    echo '<p><em>' . esc_html__('Modules must belong to exactly one course.', 'quick-courses-builder') . '</em></p>';
  }

  public static function save(int $post_id, WP_Post $post): void {
    if (!isset($_POST['qcou_module_nonce']) || !wp_verify_nonce($_POST['qcou_module_nonce'], 'qcou_save_module')) {
      return;
    }

    if (!current_user_can(QCOU_Constants::CAP_MANAGE, $post_id)) {
      return;
    }

    $parent = isset($_POST['qcou_parent_course']) ? (int) $_POST['qcou_parent_course'] : 0;

    if ($parent <= 0 || get_post_type($parent) !== QCOU_Constants::CPT_COURSE) {
      // Block publishing without a valid course.
      if ($post->post_status === 'publish') {
        QCOU_Admin_Notices::add($post_id, __('Module cannot be published without a valid parent course.', 'quick-courses-builder'));
        wp_update_post([
          'ID' => $post_id,
          'post_status' => 'draft',
        ]);
      }
      return;
    }

    wp_update_post([
      'ID' => $post_id,
      'post_parent' => $parent,
    ]);
  }
}

