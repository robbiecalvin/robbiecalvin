<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Course_Meta {

  public static function register(): void {
    add_action('add_meta_boxes', [__CLASS__, 'add_meta_boxes']);
    add_action('save_post_' . QCOU_Constants::CPT_COURSE, [__CLASS__, 'save'], 10, 2);
  }

  public static function add_meta_boxes(): void {
    add_meta_box(
      'qcou_course_settings',
      __('Course Settings', 'quick-courses-builder'),
      [__CLASS__, 'render'],
      QCOU_Constants::CPT_COURSE,
      'side',
      'high'
    );
  }

  public static function render(WP_Post $post): void {
    QCOU_Security::deny_if_cannot_manage();
    wp_nonce_field('qcou_save_course', 'qcou_course_nonce');

    $passing = (int) get_post_meta($post->ID, '_qcb_passing_grade', true);
    $test_id = (int) get_post_meta($post->ID, '_qcb_test_id', true);
    $cert_id = (int) get_post_meta($post->ID, '_qcb_certificate_id', true);
    $is_paid = (int) get_post_meta($post->ID, '_qcb_is_paid', true);
    $product_id = (int) get_post_meta($post->ID, '_qcb_wc_product_id', true);

    $woo_active = class_exists('WooCommerce');

    echo '<p><label><strong>' . esc_html__('Passing Grade (%)', 'quick-courses-builder') . '</strong></label>';
    echo '<input type="number" min="0" max="100" name="qcou_passing_grade" value="' . esc_attr($passing) . '" style="width:100%"></p>';

    echo '<p><label><strong>' . esc_html__('Linked Test', 'quick-courses-builder') . '</strong></label>';
    self::render_post_select('qcou_test_id', QCOU_Constants::CPT_TEST, $test_id);
    echo '</p>';

    echo '<p><label><strong>' . esc_html__('Linked Certificate', 'quick-courses-builder') . '</strong></label>';
    self::render_post_select('qcou_certificate_id', QCOU_Constants::CPT_CERTIFICATE, $cert_id);
    echo '</p>';

    if ($woo_active) {
      echo '<hr>';
      echo '<p><label><input type="checkbox" name="qcou_is_paid" value="1" ' . checked(1, $is_paid, false) . '> ';
      echo esc_html__('Paid Course', 'quick-courses-builder') . '</label></p>';

      echo '<p><label><strong>' . esc_html__('WooCommerce Product', 'quick-courses-builder') . '</strong></label>';
      self::render_post_select('qcou_wc_product_id', 'product', $product_id, true);
      echo '</p>';
    } else {
      echo '<p><em>' . esc_html__('WooCommerce not active. Course will behave as free.', 'quick-courses-builder') . '</em></p>';
    }
  }

  private static function render_post_select(string $name, string $post_type, int $selected, bool $allow_empty = false): void {
    $posts = get_posts([
      'post_type' => $post_type,
      'numberposts' => -1,
      'post_status' => 'publish',
      'orderby' => 'title',
      'order' => 'ASC',
    ]);

    echo '<select name="' . esc_attr($name) . '" style="width:100%">';
    if ($allow_empty) {
      echo '<option value="0">' . esc_html__('— None —', 'quick-courses-builder') . '</option>';
    }

    foreach ($posts as $p) {
      echo '<option value="' . esc_attr($p->ID) . '" ' . selected($selected, $p->ID, false) . '>';
      echo esc_html($p->post_title);
      echo '</option>';
    }

    echo '</select>';
  }

  public static function save(int $post_id, WP_Post $post): void {
    if (!isset($_POST['qcou_course_nonce']) || !wp_verify_nonce($_POST['qcou_course_nonce'], 'qcou_save_course')) {
      return;
    }

    if (!current_user_can(QCOU_Constants::CAP_MANAGE, $post_id)) {
      return;
    }

    $passing = isset($_POST['qcou_passing_grade']) ? (int) $_POST['qcou_passing_grade'] : 0;
    $passing = max(0, min(100, $passing));
    update_post_meta($post_id, '_qcb_passing_grade', $passing);

    self::validate_and_save_linked_post($post_id, '_qcb_test_id', $_POST['qcou_test_id'] ?? 0, QCOU_Constants::CPT_TEST);
    self::validate_and_save_linked_post($post_id, '_qcb_certificate_id', $_POST['qcou_certificate_id'] ?? 0, 
QCOU_Constants::CPT_CERTIFICATE);

    if (class_exists('WooCommerce')) {
      $is_paid = isset($_POST['qcou_is_paid']) ? 1 : 0;
      update_post_meta($post_id, '_qcb_is_paid', $is_paid);

      self::validate_and_save_linked_post($post_id, '_qcb_wc_product_id', $_POST['qcou_wc_product_id'] ?? 0, 'product');
    } else {
      update_post_meta($post_id, '_qcb_is_paid', 0);
      delete_post_meta($post_id, '_qcb_wc_product_id');
    }
  }

  private static function validate_and_save_linked_post(int $course_id, string $meta_key, $raw, string $expected_type): void {
    $id = (int) $raw;
    if ($id <= 0) {
      delete_post_meta($course_id, $meta_key);
      return;
    }

    $p = get_post($id);
    if (!$p || $p->post_type !== $expected_type) {
      delete_post_meta($course_id, $meta_key);
      QCOU_Admin_Notices::add($course_id, sprintf(
        __('Invalid linked %s removed.', 'quick-courses-builder'),
        esc_html($expected_type)
      ));
      return;
    }

    update_post_meta($course_id, $meta_key, $id);
  }
}

