<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Module_Builder {

  // Meta keys
  private const META_BLOCKS = '_qcb_blocks';
  private const META_EX_ENABLED = '_qcb_exercise_enabled';
  private const META_EX_REQUIRED = '_qcb_exercise_required';
  private const META_EX_CONTENT = '_qcb_exercise_content';
  private const META_NEXT = '_qcb_next_module_id';
  private const META_PREV = '_qcb_prev_module_id';

  public static function register(): void {
    add_action('add_meta_boxes', [__CLASS__, 'add_meta_boxes']);
    add_action('save_post_' . QCOU_Constants::CPT_MODULE, [__CLASS__, 'save'], 20, 2);

    add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue']);
  }

  public static function enqueue(string $hook): void {
    // Only on module edit screens
    if (!in_array($hook, ['post.php', 'post-new.php'], true)) return;

    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== QCOU_Constants::CPT_MODULE) return;

    wp_enqueue_media();

    wp_enqueue_style(
      'qcb-admin',
      QCOU_URL . 'assets/css/admin.css',
      [],
      QCOU_VERSION
    );

    wp_enqueue_script(
      'qcb-admin-module-builder',
      QCOU_URL . 'assets/js/admin-module-builder.js',
      ['jquery'],
      QCOU_VERSION,
      true
    );

    wp_localize_script('qcb-admin-module-builder', 'QCBModuleBuilder', [
      'nonce' => wp_create_nonce('qcou_module_builder_ui'),
      'strings' => [
        'addBlock' => __('Add Block', 'quick-courses-builder'),
        'remove' => __('Remove', 'quick-courses-builder'),
        'chooseImage' => __('Choose Image', 'quick-courses-builder'),
        'removeImage' => __('Remove Image', 'quick-courses-builder'),
      ],
    ]);
  }

  public static function add_meta_boxes(): void {
    add_meta_box(
      'qcou_module_builder',
      __('Module Builder', 'quick-courses-builder'),
      [__CLASS__, 'render_builder'],
      QCOU_Constants::CPT_MODULE,
      'normal',
      'high'
    );

 add_meta_box(
  'qcou_module_exercise',
  __('Exercise (Optional/Required)', 'quick-courses-builder'),
  [__CLASS__, 'render_exercise_editor'],
  QCOU_Constants::CPT_MODULE,
  'normal',
  'default'
);

add_meta_box(
  'qcou_module_nav',
  __('Module Navigation', 'quick-courses-builder'),
  [__CLASS__, 'render_navigation_editor'],
  QCOU_Constants::CPT_MODULE,
  'side',
  'default'
);

  }

  public static function render_builder(WP_Post $post): void {
    QCOU_Security::deny_if_cannot_manage();
    wp_nonce_field('qcou_save_module_builder', 'qcou_module_builder_nonce');

    $blocks = get_post_meta($post->ID, self::META_BLOCKS, true);
    if (!is_array($blocks)) $blocks = [];

    echo '<div class="qcb-builder">';
    echo '<p class="description">' . esc_html__('Add repeatable content blocks. Content supports sanitized HTML.', 'quick-courses-builder') . '</p>';

    echo '<div class="qcb-blocks" data-qcb-blocks>';
    if (empty($blocks)) {
      // Render one empty block to avoid a blank UI.
      self::render_block_row(0, [
        'heading' => '',
        'subheading' => '',
        'content' => '',
        'image_id' => 0,
      ]);
    } else {
      $i = 0;
      foreach ($blocks as $block) {
        self::render_block_row($i, $block);
        $i++;
      }
    }
    echo '</div>';

    echo '<button type="button" class="button button-secondary qcb-add-block" data-qcb-add-block>'
      . esc_html__('Add Block', 'quick-courses-builder') .
    '</button>';

    // Template for JS cloning
    echo '<script type="text/template" id="qcb-block-template">';
    ob_start();
    self::render_block_row('__INDEX__', [
      'heading' => '',
      'subheading' => '',
      'content' => '',
      'image_id' => 0,
    ], true);
    $tpl = ob_get_clean();
    echo $tpl; // already escaped where necessary in renderer
    echo '</script>';

    echo '</div>';
  }

  private static function render_block_row($index, $block, bool $is_template = false): void {
    $heading = isset($block['heading']) ? (string) $block['heading'] : '';
    $subheading = isset($block['subheading']) ? (string) $block['subheading'] : '';
    $content = isset($block['content']) ? (string) $block['content'] : '';
    $image_id = isset($block['image_id']) ? (int) $block['image_id'] : 0;

    $idx_attr = $is_template ? '__INDEX__' : (string) $index;

    $img_url = '';
    if ($image_id > 0) {
      $src = wp_get_attachment_image_src($image_id, 'medium');
      if (is_array($src) && !empty($src[0])) $img_url = $src[0];
    }

    echo '<div class="qcb-block" data-qcb-block>';
    echo '<div class="qcb-block-header">';
    echo '<strong>' . esc_html__('Block', 'quick-courses-builder') . '</strong>';
    echo '<span class="qcb-block-actions">';
    echo '<button type="button" class="button-link-delete qcb-remove-block" data-qcb-remove-block>'
      . esc_html__('Remove', 'quick-courses-builder') .
    '</button>';
    echo '</span>';
    echo '</div>';

    echo '<div class="qcb-grid">';
    // Heading
    echo '<div class="qcb-field">';
    echo '<label><strong>' . esc_html__('Heading', 'quick-courses-builder') . '</strong></label>';
    echo '<input type="text" name="qcou_blocks[' . esc_attr($idx_attr) . '][heading]" value="' . esc_attr($heading) . '" style="width:100%">';
    echo '</div>';

    // Subheading
    echo '<div class="qcb-field">';
    echo '<label><strong>' . esc_html__('Subheading', 'quick-courses-builder') . '</strong></label>';
    echo '<input type="text" name="qcou_blocks[' . esc_attr($idx_attr) . '][subheading]" value="' . esc_attr($subheading) . '" style="width:100%">';
    echo '</div>';

    // Content
    echo '<div class="qcb-field qcb-field-full">';
    echo '<label><strong>' . esc_html__('Content (HTML allowed, sanitized)', 'quick-courses-builder') . '</strong></label>';
    echo '<textarea rows="6" name="qcou_blocks[' . esc_attr($idx_attr) . '][content]" style="width:100%">' . esc_textarea($content) . '</textarea>';
    echo '</div>';

    // Image
    echo '<div class="qcb-field qcb-field-full">';
    echo '<label><strong>' . esc_html__('Image', 'quick-courses-builder') . '</strong></label>';

    echo '<input type="hidden" data-qcb-image-id name="qcou_blocks[' . esc_attr($idx_attr) . '][image_id]" value="' . esc_attr((string)$image_id) . '">';

    echo '<div class="qcb-image-row">';
    echo '<div class="qcb-image-preview" data-qcb-image-preview>';
    if ($img_url !== '') {
      echo '<img src="' . esc_url($img_url) . '" alt="" style="max-width:220px;height:auto;border:1px solid #ccd0d4;border-radius:4px;">';
    } else {
      echo '<div class="qcb-image-empty">' . esc_html__('No image selected.', 'quick-courses-builder') . '</div>';
    }
    echo '</div>';

    echo '<div class="qcb-image-actions">';
    echo '<button type="button" class="button qcb-pick-image" data-qcb-pick-image>'
      . esc_html__('Choose Image', 'quick-courses-builder') .
    '</button> ';
    echo '<button type="button" class="button qcb-remove-image" data-qcb-remove-image>'
      . esc_html__('Remove Image', 'quick-courses-builder') .
    '</button>';
    echo '</div>';

    echo '</div>'; // image row

    echo '</div>'; // field full

    echo '</div>'; // grid
    echo '</div>'; // block
  }

  public static function render_exercise_editor(WP_Post $post): void {
    QCOU_Security::deny_if_cannot_manage();

    $enabled = (int) get_post_meta($post->ID, self::META_EX_ENABLED, true);
    $required = (int) get_post_meta($post->ID, self::META_EX_REQUIRED, true);
    $content = (string) get_post_meta($post->ID, self::META_EX_CONTENT, true);

    echo '<p><label>';
    echo '<input type="checkbox" name="qcou_exercise_enabled" value="1" ' . checked(1, $enabled, false) . '> ';
    echo '<strong>' . esc_html__('Enable Exercise Section', 'quick-courses-builder') . '</strong>';
    echo '</label></p>';

    echo '<p><label>';
    echo '<input type="checkbox" name="qcou_exercise_required" value="1" ' . checked(1, $required, false) . '> ';
    echo esc_html__('Exercise is required (otherwise it is optional)', 'quick-courses-builder');
    echo '</label></p>';

    echo '<p><label><strong>' . esc_html__('Exercise Content (HTML allowed, sanitized)', 'quick-courses-builder') . '</strong></label>';
    echo '<textarea rows="6" name="qcou_exercise_content" style="width:100%">' . esc_textarea($content) . '</textarea></p>';
  }

  public static function render_navigation_editor(WP_Post $post): void {
    QCOU_Security::deny_if_cannot_manage();

    $course_id = (int) $post->post_parent;
    $next_id = (int) get_post_meta($post->ID, self::META_NEXT, true);
    $prev_id = (int) get_post_meta($post->ID, self::META_PREV, true);

    if ($course_id <= 0 || get_post_type($course_id) !== QCOU_Constants::CPT_COURSE) {
      echo '<p><em>' . esc_html__('Set a valid parent course first (required). Navigation options will appear after that.', 'quick-courses-builder') . '</em></p>';
      return;
    }

    $modules = get_posts([
      'post_type' => QCOU_Constants::CPT_MODULE,
      'post_parent' => $course_id,
      'numberposts' => -1,
      'post_status' => ['publish', 'draft', 'pending', 'private'],
      'orderby' => 'menu_order',
      'order' => 'ASC',
    ]);

    echo '<p><strong>' . esc_html__('Next Module', 'quick-courses-builder') . '</strong></p>';
    self::render_module_select('qcou_next_module_id', $modules, $post->ID, $next_id);

    echo '<p style="margin-top:12px;"><strong>' . esc_html__('Previous Module', 'quick-courses-builder') . '</strong></p>';
    self::render_module_select('qcou_prev_module_id', $modules, $post->ID, $prev_id);

    echo '<p class="description" style="margin-top:10px;">' . esc_html__('Selections must belong to the same course.', 'quick-courses-builder') . '</p>';
  }

  public static function render_navigation(int $module_id): void {
  $course_id = QCOU_Relations::get_course_id_for_module($module_id);
  if ($course_id <= 0) {
    return;
  }

  $modules = get_posts([
    'post_type'   => QCOU_Constants::CPT_MODULE,
    'post_parent' => $course_id,
    'post_status' => 'publish',
    'orderby'     => 'menu_order',
    'order'       => 'ASC',
    'numberposts' => -1,
  ]);

  if (empty($modules)) {
    return;
  }

  $current_index = null;
  foreach ($modules as $i => $m) {
    if ((int)$m->ID === $module_id) {
      $current_index = $i;
      break;
    }
  }

  if ($current_index === null) {
    return;
  }

  echo '<nav class="qcb-module-navigation">';

  // Previous
  if ($current_index > 0) {
    $prev = $modules[$current_index - 1];
    echo '<a class="qcb-nav-prev" href="' . esc_url(get_permalink($prev->ID)) . '">';
    echo '← ' . esc_html($prev->post_title);
    echo '</a>';
  }

  // Next
  if ($current_index < count($modules) - 1) {
    $next = $modules[$current_index + 1];
    echo '<a class="qcb-nav-next" href="' . esc_url(get_permalink($next->ID)) . '">';
    echo esc_html($next->post_title) . ' →';
    echo '</a>';
  }

  echo '</nav>';
}


  private static function render_module_select(string $name, array $modules, int $current_id, int $selected_id): void {
    echo '<select name="' . esc_attr($name) . '" style="width:100%">';
    echo '<option value="0">' . esc_html__('— None —', 'quick-courses-builder') . '</option>';

    foreach ($modules as $m) {
      if (!($m instanceof WP_Post)) continue;
      if ((int)$m->ID === $current_id) continue;

      $label = $m->post_title !== '' ? $m->post_title : sprintf(__('(Untitled #%d)', 'quick-courses-builder'), (int)$m->ID);
      echo '<option value="' . esc_attr((string)$m->ID) . '" ' . selected($selected_id, (int)$m->ID, false) . '>';
      echo esc_html($label);
      echo '</option>';
    }

    echo '</select>';
  }

  public static function save(int $post_id, WP_Post $post): void {
   if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
if (wp_is_post_revision($post_id)) return;
if (wp_is_post_autosave($post_id)) return;

    if (!isset($_POST['qcou_module_builder_nonce']) || !wp_verify_nonce($_POST['qcou_module_builder_nonce'], 'qcou_save_module_builder')) {
      return;
    }

    if (!current_user_can(QCOU_Constants::CAP_MANAGE, $post_id)) {
      return;
    }

    // Save blocks
    $raw_blocks = $_POST['qcou_blocks'] ?? [];
    $blocks = self::sanitize_blocks($raw_blocks);
    update_post_meta($post_id, self::META_BLOCKS, $blocks);

    // Exercise
   $ex_enabled = QCOU_Sanitize::bool01($_POST['qcou_exercise_enabled'] ?? 0);
$ex_required = $ex_enabled
  ? QCOU_Sanitize::bool01($_POST['qcou_exercise_required'] ?? 0)
  : 0;

    $ex_content = isset($_POST['qcou_exercise_content']) ? QCOU_Sanitize::html((string)$_POST['qcou_exercise_content']) : '';

    update_post_meta($post_id, self::META_EX_ENABLED, $ex_enabled);
    update_post_meta($post_id, self::META_EX_REQUIRED, $ex_required);
    update_post_meta($post_id, self::META_EX_CONTENT, $ex_content);

    // Navigation validation (must be modules under the same parent course)
    $course_id = (int) wp_get_post_parent_id($post_id);

    $next_id = QCOU_Sanitize::int($_POST['qcou_next_module_id'] ?? 0);
    $prev_id = QCOU_Sanitize::int($_POST['qcou_prev_module_id'] ?? 0);

    $next_id = self::validate_nav_target($course_id, $post_id, $next_id);
    $prev_id = self::validate_nav_target($course_id, $post_id, $prev_id);

    if ($next_id > 0) update_post_meta($post_id, self::META_NEXT, $next_id);
    else delete_post_meta($post_id, self::META_NEXT);

    if ($prev_id > 0) update_post_meta($post_id, self::META_PREV, $prev_id);
    else delete_post_meta($post_id, self::META_PREV);
  }

  private static function sanitize_blocks($raw): array {
    if (!is_array($raw)) return [];

    $out = [];
    foreach ($raw as $maybe_block) {
      if (!is_array($maybe_block)) continue;

      $heading = isset($maybe_block['heading']) ? QCOU_Sanitize::text((string)$maybe_block['heading']) : '';
      $subheading = isset($maybe_block['subheading']) ? QCOU_Sanitize::text((string)$maybe_block['subheading']) : '';
      $content = isset($maybe_block['content']) ? QCOU_Sanitize::html((string)$maybe_block['content']) : '';
      $image_id = isset($maybe_block['image_id']) ? QCOU_Sanitize::int($maybe_block['image_id']) : 0;

      if ($image_id > 0 && get_post_type($image_id) !== 'attachment') {
        $image_id = 0;
      }

      // Skip totally empty blocks (prevents junk arrays)
      if ($heading === '' && $subheading === '' && trim($content) === '' && $image_id === 0) {
        continue;
      }

      $out[] = [
        'heading' => $heading,
        'subheading' => $subheading,
        'content' => $content,
        'image_id' => $image_id,
      ];
    }

    // Always store an array, even if empty.
    return array_values($out);
  }

  private static function validate_nav_target(int $course_id, int $current_module_id, int $target_id): int {
    if ($target_id <= 0) return 0;
    if ($target_id === $current_module_id) return 0;

    $p = get_post($target_id);
    if (!$p || $p->post_type !== QCOU_Constants::CPT_MODULE) return 0;

    $target_parent = (int) wp_get_post_parent_id($target_id);
    if ($course_id <= 0 || $target_parent !== $course_id) return 0;

    return $target_id;
  }
  public static function render_blocks(int $module_id): void {
  $blocks = get_post_meta($module_id, '_qcb_blocks', true);

  if (!is_array($blocks) || empty($blocks)) {
    return;
  }

  echo '<div class="qcb-module-blocks">';

  foreach ($blocks as $block) {
    $heading = isset($block['heading']) ? esc_html($block['heading']) : '';
    $subheading = isset($block['subheading']) ? esc_html($block['subheading']) : '';
    $content = isset($block['content']) ? $block['content'] : '';
    $image_id = isset($block['image_id']) ? (int) $block['image_id'] : 0;

    echo '<div class="qcb-module-block">';

    if ($heading !== '') {
      echo '<h2 class="qcb-block-heading">' . $heading . '</h2>';
    }

    if ($subheading !== '') {
      echo '<h3 class="qcb-block-subheading">' . $subheading . '</h3>';
    }

    if ($image_id > 0) {
      $img = wp_get_attachment_image($image_id, 'large');
      if ($img) {
        echo '<div class="qcb-block-image">' . $img . '</div>';
      }
    }

    if ($content !== '') {
      echo '<div class="qcb-block-content">';
      echo apply_filters('the_content', $content);
      echo '</div>';
    }

    echo '</div>';
  }

  echo '</div>';
}
public static function render_exercise(int $module_id): void {
  $enabled = (int) get_post_meta($module_id, '_qcb_exercise_enabled', true);

  if ($enabled !== 1) {
    return;
  }

  $required = (int) get_post_meta($module_id, '_qcb_exercise_required', true);
  $content = get_post_meta($module_id, '_qcb_exercise_content', true);

  if ($content === '') {
    return;
  }

  echo '<section class="qcb-module-exercise">';
  echo '<h3>' . esc_html__('Exercise', 'quick-courses-builder');

  if ($required === 1) {
    echo ' <span style="opacity:.7;">(' . esc_html__('Required', 'quick-courses-builder') . ')</span>';
  }

  echo '</h3>';

  echo '<div class="qcb-exercise-content">';
  echo apply_filters('the_content', $content);
  echo '</div>';

  echo '</section>';
}

}
