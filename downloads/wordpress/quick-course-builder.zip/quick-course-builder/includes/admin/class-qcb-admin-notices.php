<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Admin_Notices {

  private static array $queue = [];

  public static function add(int $post_id, string $message): void {
    self::$queue[$post_id][] = $message;
    add_action('admin_notices', [__CLASS__, 'render']);
  }

  public static function render(): void {
    global $post;
    if (!($post instanceof WP_Post)) return;

    $pid = (int) $post->ID;
    if (!isset(self::$queue[$pid])) return;

    foreach (self::$queue[$pid] as $msg) {
      echo '<div class="notice notice-warning"><p>' . esc_html($msg) . '</p></div>';
    }

    unset(self::$queue[$pid]);
  }
}

