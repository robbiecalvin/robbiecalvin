<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Certificate_Builder {

  public static function register(): void {
    add_action('add_meta_boxes', [__CLASS__, 'add_meta_boxes']);
    add_action('save_post_' . QCOU_Constants::CPT_CERTIFICATE, [__CLASS__, 'save'], 10, 2);
    add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue']);
  }

  public static function add_meta_boxes(): void {
    add_meta_box(
      'qcou_certificate_settings',
      __('Certificate Template & Placement', 'quick-courses-builder'),
      [__CLASS__, 'render'],
      QCOU_Constants::CPT_CERTIFICATE,
      'normal',
      'high'
    );
  }

  public static function render(WP_Post $post): void {
    QCOU_Security::deny_if_cannot_manage();
    wp_nonce_field('qcou_save_certificate', 'qcou_certificate_nonce');

    $img_id = absint(get_post_meta($post->ID, '_qcb_cert_template_image_id', true));
    $image_url = (string) get_post_meta($post->ID, '_qcb_cert_template_image_url', true);

    if ($image_url === '' && $img_id > 0) {
      $attachment_url = wp_get_attachment_url($img_id);
      if (is_string($attachment_url) && $attachment_url !== '') {
        $image_url = $attachment_url;
      }
    }

    $logo_id = absint(get_post_meta($post->ID, '_qcb_cert_logo_id', true));
    $logo_x = (int) get_post_meta($post->ID, '_qcb_cert_logo_x', true);
    $logo_y = (int) get_post_meta($post->ID, '_qcb_cert_logo_y', true);

    $title_text = (string) get_post_meta($post->ID, '_qcb_cert_title_text', true);
    $title_x = (int) get_post_meta($post->ID, '_qcb_cert_title_x', true);
    $title_y = (int) get_post_meta($post->ID, '_qcb_cert_title_y', true);

    $bg_color = (string) get_post_meta($post->ID, '_qcb_cert_bg_color', true);
    $bg_gradient = (string) get_post_meta($post->ID, '_qcb_cert_bg_gradient', true);

    $name_x = (int) get_post_meta($post->ID, '_qcb_cert_name_x', true);
    $name_y = (int) get_post_meta($post->ID, '_qcb_cert_name_y', true);
    $name_size = (int) get_post_meta($post->ID, '_qcb_cert_name_font_size', true);
    $name_color = (string) get_post_meta($post->ID, '_qcb_cert_name_color', true);

    $date_enabled = (int) get_post_meta($post->ID, '_qcb_cert_date_enabled', true);
    $date_x = (int) get_post_meta($post->ID, '_qcb_cert_date_x', true);
    $date_y = (int) get_post_meta($post->ID, '_qcb_cert_date_y', true);
    $date_size = (int) get_post_meta($post->ID, '_qcb_cert_date_font_size', true);
    $date_color = (string) get_post_meta($post->ID, '_qcb_cert_date_color', true);

    if ($name_size <= 0) $name_size = 32;
    if ($name_color === '') $name_color = '#111111';
    if ($date_size <= 0) $date_size = 14;
    if ($date_color === '') $date_color = '#111111';
    if ($bg_color === '') $bg_color = '#ffffff';
    if ($bg_gradient === '') $bg_gradient = 'linear-gradient(135deg,#ffffff,#f2f8ff)';

    echo '<div class="qcb-cert-grid">';

    echo '<div class="qcb-cert-card">';
    echo '<h3>' . esc_html__('Background Template', 'quick-courses-builder') . '</h3>';
    echo '<p class="description">' . esc_html__('Use an uploaded image URL or a media-library image. If image generation fails, completion is still recorded as text-only.', 'quick-courses-builder') . '</p>';

    echo '<p><label><strong>' . esc_html__('Template Image URL', 'quick-courses-builder') . '</strong></label><br>';
    echo '<input type="url" class="widefat" name="qcou_cert_template_image_url" value="' . esc_attr($image_url) . '" placeholder="https://example.com/certificate.jpg"></p>';

    echo '<input type="hidden" name="qcou_cert_template_image_id" id="qcou_cert_template_image_id" value="' . esc_attr((string) $img_id) . '">';
    echo '<div id="qcb-cert-preview" class="qcb-cert-preview">';
    if ($img_id > 0) {
      echo wp_get_attachment_image($img_id, 'medium');
    } elseif ($image_url !== '') {
      echo '<img src="' . esc_url($image_url) . '" alt="" style="max-width:100%;height:auto;">';
    } else {
      echo '<span>' . esc_html__('No template image selected.', 'quick-courses-builder') . '</span>';
    }
    echo '</div>';

    echo '<p><button type="button" class="button" id="qcb-cert-pick">' . esc_html__('Select Template Image', 'quick-courses-builder') . '</button> ';
    echo '<button type="button" class="button" id="qcb-cert-clear">' . esc_html__('Clear', 'quick-courses-builder') . '</button></p>';
    echo '</div>';

    echo '<div class="qcb-cert-card">';
    echo '<h3>' . esc_html__('Certificate Builder Controls', 'quick-courses-builder') . '</h3>';

    echo '<p><label><strong>' . esc_html__('Certificate Title', 'quick-courses-builder') . '</strong></label><br>';
    echo '<input type="text" class="widefat" name="qcou_cert_title_text" value="' . esc_attr($title_text) . '" placeholder="' . esc_attr__('Certificate of Completion', 'quick-courses-builder') . '"></p>';

    echo '<p><label><strong>' . esc_html__('Background Color', 'quick-courses-builder') . '</strong></label><br>';
    echo '<input type="text" name="qcou_cert_bg_color" value="' . esc_attr($bg_color) . '" placeholder="#ffffff"></p>';

    echo '<p><label><strong>' . esc_html__('Background Gradient', 'quick-courses-builder') . '</strong></label><br>';
    echo '<input type="text" class="widefat" name="qcou_cert_bg_gradient" value="' . esc_attr($bg_gradient) . '" placeholder="linear-gradient(135deg,#fff,#f2f8ff)"></p>';

    echo '<p><label><strong>' . esc_html__('Logo Image ID', 'quick-courses-builder') . '</strong></label><br>';
    echo '<input type="number" name="qcou_cert_logo_id" value="' . esc_attr((string) $logo_id) . '"></p>';

    echo '<table class="form-table" role="presentation"><tbody>';
    echo '<tr><th>' . esc_html__('Title X/Y', 'quick-courses-builder') . '</th><td><input type="number" name="qcou_cert_title_x" value="' . esc_attr((string) $title_x) . '"> <input type="number" name="qcou_cert_title_y" value="' . esc_attr((string) $title_y) . '"></td></tr>';
    echo '<tr><th>' . esc_html__('Logo X/Y', 'quick-courses-builder') . '</th><td><input type="number" name="qcou_cert_logo_x" value="' . esc_attr((string) $logo_x) . '"> <input type="number" name="qcou_cert_logo_y" value="' . esc_attr((string) $logo_y) . '"></td></tr>';
    echo '<tr><th>' . esc_html__('Name X/Y', 'quick-courses-builder') . '</th><td><input type="number" name="qcou_cert_name_x" value="' . esc_attr((string) $name_x) . '"> <input type="number" name="qcou_cert_name_y" value="' . esc_attr((string) $name_y) . '"></td></tr>';
    echo '<tr><th>' . esc_html__('Name size/color', 'quick-courses-builder') . '</th><td><input type="number" name="qcou_cert_name_font_size" value="' . esc_attr((string) $name_size) . '"> <input type="text" name="qcou_cert_name_color" value="' . esc_attr($name_color) . '"></td></tr>';
    echo '<tr><th>' . esc_html__('Date enabled', 'quick-courses-builder') . '</th><td><label><input type="checkbox" name="qcou_cert_date_enabled" value="1" ' . checked(1, $date_enabled, false) . '> ' . esc_html__('Include issue date', 'quick-courses-builder') . '</label></td></tr>';
    echo '<tr><th>' . esc_html__('Date X/Y', 'quick-courses-builder') . '</th><td><input type="number" name="qcou_cert_date_x" value="' . esc_attr((string) $date_x) . '"> <input type="number" name="qcou_cert_date_y" value="' . esc_attr((string) $date_y) . '"></td></tr>';
    echo '<tr><th>' . esc_html__('Date size/color', 'quick-courses-builder') . '</th><td><input type="number" name="qcou_cert_date_font_size" value="' . esc_attr((string) $date_size) . '"> <input type="text" name="qcou_cert_date_color" value="' . esc_attr($date_color) . '"></td></tr>';
    echo '</tbody></table>';
    echo '</div>';

    echo '</div>';

    ?>
    <script>
      (function(){
        var pickBtn = document.getElementById('qcb-cert-pick');
        var clearBtn = document.getElementById('qcb-cert-clear');
        var input = document.getElementById('qcou_cert_template_image_id');
        var preview = document.getElementById('qcb-cert-preview');
        if (!pickBtn || !input || !preview || !window.wp || !wp.media) return;

        var frame;
        pickBtn.addEventListener('click', function(){
          if (frame) { frame.open(); return; }
          frame = wp.media({
            title: 'Select Certificate Image',
            button: { text: 'Use this image' },
            multiple: false
          });
          frame.on('select', function(){
            var att = frame.state().get('selection').first().toJSON();
            input.value = att.id || '';
            preview.innerHTML = att.sizes && att.sizes.medium ? '<img src="'+att.sizes.medium.url+'" style="max-width:100%;height:auto;">' : '<img src="'+att.url+'" style="max-width:100%;height:auto;">';
          });
          frame.open();
        });

        clearBtn.addEventListener('click', function(){
          input.value = '';
          preview.innerHTML = '<span>No template image selected.</span>';
        });
      })();
    </script>
    <?php
  }

  public static function save(int $post_id, WP_Post $post): void {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;

    if (!isset($_POST['qcou_certificate_nonce']) || !wp_verify_nonce((string) $_POST['qcou_certificate_nonce'], 'qcou_save_certificate')) {
      return;
    }

    if (!current_user_can(QCOU_Constants::CAP_MANAGE, $post_id)) {
      return;
    }

    try {
      $image_id = isset($_POST['qcou_cert_template_image_id']) ? absint($_POST['qcou_cert_template_image_id']) : 0;
      $image_url = isset($_POST['qcou_cert_template_image_url']) ? esc_url_raw(trim((string) $_POST['qcou_cert_template_image_url'])) : '';

      if ($image_id > 0) {
        update_post_meta($post_id, '_qcb_cert_template_image_id', $image_id);
        if ($image_url === '') {
          $resolved = wp_get_attachment_url($image_id);
          if (is_string($resolved) && $resolved !== '') {
            $image_url = $resolved;
          }
        }
      } else {
        delete_post_meta($post_id, '_qcb_cert_template_image_id');
      }

      if ($image_url !== '') {
        update_post_meta($post_id, '_qcb_cert_template_image_url', $image_url);
      } else {
        delete_post_meta($post_id, '_qcb_cert_template_image_url');
      }

      $fields_int = [
        '_qcb_cert_logo_id' => 'qcou_cert_logo_id',
        '_qcb_cert_logo_x' => 'qcou_cert_logo_x',
        '_qcb_cert_logo_y' => 'qcou_cert_logo_y',
        '_qcb_cert_title_x' => 'qcou_cert_title_x',
        '_qcb_cert_title_y' => 'qcou_cert_title_y',
        '_qcb_cert_name_x' => 'qcou_cert_name_x',
        '_qcb_cert_name_y' => 'qcou_cert_name_y',
        '_qcb_cert_name_font_size' => 'qcou_cert_name_font_size',
        '_qcb_cert_date_x' => 'qcou_cert_date_x',
        '_qcb_cert_date_y' => 'qcou_cert_date_y',
        '_qcb_cert_date_font_size' => 'qcou_cert_date_font_size',
      ];

      foreach ($fields_int as $meta_key => $post_key) {
        $value = isset($_POST[$post_key]) ? (int) $_POST[$post_key] : 0;
        update_post_meta($post_id, $meta_key, $value);
      }

      $fields_text = [
        '_qcb_cert_title_text' => 'qcou_cert_title_text',
        '_qcb_cert_bg_gradient' => 'qcou_cert_bg_gradient',
      ];

      foreach ($fields_text as $meta_key => $post_key) {
        $value = isset($_POST[$post_key]) ? sanitize_text_field((string) $_POST[$post_key]) : '';
        if ($value === '') {
          delete_post_meta($post_id, $meta_key);
        } else {
          update_post_meta($post_id, $meta_key, $value);
        }
      }

      $bg_color = isset($_POST['qcou_cert_bg_color']) ? sanitize_text_field((string) $_POST['qcou_cert_bg_color']) : '#ffffff';
      update_post_meta($post_id, '_qcb_cert_bg_color', self::sanitize_hex($bg_color, '#ffffff'));

      $name_color = isset($_POST['qcou_cert_name_color']) ? sanitize_text_field((string) $_POST['qcou_cert_name_color']) : '#111111';
      update_post_meta($post_id, '_qcb_cert_name_color', self::sanitize_hex($name_color, '#111111'));

      $date_color = isset($_POST['qcou_cert_date_color']) ? sanitize_text_field((string) $_POST['qcou_cert_date_color']) : '#111111';
      update_post_meta($post_id, '_qcb_cert_date_color', self::sanitize_hex($date_color, '#111111'));

      update_post_meta($post_id, '_qcb_cert_date_enabled', isset($_POST['qcou_cert_date_enabled']) ? 1 : 0);

      // Lite: keep certificate customization simple.
      if (!qcou_is_premium_active()) {
        update_post_meta($post_id, '_qcb_cert_bg_gradient', 'linear-gradient(135deg,#ffffff,#f2f8ff)');
        update_post_meta($post_id, '_qcb_cert_logo_id', 0);
      }
    } catch (Throwable $e) {
      // Block fatals and keep editor usable.
      QCOU_Admin_Notices::add($post_id, __('Certificate settings could not be fully saved. Please review fields and try again.', 'quick-courses-builder'));
    }
  }

  private static function sanitize_hex(string $val, string $fallback): string {
    $val = trim($val);
    if ($val === '') return $fallback;
    if ($val[0] !== '#') $val = '#' . $val;
    if (preg_match('/^#[0-9a-fA-F]{6}$/', $val)) return strtolower($val);
    return $fallback;
  }

  public static function enqueue(string $hook): void {
    if (!in_array($hook, ['post.php', 'post-new.php'], true)) return;

    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== QCOU_Constants::CPT_CERTIFICATE) return;

    wp_enqueue_media();
    wp_enqueue_style('qcb-admin', QCOU_URL . 'assets/css/admin.css', [], QCOU_VERSION);
  }
}
