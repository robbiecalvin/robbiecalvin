<?php
if (!defined('ABSPATH')) exit;

final class QCOU_Test_Builder {

  private const META_VER = '_qcb_test_schema_version';
  private const META_Q   = '_qcb_test_questions';

  public static function register(): void {
    add_action('add_meta_boxes', [__CLASS__, 'add_meta_boxes']);
    add_action('save_post_' . QCOU_Constants::CPT_TEST, [__CLASS__, 'save'], 10, 2);
    add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue']);
  }

  public static function enqueue(string $hook): void {
    // Only load on qc_test editor screens
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen || $screen->post_type !== QCOU_Constants::CPT_TEST) return;
    if (!in_array($screen->base, ['post', 'post-new'], true)) return;

    wp_enqueue_script(
      'qcb-admin-test-builder',
      QCOU_URL . 'assets/js/admin-test-builder.js',
      ['jquery'],
      QCOU_VERSION,
      true
    );
  }

  public static function add_meta_boxes(): void {
    add_meta_box(
      'qcou_test_builder',
      __('Test Builder', 'quick-courses-builder'),
      [__CLASS__, 'render'],
      QCOU_Constants::CPT_TEST,
      'normal',
      'high'
    );
  }

  public static function render(WP_Post $post): void {
    QCOU_Security::deny_if_cannot_manage();
    wp_nonce_field('qcou_save_test', 'qcou_test_nonce');

    $questions = get_post_meta($post->ID, self::META_Q, true);
    if (!is_array($questions)) $questions = [];

    echo '<div class="qcb-test-builder" data-qcb-test-builder="1">';

    echo '<p style="margin:0 0 10px 0;">';
    echo esc_html__('Add multiple choice questions. Select exactly one correct answer per question.', 'quick-courses-builder');
    echo '</p>';

    echo '<div class="qcb-test-questions" id="qcb-test-questions">';
    // Existing questions
    foreach ($questions as $qi => $q) {
      self::render_question($qi, $q);
    }
    echo '</div>';

    echo '<button type="button" class="button" id="qcb-add-question">' . esc_html__('Add Question', 'quick-courses-builder') . '</button>';

    echo '</div>';
  }

  private static function render_question(int $qi, array $q): void {
    $id = isset($q['id']) ? (string) $q['id'] : ('q_' . $qi);
    $text = isset($q['question']) ? (string) $q['question'] : '';
    $answers = isset($q['answers']) && is_array($q['answers']) ? $q['answers'] : [''];
    $correct = isset($q['correct_index']) ? (int) $q['correct_index'] : 0;

    echo '<div class="qcb-question" data-qcb-question>';

    echo '<div style="display:flex;justify-content:space-between;align-items:center;">';
    echo '<strong>' . esc_html__('Question', 'quick-courses-builder') . '</strong>';
    echo '<button type="button" class="button-link-delete qcb-remove-question">' . esc_html__('Remove', 'quick-courses-builder') . '</button>';
    echo '</div>';

    echo '<input type="hidden" name="qcou_test[q][' . esc_attr($qi) . '][id]" value="' . esc_attr($id) . '">';

    echo '<p><textarea name="qcou_test[q][' . esc_attr($qi) . '][question]" rows="2" style="width:100%;">' . esc_textarea($text) . '</textarea></p>';

    echo '<div class="qcb-answers" data-qcb-answers>';
    foreach ($answers as $ai => $a) {
      $a = (string) $a;
      echo '<div class="qcb-answer" data-qcb-answer style="display:flex;gap:10px;align-items:center;margin:6px 0;">';
      echo '<input type="radio" name="qcou_test[q][' . esc_attr($qi) . '][correct_index]" value="' . esc_attr($ai) . '" ' . checked($correct, $ai, false) . '>';
      echo '<input type="text" name="qcou_test[q][' . esc_attr($qi) . '][answers][' . esc_attr($ai) . ']" value="' . esc_attr($a) . '" style="width:100%;">';
      echo '<button type="button" class="button qcb-remove-answer" style="white-space:nowrap;">' . esc_html__('Remove', 'quick-courses-builder') . '</button>';
      echo '</div>';
    }
    echo '</div>';

    echo '<button type="button" class="button qcb-add-answer">' . esc_html__('Add Answer', 'quick-courses-builder') . '</button>';

    echo '<hr style="margin:16px 0;">';
    echo '</div>';
  }

  public static function save(int $post_id, WP_Post $post): void {
    if (!isset($_POST['qcou_test_nonce']) || !wp_verify_nonce($_POST['qcou_test_nonce'], 'qcou_save_test')) {
      return;
    }

    if (!current_user_can(QCOU_Constants::CAP_MANAGE, $post_id)) {
      return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    if (wp_is_post_autosave($post_id)) return;

    $raw = $_POST['qcou_test']['q'] ?? [];
    if (!is_array($raw)) $raw = [];

    $questions = [];
    foreach ($raw as $q) {
      if (!is_array($q)) continue;

      $qid = isset($q['id']) ? sanitize_key((string) $q['id']) : '';
      if ($qid === '') {
        $qid = sanitize_key(uniqid('qcbq_', true));
      }

      $qt = isset($q['question']) ? sanitize_textarea_field((string) $q['question']) : '';
      $answers_raw = isset($q['answers']) && is_array($q['answers']) ? $q['answers'] : [];

      $answers = [];
      foreach ($answers_raw as $a) {
        $a = sanitize_text_field((string) $a);
        if ($a !== '') $answers[] = $a;
      }

      // Require at least 2 answers for a meaningful multiple choice question
      if ($qt === '' || count($answers) < 2) {
        continue;
      }

      $correct = isset($q['correct_index']) ? (int) $q['correct_index'] : 0;
      if ($correct < 0) $correct = 0;
      if ($correct >= count($answers)) $correct = 0;

      $questions[] = [
        'id' => $qid,
        'question' => $qt,
        'answers' => array_values($answers),
        'correct_index' => $correct,
      ];
    }

    update_post_meta($post_id, self::META_VER, 1);
    update_post_meta($post_id, self::META_Q, $questions);
  }

  public static function get_questions(int $test_id): array {
    $q = get_post_meta($test_id, self::META_Q, true);
    return is_array($q) ? $q : [];
  }
}

