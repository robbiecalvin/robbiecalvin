# Quick Courses -- Visual To‑Do

-   Set background to branded sky blue on:
    -   Courses
    -   Tests
    -   Certificates
-   Change buttons to blue with white text
