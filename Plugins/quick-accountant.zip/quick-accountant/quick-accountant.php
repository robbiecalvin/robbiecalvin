<?php
/**
 * Plugin Name: Quick Accountant
 * Description: Accounting-lite tracker for income, expenses, budgets, and reports inside WordPress.
 * Version: 1.0.0
 * Author: QuickWoo by Robbie Calvin
 * Author URI: https://quickwoo.pro
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: quick-accountant
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/quick-core/bootstrap.php';
}

define('QACC_PLUGIN_VERSION', '1.0.0');
define('QACC_PLUGIN_FILE', __FILE__);
define('QACC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('QACC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('QACC_SETTINGS_OPTION', 'qacc_settings');

function qacc_is_premium_active() {
    if ( function_exists( 'qwoo_has_active_license' ) ) {
        return (bool) qwoo_has_active_license( array( 'quick-accountant' ) );
    }

    return false;
}

require_once QACC_PLUGIN_DIR . 'includes/helpers.php';
require_once QACC_PLUGIN_DIR . 'includes/class-qa-activator.php';
require_once QACC_PLUGIN_DIR . 'includes/class-qa-admin.php';
require_once QACC_PLUGIN_DIR . 'includes/class-qa-transactions.php';
require_once QACC_PLUGIN_DIR . 'includes/class-qa-categories.php';
require_once QACC_PLUGIN_DIR . 'includes/class-qa-budgets.php';
require_once QACC_PLUGIN_DIR . 'includes/class-qa-reports.php';
require_once QACC_PLUGIN_DIR . 'includes/class-qa-settings.php';
require_once QACC_PLUGIN_DIR . 'includes/class-qa-export.php';

register_activation_hook(__FILE__, array('QACC_Activator', 'activate'));

function qacc_accountant_bootstrap()
{
    if (!is_admin()) {
        return;
    }

    QACC_Admin::instance();
}
add_action('plugins_loaded', 'qacc_accountant_bootstrap');

function qacc_pro_auto_sync_enabled()
{
    if (!qacc_is_premium_active()) {
        return false;
    }

    $settings = qacc_get_settings();
    return !empty($settings['enable_woo_auto_sync']);
}

function qacc_sync_order_to_ledger($order_id)
{
    if (!qacc_pro_auto_sync_enabled() || !function_exists('wc_get_order')) {
        return;
    }

    $order_id = absint($order_id);
    if ($order_id <= 0) {
        return;
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        return;
    }

    global $wpdb;
    $ledger_table = qacc_table_ledger();

    $exists = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ledger_table} WHERE source = %s AND order_id = %d",
            'woocommerce',
            $order_id
        )
    );

    if ($exists > 0) {
        return;
    }

    $gross = (float) $order->get_total();
    $tax = (float) $order->get_total_tax();
    $net = $gross - $tax;

    $customer_name = trim((string) $order->get_formatted_billing_full_name());
    if ($customer_name === '') {
        $customer_name = (string) $order->get_billing_email();
    }

    $created_at = current_time('mysql');

    $wpdb->insert(
        $ledger_table,
        array(
            'type' => 'income',
            'source' => 'woocommerce',
            'order_id' => $order_id,
            'gross_amount' => number_format($gross, 2, '.', ''),
            'tax_amount' => number_format($tax, 2, '.', ''),
            'net_amount' => number_format($net, 2, '.', ''),
            'customer_name' => sanitize_text_field($customer_name),
            'created_at' => $created_at,
        ),
        array('%s', '%s', '%d', '%f', '%f', '%f', '%s', '%s')
    );
}

add_action('woocommerce_order_status_completed', 'qacc_sync_order_to_ledger', 10, 1);
add_action('woocommerce_order_status_processing', 'qacc_sync_order_to_ledger', 10, 1);

add_action(
    'plugins_loaded',
    static function () {
        if (function_exists('qwoo_register_plugin')) {
            qwoo_register_plugin('quick-accountant', array(
                'name' => 'Quick Woo Accountant',
                'version' => QACC_PLUGIN_VERSION,
                'file' => QACC_PLUGIN_FILE,
                'features' => array('transactions', 'budgets', 'reports'),
            ));
        }

        if (function_exists('qwoo_event')) {
            qwoo_event('plugin_booted', array('plugin' => 'quick-accountant', 'version' => QACC_PLUGIN_VERSION));
        }
    },
    20
);

if ( ! function_exists( 'qwoo_quick_accountant_license_bootstrap' ) ) {
    function qwoo_quick_accountant_license_bootstrap() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu', 'qwoo_quick_accountant_license_menu' );
        add_action( 'admin_post_qwoo_quick_accountant_activate_license', 'qwoo_quick_accountant_license_handle_activate' );
        add_action( 'admin_post_qwoo_quick_accountant_deactivate_license', 'qwoo_quick_accountant_license_handle_deactivate' );
    }
    add_action( 'plugins_loaded', 'qwoo_quick_accountant_license_bootstrap', 30 );

    function qwoo_quick_accountant_license_option_key() {
        return 'qwoo_quick_accountant_license';
    }

    function qwoo_quick_accountant_license_product_scope() {
        return array( 'quick-accountant' );
    }

    function qwoo_quick_accountant_license_get_data() {
        $defaults = array(
            'license_key' => '',
            'license_status' => 'inactive',
            'license_message' => '',
        );

        $saved = get_option( qwoo_quick_accountant_license_option_key(), array() );
        $saved = is_array( $saved ) ? $saved : array();

        return wp_parse_args( $saved, $defaults );
    }

    function qwoo_quick_accountant_license_save_data( $data ) {
        $data = is_array( $data ) ? $data : array();

        $clean = array(
            'license_key' => sanitize_text_field( (string) ( $data['license_key'] ?? '' ) ),
            'license_status' => sanitize_key( (string) ( $data['license_status'] ?? 'inactive' ) ),
            'license_message' => sanitize_text_field( (string) ( $data['license_message'] ?? '' ) ),
        );

        update_option( qwoo_quick_accountant_license_option_key(), $clean, false );
        return $clean;
    }

    function qwoo_quick_accountant_license_menu() {
        add_options_page(
            'Laccountant License',
            'Laccountant License',
            'manage_options',
            'qwoo-quick-accountant-license',
            'qwoo_quick_accountant_license_render_page'
        );
    }

    function qwoo_quick_accountant_license_render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = qwoo_quick_accountant_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );

        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $status = qlic_get_license_status_for_key_products( $license_key, qwoo_quick_accountant_license_product_scope() );
            if ( is_array( $status ) ) {
                $data['license_status'] = sanitize_key( (string) ( $status['status'] ?? $data['license_status'] ) );
                $data['license_message'] = sanitize_text_field( (string) ( $status['message'] ?? $data['license_message'] ) );
                if ( ! empty( $status['valid'] ) && ! empty( $status['domain_active'] ) ) {
                    $data['license_status'] = 'active';
                }
                qwoo_quick_accountant_license_save_data( $data );
            }
        }

        $notice = isset( $_GET['qwoo_license_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qwoo_license_notice'] ) ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Laccountant License', 'quick-accountant' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-accountant' ), (string) ( $data['license_status'] ?? 'inactive' ) ) ); ?></p>
            <?php if ( ! empty( $data['license_message'] ) ) : ?>
                <p><?php echo esc_html( (string) $data['license_message'] ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_accountant_activate_license" />
                <?php wp_nonce_field( 'qwoo_quick_accountant_activate_license', 'qwoo_quick_accountant_activate_license_nonce' ); ?>
                <p>
                    <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( (string) ( $data['license_key'] ?? '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button type="submit" class="button button-primary"><?php echo esc_html__( 'Activate License', 'quick-accountant' ); ?></button>
                </p>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_accountant_deactivate_license" />
                <?php wp_nonce_field( 'qwoo_quick_accountant_deactivate_license', 'qwoo_quick_accountant_deactivate_license_nonce' ); ?>
                <p><button type="submit" class="button"><?php echo esc_html__( 'Deactivate License', 'quick-accountant' ); ?></button></p>
            </form>
        </div>
        <?php
    }

    function qwoo_quick_accountant_license_redirect( $message ) {
        $url = add_query_arg(
            array(
                'page' => 'qwoo-quick-accountant-license',
                'qwoo_license_notice' => rawurlencode( (string) $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    function qwoo_quick_accountant_license_handle_activate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-accountant' ) );
        }

        check_admin_referer( 'qwoo_quick_accountant_activate_license', 'qwoo_quick_accountant_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        if ( '' === $license_key ) {
            qwoo_quick_accountant_license_save_data(
                array(
                    'license_key' => '',
                    'license_status' => 'inactive',
                    'license_message' => 'License key is required.',
                )
            );
            qwoo_quick_accountant_license_redirect( 'License key is required.' );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            qwoo_quick_accountant_license_save_data(
                array(
                    'license_key' => $license_key,
                    'license_status' => 'invalid',
                    'license_message' => 'Quick License plugin is required for activation.',
                )
            );
            qwoo_quick_accountant_license_redirect( 'Quick License plugin is required for activation.' );
        }

        $result = qlic_activate_license_key_for_products( $license_key, qwoo_quick_accountant_license_product_scope() );
        $data = array(
            'license_key' => $license_key,
            'license_status' => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'license_message' => sanitize_text_field( (string) ( $result['message'] ?? 'License validation failed.' ) ),
        );
        if ( ! empty( $result['valid'] ) ) {
            $data['license_status'] = 'active';
        }

        qwoo_quick_accountant_license_save_data( $data );
        qwoo_quick_accountant_license_redirect( (string) $data['license_message'] );
    }

    function qwoo_quick_accountant_license_handle_deactivate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-accountant' ) );
        }

        check_admin_referer( 'qwoo_quick_accountant_deactivate_license', 'qwoo_quick_accountant_deactivate_license_nonce' );

        $data = qwoo_quick_accountant_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );
        $message = 'License deactivated.';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products( $license_key, qwoo_quick_accountant_license_product_scope() );
            if ( is_array( $result ) && ! empty( $result['message'] ) ) {
                $message = sanitize_text_field( (string) $result['message'] );
            }
        }

        qwoo_quick_accountant_license_save_data(
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => $message,
            )
        );

        qwoo_quick_accountant_license_redirect( $message );
    }
}
