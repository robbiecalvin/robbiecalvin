<?php
/**
 * Plugin Name: Quick Course Builder
 * Description: Production-grade course creation and delivery system (Courses, Modules, Tests, Certificates).
 * Version: 1.0.0
 * Author: QuickWoo by Robbie Calvin
 * Author URI: https://quickwoo.pro
 * Requires at least: 6.2
 * Requires PHP: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'QUICK_CORE_VERSION' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'includes/quick-core/bootstrap.php';
}

define('QCOU_PATH', plugin_dir_path(__FILE__));
define('QCOU_URL', plugin_dir_url(__FILE__));
define('QCOU_VERSION', '1.0.0');

require_once QCOU_PATH . 'includes/class-qcb-plugin.php';

function qcou_boot() {
  return QCOU_Plugin::instance();
}

qcou_boot();

function qcou_is_premium_active() {
  if (function_exists('qwoo_has_active_license')) {
    return (bool) qwoo_has_active_license(array('quick-course-builder'));
  }

  return false;
}


add_action(
  'plugins_loaded',
  static function () {
    if (function_exists('qwoo_register_plugin')) {
      qwoo_register_plugin('quick-course-builder', array(
        'name' => 'Quick Woo Course Builder',
        'version' => QCOU_VERSION,
        'file' => __FILE__,
        'features' => array('courses', 'modules', 'tests', 'certificates'),
      ));
    }

    if (function_exists('qwoo_event')) {
      qwoo_event('plugin_booted', array('plugin' => 'quick-course-builder', 'version' => QCOU_VERSION));
    }
  },
  20
);

if ( ! function_exists( 'qwoo_quick_course_builder_license_bootstrap' ) ) {
    function qwoo_quick_course_builder_license_bootstrap() {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu', 'qwoo_quick_course_builder_license_menu' );
        add_action( 'admin_post_qwoo_quick_course_builder_activate_license', 'qwoo_quick_course_builder_license_handle_activate' );
        add_action( 'admin_post_qwoo_quick_course_builder_deactivate_license', 'qwoo_quick_course_builder_license_handle_deactivate' );
    }
    add_action( 'plugins_loaded', 'qwoo_quick_course_builder_license_bootstrap', 30 );

    function qwoo_quick_course_builder_license_option_key() {
        return 'qwoo_quick_course_builder_license';
    }

    function qwoo_quick_course_builder_license_product_scope() {
        return array( 'quick-course-builder' );
    }

    function qwoo_quick_course_builder_license_get_data() {
        $defaults = array(
            'license_key' => '',
            'license_status' => 'inactive',
            'license_message' => '',
        );

        $saved = get_option( qwoo_quick_course_builder_license_option_key(), array() );
        $saved = is_array( $saved ) ? $saved : array();

        return wp_parse_args( $saved, $defaults );
    }

    function qwoo_quick_course_builder_license_save_data( $data ) {
        $data = is_array( $data ) ? $data : array();

        $clean = array(
            'license_key' => sanitize_text_field( (string) ( $data['license_key'] ?? '' ) ),
            'license_status' => sanitize_key( (string) ( $data['license_status'] ?? 'inactive' ) ),
            'license_message' => sanitize_text_field( (string) ( $data['license_message'] ?? '' ) ),
        );

        update_option( qwoo_quick_course_builder_license_option_key(), $clean, false );
        return $clean;
    }

    function qwoo_quick_course_builder_license_menu() {
        add_options_page(
            'Lcourse builder License',
            'Lcourse builder License',
            'manage_options',
            'qwoo-quick-course-builder-license',
            'qwoo_quick_course_builder_license_render_page'
        );
    }

    function qwoo_quick_course_builder_license_render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $data = qwoo_quick_course_builder_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );

        if ( '' !== $license_key && function_exists( 'qlic_get_license_status_for_key_products' ) ) {
            $status = qlic_get_license_status_for_key_products( $license_key, qwoo_quick_course_builder_license_product_scope() );
            if ( is_array( $status ) ) {
                $data['license_status'] = sanitize_key( (string) ( $status['status'] ?? $data['license_status'] ) );
                $data['license_message'] = sanitize_text_field( (string) ( $status['message'] ?? $data['license_message'] ) );
                if ( ! empty( $status['valid'] ) && ! empty( $status['domain_active'] ) ) {
                    $data['license_status'] = 'active';
                }
                qwoo_quick_course_builder_license_save_data( $data );
            }
        }

        $notice = isset( $_GET['qwoo_license_notice'] ) ? sanitize_text_field( wp_unslash( $_GET['qwoo_license_notice'] ) ) : '';
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Lcourse builder License', 'quick-course-builder' ); ?></h1>
            <?php if ( '' !== $notice ) : ?>
                <div class="notice notice-info"><p><?php echo esc_html( $notice ); ?></p></div>
            <?php endif; ?>
            <p><?php echo esc_html( sprintf( __( 'Current status: %s', 'quick-course-builder' ), (string) ( $data['license_status'] ?? 'inactive' ) ) ); ?></p>
            <?php if ( ! empty( $data['license_message'] ) ) : ?>
                <p><?php echo esc_html( (string) $data['license_message'] ); ?></p>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_course_builder_activate_license" />
                <?php wp_nonce_field( 'qwoo_quick_course_builder_activate_license', 'qwoo_quick_course_builder_activate_license_nonce' ); ?>
                <p>
                    <input type="text" class="regular-text" name="license_key" value="<?php echo esc_attr( (string) ( $data['license_key'] ?? '' ) ); ?>" placeholder="XXXX-XXXX-XXXX-XXXX" />
                    <button type="submit" class="button button-primary"><?php echo esc_html__( 'Activate License', 'quick-course-builder' ); ?></button>
                </p>
            </form>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="qwoo_quick_course_builder_deactivate_license" />
                <?php wp_nonce_field( 'qwoo_quick_course_builder_deactivate_license', 'qwoo_quick_course_builder_deactivate_license_nonce' ); ?>
                <p><button type="submit" class="button"><?php echo esc_html__( 'Deactivate License', 'quick-course-builder' ); ?></button></p>
            </form>
        </div>
        <?php
    }

    function qwoo_quick_course_builder_license_redirect( $message ) {
        $url = add_query_arg(
            array(
                'page' => 'qwoo-quick-course-builder-license',
                'qwoo_license_notice' => rawurlencode( (string) $message ),
            ),
            admin_url( 'options-general.php' )
        );

        wp_safe_redirect( $url );
        exit;
    }

    function qwoo_quick_course_builder_license_handle_activate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-course-builder' ) );
        }

        check_admin_referer( 'qwoo_quick_course_builder_activate_license', 'qwoo_quick_course_builder_activate_license_nonce' );

        $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
        if ( '' === $license_key ) {
            qwoo_quick_course_builder_license_save_data(
                array(
                    'license_key' => '',
                    'license_status' => 'inactive',
                    'license_message' => 'License key is required.',
                )
            );
            qwoo_quick_course_builder_license_redirect( 'License key is required.' );
        }

        if ( ! function_exists( 'qlic_activate_license_key_for_products' ) ) {
            qwoo_quick_course_builder_license_save_data(
                array(
                    'license_key' => $license_key,
                    'license_status' => 'invalid',
                    'license_message' => 'Quick License plugin is required for activation.',
                )
            );
            qwoo_quick_course_builder_license_redirect( 'Quick License plugin is required for activation.' );
        }

        $result = qlic_activate_license_key_for_products( $license_key, qwoo_quick_course_builder_license_product_scope() );
        $data = array(
            'license_key' => $license_key,
            'license_status' => sanitize_key( (string) ( $result['status'] ?? 'invalid' ) ),
            'license_message' => sanitize_text_field( (string) ( $result['message'] ?? 'License validation failed.' ) ),
        );
        if ( ! empty( $result['valid'] ) ) {
            $data['license_status'] = 'active';
        }

        qwoo_quick_course_builder_license_save_data( $data );
        qwoo_quick_course_builder_license_redirect( (string) $data['license_message'] );
    }

    function qwoo_quick_course_builder_license_handle_deactivate() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized request.', 'quick-course-builder' ) );
        }

        check_admin_referer( 'qwoo_quick_course_builder_deactivate_license', 'qwoo_quick_course_builder_deactivate_license_nonce' );

        $data = qwoo_quick_course_builder_license_get_data();
        $license_key = sanitize_text_field( (string) ( $data['license_key'] ?? '' ) );
        $message = 'License deactivated.';

        if ( '' !== $license_key && function_exists( 'qlic_deactivate_license_key_for_products' ) ) {
            $result = qlic_deactivate_license_key_for_products( $license_key, qwoo_quick_course_builder_license_product_scope() );
            if ( is_array( $result ) && ! empty( $result['message'] ) ) {
                $message = sanitize_text_field( (string) $result['message'] );
            }
        }

        qwoo_quick_course_builder_license_save_data(
            array(
                'license_key' => '',
                'license_status' => 'inactive',
                'license_message' => $message,
            )
        );

        qwoo_quick_course_builder_license_redirect( $message );
    }
}
